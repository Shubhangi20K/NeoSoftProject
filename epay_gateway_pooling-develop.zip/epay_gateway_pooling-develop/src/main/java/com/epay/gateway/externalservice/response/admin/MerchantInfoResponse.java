package com.epay.gateway.externalservice.response.admin;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.util.List;

/**
 * Class Name: MerchantInfoResponse
 * *
 * Description: dto for MerchantInfo which contains merchant information
 * *
 * Author: Gireesh M
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * Version:1.0
 */
@Data
@RequiredArgsConstructor
public class MerchantInfoResponse {

    @JsonProperty("mId")
    private String mId;
    private String isActive;
    private String merchantName;
    private String logoUrl;
    private String countryCode;
    private String currency;
    private String preferredPayMode;
    private String preferredBank;
    private String returnURL;
    private String status;
    private List<String> currencyCodes;
    private Integer maxAtrnCount;
    private Long accessTokenExpiryTime;
    private Long transactionTokenExpiryTime;
    private Long orderExpiryTime;
    private String merchantVolVelFlag;

}