package com.epay.gateway.service;

import com.epay.gateway.dao.MerchantOrderPaymentDao;
import com.epay.gateway.dao.PaymentDao;
import com.epay.gateway.dto.MerchantOrderPaymentDto;
import com.epay.gateway.externalservice.InbClientService;
import com.epay.gateway.externalservice.response.inb.InbMapWebResponse;
import com.epay.gateway.util.InbUtil;
import com.epay.gateway.util.enums.PaymentStatus;
import com.epay.gateway.util.enums.TransactionStatus;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.text.MessageFormat;

import static com.epay.gateway.util.GatewayPoolingConstant.*;

@Service
@RequiredArgsConstructor
public class InbService {
    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());

    private final PaymentDao paymentDao;
    private final MerchantOrderPaymentDao merchantOrderPaymentDao;
    private final ObjectMapper objectMapper;
    private final InbClientService inbClientService;

    /**
     * this method is used to process the INB data.
     *
     * @param message string
     */
    public void processForInb(String message) {
        logger.info("Converting string to merchant order payments.");
        try {
            MerchantOrderPaymentDto merchantOrderPaymentDto = objectMapper.readValue(message, new TypeReference<>() {});
            //Process Merchant Order Payment pending.
            if (TRANSACTION_STATUS_PENDING.equals(merchantOrderPaymentDto.getTransactionStatus())) {
                processMerchantOrderPaymentINB(merchantOrderPaymentDto);
            }
            if (TRANSACTION_STATUS_BOOKED.equals(merchantOrderPaymentDto.getTransactionStatus())) {
                //Process Merchant Order Payment booked.
                processMerchantOrderPaymentINB(merchantOrderPaymentDto);
            }
        } catch (Exception e) {
            logger.error("Error while processing INB data: {}", e.getMessage());
        }
    }

    /**
     * This method is used to process the merchant order payments for INB
     *
     * @param merchantOrderPaymentDto list of merchant order payment
     */
    private void processMerchantOrderPaymentINB(MerchantOrderPaymentDto merchantOrderPaymentDto) {
        logger.info("Processing merchant order payment.");
        try {
            String plainDvRequest = buildINBRequest(merchantOrderPaymentDto.getAtrnNumber(), merchantOrderPaymentDto.getDebitAmount());
            String inbResponse = inbClientService.processingDoubleVerRequest(plainDvRequest);
            InbMapWebResponse inbMapResponse = new ObjectMapper().convertValue(
                    InbUtil.getDecryptedData(inbResponse.trim()), InbMapWebResponse.class);
            if (SUCCESS.equalsIgnoreCase(inbMapResponse.getStatus())) {
                merchantOrderPaymentDao.updateTransactionStatusAndPaymentStatus(merchantOrderPaymentDto.getAtrnNumber(), TransactionStatus.SUCCESS.name(), PaymentStatus.SUCCESS.name(), POOLING_STATUS_SUCCESS);
                logger.info("Updated OrderPaymentINB as Success.");
            }
            if (FAILURE.equalsIgnoreCase(inbMapResponse.getStatus())) {
                merchantOrderPaymentDao.updateTransactionStatusAndPaymentStatus(merchantOrderPaymentDto.getAtrnNumber(), TransactionStatus.FAILED.name(), PaymentStatus.FAILED.name(), POOLING_STATUS_FAILURE);
                logger.info("Updated OrderPaymentINB as Failed.");
            }
            if (PENDING.equalsIgnoreCase(inbMapResponse.getStatus())) {
                merchantOrderPaymentDao.updateTransactionStatusAndPaymentStatus(merchantOrderPaymentDto.getAtrnNumber(), TransactionStatus.PENDING.name(), PaymentStatus.PENDING.name(), POOLING_STATUS_PENDING);
                logger.info("Updated OrderPaymentINB as Pending.");
            }
        } catch (Exception e) {
            logger.error("Error while processing process ATRN {}: {}", merchantOrderPaymentDto.getAtrnNumber(), e.getMessage());
            merchantOrderPaymentDao.updateTransactionStatusAndPaymentStatus(merchantOrderPaymentDto.getAtrnNumber(), TransactionStatus.PENDING.name(), PaymentStatus.PENDING.name(), POOLING_STATUS_PENDING);
            logger.info("Updated OrderPaymentINB as Pending while API failure.");
        }
    }

    /**
     * this method is used to create request for payment status API
     *
     * @param txnRefNo String
     * @param amount   big decimal
     * @return String
     */
    private String buildINBRequest(String txnRefNo, BigDecimal amount) {
        // Create DV request and checksum.
        String plainDvRequestAndChecksum = MessageFormat.format(SBIINB_DV_REQUEST, txnRefNo, amount)
                .concat(SBIINB_CHECKSUM)
                .concat(InbUtil.getSHA2Checksum(MessageFormat.format(SBIINB_DV_REQUEST, txnRefNo, amount)));
        logger.info("Payment status plain request: {}", plainDvRequestAndChecksum);
        // Save DV Request...
        paymentDao.saveRequestLog(plainDvRequestAndChecksum, txnRefNo, DV_REQUEST_TYPE, CREATED_BY);
        return plainDvRequestAndChecksum;
    }
}
