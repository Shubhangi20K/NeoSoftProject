package com.epay.gateway.util;

import com.epay.gateway.externalservice.response.OtherInbMapResponse;
import lombok.experimental.UtilityClass;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Stream;

@UtilityClass
public class OtherInbUtil {

    public static OtherInbMapResponse splitOtherInbDVResponse(String otherInbResponse) {
        List<String> arrayList = Stream.of(otherInbResponse.split("[|,^]"))
                .map(String::new)
                .toList();
        return OtherInbMapResponse.builder()
                .otherInbAtrn(arrayList.get(6))
                .atrn(arrayList.get(1))
                .status(arrayList.get(2))
                .bankRefNo(arrayList.get(10))
                .amount(new BigDecimal(arrayList.get(7)))
                .build();
    }
}
