package com.epay.gateway.util.enums;

import com.epay.gateway.exceptions.GatewayPoolingException;
import com.epay.gateway.util.GatewayPoolingErrorConstants;

import java.text.MessageFormat;
import java.util.Arrays;

/**
 * Class Name:PaymentStatus
 * *
 * Description:
 * *
 * Author: V1019436(Gireesh M)
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
public enum PaymentStatus {
    BOOKED, PAYMENT_INITIATION_START,SUCCESS, FAILED,PENDING;

    public static PaymentStatus getPaymentStatus(String paymentStatus) {
        return Arrays.stream(values()).filter(t -> t.name().equalsIgnoreCase(paymentStatus)).findFirst().orElseThrow(() -> new GatewayPoolingException(GatewayPoolingErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(GatewayPoolingErrorConstants.INVALID_ERROR_MESSAGE, "Payment status")));
    }
}
