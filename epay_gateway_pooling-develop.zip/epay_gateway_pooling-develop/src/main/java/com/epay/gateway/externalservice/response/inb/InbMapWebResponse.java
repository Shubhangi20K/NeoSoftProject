package com.epay.gateway.externalservice.response.inb;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.math.BigDecimal;

/**
 * Class Name: NbMapWebResponseDto
 * *
 * Description:
 * *
 * Author: V1019436(Gireesh M)
 * Copyright (c) 2025 [State Bank of India]
 * ALl rights reserved
 * *
 * Version: 1.0
 */
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class InbMapWebResponse {

    private String amount;
    @JsonProperty("status_desc")
    private String statusDesc;
    @JsonProperty("txnrefNo")
    private String txnRefNo;
    @JsonProperty("sbirefNo")
    private String sbiRefNo;
    private String checkSum;
    private String status;
}
