package com.epay.gateway.etl.producer;

import com.epay.gateway.config.kafka.Topics;
import com.epay.gateway.dao.MerchantOrderPaymentDao;
import com.epay.gateway.dto.MerchantOrderPaymentDto;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import org.springframework.stereotype.Service;

import static com.epay.gateway.util.GatewayPoolingConstant.POOLING_STATUS_QUEUE;

@Service
public class InbPoolingProducer extends GatewayPoolingProducer<MerchantOrderPaymentDto> {
    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());

    private final ObjectMapper objectMapper;
    private final MerchantOrderPaymentDao merchantOrderPaymentDao;

    public InbPoolingProducer(KafkaMessagePublisher kafkaMessagePublisher, Topics topics, ObjectMapper objectMapper, MerchantOrderPaymentDao merchantOrderPaymentDao) {
        super(kafkaMessagePublisher, topics);
        this.objectMapper = objectMapper;
        this.merchantOrderPaymentDao = merchantOrderPaymentDao;
    }

    @Override
    public void publish(String routingKey, MerchantOrderPaymentDto message) {
        try {
            logger.debug("Gateway Pooling publishing for routingKey : {} and message : {}", routingKey, message);
            getKafkaMessagePublisher().publish(getTopics().getGatewayPoolingInbTopic(), getRoutingKey(routingKey), objectMapper.writeValueAsString(message));
            merchantOrderPaymentDao.updatePoolingStatus(message.getAtrnNumber(), POOLING_STATUS_QUEUE);
        } catch (Exception ex) {
            logger.error("Error while publishing Inb, MerchantOrderPaymentDto {}, {}", message, ex.getMessage());
        }
    }
}
