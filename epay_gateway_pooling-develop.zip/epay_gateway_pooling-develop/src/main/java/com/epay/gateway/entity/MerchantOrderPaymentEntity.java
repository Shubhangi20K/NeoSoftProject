package com.epay.gateway.entity;

import com.epay.gateway.util.GatewayPoolingUtil;
import com.epay.gateway.util.enums.PayMode;
import jakarta.persistence.*;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

@Data
@Entity
@Table(name = "MERCHANT_ORDER_PAYMENTS")
public class MerchantOrderPaymentEntity {

    @Id
    @Column(name = "ATRN_NUM", nullable = false, updatable = false, unique = true)
    private String atrnNumber;
    private String merchantId;
    private String orderRefNumber;
    private String sbiOrderRefNumber;
    private String bankReferenceNumber;
    private String payMode;
    /* Payment Information */
    private String currencyCode;
    private BigDecimal orderAmount;
    private String paymentStatus;
    private String transactionStatus;
    private String failReason;
    @Column(name = "debit_amt")
    private BigDecimal debitAmount;
    @Column(name = "GST_IN")
    private String gstin;
    private String channelBank;
    private String settlementStatus;
    private String refundStatus;
    private String cancellationStatus;
    private String cin;
    @Column(name = "GTW_MAP_ID")
    private String pgBankCode;//this is gateway map id
    private String payProcId; //this is pay proc id e.g. Visa, Master, Rupay
    @Column(name = "PAY_PROC_TYPE")
    private String paymodeType; //this is Pay proc type e.g. onus, offus
    @Column(name = "GTW_ISSUE_MECODE")
    private String gatewayIssueMECode; //merchant wise and/or payment wise ME code received from bank
    @Lob
    private String pushResponse;
    private String pushStatus;
    private String poolingStatus;
    private String createdBy;
    private String updatedBy;
    @Column(name = "CREATED_DATE_NUM")
    private Long createdDate;
    private Long updatedDate;
    private Date paymentSuccessDate;
    private BigDecimal availableRefundAmount;
    @Column(name = "CHARGEBACK_AMOUNT")
    private BigDecimal chargeBackAmount;
    @Column(name = "CHARGEBACK_STATUS")
    private String chargeBackStatus;

    /**
     * custom generator, do not remove it
     */
    @PrePersist
    protected void generatedATRN() {
        this.atrnNumber = GatewayPoolingUtil.createAtrnNumber(merchantId, PayMode.valueOf(payMode));
    }

}