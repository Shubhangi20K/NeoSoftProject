package com.epay.gateway.etl.listener;

import com.epay.gateway.service.OtherInbService;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.MDC;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import java.util.UUID;

import static com.epay.gateway.util.GatewayPoolingConstant.*;

@Component
@RequiredArgsConstructor
public class OtherInbListener {

    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private final OtherInbService otherInbService;

    /**
     * this method consumes otherIND data.
     * @param consumerRecord key value
     */
    @KafkaListener(topics = "${spring.kafka.topic.gateway.pooling.otherINB}")
    public void otherInbListener(ConsumerRecord<String, String> consumerRecord) {
        MDC.put(CORRELATION_ID, String.valueOf(UUID.randomUUID()));
        MDC.put(SCENARIO, InbListener.class.getCanonicalName());
        MDC.put(OPERATION, "pooling.otherInb");
        logger.debug("Gateway pooling request received for key: {} and value: {}", consumerRecord.key(), consumerRecord.value());
        otherInbService.processForOtherInb(consumerRecord.value());
    }
}
