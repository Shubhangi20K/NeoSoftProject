package com.epay.gateway.util.enums;

import com.epay.gateway.exceptions.GatewayPoolingException;
import com.epay.gateway.util.GatewayPoolingErrorConstants;

import java.text.MessageFormat;
import java.util.Arrays;

public enum PayMode {
    UPI, NB, CC,DC,PC,NEFT,CASH,PAYPAL,WALLET;

    public static PayMode getPayMode(String payMode) {
        return Arrays.stream(values()).filter(p -> p.name().equalsIgnoreCase(payMode)).findFirst().orElseThrow(() -> new GatewayPoolingException(GatewayPoolingErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(GatewayPoolingErrorConstants.INVALID_ERROR_MESSAGE, "PayMode")));
    }
}
