package com.epay.gateway.externalservice;


import com.epay.gateway.client.ApiClient;
import com.epay.gateway.externalservice.response.admin.MerchantInfoResponse;
import com.epay.gateway.model.response.GatewayPoolingResponse;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import org.springframework.core.ParameterizedTypeReference;

/**
 * Class Name: AdminServicesClient
 * *
 * AdminServicesClient is responsible for interacting with the admin service APIs
 * to fetch and validate merchant-related details.
 * Author: Gireesh M
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */

public class AdminServicesClient extends ApiClient {

    private static final String MERCHANT = "/merchant/";


    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    /**
     * Constructor to initialize AdminServicesClient with the base URL.
     *
     * @param baseUrl API base URL
     */
    public AdminServicesClient(String baseUrl) {
        super(baseUrl);
    }

    /**
     * Fetches merchant information by merchant ID.
     *
     * @param mId Merchant ID
     * @return Transaction response containing merchant information
     */
    public GatewayPoolingResponse<MerchantInfoResponse> getMerchantInfoByMId(String mId) {
        logger.info("Fetching merchant info for mId: {}", mId);
        return post(MERCHANT + mId, mId, new ParameterizedTypeReference<>() {});
    }

}
