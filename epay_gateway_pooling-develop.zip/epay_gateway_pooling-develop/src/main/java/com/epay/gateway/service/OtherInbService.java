package com.epay.gateway.service;

import com.epay.gateway.config.OtherInbConfig;
import com.epay.gateway.dao.MerchantOrderPaymentDao;
import com.epay.gateway.dao.PaymentDao;
import com.epay.gateway.dto.MerchantOrderPaymentDto;
import com.epay.gateway.externalservice.OtherINBClientService;
import com.epay.gateway.externalservice.response.OtherInbMapResponse;
import com.epay.gateway.util.OtherInbEncryptionDecryptionUtil;
import com.epay.gateway.util.OtherInbUtil;
import com.epay.gateway.util.enums.PaymentStatus;
import com.epay.gateway.util.enums.TransactionStatus;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.text.MessageFormat;

import static com.epay.gateway.util.GatewayPoolingConstant.*;

@Service
@RequiredArgsConstructor
public class OtherInbService {
    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private final OtherInbConfig otherInbConfig;
    private final ObjectMapper objectMapper;
    private final OtherINBClientService otherINBClientService;
    private final MerchantOrderPaymentDao merchantOrderPaymentDao;
    private final PaymentDao paymentDao;

    /**
     * this method is used to process the otherINB data.
     *
     * @param message string
     */
    public void processForOtherInb(String message) {
        logger.info("Converting string to merchant order payments.");
        try {
            MerchantOrderPaymentDto merchantOrderPaymentDto = objectMapper.readValue(message, new TypeReference<>() {});
            //Process Merchant Order Payment pending.
            if (TRANSACTION_STATUS_PENDING.equals(merchantOrderPaymentDto.getTransactionStatus())) {
                processMerchantOrderPaymentOtherINB(merchantOrderPaymentDto);
            }

            //Process Merchant Order Payment booked.
            if (TRANSACTION_STATUS_BOOKED.equals(merchantOrderPaymentDto.getTransactionStatus())) {
                processMerchantOrderPaymentOtherINB(merchantOrderPaymentDto);
            }
        } catch (Exception e) {
            logger.error("Error while processing otherINB data : {}", e.getMessage());
        }
    }

    /**
     * This method is used to process the merchant order payments for otherINB
     *
     * @param merchantOrderPaymentDtoList list of merchant order payment
     */
    private void processMerchantOrderPaymentOtherINB(MerchantOrderPaymentDto merchantOrderPaymentDtoList) {
        logger.info("Processing merchant order payment for otherINB.");
        try {
            String plainOtherInbRequest = buildOtherINBRequest(merchantOrderPaymentDtoList);
            String otherINBResponse = otherINBClientService.otherINBDVResponseConn(otherInbConfig.getOtherInbStatusQuery(), plainOtherInbRequest);

            otherINBResponse = OtherInbEncryptionDecryptionUtil.decryptAesGcmNoPadding(otherInbConfig.getOtherInbKey(), otherINBResponse);

            OtherInbMapResponse otherInbMappedResponse = OtherInbUtil.splitOtherInbDVResponse(otherINBResponse);
            if (SUCCESS.equalsIgnoreCase(otherInbMappedResponse.getStatus())) {
                merchantOrderPaymentDao.updateTransactionStatusAndPaymentStatus(merchantOrderPaymentDtoList.getAtrnNumber(), TransactionStatus.SUCCESS.name(), PaymentStatus.SUCCESS.name(), POOLING_STATUS_SUCCESS);
                logger.info("Updated OrderPaymentOtherINB as Success.");
            }
            if (FAILURE.equalsIgnoreCase(otherInbMappedResponse.getStatus())) {
                merchantOrderPaymentDao.updateTransactionStatusAndPaymentStatus(merchantOrderPaymentDtoList.getAtrnNumber(), TransactionStatus.FAILED.name(), PaymentStatus.FAILED.name(), POOLING_STATUS_FAILURE);
                logger.info("Updated OrderPaymentOtherINB as Failure.");
            }
            if (PENDING.equalsIgnoreCase(otherInbMappedResponse.getStatus())) {
                merchantOrderPaymentDao.updateTransactionStatusAndPaymentStatus(merchantOrderPaymentDtoList.getAtrnNumber(), TransactionStatus.PENDING.name(), PaymentStatus.PENDING.name(), POOLING_STATUS_PENDING);
                logger.info("Updated OrderPaymentOtherINB as Pending.");
            }
        } catch (Exception e) {
            merchantOrderPaymentDao.updateTransactionStatusAndPaymentStatus(merchantOrderPaymentDtoList.getAtrnNumber(), TransactionStatus.PENDING.name(), PaymentStatus.PENDING.name(), POOLING_STATUS_PENDING);
            logger.info("Updated OrderPaymentOtherINB as Pending while API failure.");
        }
    }

    /**
     * this method is used to build otherINB request.
     *
     * @param merchantOrderPaymentDto merchant order payment dto.
     * @return string
     */
    private String buildOtherINBRequest(MerchantOrderPaymentDto merchantOrderPaymentDto) {
        String plainDVRequestString = MessageFormat.format(OTHER_INB_DV_CALLBACK, merchantOrderPaymentDto.getAtrnNumber(), otherInbConfig.getOtherInbMid(), merchantOrderPaymentDto.getSbiOrderRefNumber(), merchantOrderPaymentDto.getDebitAmount());
        logger.info(" plain DV Request String for otherINB {} ", plainDVRequestString);

        String encQueryRequest = OtherInbEncryptionDecryptionUtil.encryptAesGcmNoPadding(otherInbConfig.getOtherInbKey(), plainDVRequestString)
                .replaceAll(NEW_LINE_REGEX, PATTERN_EMPTY).trim();
        logger.info("Enc QueryRequest for otherINB {} ", encQueryRequest);

        String dvRequestString = MessageFormat.format(OTHER_INB_CALLBACK, SBIEPAY, encQueryRequest, otherInbConfig.getOtherInbMid());
       logger.info("DV CallBack queryRequest for otherINB {} ", dvRequestString);
        //Save DV Request in DB
        paymentDao.saveRequestLog(plainDVRequestString, merchantOrderPaymentDto.getAtrnNumber(), DV_REQUEST_TYPE, merchantOrderPaymentDto.getChannelBank());
        return dvRequestString;
    }
}
