package com.epay.gateway.config;

import com.epay.gateway.externalservice.AdminServicesClient;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@Getter
@RequiredArgsConstructor
public class APIConfig {
    @Value("${spring.external.api.services.base.path.admin}")
    private String adminServicesBasePath;

    @Bean
    public AdminServicesClient constructAdminServicesClient() {
        return new AdminServicesClient(adminServicesBasePath);
    }
}
