package com.epay.gateway.repository;

import com.epay.gateway.entity.PaymentLog;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

/**
 * Class Name: PaymentRepository
 * *
 * Description:
 * *
 * Author: V1019436(Gireesh M)
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
public interface PaymentRepository extends JpaRepository<PaymentLog, UUID> {
}