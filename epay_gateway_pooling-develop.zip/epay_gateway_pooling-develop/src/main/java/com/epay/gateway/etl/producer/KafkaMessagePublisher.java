package com.epay.gateway.etl.producer;

import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class KafkaMessagePublisher {
    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    private final KafkaTemplate<String, String> kafkaTemplate;

    /**
     * Publishing string message on transaction topic(s).
     *
     * @param topic   String
     * @param key     String
     * @param message String
     */
    public void publish(String topic, String key, String message) {
        try {
            kafkaTemplate.send(topic, key, message);
        } catch (Exception e) {
            log.debug("Issue in message publishing to kafka topic: {} , key : {} and  message : {}", topic, key, message);
        }
    }

}
