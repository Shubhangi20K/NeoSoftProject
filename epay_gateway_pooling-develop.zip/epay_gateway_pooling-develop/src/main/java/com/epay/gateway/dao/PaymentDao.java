package com.epay.gateway.dao;

import com.epay.gateway.entity.PaymentLog;
import com.epay.gateway.repository.PaymentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.sql.Timestamp;

/**
 * Class Name: PaymentDAO * Description: * Author: Gireesh M Copyright (c) 2025 [State Bank of India] ALl rights
 * reserved * Version: 1.0
 */
@Component
@RequiredArgsConstructor
public class PaymentDao {
    private final PaymentRepository paymentRepository;

    public void saveRequestLog(String paymentApiRequest, String atrn, String requestType, String createdBy) {
        PaymentLog webRequest = PaymentLog.builder()
                .atrnNum(atrn)
                .requestType(requestType)
                .log(paymentApiRequest.getBytes())
                .createdBy(createdBy)
                .createdDate(new Timestamp(System.currentTimeMillis()).getTime())
                .build();
        paymentRepository.save(webRequest);
    }
}
