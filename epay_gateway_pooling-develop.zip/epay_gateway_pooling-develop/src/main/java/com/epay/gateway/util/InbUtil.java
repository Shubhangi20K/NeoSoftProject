package com.epay.gateway.util;

import com.epay.gateway.exceptions.GatewayPoolingException;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.experimental.UtilityClass;
import org.apache.commons.lang3.StringUtils;

import java.security.MessageDigest;
import java.text.MessageFormat;
import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;

import static com.epay.gateway.util.GatewayPoolingConstant.INVALID_HASH;
import static com.epay.gateway.util.GatewayPoolingErrorConstants.INVALID_ERROR_CODE;
import static com.epay.gateway.util.GatewayPoolingErrorConstants.INVALID_ERROR_MESSAGE;

@UtilityClass
public class InbUtil {

    private static final LoggerUtility logger = LoggerFactoryUtility.getLogger(InbUtil.class);

    public static String getSHA2Checksum(String data) {
        MessageDigest md;
        StringBuilder hexString = new StringBuilder();
        try{
            md = MessageDigest.getInstance("SHA-256");
            md.update(data.getBytes());
            byte[] byteData = md.digest();
            StringBuilder sb = new StringBuilder();
            for (byte byteDatum : byteData) {
                sb.append(Integer.toString((byteDatum & 0xff) + 0x100, 16).substring(1));
            }
            for (byte byteDatum : byteData) {
                String hex = Integer.toHexString(0xff & byteDatum);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        } catch (Exception e) { // Exception throw by INB Bank Algorithm
            logger.error("Exception While Decrypt  {} {}", e.getCause(),e.getMessage());
            throw new GatewayPoolingException(INVALID_ERROR_CODE, MessageFormat.format(INVALID_ERROR_MESSAGE, INVALID_HASH));
        }
    }

    /**
     * return: key, value
     * methodName: Web and DV Decrypted Data set in map.
     * Method-Description: Process DecryptedData and set in map.
     * param: decResponse
     * Exception: or @Error :Exception
     */
    public static Map<String,String> getDecryptedData(String decResponse) {
        return Arrays.stream(decResponse.split(GatewayPoolingConstant.PIPE_CONST))
                .map(kv -> kv.split(GatewayPoolingConstant.PATTERN_EQUAL_TO_CONST))
                .filter(kvArray -> kvArray.length == 2)
                .collect(Collectors.toMap(kv -> kv[0], kv -> StringUtils.isBlank(kv[1])?GatewayPoolingConstant.NA:kv[1]));
    }
}
