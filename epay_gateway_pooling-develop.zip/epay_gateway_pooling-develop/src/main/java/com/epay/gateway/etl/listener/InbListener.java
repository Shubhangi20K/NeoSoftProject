package com.epay.gateway.etl.listener;

import com.epay.gateway.service.InbService;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.MDC;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import java.util.UUID;

import static com.epay.gateway.util.GatewayPoolingConstant.*;

@Component
@RequiredArgsConstructor
public class InbListener {

    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    private final InbService inbService;

    /**
     * this method consumes INB data.
     *
     * @param consumerRecord key value
     */
    @KafkaListener(topics = "${spring.kafka.topic.gateway.pooling.inb}")
    public void inbListener(ConsumerRecord<String, String> consumerRecord) {
        MDC.put(CORRELATION_ID, String.valueOf(UUID.randomUUID()));
        MDC.put(SCENARIO, InbListener.class.getCanonicalName());
        MDC.put(OPERATION, "pooling.inb");
        log.debug("Gateway pooling request received for key: {} and value: {}", consumerRecord.key(), consumerRecord.value());
        String message = consumerRecord.value();
        inbService.processForInb(message);
    }
}
