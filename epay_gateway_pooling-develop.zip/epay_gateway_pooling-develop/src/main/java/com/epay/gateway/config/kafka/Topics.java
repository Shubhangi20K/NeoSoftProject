package com.epay.gateway.config.kafka;

import lombok.Getter;
import org.apache.kafka.clients.admin.NewTopic;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

@Getter
@Component
public class Topics {

    @Value("${spring.kafka.topic.gateway.pooling.inb}")
    private String gatewayPoolingInbTopic;

    @Value("${spring.kafka.topic.gateway.pooling.otherINB}")
    private String gatewayPoolingOtherInbTopic;

    @Value("${spring.kafka.topic.partitions}")
    private int noOfPartitions;

    @Value("${spring.kafka.topic.replicationFactor}")
    private short replicationFactor;

    @Bean
    public NewTopic createGatewayPoolingInbTopic() {
        return new NewTopic(gatewayPoolingInbTopic, noOfPartitions, replicationFactor);
    }

    @Bean
    public NewTopic createGatewayPoolingOtherInbTopic() {
        return new NewTopic(gatewayPoolingOtherInbTopic, noOfPartitions, replicationFactor);
    }
}
