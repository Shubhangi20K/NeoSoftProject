package com.epay.gateway.util;

import lombok.experimental.UtilityClass;

@UtilityClass
public class GatewayPoolingErrorConstants {

    public static final String NOT_FOUND_ERROR_CODE = "3002";
    public static final String NOT_FOUND_ERROR_MESSAGE = "{0} is not found.";

    public static final String EXTERNAL_SERVICE_ERROR_CODE = "3207";
    public static final String EXTERNAL_SERVICE_ERROR_MESSAGE = "{0} Service is Down. Please try again";

    public static final String INVALID_ERROR_CODE = "1002";
    public static final String INVALID_ERROR_MESSAGE = "{0} is Invalid.";
    /**
     * Generic error codes
     */

    public static final String ENCRYPTION_ERROR_CODE = "3505";
    public static final String ENCRYPTION_ERROR_MESSAGE = "Exception While Encrypting Web Request in SBIINB";

    public static final String DOUBLE_VERIFICATION_ERROR_CODE = "3506";
    public static final String DOUBLE_VERIFICATION_ERROR_MESSAGE = "Empty Double Verification Response";

    public static final String HTTP_CONNECTION_ERROR_CODE = "4003";

    public static final String EXCEPTION_WHILE_DECRYPT = "Exception while decrypt  {} {}";
}
