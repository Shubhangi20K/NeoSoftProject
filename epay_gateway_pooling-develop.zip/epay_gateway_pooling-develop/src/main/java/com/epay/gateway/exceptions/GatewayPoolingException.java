package com.epay.gateway.exceptions;

import com.epay.gateway.dto.ErrorDto;
import lombok.*;

import java.util.ArrayList;
import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Getter
@Builder
public class GatewayPoolingException extends RuntimeException {
    private final String errorCode;
    private final String errorMessage;
    private final List<ErrorDto> errorMessages;

    /**
     * Parametrized constructor taking error code and errorMessage
     *
     * @param errorCode    String
     * @param errorMessage String
     */
    public GatewayPoolingException(String errorCode, String errorMessage) {
        super(errorMessage);
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
        this.errorMessages = new ArrayList<>();
    }

    /**
     * Parametrized constructor taking List of ErrorDTO
     *
     * @param errorMessages List<ErrorDto>
     */
    public GatewayPoolingException(String errorCode, String errorMessage, List<ErrorDto> errorMessages) {
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
        this.errorMessages = errorMessages;
    }
}
