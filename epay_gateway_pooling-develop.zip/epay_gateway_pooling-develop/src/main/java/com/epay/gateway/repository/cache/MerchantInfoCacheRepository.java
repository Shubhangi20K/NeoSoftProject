package com.epay.gateway.repository.cache;

import com.sbi.epay.cache.admin.entity.MerchantCache;
import org.springframework.data.gemfire.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

import static com.epay.gateway.util.queries.cache.MerchantInfoQueries.FIND_MERCHANT_INFO_BY_MID_AND_TRANSACTION_EXPIRY_TIME;

/**
 * Class Name:MerchantCacheRepository * Description: This class to get the Merchant info from cache repository *
 * Author:Gireesh M
 * <p>
 * Copyright (c) 2025 [State Bank of India] All right reserved
 * Version:1.0
 */
public interface MerchantInfoCacheRepository extends CrudRepository<MerchantCache, String> {

    @Query(FIND_MERCHANT_INFO_BY_MID_AND_TRANSACTION_EXPIRY_TIME)
    Optional<MerchantCache> findByMIdAndTransactionExpiryTime(@Param("mId") String mId, @Param("minutes") Long minutes);
}
