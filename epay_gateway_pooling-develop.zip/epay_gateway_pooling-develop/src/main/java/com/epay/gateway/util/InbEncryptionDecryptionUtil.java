package com.epay.gateway.util;

import com.epay.gateway.exceptions.GatewayPoolingException;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.experimental.UtilityClass;
import org.apache.commons.codec.binary.Base64;
import org.springframework.core.io.ClassPathResource;

import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.text.MessageFormat;
import java.util.Arrays;

import static com.epay.gateway.util.GatewayPoolingErrorConstants.EXCEPTION_WHILE_DECRYPT;

@UtilityClass
public class InbEncryptionDecryptionUtil {
    private static final LoggerUtility logger = LoggerFactoryUtility.getLogger(InbEncryptionDecryptionUtil.class);

    public static String encrypt(String data) {
        ClassPathResource path = new ClassPathResource(GatewayPoolingConstant.SBIINB_KEY_PATH);
        byte[] key;
        try {
            key = returnByte(path.getInputStream());

            String encData;

            Cipher cipher = Cipher.getInstance(GatewayPoolingConstant.SBIINB_AES_GCM_NOPADDING);
            int blockSize = cipher.getBlockSize();
            byte[] iv = new byte[cipher.getBlockSize()];
            byte[] dataBytes = data.getBytes();
            int plaintextLength = dataBytes.length;
            int remainder = plaintextLength % blockSize;
            if (remainder != 0) {
                plaintextLength += blockSize - remainder;
            }
            byte[] plaintext = new byte[plaintextLength];
            System.arraycopy(dataBytes, 0, plaintext, 0, dataBytes.length);
            SecretKeySpec keySpec = new SecretKeySpec(key, GatewayPoolingConstant.AES_ALGO);
            SecureRandom randomSecureRandom = SecureRandom.getInstance(GatewayPoolingConstant.SHA1PRNG);
            randomSecureRandom.nextBytes(iv);
            GCMParameterSpec parameterSpec = new GCMParameterSpec(128, iv);
            cipher.init(1, keySpec, parameterSpec);
            byte[] results = cipher.doFinal(plaintext);
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            outputStream.write(iv);
            outputStream.write(results);
            byte[] encryptedData = outputStream.toByteArray();
            encData = Base64.encodeBase64String(encryptedData);
            encData = encData.replace("\n", "").replace("\r", "");
            encData = encData.replaceAll("\r\n", "");
            encData = encData.replaceAll("\r", "");
            encData = encData.replaceAll("\n", "");
            encData = encData.replaceAll(" ", "");

            return encData;
        } catch (Exception e) { // Exception throw by INB Bank Algorithm
            logger.error(EXCEPTION_WHILE_DECRYPT, e.getCause(), e.getMessage());
            throw new GatewayPoolingException(GatewayPoolingErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(GatewayPoolingErrorConstants.INVALID_ERROR_MESSAGE, GatewayPoolingConstant.INVALID_HASH));
        }
    }


    public static String decrypt(String encData) {
        String decdata;
        try {
            ClassPathResource path = new ClassPathResource(GatewayPoolingConstant.SBIINB_KEY_PATH);
            byte[] key = returnByte(path.getInputStream());

            Cipher cipher = Cipher.getInstance(GatewayPoolingConstant.SBIINB_AES_GCM_NOPADDING);
            SecretKeySpec keySpec = new SecretKeySpec(key, "AES");
            byte[] results = Base64.decodeBase64(encData);
            byte[] iv = Arrays.copyOfRange(results, 0, cipher.getBlockSize());
            cipher.init(2, keySpec, new GCMParameterSpec(128, iv));
            byte[] results1 = Arrays.copyOfRange(results, cipher.getBlockSize(), results.length);
            byte[] ciphertext = cipher.doFinal(results1);
            decdata = new String(ciphertext, StandardCharsets.UTF_8).trim();

            return decdata;
        } catch (Exception e) { // Exception throw by INB Bank Algorithm
            logger.error(EXCEPTION_WHILE_DECRYPT, e.getCause(), e.getMessage());
            throw new GatewayPoolingException(GatewayPoolingErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(GatewayPoolingErrorConstants.INVALID_ERROR_MESSAGE, GatewayPoolingConstant.INVALID_HASH));
        }
    }


    private static byte[] returnByte(InputStream inputData) {
        try {
            return inputData.readAllBytes();
        } catch (Exception e) { // Exception throw by INB Bank Algorithm
            logger.error(EXCEPTION_WHILE_DECRYPT, e.getCause(), e.getMessage());
            throw new GatewayPoolingException(GatewayPoolingErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(GatewayPoolingErrorConstants.INVALID_ERROR_MESSAGE, GatewayPoolingConstant.INVALID_HASH));
        }
    }
}
