package com.epay.gateway.config.kafka;

import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.admin.AdminClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import java.util.Properties;

/**
 * Class Name: TopicsConfig
 * Description:
 * The TopicsConfig class is responsible for configuring Kafka topics in the application.
 * It includes the necessary settings for topics like the topic name, number of partitions,
 * and replication factor. This configuration is typically loaded at startup.
 * Author: Gireesh M
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * Version: 1.0
 */
@Configuration
public class TopicsConfig {

    @Value("${spring.kafka.bootstrapServers}")
    private String bootstrapServers;

    @Bean
    @Primary
    protected AdminClient adminClient() {
        Properties props = new Properties();
        props.put(CommonClientConfigs.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        return AdminClient.create(props);
    }
}
