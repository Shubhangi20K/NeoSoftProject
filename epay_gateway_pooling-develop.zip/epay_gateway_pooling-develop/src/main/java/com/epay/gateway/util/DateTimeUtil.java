package com.epay.gateway.util;

import lombok.experimental.UtilityClass;

import java.time.LocalDateTime;

@UtilityClass
public class DateTimeUtil {

    /**
     * This method is used to get the current time in minutes
     *
     * @return int
     */
    public static int getCurrentTimeInMin() {
        return LocalDateTime.now().getMinute();
    }

    /**
     * Retrieves the current system time in milliseconds.
     */
    public static Long getCurrentTimeInMills() {
        return System.currentTimeMillis();
    }
}
