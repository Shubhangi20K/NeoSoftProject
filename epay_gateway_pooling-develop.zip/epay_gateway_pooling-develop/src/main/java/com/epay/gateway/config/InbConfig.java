package com.epay.gateway.config;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

/**
 * Class Name:InbConfig
 * *
 * Description:
 * *
 * Author:Gireesh M
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
@Data
@Configuration
public class InbConfig {

    @Value("${epay.payment.sbiinb.bankdvurl}")
    private String sbiNburl;

    @Value("${epay.payment.sbiinb.merchantcode}")
    private String merchantCode;

    @Value("${epay.payment.inb.gatewayMapId}")
    private String gatewayMapId;
}
