package com.epay.gateway.util.enums;

import com.epay.gateway.exceptions.GatewayPoolingException;
import com.epay.gateway.util.GatewayPoolingErrorConstants;

import java.text.MessageFormat;
import java.util.Arrays;

public enum TransactionStatus {
    BOOKED, BOOKED_FAIL,
    PAYMENT_INITIATED_FAIL,
    PAYMENT_IN_VERIFICATION, PAYMENT_VERIFIED, PAYMENT_VERIFICATION_FAIL,
    SUCCESS, SETTLED,FAILED,PENDING;

    public static TransactionStatus getTransactionStatus(String transactionStatus) {
        return Arrays.stream(values()).filter(ts -> ts.name().equalsIgnoreCase(transactionStatus)).findFirst().orElseThrow(() -> new GatewayPoolingException(GatewayPoolingErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(GatewayPoolingErrorConstants.INVALID_ERROR_MESSAGE, "Transaction status")));
    }
}
