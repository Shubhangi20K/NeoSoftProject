package com.epay.gateway.schedular;

import com.epay.gateway.config.InbConfig;
import com.epay.gateway.dao.MerchantOrderPaymentDao;
import com.epay.gateway.dto.MerchantOrderPaymentDto;
import com.epay.gateway.etl.producer.InbPoolingProducer;
import com.epay.gateway.etl.producer.OtherInbPoolingProducer;
import com.epay.gateway.externalservice.AdminServicesClient;
import com.epay.gateway.externalservice.response.admin.MerchantInfoResponse;
import com.epay.gateway.model.response.GatewayPoolingResponse;
import com.epay.gateway.repository.cache.MerchantInfoCacheRepository;
import com.epay.gateway.util.DateTimeUtil;
import com.epay.gateway.util.enums.PaymentStatus;
import com.epay.gateway.util.enums.TransactionStatus;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.slf4j.MDC;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

import static com.epay.gateway.util.GatewayPoolingConstant.*;
import static org.apache.commons.lang3.ObjectUtils.isNotEmpty;

@Component
@RequiredArgsConstructor
public class GatewayPoolingScheduler {
    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());

    private final MerchantOrderPaymentDao merchantOrderPaymentDao;
    private final InbPoolingProducer inbProducer;
    private final OtherInbPoolingProducer otherInbProducer;
    private final InbConfig inbConfig;
    private final MerchantInfoCacheRepository merchantInfoCacheRepository;
    private final AdminServicesClient adminServicesClient;


    @Scheduled(cron = "${gateway.pooling.pending.cron_time}")
    public void pendingMerchantOrderPaymentsScheduler() {
        MDC.put(CORRELATION_ID, String.valueOf(UUID.randomUUID()));
        MDC.put(SCENARIO, GatewayPoolingScheduler.class.getCanonicalName());
        MDC.put(OPERATION, "pendingMerchantOrderPaymentsScheduler");

        List<MerchantOrderPaymentDto> merchantOrderPaymentList = merchantOrderPaymentDao.getPendingMerchantOrderPayments(DateTimeUtil.getCurrentTimeInMills());
        if (merchantOrderPaymentList.isEmpty()) {
            logger.info("No merchant order payment data found for pending.");
        } else {
            handleIndAndOtherInb(merchantOrderPaymentList);
        }
        //update merchant order payment which or above 24hrs.
        updateMerchantOrderPayments();
    }

    @Scheduled(cron = "${gateway.pooling.booked.cron_time}")
    public void bookedMerchantOrderPaymentsScheduler() {
        List<MerchantOrderPaymentDto> merchantOrderPaymentList = merchantOrderPaymentDao.getBookedMerchantOrderPayments(DateTimeUtil.getCurrentTimeInMills());
        if (merchantOrderPaymentList.isEmpty()) {
            logger.info("No merchant order payment data found for booked.");
        } else {
            handleIndAndOtherInb(merchantOrderPaymentList);
            updateBookedMerchantOrderPayment(merchantOrderPaymentList);
        }
    }


    private void handleIndAndOtherInb(List<MerchantOrderPaymentDto> merchantOrderPaymentList) {
        logger.info("Grouping merchant order payment list");
        Map<Boolean, List<MerchantOrderPaymentDto>> groupedByGatewayMapId = merchantOrderPaymentList.stream()
                .collect(Collectors.partitioningBy(e -> e.getPgBankCode().equalsIgnoreCase(inbConfig.getGatewayMapId())));

        // List of INB (gatewayMapId == 86)
        List<MerchantOrderPaymentDto> inbList = groupedByGatewayMapId.getOrDefault(true, List.of());

        // List of other INB (gatewayMapId != 86)
        List<MerchantOrderPaymentDto> otherInbList = groupedByGatewayMapId.getOrDefault(false, List.of());

        //Publishing merchant order payments for INB
        publishMerchantOrderPaymentInb(inbList);

        //Publishing merchant order payments for otherINB
        publishMerchantOrderPaymentOtherInb(otherInbList);
    }

    private void publishMerchantOrderPaymentInb(List<MerchantOrderPaymentDto> inbList) {
        if (isNotEmpty(inbList)) {
            inbList.forEach(mopInb -> inbProducer.publish(mopInb.getAtrnNumber(), mopInb));
        }
    }

    private void publishMerchantOrderPaymentOtherInb(List<MerchantOrderPaymentDto> otherInbList) {
        if (isNotEmpty(otherInbList)) {
            otherInbList.forEach(mopOtherInb -> otherInbProducer.publish(mopOtherInb.getAtrnNumber(), mopOtherInb));
        }
    }

    private void updateMerchantOrderPayments() {
        List<MerchantOrderPaymentDto> merchantOrderPaymentDtoListAbove24Hrs = merchantOrderPaymentDao.getPendingMerchantOrderPayments24Hrs(1740749922386L);
        if (isNotEmpty(merchantOrderPaymentDtoListAbove24Hrs)) {
            List<String> listOfAtrnNumber = merchantOrderPaymentDtoListAbove24Hrs.stream().map(MerchantOrderPaymentDto::getAtrnNumber).toList();
            merchantOrderPaymentDao.updateTransactionStatusAndPaymentStatus(listOfAtrnNumber, TransactionStatus.FAILED.name(), PaymentStatus.FAILED.name(), POOLING_STATUS_FAILURE);
        }
    }

    private void updateBookedMerchantOrderPayment(List<MerchantOrderPaymentDto> merchantOrderPaymentList) {
        merchantOrderPaymentList.forEach(bookedMop -> {
            if (merchantInfoCacheRepository.findByMIdAndTransactionExpiryTime(bookedMop.getMerchantId(), (long) DateTimeUtil.getCurrentTimeInMin()).isEmpty()) {
                merchantOrderPaymentDao.updateTransactionStatusAndPaymentStatus(bookedMop.getAtrnNumber(), TransactionStatus.FAILED.name(), PaymentStatus.FAILED.name(), POOLING_STATUS_FAILURE);
            } else {
                GatewayPoolingResponse<MerchantInfoResponse> merchantInfoResponse = adminServicesClient.getMerchantInfoByMId(bookedMop.getMerchantId());
                if (merchantInfoResponse.getData().getFirst().getTransactionTokenExpiryTime() < DateTimeUtil.getCurrentTimeInMin()) {
                    merchantOrderPaymentDao.updateTransactionStatusAndPaymentStatus(bookedMop.getAtrnNumber(), TransactionStatus.FAILED.name(), PaymentStatus.FAILED.name(), POOLING_STATUS_FAILURE);
                }
            }
        });
    }
}
