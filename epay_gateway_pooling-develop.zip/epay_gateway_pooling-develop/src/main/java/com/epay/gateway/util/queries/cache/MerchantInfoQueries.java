package com.epay.gateway.util.queries.cache;

import lombok.experimental.UtilityClass;

@UtilityClass
public class MerchantInfoQueries {
    public static final String FIND_MERCHANT_INFO_BY_MID_AND_TRANSACTION_EXPIRY_TIME = "SELECT m FROM /Admin_Merchant_Info m WHERE m.mId = $1 AND m.transactionTokenExpiryTime < $2";
}
