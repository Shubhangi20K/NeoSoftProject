package com.epay.gateway.etl.producer;

import com.epay.gateway.config.kafka.Topics;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public abstract class GatewayPoolingProducer<T> {

    private final KafkaMessagePublisher kafkaMessagePublisher;

    private final Topics topics;

    String getRoutingKey(String routingKey) {
        return "gatewayPooling." + routingKey;
    }

    public abstract void publish(String routingKey, T message);
}
