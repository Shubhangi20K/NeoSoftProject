package com.epay.gateway.repository;

import com.epay.gateway.entity.MerchantOrderPaymentEntity;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

import static com.epay.gateway.util.queries.MerchantOrderPaymentQueries.*;

public interface MerchantOrderPaymentRepository extends JpaRepository<MerchantOrderPaymentEntity, String> {

    @Query(value = FIND_BY_PENDING_STATUS, nativeQuery = true)
    List<MerchantOrderPaymentEntity> findPendingMerchantOrderPayments(Long currentMilliSec);

    @Query(value = FIND_BY_PENDING_STATUS_ABOVE_24Hrs, nativeQuery = true)
    List<MerchantOrderPaymentEntity> findPendingMerchantOrderPaymentsAbove24hrs(Long currentMilliSec);

    @Query(value = FIND_BY_PAYMENT_BOOKED_STATUS, nativeQuery = true)
    List<MerchantOrderPaymentEntity> findBookedMerchantOrderPayments(Long currentMilliSec);

    @Modifying
    @Transactional
    @Query(UPDATE_POOLING_STATUS_BY_ATRN)
    void updatePoolingStatusToQ(@Param("atrnNumber") String atrnNumber, @Param("poolingStatus") String poolingStatus);

    @Modifying
    @Transactional
    @Query(UPDATE_STATUS_BY_ATRN)
    void updateTransactionStatusAndPaymentStatus(@Param("atrnNumber") String atrnNumber,
                                                @Param("transactionStatus") String transactionStatus,
                                                @Param("paymentStatus") String paymentStatus,
                                                @Param("poolingStatus") String poolingStatus);

    @Modifying
    @Transactional
    @Query(UPDATE_MERCHANT_ORDER_PAYMENT_STATUS_LIST)
    void batchUpdateTransactionStatusAndPaymentStatus(@Param("atrnNumber") List<String> atrnNumber,
                                                      @Param("transactionStatus") String transactionStatus,
                                                      @Param("paymentStatus") String paymentStatus,
                                                      @Param("poolingStatus") String poolingStatus);
}
