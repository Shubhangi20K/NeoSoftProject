package com.epay.gateway.mapper;

import com.epay.gateway.dto.MerchantOrderPaymentDto;
import com.epay.gateway.entity.MerchantOrderPaymentEntity;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(builder = @Builder(disableBuilder = true), componentModel = "spring")
public interface MerchantOrderPaymentMapper {
    List<MerchantOrderPaymentDto> mapMerchantOrderPaymentEntity(List<MerchantOrderPaymentEntity> merchantOrderPaymentEntityList);

    MerchantOrderPaymentDto mapMerchantOrderPaymentEntity(MerchantOrderPaymentEntity merchantOrderPaymentEntity);
}
