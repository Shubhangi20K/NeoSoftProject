package com.epay.gateway.util;

import com.epay.gateway.util.enums.PayMode;
import lombok.experimental.UtilityClass;

import java.security.SecureRandom;
import java.util.Random;

@UtilityClass
public class GatewayPoolingUtil {

    private static final Random random = new SecureRandom();

    public static String createAtrnNumber(String mId, PayMode payMode) {
        StringBuilder sb = new StringBuilder();
        sb.append(payMode.toString(), 0, 2)
                .append(mId, 4, 7)
                .append(Long.toString(System.currentTimeMillis()), 0, 9)
                .append(Long.toString(System.nanoTime(), 36), 3, 9);
        while (sb.length() < 20) {
            sb.append(random.nextInt(10));
        }
        return sb.toString();
    }
}
