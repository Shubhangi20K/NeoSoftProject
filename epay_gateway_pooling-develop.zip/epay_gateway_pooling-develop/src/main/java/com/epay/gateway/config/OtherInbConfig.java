package com.epay.gateway.config;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

/**
 * Class Name:OtherInbConfig
 * *
 * Description:
 * *
 * Author:Gireesh M
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
@Data
@Configuration
public class OtherInbConfig {

    @Value("${epay.payment.otherinb.success.base.path}")
    private  String successUrl;

    @Value("${epay.payment.otherinb.fail.base.path}")
    private  String failUrl;

    @Value("${epay.payment.other_inb_mid}")
    private  String otherInbMid;

    @Value("${epay.payment.other_inb_key}")
    private  String otherInbKey;

    @Value("${epay.payment.merchant_post_url}")
    private  String merchantPostUrl;

    @Value("${epay.payment.sbiinb.otherinbstatusquery}")
    private String otherInbStatusQuery;

}