package com.epay.gateway.externalservice;

import com.epay.gateway.config.InbConfig;
import com.epay.gateway.exceptions.GatewayPoolingException;
import com.epay.gateway.util.GatewayPoolingConstant;
import com.epay.gateway.util.GatewayPoolingErrorConstants;
import com.epay.gateway.util.InbEncryptionDecryptionUtil;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import javax.net.ssl.SSLContext;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.text.MessageFormat;
import java.util.Optional;

import static com.epay.gateway.util.GatewayPoolingConstant.*;

@Component
@RequiredArgsConstructor
public class InbClientService {

    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private final InbConfig inbConfig;

    /**
     * this method is used to get hit the inb service API
     *
     * @param encryptedInbRequest String
     * @return String
     */
    public String processingDoubleVerRequest(String encryptedInbRequest) {
        try {
            String encryptedDVData = Optional.ofNullable(URLEncoder.encode(InbEncryptionDecryptionUtil.encrypt(encryptedInbRequest), GatewayPoolingConstant.UTF_EIGHT)).filter(x -> !x.isEmpty()).orElseThrow(() -> new GatewayPoolingException(GatewayPoolingErrorConstants.ENCRYPTION_ERROR_CODE, GatewayPoolingErrorConstants.ENCRYPTION_ERROR_MESSAGE));
            logger.info("Payment Callback Encrypted and Encoded Double Verification {} " + encryptedDVData);

            String doubleVerificationResp = Optional.ofNullable(sbiDVResponseConn(inbConfig.getSbiNburl(),
                            SBIINB_MERCH_CODE_CONST
                                    .concat(SBIINB_MERCH_CODE_VAL)
                                    .concat(SBIINB_ENC_DATA).concat(encryptedDVData)))
                    .filter(x -> !x.isEmpty()).orElseThrow(() -> new GatewayPoolingException(GatewayPoolingErrorConstants.DOUBLE_VERIFICATION_ERROR_CODE, GatewayPoolingErrorConstants.DOUBLE_VERIFICATION_ERROR_MESSAGE));
            logger.info("Payment Callback Encrypted Double Verification Response {} ", doubleVerificationResp);

            String decryptedDVResponse = URLDecoder.decode(InbEncryptionDecryptionUtil.decrypt(doubleVerificationResp.trim().replaceAll(NEW_LINE_REGEX, PATTERN_EMPTY).replace(PATTERN_SPACE, PATTERN_EMPTY)), StandardCharsets.UTF_8);
            logger.info("Payment Callback Decrypted and Decode Double Verification Response {} ", decryptedDVResponse);
            return decryptedDVResponse;
        } catch (Exception e) { // Exception throw by INB Bank Algorithm
            logger.error("Exception While processingDoubleVerRequest  {}", e);
            throw new GatewayPoolingException(GatewayPoolingErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(GatewayPoolingErrorConstants.INVALID_ERROR_MESSAGE, INVALID_HASH));
        }
    }

    private String sbiDVResponseConn(String bankUrl, String encryptedData) {
        logger.info("SBIINB DV Request posting parameters DV Url {} and encryptedData {} ", bankUrl, encryptedData);
        try {
            SSLContext sc = SSLContext.getInstance(HTTPS_PROTOCOLS_VALUE);
            sc.init(null, null, new SecureRandom());
            System.setProperty(JAVA_PROTOCAL_HANDLER_KEY, JAVA_PROTOCAL_HANDLER_VALUE);
            System.setProperty(HTTPS_PROXY_SET_KEY, HTTPS_PROXY_SET_VALUE);
            System.setProperty(HTTPS_PROTOCOLS_KEY, HTTPS_PROTOCOLS_VALUE);
            System.setProperty(HTTPS_PROXY_HOST_KEY, HTTPS_PROXY_HOST_VALUE);
            System.setProperty(HTTPS_PROXY_PORT_KEY, HTTPS_PROXY_PORT_VALUE);

            WebClient webClient = WebClient.builder()
                    .baseUrl(bankUrl)
                    .build();
            logger.info("webClient URL for SBIINB {} ", webClient);
            return webClient.post().header(REQUESTPROPERTY, URL_ENCODED_CONTENT_TYPE)
                    .bodyValue(encryptedData).retrieve().onStatus(status -> {
                                logger.info("SBIINB DV Response received {} ", status);
                                return !status.is2xxSuccessful();
                            },
                            clientResponse ->
                                    clientResponse.bodyToMono(String.class)
                                            .flatMap(errorBody -> Mono.error(new GatewayPoolingException(GatewayPoolingErrorConstants.HTTP_CONNECTION_ERROR_CODE, errorBody)
                                            ))
                    ).bodyToMono(String.class).
                    doOnNext(body -> logger.info("responseCode SBIINB {} ", body))
                    .doOnError(error -> logger.info("error responseCode SBIINB {} ", error))
                    .onErrorResume(error -> {
                        logger.info("error responseCode SBIINB {} ", error);
                        return Mono.error(() -> new GatewayPoolingException(GatewayPoolingErrorConstants.HTTP_CONNECTION_ERROR_CODE, error.getMessage()));
                    }).block();
        } catch (Exception e) { // Exception throw by INB Bank Algorithm
            logger.error("Exception While SBIDVResponseConn  {}", e);
            throw new GatewayPoolingException(GatewayPoolingErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(GatewayPoolingErrorConstants.INVALID_ERROR_MESSAGE, INVALID_HASH));
        }
    }
}
