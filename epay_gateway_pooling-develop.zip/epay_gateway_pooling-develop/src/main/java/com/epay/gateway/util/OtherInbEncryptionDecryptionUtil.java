package com.epay.gateway.util;

import Decoder.BASE64Decoder;
import Decoder.BASE64Encoder;
import com.epay.gateway.exceptions.GatewayPoolingException;
import lombok.experimental.UtilityClass;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.text.MessageFormat;

@UtilityClass
public class OtherInbEncryptionDecryptionUtil {

    private static final String ENCRYPT_ALGO = "AES/GCM/NoPadding";
    private static final int TAG_LENGTH_BIT = 128;
    private static final int IV_LENGTH_BYTE = 16;

    public static String encryptAesGcmNoPadding(String keyn, String value) {
        String result;
        try {
            Cipher cipher = Cipher.getInstance(ENCRYPT_ALGO);
            byte[] iv = new byte[IV_LENGTH_BYTE];
            SecretKey key = decodedValue(keyn);
            GCMParameterSpec gcmParameterSpec = new GCMParameterSpec(TAG_LENGTH_BIT, iv);
            cipher.init(Cipher.ENCRYPT_MODE, key, gcmParameterSpec);
            byte[] encryptedValue = cipher.doFinal(value.getBytes(StandardCharsets.UTF_8));
            BASE64Encoder base64encoder = new BASE64Encoder();
            result = base64encoder.encode(encryptedValue);
        } catch (Exception ex) {
            throw new GatewayPoolingException(GatewayPoolingErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(GatewayPoolingErrorConstants.INVALID_ERROR_MESSAGE, "Encrypt AES GCM NoPadding"));
        }
        return result;
    }

    public static String decryptAesGcmNoPadding(String keyn, String value) {
        String result;
        try {
            Cipher cipher = Cipher.getInstance(ENCRYPT_ALGO);
            byte[] iv = new byte[IV_LENGTH_BYTE];
            SecretKey key = decodedValue(keyn);
            GCMParameterSpec gcmParameterSpec = new GCMParameterSpec(TAG_LENGTH_BIT, iv);
            BASE64Decoder decoder = new BASE64Decoder();
            byte[] encryptedBytes = decoder.decodeBuffer(value);
            cipher.init(Cipher.DECRYPT_MODE, key, gcmParameterSpec);
            byte[] decryptedBytes = cipher.doFinal(encryptedBytes);
            result = new String(decryptedBytes, StandardCharsets.UTF_8);
        } catch (Exception ex) {
            throw new GatewayPoolingException(GatewayPoolingErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(GatewayPoolingErrorConstants.INVALID_ERROR_MESSAGE, "Decrypt AES GCM NoPadding"));
        }
        return result;
    }

    public static SecretKey decodedValue(String key) throws IOException {
        BASE64Decoder base64decoder = new BASE64Decoder();
        byte[] decodedKey = base64decoder.decodeBuffer(key);
        return new SecretKeySpec(decodedKey, 0, decodedKey.length, "AES");
    }
}
