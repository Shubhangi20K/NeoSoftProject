package com.epay.gateway.util.queries;

import lombok.experimental.UtilityClass;

@UtilityClass
public class MerchantOrderPaymentQueries {
    //Fetching pending data within 24hrs.
    public static final String FIND_BY_PENDING_STATUS = """
            SELECT T.* FROM MERCHANT_ORDER_PAYMENTS T
            WHERE TRANSACTION_STATUS = 'PENDING'
            AND PAYMENT_STATUS = 'PENDING' AND POOLING_STATUS = 'P'
            AND (TIMESTAMP '1970-01-01 00:00:00' + NUMTODSINTERVAL(CREATED_DATE / 1000, 'SECOND'))
            BETWEEN (TIMESTAMP '1970-01-01 00:00:00' + NUMTODSINTERVAL(:currentMilliSec / 1000, 'SECOND'))
            AND (TIMESTAMP '1970-01-01 00:00:00' + NUMTODSINTERVAL(:currentMilliSec / 1000 + 86400, 'SECOND'))
            """;

    //Fetching pending data above 24hrs.
    public static final String FIND_BY_PENDING_STATUS_ABOVE_24Hrs = """
            SELECT T.* FROM MERCHANT_ORDER_PAYMENTS T
            WHERE TRANSACTION_STATUS = 'PENDING' AND PAYMENT_STATUS = 'PENDING' AND POOLING_STATUS = 'P'
            AND (TIMESTAMP '1970-01-01 00:00:00' + NUMTODSINTERVAL(CREATED_DATE / 1000, 'SECOND'))
            < (TIMESTAMP '1970-01-01 00:00:00' + NUMTODSINTERVAL(:currentMilliSec / 1000 - 86400, 'SECOND'))
            """;

    //Fetching booked data within 24hrs
    public static final String FIND_BY_PAYMENT_BOOKED_STATUS = """
            SELECT T.* FROM MERCHANT_ORDER_PAYMENTS T
            WHERE TRANSACTION_STATUS = 'BOOKED' AND PAYMENT_STATUS = 'PAYMENT_INITIATION_START'
            AND POOLING_STATUS = 'P'
            AND (TIMESTAMP '1970-01-01 00:00:00' + NUMTODSINTERVAL(CREATED_DATE / 1000, 'SECOND'))
            BETWEEN (TIMESTAMP '1970-01-01 00:00:00' + NUMTODSINTERVAL(:currentMilliSec / 1000, 'SECOND'))
            AND (TIMESTAMP '1970-01-01 00:00:00' + NUMTODSINTERVAL(:currentMilliSec / 1000 + 86400, 'SECOND'))
            """;

    public static final String UPDATE_POOLING_STATUS_BY_ATRN =
            "UPDATE MerchantOrderPaymentEntity mopDtl SET mopDtl.poolingStatus =:poolingStatus WHERE mopDtl.atrnNumber =:atrnNumber";

    public static final String UPDATE_STATUS_BY_ATRN =
            "UPDATE MerchantOrderPaymentEntity mop SET mop.transactionStatus =:transactionStatus, mop.paymentStatus =:paymentStatus, mop.poolingStatus =:poolingStatus WHERE mop.atrnNumber =:atrnNumber";

    public static final String UPDATE_MERCHANT_ORDER_PAYMENT_STATUS_LIST =
            "UPDATE MerchantOrderPaymentEntity mop SET mop.transactionStatus =:transactionStatus, mop.paymentStatus =:paymentStatus, mop.poolingStatus =:poolingStatus WHERE mop.atrnNumber IN :atrnNumber";
}