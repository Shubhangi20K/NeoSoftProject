package com.epay.gateway.util;

import lombok.experimental.UtilityClass;

@UtilityClass
public class GatewayPoolingConstant {

    public static final String SBIINB_DV_REQUEST = "txnrefNo={0}|amount={1}";
    public static final String DV_REQUEST_TYPE = "DV Request";
    public static final String CREATED_BY = "SBI Net Banking";
    public static final String PATTERN_EMPTY = "";
    public static final String UTF_EIGHT = "UTF-8";
    public static final String SBIEPAY = "SBIEPAY";
    public static final String SUCCESS = "SUCCESS";
    public static final String FAILURE = "FAILURE";
    public static final String PENDING = "PENDING";
    public static final String SBIINB_MERCH_CODE_CONST = "merchant_code=";
    public static final String SBIINB_MERCH_CODE_VAL = "SBIEPAY2";
    public static final String SBIINB_ENC_DATA = "&encdata=";
    public static final String SBIINB_CHECKSUM = "|checkSum=";
    public static final String SBIINB_KEY_PATH = "keys/SBIEPAY_NEW.key";
    public static final String SBIINB_AES_GCM_NOPADDING = "AES/GCM/NoPadding";
    public static final String JAVA_PROTOCAL_HANDLER_KEY = "java.protocol.handler.pkgs";
    public static final String HTTPS_PROXY_SET_VALUE = "true";
    public static final String HTTPS_PROTOCOLS_VALUE = "TLSv1.2";
    public static final String HTTPS_PROXY_HOST_VALUE = "10.191.191.39";
    public static final String HTTPS_PROXY_PORT_VALUE = "9090";
    public static final String HTTPS_PROXY_SET_KEY = "https.proxySet";
    public static final String HTTPS_PROTOCOLS_KEY = "https.protocols";
    public static final String HTTPS_PROXY_HOST_KEY = "https.proxyHost";
    public static final String HTTPS_PROXY_PORT_KEY = "https.proxyPort";
    public static final String REQUESTPROPERTY = "Content-Type";
    public static final String JAVA_PROTOCAL_HANDLER_VALUE = "com.sun.net.ssl.internal.www.protocol";

    public static final String NEW_LINE_REGEX = "[\\r\\n]";
    public static final String PATTERN_SPACE = " ";

    public static final String URL_ENCODED_CONTENT_TYPE = "application/x-www-form-urlencoded";

    public static final String PIPE_CONST = "\\|";
    public static final String PATTERN_EQUAL_TO_CONST = "=";
    public static final String NA = "NA";

    public static final String INVALID_HASH = "INVALID_HASH";

    public static final String AES_ALGO = "AES";
    public static final String SHA1PRNG = "SHA1PRNG";
    public static final String OTHER_INB_CALLBACK = "aggregatorId={0}&queryRequest={1}&merchantId={2}";
    public static final String OTHER_INB_DV_CALLBACK = "{0}|{1}|{2}|{3}";

    public static final String UAT_JAVA_PROTOCAL_HANDLER_KEY = "java.protocol.handler.pkgs";
    public static final String UAT_JAVA_PROTOCAL_HANDLER_VALUE = "com.sun.net.ssl.internal.www.protocol";
    public static final String UAT_HTTPS_PROXY_SET_VALUE = "true";
    public static final String UAT_HTTPS_PROTOCOLS_VALUE = "TLSv1.2";
    public static final String UAT_HTTPS_PROXY_HOST_VALUE = "10.176.206.224";
    public static final String UAT_HTTPS_PROXY_PORT_VALUE = "3066";

    public static final String TRANSACTION_STATUS_BOOKED = "BOOKED";
    public static final String TRANSACTION_STATUS_PENDING = "PENDING";

    public static final String POOLING_STATUS_PENDING = "P";
    public static final String POOLING_STATUS_QUEUE = "Q";
    public static final String POOLING_STATUS_SUCCESS = "Y";
    public static final String POOLING_STATUS_FAILURE = "F";

    public static final String CORRELATION_ID = "correlation";
    public static final String SCENARIO = "scenario";
    public static final String OPERATION = "operation";
    public static final String X_CORRELATION_ID = "X-Correlation-Id";
}