package com.epay.gateway.dto;

import lombok.*;

import java.math.BigDecimal;
import java.util.Date;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class MerchantOrderPaymentDto {

    private String atrnNumber;
    private String merchantId;
    private String orderRefNumber;
    private String sbiOrderRefNumber;
    private String bankReferenceNumber;
    private String payMode;
    private String currencyCode;
    private BigDecimal orderAmount;
    private String paymentStatus;
    private String transactionStatus;
    private String failReason;
    private BigDecimal debitAmount;
    private String gstin;
    private String channelBank;
    private String settlementStatus;
    private String refundStatus;
    private String cancellationStatus;
    private String cin;
    private String pgBankCode;
    private String payProcId;
    private String paymodeType;
    private String gatewayIssueMECode;
    private String pushResponse;
    private String pushStatus;
    private String poolingStatus;
    private String createdBy;
    private String updatedBy;
    private Long createdDate;
    private Long updatedDate;
    private Date paymentSuccessDate;
    private BigDecimal availableRefundAmount;
    private BigDecimal chargeBackAmount;
    private String chargeBackStatus;
}