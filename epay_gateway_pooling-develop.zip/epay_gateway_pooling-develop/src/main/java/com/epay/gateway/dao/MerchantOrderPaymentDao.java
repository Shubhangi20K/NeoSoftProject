package com.epay.gateway.dao;

import com.epay.gateway.dto.MerchantOrderPaymentDto;
import com.epay.gateway.mapper.MerchantOrderPaymentMapper;
import com.epay.gateway.repository.MerchantOrderPaymentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Class Name: MerchantOrderPaymentDao
 * *
 * Description:
 * *
 * Author: Gireesh M
 * Copyright (c) 2025 [State Bank of India]
 * ALl rights reserved
 * *
 * Version: 1.0
 */
@Component
@RequiredArgsConstructor
public class MerchantOrderPaymentDao {

    private final MerchantOrderPaymentRepository merchantOrderPaymentRepository;
    private final MerchantOrderPaymentMapper merchantOrderPaymentMapper;

    public List<MerchantOrderPaymentDto> getPendingMerchantOrderPayments(Long currentMilliSecond) {
        return merchantOrderPaymentMapper.mapMerchantOrderPaymentEntity(merchantOrderPaymentRepository.findPendingMerchantOrderPayments(currentMilliSecond));
    }

    public List<MerchantOrderPaymentDto> getPendingMerchantOrderPayments24Hrs(Long currentMilliSecond) {
        return merchantOrderPaymentMapper.mapMerchantOrderPaymentEntity(merchantOrderPaymentRepository.findPendingMerchantOrderPaymentsAbove24hrs(currentMilliSecond));
    }

    public List<MerchantOrderPaymentDto> getBookedMerchantOrderPayments(Long currentMilliSecond) {
        return merchantOrderPaymentMapper.mapMerchantOrderPaymentEntity(merchantOrderPaymentRepository.findBookedMerchantOrderPayments(currentMilliSecond));
    }


    public void updatePoolingStatus(String listOfAtrnNumber, String poolingStatus) {
        merchantOrderPaymentRepository.updatePoolingStatusToQ(listOfAtrnNumber, poolingStatus);
    }

    public void updateTransactionStatusAndPaymentStatus(String listOfAtrnNumber, String transactionStatus, String paymentStatus, String poolingStatus) {
         merchantOrderPaymentRepository.updateTransactionStatusAndPaymentStatus(listOfAtrnNumber, transactionStatus, paymentStatus, poolingStatus);
    }

    public void updateTransactionStatusAndPaymentStatus(List<String> listOfAtrnNumber, String transactionStatus, String paymentStatus, String poolingStatus) {
        merchantOrderPaymentRepository.batchUpdateTransactionStatusAndPaymentStatus(listOfAtrnNumber, transactionStatus, paymentStatus, poolingStatus);
    }
}
