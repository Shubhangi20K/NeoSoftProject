package com.epay.gateway.client;

import com.epay.gateway.exceptions.GatewayPoolingException;
import com.epay.gateway.model.response.GatewayPoolingResponse;
import com.epay.gateway.util.GatewayPoolingErrorConstants;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import io.netty.handler.ssl.SslContextBuilder;
import io.netty.handler.ssl.util.InsecureTrustManagerFactory;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.MDC;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.netty.http.client.HttpClient;

import java.net.URI;
import java.text.MessageFormat;

import static com.epay.gateway.util.GatewayPoolingConstant.CORRELATION_ID;
import static com.epay.gateway.util.GatewayPoolingConstant.X_CORRELATION_ID;

/**
 * Copyright (c) [2025] [State Bank of India]
 * All rights reserved.
 * <p>
 * Author:Gireesh M
 * Version:1.0
 */
@Getter
public class ApiClient {
    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private final String baseUrl;
    private final WebClient webClient;

    public ApiClient(String baseUrl) {
        this.baseUrl = baseUrl;
        this.webClient = WebClient.builder()
                .clientConnector(new ReactorClientHttpConnector(HttpClient.create().secure(t -> t.sslContext(SslContextBuilder.forClient().trustManager(InsecureTrustManagerFactory.INSTANCE)))))
                .build();
    }

    protected HttpHeaders prepareHttpHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);
        headers.add(X_CORRELATION_ID, MDC.get(CORRELATION_ID));
        return headers;
    }

    protected <T, R> GatewayPoolingResponse<R> post(String urlPath, T requestBody, ParameterizedTypeReference<GatewayPoolingResponse<R>> typeReference) {
        URI uri = URI.create(getBaseUrl() + urlPath);
        logger.info("Calling uri: {}", uri);
        logger.debug("Request body: {}", requestBody);
        return getWebClient().post().uri(uri).headers(prepareHttpHeaders()::addAll).bodyValue(requestBody).retrieve().onStatus(httpStatusCode -> httpStatusCode.is4xxClientError() || httpStatusCode.is5xxServerError(), clientResponse -> Mono.error(new GatewayPoolingException(GatewayPoolingErrorConstants.EXTERNAL_SERVICE_ERROR_CODE, MessageFormat.format(GatewayPoolingErrorConstants.EXTERNAL_SERVICE_ERROR_MESSAGE, getServiceName())))).bodyToMono(typeReference).block();
    }

    /**
     * Return current service name.
     * @return String
     */
    private String getServiceName() {
        return this.getClass().getSimpleName().replace("Client", StringUtils.EMPTY).replace("Services", StringUtils.EMPTY);
    }

    protected <T> GatewayPoolingResponse<T> get(String urlPath, ParameterizedTypeReference<GatewayPoolingResponse<T>> typeReference) {
        URI uri = URI.create(getBaseUrl() + urlPath);
        return getWebClient().get().uri(uri).headers(httpHeaders -> httpHeaders.addAll(prepareHttpHeaders())).retrieve().onStatus(httpStatusCode -> httpStatusCode.is4xxClientError() || httpStatusCode.is5xxServerError(), clientResponse -> Mono.error(new GatewayPoolingException(GatewayPoolingErrorConstants.NOT_FOUND_ERROR_CODE, MessageFormat.format(GatewayPoolingErrorConstants.NOT_FOUND_ERROR_MESSAGE, "Encryption Key")))).bodyToMono(typeReference).block();
    }
}