package com.epay.gateway.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.data.gemfire.config.annotation.ClientCacheApplication;
import org.springframework.data.gemfire.config.annotation.EnableEntityDefinedRegions;
import org.springframework.data.gemfire.repository.config.EnableGemfireRepositories;

/**
 * Class Name: GemFireConfiguration * Description: * Author: Gireesh M
 * <p>
 * Copyright (c) 2025 [State Bank of India] All rights reserved * Version:1.0
 */
@Configuration
@ClientCacheApplication
@EnableEntityDefinedRegions(basePackages = "com.sbi.epay.cache")
@EnableGemfireRepositories(basePackages = "com.epay.gateway.repository.cache")
public class GemFireConfiguration {
}
