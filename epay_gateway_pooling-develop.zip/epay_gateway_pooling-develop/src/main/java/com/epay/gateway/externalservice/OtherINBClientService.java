package com.epay.gateway.externalservice;

import com.epay.gateway.exceptions.GatewayPoolingException;
import com.epay.gateway.util.GatewayPoolingConstant;
import com.epay.gateway.util.GatewayPoolingErrorConstants;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import javax.net.ssl.SSLContext;
import java.security.SecureRandom;
import java.text.MessageFormat;

import static com.epay.gateway.util.GatewayPoolingConstant.*;
import static com.epay.gateway.util.GatewayPoolingErrorConstants.HTTP_CONNECTION_ERROR_CODE;
import static com.epay.gateway.util.GatewayPoolingErrorConstants.INVALID_ERROR_MESSAGE;

@Component
@RequiredArgsConstructor
public class OtherINBClientService {

    LoggerUtility logger = LoggerFactoryUtility.getLogger(OtherINBClientService.class);

    public String otherINBDVResponseConn(String bankDvURL, String encryptedData) {
        logger.info("Other INB DV Request posting parameters DV Url {} and encryptedData {} ", bankDvURL, encryptedData);
        try {
            SSLContext sc = SSLContext.getInstance(HTTPS_PROTOCOLS_VALUE);
            sc.init(null, null, new SecureRandom());
            System.setProperty(UAT_JAVA_PROTOCAL_HANDLER_KEY, UAT_JAVA_PROTOCAL_HANDLER_VALUE);
            System.setProperty(HTTPS_PROXY_SET_KEY, UAT_HTTPS_PROXY_SET_VALUE);
            System.setProperty(HTTPS_PROTOCOLS_KEY, UAT_HTTPS_PROTOCOLS_VALUE);
            System.setProperty(HTTPS_PROXY_HOST_KEY, UAT_HTTPS_PROXY_HOST_VALUE);
            System.setProperty(HTTPS_PROXY_PORT_KEY, UAT_HTTPS_PROXY_PORT_VALUE);

            WebClient webClient = WebClient.builder()
                    .baseUrl(bankDvURL)
                    .build();
            logger.info("webClient URL for otherINB {} ", webClient);
            return webClient.post().header(GatewayPoolingConstant.REQUESTPROPERTY, URL_ENCODED_CONTENT_TYPE)
                    .bodyValue(encryptedData).retrieve().onStatus(status -> {
                                logger.info("DV Response received status for otherINB {} ", status);
                                return !status.is2xxSuccessful();
                            },
                            clientResponse ->
                                    clientResponse.bodyToMono(String.class)
                                            .flatMap(errorBody -> Mono.error(new GatewayPoolingException(HTTP_CONNECTION_ERROR_CODE, errorBody)
                                            ))
                    ).bodyToMono(String.class).
                    doOnNext(body -> logger.info("responseCode for otherINB {} ", body)).doOnError(error -> logger.info("error responseCode for otherINB {} ", error)).onErrorResume(error -> {
                        logger.info("error responseCode for otherINB {} ", error);
                        return Mono.error(() -> new GatewayPoolingException(HTTP_CONNECTION_ERROR_CODE, error.getMessage()));
                    }).block();
        } catch (Exception e) { // Exception throw by INB Bank Algorithm
            logger.error("Error in otherINB client service : {}", e);
            throw new GatewayPoolingException(GatewayPoolingErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(INVALID_ERROR_MESSAGE, INVALID_HASH));
        }
    }
}
