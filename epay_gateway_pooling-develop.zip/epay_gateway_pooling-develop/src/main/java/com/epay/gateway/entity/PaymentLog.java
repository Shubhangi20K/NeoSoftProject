package com.epay.gateway.entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.UUID;

/**
 * Class Name: PaymentLog
 * *
 * Description:
 * *
 * Author: Gireesh M
 * Copyright (c) 2025 [State Bank of India]
 * ALl rights reserved
 * *
 * Version: 1.0
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "PAYMENT_LOG_DETAILS")
@Builder
public class PaymentLog {

   @Id
   @GeneratedValue(strategy = GenerationType.UUID)
   @Column(nullable = false, updatable = false, unique = true)
   private UUID id;
   private String atrnNum;
   private String sbiOrderRefNumber;
   private String requestType;
   @Lob
   private byte[] log;
   private String createdBy;
   private String updatedBy;
   @Column(name = "CREATED_DATE_NUM")
   private Long createdDate;
   private Long updatedDate;

}