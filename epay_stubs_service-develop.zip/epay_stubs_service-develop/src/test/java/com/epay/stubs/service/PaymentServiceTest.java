package com.epay.stubs.service;

import org.springframework.boot.test.context.SpringBootTest;

/**
 * Class Name:PaymentServiceTest
 * *
 * Description:
 * *
 * Author: V1018344(Rahul Prajapati)
 * Copyright (c) 2024 [State Bank of India]
 * ALl rights reserved
 * *
 * Version: 1.0
 */
@SpringBootTest
public class PaymentServiceTest {

}