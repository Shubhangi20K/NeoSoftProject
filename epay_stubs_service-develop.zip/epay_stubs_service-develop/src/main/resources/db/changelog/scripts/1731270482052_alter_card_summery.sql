--liquibase formatted sql
--changeset PAYMENT:12

ALTER TABLE card_payment_summary
ADD CARD_HASH varchar2(50);



