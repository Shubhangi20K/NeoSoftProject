package com.epay.stubs.util;

/**
 * Class Name:CardIntlUtil
 * *
 * Description: Customer creation for given Merchant.
 * *
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */

import com.epay.stubs.config.CardConfigDeatils;
import com.epay.stubs.dto.CardOnBoardDetailsResponseDto;
import com.epay.stubs.dto.TransactionDto;
import com.epay.stubs.exceptions.PaymentException;
import com.epay.stubs.model.request.*;
import com.epay.stubs.model.response.*;
import com.epay.stubs.validator.PaymentValidator;
import com.google.gson.Gson;
import com.sbi.epay.encryptdecrypt.service.HashingService;
import com.sbi.epay.encryptdecrypt.util.enums.HashAlgorithm;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import com.sbipg.mlehelper.beans.AES;
import com.sbipg.mlehelper.beans.EncryptedRequestData;
import com.sbipg.mlehelper.util.DecryptionUtil;
import com.sbipg.mlehelper.util.EncryptionUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.security.interfaces.RSAPrivateKey;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

@Component
@RequiredArgsConstructor
public class CardIntlUtil {

    LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private final CardEncryptionDecryptionINTLUtil cardEncryptionDecryptionUtil;
    private final PaymentValidator PaymentValidator;
    private final CardConfigDeatils cardConfigDeatils;

    /**
     * @return: String
     * @methodName: maskAltId
     * @@Method-Description: Process card masking
     * @param: input, startLength,endLength
     * @Exception: or @Error :Exception
     */
    public String maskAltId(String input, int startLength,int endLength) {
        return IntStream.range(0, input.length())
                .mapToObj(i -> (i >= startLength && i < input.length() - endLength) ? "*" : String.valueOf(input.charAt(i)))
                .collect(Collectors.joining());
    }

    /**
     * @return: HashMap<String, String>
     * @methodName: createAltIdRequestHeader
     * @@Method-Description: Process setting header
     * @param: clientApiUser,clientApiKey,XauthToken,clientId
     * @Exception: or @Error :Exception
     */
    public HashMap<String, String> createAltIdRequestHeader(String clientApiUser,String clientApiKey,String XauthToken,String clientId) {
        HashMap<String, String> requestHeaders = new HashMap<>();
        requestHeaders.put(PaymentConstants.REQUESTPROPERTY, PaymentConstants.APPLICATION_JSON);
        requestHeaders.put(PaymentConstants.ACCEPT_ACTION, PaymentConstants.APPLICATION_JSON);
        requestHeaders.put(PaymentConstants.clientApiUser, clientApiUser);
        requestHeaders.put(PaymentConstants.clientApiKey, clientApiKey);
        requestHeaders.put(PaymentConstants.XauthToken, XauthToken);
        requestHeaders.put(PaymentConstants.clientId, clientId);
        return requestHeaders;
    }
    /**
     * @return: HashMap<String, String>
     * @methodName: createThreeDsRequestHeader
     * @@Method-Description: Process setting header
     * @param: xApiKey,pgInstanceId
     * @Exception: or @Error :Exception
     */
    public HashMap<String, String> createThreeDsRequestHeader(String xApiKey,String pgInstanceId) {
        HashMap<String, String> requestHeaders = new HashMap<>();
        requestHeaders.put(PaymentConstants.REQUESTPROPERTY, PaymentConstants.APPLICATION_JSON);
        requestHeaders.put(PaymentConstants.ACCEPT_ACTION, PaymentConstants.APPLICATION_JSON);
        requestHeaders.put(PaymentConstants.XAPIKEY, xApiKey);
        requestHeaders.put(PaymentConstants.PgInstanceId, pgInstanceId);
        return requestHeaders;
    }
    /**
     * @return: HashMap<String, String>
     * @methodName: createAuthorizationRequestHeader
     * @@Method-Description: Process setting header
     * @param: xApiKey,pgInstanceId,merchantId
     * @Exception: or @Error :Exception
     */
    public HashMap<String, String> createAuthorizationRequestHeader(String xApiKey,String pgInstanceId,String merchantId) {
        HashMap<String, String> requestHeaders = new HashMap<>();
        requestHeaders.put(PaymentConstants.REQUESTPROPERTY, PaymentConstants.APPLICATION_JSON);
        requestHeaders.put(PaymentConstants.ACCEPT_ACTION, PaymentConstants.APPLICATION_JSON);
        requestHeaders.put(PaymentConstants.XAPIKEY, xApiKey);
        requestHeaders.put(PaymentConstants.PgInstanceId, pgInstanceId);
        requestHeaders.put(PaymentConstants.MerchantId, merchantId);
        return requestHeaders;
    }
    /**
     * @return: String
     * @methodName: saveSummeryData
     * @@Method-Description: Process setting card summery data
     * @param: PVrqResponse ,PArqResponse ,TokenAltResponse
     * @Exception: or @Error :Exception
     */
    public String saveSummaryData(String paymentRequestCard, PVrqResponse pVrqResponse, PArqResponse pArqResponse) {
        //Insert Card Summery In DB
        CardSummaryResponse cardSummaryResponse = CardSummaryResponse.builder()
                .threeDSServerTransID(pVrqResponse.getThreeDSServerTransID()).tokenExpiryDate(PaymentConstants.TWO_ZERO).var2(PaymentConstants.EMPTY)
                .transStatus(pArqResponse.getTransStatus()).acsTransID(pArqResponse.getAcsTransID()).merchantTransID(pArqResponse.getMerchantTransID())
                .dsTransID(pArqResponse.getDsTransID()).authenticationUrl(pArqResponse.getAuthenticationUrl())
                .eci(pArqResponse.getEci()).authenticationValue(pArqResponse.getAuthenticationValue())
                .p_messageVersion(pArqResponse.getP_messageVersion())
                .paymentCard(paymentRequestCard)
                .build();
        return new Gson().toJson(cardSummaryResponse);
    }

    /**
     * @return: String
     * @methodName: createPvrqVersioningPayload
     * @@Method-Description: Process setting pVrq data
     * @param: paymentRequestCard, altCardNo
     * @Exception: or @Error :Exception
     */
    public String  createPvrqVersioningPayload(PaymentRequestCard paymentRequestCard) {
        return new Gson().toJson(PVrqRequest.builder()
                .messageType(PaymentConstants.messageType_PVRQ)
                .deviceChannel(cardConfigDeatils.getDeviceChannel())
                .merchantTransID(paymentRequestCard.getAtrn())
                .acquirerBIN(getAcquirerBIN(paymentRequestCard.getPayProcId()))
                .acquirerID(cardConfigDeatils.getAcquirerID())
                .threeDSRequestorMethodNotificationRespURL(cardConfigDeatils.getCallbackUrl_intl())
                .p_messageVersion(cardConfigDeatils.getP_messageVersion())
                .acctNumber(paymentRequestCard.getAltNumber())
                .build());
    }

    /**
     * @return: String
     * @methodName: createParqPayload
     * @@Method-Description: Process setting pArq data
     * @param: transactionDto,cardOnboardDto, paymentRequestCard, altIDResponse, pVrqResponse
     * @Exception: or @Error :Exception
     */
    public String  createParqPayload(TransactionDto transactionDto,CardOnBoardDetailsResponseDto cardOnboardDto, PaymentRequestCard paymentRequestCard, PVrqResponse pVrqResponse)  {
        PArqRequest pArqRequest = PArqRequest.builder()
                .messageType(PaymentConstants.messageType_PARQ)
                .deviceChannel(cardConfigDeatils.getDeviceChannel())
                .merchantTransID(paymentRequestCard.getAtrn())
                .messageVersion(cardConfigDeatils.getP_messageVersion())
                .messageCategory(cardConfigDeatils.getMessageCategory())
                .threeDSServerTransID(pVrqResponse.getThreeDSServerTransID())
                .threeDSRequestorID(PaymentConstants.aggregatorid)
                .threeDSRequestorName(PaymentConstants.aggregatorid)
                .threeDSRequestorURL(cardConfigDeatils.getCallbackUrl_intl())
                .threeDSCompInd(PaymentConstants.U_CONST)
                .threeDSRequestorAuthenticationInd(PaymentConstants.ONE)
                .threeDSRequestorAuthenticationInfo(threeDsRequestAuthenticationInfo())
                .acctType(getAccType(paymentRequestCard.getPaymode()))
                .addrMatch(PaymentConstants.YES)
                .mcc(cardConfigDeatils.getMCC())
                .merchantName(cardOnboardDto.getLegalName().substring(0, Math.min(cardOnboardDto.getLegalName().length(), 20)))
                .merchantUrl( cardConfigDeatils.getCallbackUrl_intl().substring(0, Math.min(cardConfigDeatils.getCallbackUrl_intl().length(), 35)))
                .merchantCountryCode(cardConfigDeatils.getUSD())
                .acquirerBIN(getAcquirerBIN(paymentRequestCard.getPayProcId()))
                .acquirerID(cardConfigDeatils.getAcquirerID())
                .acquirerMerchantID(cardOnboardDto.getWibMomId())
                .purchaseCurrency(cardConfigDeatils.getUSD())
                .purchaseExponent(PaymentConstants.TWO_ONLY)
                .purchaseAmount(PaymentValidator.cardAmountConverter(transactionDto.getDebitAmt()))
                .purchaseDate(new SimpleDateFormat(PaymentConstants.DATE_PARQ).format(new Date()))
                .mobilePhone(mobilePhone())
                .workPhone(mobilePhone())
                .email(PaymentConstants.emailConst)
                .homePhone(mobilePhone())
                .transType(PaymentConstants.ONE)
                .threeRIInd(PaymentConstants.TWO)
                .threeDSRequestorFinalAuthRespURL(cardConfigDeatils.getCallbackUrl_intl())
                .browserAcceptHeader(PaymentConstants.httpAccept).browserIP(PaymentConstants.dummyIp)
                .browserJavaEnabled(PaymentConstants.TRUE_CONST).browserJavascriptEnabled(PaymentConstants.TRUE_CONST)
                .browserLanguage(PaymentConstants.BROWSER_LANG).browserColorDepth(PaymentConstants.BROWSER_DEPT)
                .browserScreenHeight(PaymentConstants.SCREEN_HIGHT).browserScreenWidth(PaymentConstants.SCREEN_WIDTH)
                .browserTZ(PaymentConstants.BROWSER_TZ).browserUserAgent(PaymentConstants.userAgent)
                .p_messageVersion(cardConfigDeatils.getP_messageVersion())
                .acctNumber(paymentRequestCard.getAltNumber())
                .cardExpiryDate(paymentRequestCard.getExpiryYear().substring(paymentRequestCard.getExpiryYear().length() - 2).concat(paymentRequestCard.getExpiryMonth()))
                .cardholderName(paymentRequestCard.getCardHolderName())
                .build();

        return  new Gson().toJson(pArqRequest);
    }

    /**
     * @return: String
     * @methodName: getEncryptedpvrqPayload
     * @@Method-Description: Process setting Encryption data
     * @param: requestPayload
     * @Exception: or @Error :Exception
     */

    public String  getEncryptedpvrqPayload( String requestPayload) {
        try{
            final KeyStore.PrivateKeyEntry entry = cardEncryptionDecryptionUtil.loadPriavteKeys();
            final RSAPrivateKey privateKey  = (RSAPrivateKey) entry.getPrivateKey();
            AES aes = AES.init();
            final String encSymmetricKey = EncryptionUtil.encryptDEK(aes.getKey(), cardEncryptionDecryptionUtil.loadPublicKeysServer());
            return cardEncryptionDecryptionUtil.getJsonString(EncryptedRequestData.buildRequest(EncryptionUtil.encrypt(EncryptionUtil.digitalSignWithRSA(requestPayload, privateKey), aes), encSymmetricKey, aes));
        } catch (Exception e) { // Exception throw by WIMBO PG  Jar
            logger.error("Exception While encrypt pvrqPayload PG response {}", e);
            throw new PaymentException(ErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(ErrorConstants.INVALID_ERROR_MESSAGE, PaymentConstants.INVALIDHASHVALUE));
        }
    }

    /**
     * @return: String
     * @methodName: getDecryptedPayload
     * @@Method-Description: Process setting Decryption data
     * @param: responsePayload
     * @Exception: or @Error :Exception
     */


    public String  getDecryptedPayload( String encryptedResponse ) {
        PVrqEncResponse object_pArq= new Gson().fromJson(encryptedResponse, PVrqEncResponse.class);
        String signedEncResponsePayload_pArq = object_pArq.getSignedEncResponsePayload();
        String responseSymmetricEncKey_pArq = object_pArq.getResponseSymmetricEncKey();
        String iv_pArq = object_pArq.getIv();
        final RSAPrivateKey privateKey = (RSAPrivateKey) cardEncryptionDecryptionUtil.loadPriavteKeys().getPrivateKey();
        try{
            SecretKey decryptedSymmetricKey_pArq =  DecryptionUtil.decryptDEK(responseSymmetricEncKey_pArq,privateKey);
            String decryptedResponse = DecryptionUtil.decrypt(signedEncResponsePayload_pArq,iv_pArq, decryptedSymmetricKey_pArq);

            if(!DecryptionUtil.verifySignature(decryptedResponse, cardEncryptionDecryptionUtil.loadPublicKeysServer())) {
                throw new PaymentException(ErrorConstants.INVALID_ERROR_CODE,MessageFormat.format(ErrorConstants.INVALID_ERROR_MESSAGE,PaymentConstants.DECRYPTION,PaymentConstants.DECRYPTION_ERROR));
            }
            return Optional.ofNullable(DecryptionUtil.getJsonFromJws(decryptedResponse)).orElseThrow(() -> new PaymentException(CardErrorConstants.PROCESS_SERVICE_ERROR_CODE, MessageFormat.format(CardErrorConstants.PROCESS_SERVICE_ERROR_MESSAGE,PaymentConstants.DECRYPTION_CONST)));
        } catch (Exception e) { // Exception throw by WIMBO PG  Jar
            logger.error("Exception While Decrypt Payload {}", e);
            throw new PaymentException(ErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(ErrorConstants.INVALID_ERROR_MESSAGE, PaymentConstants.DECRYPTION,PaymentConstants.DECRYPTION_ERROR));
        }
    }

    /**
     * @return: String
     * @methodName: getDecryptedResponse
     * @@Method-Description: Process setting Decryption data
     * @param: responsePayload
     * @Exception: or @Error :Exception
     */

    public String  getDecryptedResponse( String responsePayload ) {
        RSAPrivateKey privateKey = (RSAPrivateKey) cardEncryptionDecryptionUtil.loadPriavteKeys().getPrivateKey();
        SaleEncResponse respRupayBean = new Gson().fromJson(responsePayload, SaleEncResponse.class);
        try {
            SecretKey decryptedSymmetricKey = DecryptionUtil.decryptDEK(respRupayBean.getResponseSymmetricEncKey(), privateKey);
            String signedResponse = DecryptionUtil.decrypt(respRupayBean.getSignedEncResponsePayload(), respRupayBean.getIv(), decryptedSymmetricKey);

            if (!DecryptionUtil.verifySignature(signedResponse, cardEncryptionDecryptionUtil.loadPublicKeysServer())) {
                throw new PaymentException(ErrorConstants.INVALID_ERROR_CODE,MessageFormat.format(ErrorConstants.INVALID_ERROR_MESSAGE,PaymentConstants.DECRYPTION,PaymentConstants.DECRYPTION_ERROR));
            }
            return Optional.ofNullable(DecryptionUtil.getJsonFromJws(signedResponse)).orElseThrow(() -> new PaymentException(CardErrorConstants.PROCESS_SERVICE_ERROR_CODE, MessageFormat.format(CardErrorConstants.PROCESS_SERVICE_ERROR_MESSAGE,PaymentConstants.DECRYPTION_CONST)));
        } catch (Exception e) { // Exception throw by WIMBO PG  Jar
            logger.error("Exception While Decrypt Payload PG response {}", e);
            throw new PaymentException(ErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(ErrorConstants.INVALID_ERROR_MESSAGE, PaymentConstants.DECRYPTION,PaymentConstants.DECRYPTION_ERROR));
        }
    }


    /**
     * @return: LinkedHashMap<String, String>
     * @methodName: threeDsRequestAuthenticationInfo
     * @@Method-Description: Process setting Constants data
     * @param:
     * @Exception: or @Error :Exception
     */
    private LinkedHashMap<String, String>  threeDsRequestAuthenticationInfo(){
        LinkedHashMap<String, String>  threeDSRequestAuthenticationInfo = new LinkedHashMap<String,String>();
        threeDSRequestAuthenticationInfo.put(PaymentConstants.threeDSReqAuthMethod, PaymentConstants.FOUR);
        threeDSRequestAuthenticationInfo.put(PaymentConstants.threeDSReqAuthTimestamp, new SimpleDateFormat(PaymentConstants.DATE_PG).format(new Date()));
        threeDSRequestAuthenticationInfo.put(PaymentConstants.threeDSReqAuthData, PaymentConstants.TWO_ZERO);
        return threeDSRequestAuthenticationInfo;
    }

    /**
     * @return: LinkedHashMap<String, String>
     * @methodName: mobilePhone
     * @@Method-Description: Process setting Constant data
     * @param:
     * @Exception: or @Error :Exception
     */
    private LinkedHashMap<String, String>  mobilePhone(){
        LinkedHashMap<String, String>  mobilePhone = new LinkedHashMap<String,String>();
        mobilePhone.put(PaymentConstants.CC_SMALL, PaymentConstants.STD_IND);
        mobilePhone.put(PaymentConstants.subscriber, PaymentConstants.DUMMY_PHONE);
        return mobilePhone;
    }

    /**
     * @return: String
     * @methodName: createCheckBinRequest
     * @@Method-Description: Process setting CheckBin data
     * @param: paymentRequestCard
     * @Exception: or @Error :Exception
     */
    public String createCheckBinRequest(PaymentRequestCard paymentRequestCard) {
        return new Gson().toJson(BinCheckRequest.builder()
                .pgInstanceId(cardConfigDeatils.getPgInstanceId_2()).cardBin(paymentRequestCard.getAltNumber().substring(0,9))
                .build());
    }

    /**
     * @return: String
     * @methodName: createInitiate2Request
     * @@Method-Description: Process setting Initiate 2 data
     * @param: cardOnboardDto,transactionDto,paymentRequestCard
     * @Exception: or @Error :Exception
     */
    public String createInitiate2Request(CardOnBoardDetailsResponseDto cardOnboardDto,TransactionDto transactionDto,PaymentRequestCard paymentRequestCard) {
        return new Gson().toJson(InitiateRequest.builder()
                .pgInstanceId(cardConfigDeatils.getPgInstanceId_2())
                .merchantId(cardOnboardDto.getPgMerchantId())
                .merchantReferenceNo(paymentRequestCard.getAtrn())
                .browserUserAgent(PaymentConstants.userAgent)
                .ipAddress(PaymentConstants.dummyIp)
                .httpAccept(PaymentConstants.httpAccept)
                .authAmount(PaymentValidator.cardAmountConverter(transactionDto.getDebitAmt()))
                .currencyCode(cardConfigDeatils.getUSD())
                .orderDesc(PaymentConstants.NA)
                .ext1(PaymentConstants.EXT_PARAM)
                .ext2(PaymentConstants.EXT_PARAM)
                .amountInInr(PaymentValidator.cardAmountConverter(transactionDto.getDebitAmt()))
                .originalAmount(PaymentValidator.cardAmountConverter(transactionDto.getDebitAmt()))
                .merchantResponseUrl(cardConfigDeatils.getCallback_Url_Rupay())
                .transaction_type_indicator(PaymentConstants.DMS)
                .purposeOfAuthentication(PaymentConstants.PurposeOfTransaction)
                .tokenAuthenticationValue(PaymentConstants.PATTERN_EMPTY)
                .email(PaymentConstants.emailConst)
                .pan(paymentRequestCard.getAltNumber())
                .cardExpDate(paymentRequestCard.getExpiryMonth().concat(paymentRequestCard.getExpiryYear()))
                .cvd2(paymentRequestCard.getCvv())
                .nameOnCard(paymentRequestCard.getCardHolderName())
                .build());
    }

    /**
     * @return: String
     * @methodName: createGenerateOTPRequest
     * @@Method-Description: Process setting Generate OTP data
     * @param: cardOnboardDto,transactionDto,paymentRequestCard
     * @Exception: or @Error :Exception
     */
    public String createGenerateOTPRequest(CardOnBoardDetailsResponseDto cardOnboardDto,TransactionDto transactionDto,PaymentRequestCard paymentRequestCard) {
        return new Gson().toJson(GenerateOTPRequest.builder()
                .pgInstanceId(cardConfigDeatils.getPgInstanceId_2())
                .merchantId(cardOnboardDto.getPgMerchantId())
                .merchantReferenceNo(transactionDto.getAtrnNum())
                .cardHolderStatus(PaymentConstants.NW)
                .email(PaymentConstants.emailConst)
                .amount(PaymentValidator.cardAmountConverter(transactionDto.getDebitAmt()))
                .currencyCode(cardConfigDeatils.getUSD())
                .customerIpAddress(PaymentConstants.dummyIp)
                .browserUserAgent(PaymentConstants.userAgent)
                .httpAccept(PaymentConstants.httpAccept)
                .ext1(PaymentConstants.PATTERN_EMPTY)
                .ext2(PaymentConstants.PATTERN_EMPTY)
                .amountInInr(PaymentValidator.cardAmountConverter(transactionDto.getDebitAmt()))
                .originalAmount(PaymentValidator.cardAmountConverter(transactionDto.getDebitAmt()))
                .tokenAuthenticationValue(PaymentConstants.dummyHash)
                .purposeOfAuthentication(PaymentConstants.PurposeOfTransaction)
                .orderDesc(PaymentConstants.NA)
                .pan(paymentRequestCard.getAltNumber())
                .cardExpDate(paymentRequestCard.getExpiryMonth().concat(paymentRequestCard.getExpiryYear()))
                .cvd2(paymentRequestCard.getCvv())
                .nameOnCard(paymentRequestCard.getCardHolderName())
                .build());
    }

    /**
     * @return: String
     * @methodName: setTokenRequestorId
     * @@Method-Description: Process setting constant data
     * @param: cardType
     * @Exception: or @Error :Exception
     */
    private  String setTokenRequestorId(String cardType){
        return switch (cardType) {
            case PaymentConstants.VISA -> cardConfigDeatils.getTokenRequesterId_VS_intl();
            case PaymentConstants.MASTER -> cardConfigDeatils.getAcquirerBin_Master();
            case PaymentConstants.RUPAY -> cardConfigDeatils.getCallback_Url_Rupay_intl();
            default -> throw new PaymentException(ErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(ErrorConstants.INVALID_ERROR_MESSAGE, PaymentConstants.TOKEN_ERROR_CONST,PaymentConstants.TOKEN_ERROR_CONST_MESSAGE));

        };
    }

    /**
     * @return: String
     * @methodName: setAuthCode
     * @@Method-Description: Process setting constant data
     * @param: cardType, authCode
     * @Exception: or @Error :Exception
     */
    private  String setAuthCode(String cardType,String authCode){
        return switch (cardType) {
            case PaymentConstants.RUPAY -> authCode;
            default -> "";
        };
    }

    /**
     * @return: String
     * @methodName: setCardType
     * @@Method-Description: Process setting constant data
     * @param: cardType
     * @Exception: or @Error :Exception
     */
    private  String setCardType(String cardType){
        return switch (cardType) {
            case PaymentConstants.VISA -> PaymentConstants.V_CONST;
            case PaymentConstants.MASTER -> PaymentConstants.M_CONST;
            case PaymentConstants.RUPAY -> PaymentConstants.R_CONST;
            default -> "";
        };
    }

    /**
     * @return: String
     * @methodName: getAcquirerBIN
     * @@Method-Description: Process setting constant data
     * @param: cardType
     * @Exception: or @Error :Exception
     */
    private  String getAcquirerBIN(String cardType){
        return switch (cardType) {
            case PaymentConstants.VISA -> cardConfigDeatils.getAcquirerBin_Visa();
            case PaymentConstants.MASTER -> cardConfigDeatils.getAcquirerBin_Master();
            default -> "";
        };
    }

    /**
     * @return: String
     * @methodName: getAccType
     * @@Method-Description: Process setting constant data
     * @param: payMode
     * @Exception: or @Error :Exception
     */
    private  String getAccType(String payMode){
        return switch (payMode) {
            case PaymentConstants.DC -> PaymentConstants.THREE;
            case PaymentConstants.CC -> PaymentConstants.TWO;
            default -> PaymentConstants.ONE;
        };
    }

    /**
     * @return: List<String>
     * @methodName: encryptCardDetails
     * @@Method-Description: Process setting encryption data
     * @param: cardData
     * @Exception: or @Error :Exception
     */

    private  List<String> encryptCardDetails(String cardData){

        List<String> listData = new ArrayList<>();
        SecureRandom secureRandom = new SecureRandom();
        byte[] nonce = new byte[16]; // 96 bits is a common choice for the nonce size
        secureRandom.nextBytes(nonce);
        String ivConverted = cardEncryptionDecryptionUtil.byteArrayToHexString(nonce);
        listData.add(ivConverted);
        SecretKey secretKey = cardEncryptionDecryptionUtil.generateSecretKey(cardConfigDeatils.getTokenSecretKey_intl());
        byte[] IV = ivConverted.getBytes();
        String encryptPayloadTokenReq = cardEncryptionDecryptionUtil.encrypt(cardData.getBytes(), secretKey, IV);
        listData.add(encryptPayloadTokenReq);
        return listData;
    }

    /**
     * @return: String
     * @methodName: createSaleSeamRequestPayload
     * @@Method-Description: Process setting Sale API Request Payload
     * @param: cardOnboardDto,transactionDto,paymentRequestCard,altIDResponse,pArqResponse
     * @Exception: or @Error :Exception
     */

    public String  createSaleSeamRequestPayload(CardOnBoardDetailsResponseDto cardOnboardDto,TransactionDto transactionDto,PaymentRequestCard paymentRequestCard,PArqResponse pArqResponse)  {
        return new Gson().toJson(SaleAuthRequest.builder()
                .pgInstanceId(cardConfigDeatils.getPgInstanceId()).merchantId(cardOnboardDto.getPgMerchantId())
                .acquiringBankId(cardConfigDeatils.getAcquiringBankId_intl())
                .action(PaymentConstants.action)
                .transactionTypeCode(cardConfigDeatils.getTransactionTypeCode())
                .deviceCategory(PaymentConstants.ZERO)
                .currencyCode(cardConfigDeatils.getUSD())
                .amount(PaymentValidator.cardAmountConverter(transactionDto.getDebitAmt()))
                .merchantReferenceNo(transactionDto.getAtrnNum())
                .orderDesc(PaymentConstants.NA)
                .mpiTransactionId(pArqResponse.getThreeDSServerTransID())
                .threeDsXid(PaymentConstants.XID_CONST)
                .threeDsStatus(pArqResponse.getTransStatus())
                .threeDsEci(pArqResponse.getEci())
                .threeDsCavvAav(pArqResponse.getAuthenticationValue())
                .threeDsTxnId(pArqResponse.getDsTransID())
                .threeDsVersion(pArqResponse.getP_messageVersion().startsWith(PaymentConstants.TWO_ONLY) ? PaymentConstants.PMSG_VERSION2 : PaymentConstants.PMSG_VERSION1)
                .cryptogram(PaymentConstants.EMPTY)
                .pan(paymentRequestCard.getAltNumber())
                .expiryDateYYYY(paymentRequestCard.getExpiryYear())
                .expiryDateMM(paymentRequestCard.getExpiryMonth())
                .cvv2(paymentRequestCard.getCvv())
                .nameOnCard(paymentRequestCard.getCardHolderName())
                .build());
    }

    public static String hashValue(String values){
        byte[] bytes = HashingService.generateHash(Base64.getDecoder().decode(values), HashAlgorithm.SHA_512);
        return Base64.getEncoder().encodeToString(bytes).replaceAll(PaymentConstants.SPECIAL_CHAR_REGEX, PaymentConstants.EMPTY);
    }
/////////////CALL BACK INTL

    /**
     * @return: ACSResponse
     * @methodName: getRedirectTransStatus
     * @@Method-Description: Process setting acs data
     * @param: paymentRequest
     * @Exception: or @Error :Exception
     */
    public ACSResponse  getRedirectTransStatus(String paymentRequest){
        byte[] valueDecoded = org.apache.commons.codec.binary.Base64.decodeBase64(paymentRequest.trim());
        return Optional.ofNullable(new Gson().fromJson(new String(valueDecoded,StandardCharsets.UTF_8), ACSResponse.class)).orElseThrow(() -> new PaymentException(CardErrorConstants.PROCESS_SERVICE_ERROR_CODE, MessageFormat.format(CardErrorConstants.PROCESS_SERVICE_ERROR_MESSAGE,PaymentConstants.ACS)));
    }

    /**
     * @return: String
     * @methodName: createpRqFrqPayload
     * @@Method-Description: Process setting prqfrq payload
     * @param: transData, cardSummeryResponse
     * @Exception: or @Error :Exception
     */
    public String  createpRqFrqPayload(String transData, CardSummaryResponse cardSummaryResponse){
        return new Gson().toJson(PRqFrqRequest.builder()
                .messageType(PaymentConstants.messageType_PRQFRQ).messageVersion(cardConfigDeatils.getP_messageVersion()).threeDSServerTransID(cardSummaryResponse.getThreeDSServerTransID())
                .acsTransID(cardSummaryResponse.getAcsTransID()).dsTransID(cardSummaryResponse.getDsTransID()).merchantTransID(cardSummaryResponse.getMerchantTransID())
                .acquirerID(cardConfigDeatils.getAcquirerID()).acsAuthResponse(transData.trim()).p_messageVersion(cardConfigDeatils.getP_messageVersion()).build());
    }

    /**
     * @return: String
     * @methodName: createSaleRequestPayload
     * @@Method-Description: Process setting sale payload
     * @param: cardAuthorizationEntity transactionDto pRqFrqResponse, cardOnboardDto,cardSummeryResponse
     * @Exception: or @Error :Exception
     */
    public String  createSaleRequestPayload(TransactionDto transactionDto, PRqFrqResponse pRqFrqResponse, CardOnBoardDetailsResponseDto cardOnboardDto, CardSummaryResponse cardSummaryResponse){
        List<String> getCardDetails = getCardDetails(cardSummaryResponse.getPaymentCard());

        return new Gson().toJson(SaleAuthRequest.builder()
                .pgInstanceId(cardConfigDeatils.getPgInstanceId()).merchantId(cardOnboardDto.getPgMerchantId()).acquiringBankId(cardConfigDeatils.getAcquiringBankId_intl()).action(PaymentConstants.action)
                .transactionTypeCode(cardConfigDeatils.getTransactionTypeCode()).deviceCategory(PaymentConstants.ZERO).currencyCode(cardConfigDeatils.getUSD())
                .amount(PaymentValidator.cardAmountConverter(transactionDto.getDebitAmt())).merchantReferenceNo(transactionDto.getAtrnNum())
                .orderDesc(PaymentConstants.NA).mpiTransactionId(cardSummaryResponse.getThreeDSServerTransID())
                .threeDsXid(PaymentConstants.XID_CONST)
                .threeDsStatus(pRqFrqResponse.getTransStatus() == null ? cardSummaryResponse.getTransStatus() : pRqFrqResponse.getTransStatus())
                .threeDsEci(pRqFrqResponse.getEci() == null ? cardSummaryResponse.getEci() : pRqFrqResponse.getEci())
                .threeDsCavvAav(pRqFrqResponse.getAuthenticationValue() == null ? cardSummaryResponse.getAuthenticationValue() : pRqFrqResponse.getAuthenticationValue())
                .threeDsTxnId(pRqFrqResponse.getDsTransID() == null ? cardSummaryResponse.getEci() : pRqFrqResponse.getDsTransID())
                .threeDsVersion(cardSummaryResponse.getP_messageVersion().startsWith(PaymentConstants.TWO_ONLY) ? PaymentConstants.PMSG_VERSION2 : PaymentConstants.PMSG_VERSION1)
                .cryptogram(PaymentConstants.EMPTY)
                .pan(getCardDetails.get(0))
                .expiryDateYYYY(getCardDetails.get(2))
                .expiryDateMM(getCardDetails.get(1))
                .cvv2(getCardDetails.get(3))
                .nameOnCard(getCardDetails.get(4))
                .build());

    }

    /**
     * @return: String
     * @methodName: getEncryptedPayload
     * @@Method-Description: Process setting encryption data
     * @param: requestPayload
     * @Exception: or @Error :Exception
     */

    public String  getEncryptedPayload( String requestPayload) {
        final KeyStore.PrivateKeyEntry entry = cardEncryptionDecryptionUtil.loadPriavteKeys();
        final RSAPrivateKey privateKey  = (RSAPrivateKey) entry.getPrivateKey();
        try{
            AES aes = AES.init();
            final String encSymmetricKey = EncryptionUtil.encryptDEK(aes.getKey(), cardEncryptionDecryptionUtil.loadPublicKeysServer());
            return cardEncryptionDecryptionUtil.getJsonString(EncryptedRequestData.buildRequest(EncryptionUtil.encrypt(EncryptionUtil.digitalSignWithRSA(requestPayload, privateKey), aes), encSymmetricKey, aes));
        } catch (Exception e) { // Exception throw by WIMBO PG  Jar
            logger.error("Exception While Encrypt Payload {}", e);
            throw new PaymentException(ErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(ErrorConstants.INVALID_ERROR_MESSAGE, PaymentConstants.ENCRYPTION,PaymentConstants.ENCRYPTION_ERROR));
        }
    }

    /**
     * @return: List<String>
     * @methodName: getCardDetails
     * @@Method-Description: Process setting card details
     * @param: cardAuthorizationEntity
     * @Exception: or @Error :Exception
     */
    public  List<String> getCardDetails(String cardAuthorizationEntity){
        byte[] tokenDecrypted = org.apache.commons.codec.binary.Base64.decodeBase64(cardAuthorizationEntity);
        String paymentRequestCard = new String(tokenDecrypted, StandardCharsets.UTF_8);
        return Stream.of(paymentRequestCard.split(PaymentConstants.PIPE_REGEX))
                .map (String::new)
                .collect(Collectors.toList());
    }

    /**
     * @return: String
     * @methodName: createSaleRupayRequestPayload
     * @@Method-Description: Process setting sale api payload
     * @param: cardAuthorizationEntity,altIDResponse, transactionDto, cardOnboardDto,pgTransactionId
     * @Exception: or @Error :Exception
     */

    public String  createSaleRupayRequestPayload(String cardDetails ,TransactionDto transactionDto,CardOnBoardDetailsResponseDto cardOnboardDto,String pgTransactionId) {
        List<String> cardData = getCardDetails(cardDetails);
        String cardN = cardData.get(0) == null ? PaymentConstants.TWO_ZERO : cardData.get(0);
        String month = cardData.get(1) == null ? PaymentConstants.TWO_ZERO : cardData.get(1);
        String year = cardData.get(2) == null ? PaymentConstants.TWO_ZERO : cardData.get(2);

        return new Gson().toJson(SaleAPIRequest.builder()
                .pgInstanceId(cardConfigDeatils.getPgInstanceId())
                .merchantId(cardOnboardDto.getPgMerchantId())
                .pgTransactionId(pgTransactionId.isEmpty() ? cardData.get(7) : pgTransactionId)
                .merchantReferenceNo(transactionDto.getAtrnNum())
                .altId(cardN)
                .altExpiry(month.concat(year))
                .tokenAuthenticationValue(PaymentConstants.EMPTY)
                .build());
    }
    /**
     * @return: String
     * @methodName: createResendOTPPayload
     * @@Method-Description: Process setting resend otp payload
     * @param: cardOnboardDto,atrn,otp,pgtransactionid
     * @Exception: or @Error :Exception
     */
    public String createResendOTPPayload(CardOnBoardDetailsResponseDto cardOnboardDto,PaymentRequestResendCard paymentRequestResendCard){
        return new Gson().toJson(ResendOTPRequest.builder()
                .pgInstanceId(cardConfigDeatils.getPgInstanceId_2())
                .merchantId(cardOnboardDto.getPgMerchantId())
                .merchantReferenceNo(paymentRequestResendCard.getAtrn())
                .pgTransactionId(paymentRequestResendCard.getPgtransactionid())
                .cardHolderStatus(PaymentConstants.NW)
                .build());
    }

    /**
     * @return: String
     * @methodName: createVerifyOTPPayload
     * @@Method-Description: Process setting verify otp payload
     * @param: cardOnboardDto,atrn,otp,pgtransactionid
     * @Exception: or @Error :Exception
     */
    public String createVerifyOTPPayload(CardOnBoardDetailsResponseDto cardOnboardDto,PaymentRequestVerifyCard paymentRequestVerifyCard){
        return new Gson().toJson(VerifyOTPRequest.builder()
                .pgInstanceId(cardConfigDeatils.getPgInstanceId_2())
                .merchantId(cardOnboardDto.getPgMerchantId())
                .merchantReferenceNo(paymentRequestVerifyCard.getAtrn())
                .pgTransactionId(paymentRequestVerifyCard.getPgtransactionid())
                .otp(paymentRequestVerifyCard.getOtp())
                .build());
    }

    /**
     * @return: String
     * @methodName: getAltIdToken
     * @@Method-Description: Process setting Alt Id data
     * @param: paymentRequestCard,tokenAltResponse
     * @Exception: or @Error :Exception
     * */

    public String getAltIdToken(PaymentRequestCard paymentRequestCard)  {
        String plainData = paymentRequestCard.getAltNumber().concat("|").concat(paymentRequestCard.getExpiryMonth()).concat("|").concat(paymentRequestCard.getExpiryYear()).concat("|").concat(paymentRequestCard.getCvv()).concat("|").concat(paymentRequestCard.getCardHolderName());
        return Optional.ofNullable(Base64.getEncoder().encodeToString(plainData.getBytes())).orElseThrow(() -> new PaymentException(CardErrorConstants.PROCESS_SERVICE_ERROR_CODE, MessageFormat.format(CardErrorConstants.PROCESS_SERVICE_ERROR_MESSAGE,PaymentConstants.Tokenization)));
    }
}
