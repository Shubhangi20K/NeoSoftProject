package com.epay.stubs.exceptionhandlers;


import com.epay.stubs.dto.ErrorDto;
import com.epay.stubs.exceptions.PaymentException;
import com.epay.stubs.exceptions.ValidationException;
import com.epay.stubs.model.response.FieldValidationErrorResponse;
import com.epay.stubs.model.response.PaymentResponse;
import com.epay.stubs.util.ErrorConstants;
import com.epay.stubs.util.PaymentConstants;
import com.epay.stubs.util.PaymentUtil;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.google.gson.JsonSyntaxException;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import io.jsonwebtoken.JwtException;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import lombok.NonNull;
import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.actuate.endpoint.invoke.MissingParametersException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.lang.Nullable;
import org.springframework.util.CollectionUtils;
import org.springframework.web.HttpMediaTypeNotAcceptableException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingPathVariableException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;
import org.springframework.web.servlet.resource.NoResourceFoundException;
import sbi.mer.pgp.exception.PGPEncryptException;

import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.*;
import java.util.function.BiFunction;
import java.util.stream.Collectors;

/**
 * Class Name: PaymentExceptionHandler
 * *
 * Description:
 * *

 * ALl rights reserved
 * *
 * Version: 1.0
 */

@ControllerAdvice
public class PaymentExceptionHandler extends ResponseEntityExceptionHandler {

    LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());


  /*  @Override
    protected ResponseEntity<Object> handleHttpMessageNotReadable(@NonNull HttpMessageNotReadableException ex, @NonNull HttpHeaders headers, @NonNull HttpStatusCode status, @NonNull WebRequest request) {
        ErrorDto errorDto = ErrorDto.builder()
                .errorCode(String.valueOf(HttpStatus.BAD_REQUEST.value()))
                .errorMessage("Missing body param")
                .build();
        return generateResponseWithErrors(List.of(errorDto));
    }
*/

    @Override
    protected ResponseEntity<Object> handleHttpRequestMethodNotSupported(
            @NonNull HttpRequestMethodNotSupportedException ex, @NonNull HttpHeaders headers, @NonNull HttpStatusCode status, @NonNull WebRequest request) {
        logger.error("Method not allowed: {} ", ex);
        ErrorDto errorDto = ErrorDto.builder()
                .errorCode(ErrorConstants.UNCATEGORIZED_ERROR_CODE)
                .errorMessage(ErrorConstants.UNCATEGORIZED_ERROR_MESSAGE)
                .build();
        return ResponseEntity.status(HttpStatus.METHOD_NOT_ALLOWED).body(PaymentResponse.builder().status(0).errors(List.of(errorDto)).build());
    }


    @Override
    protected ResponseEntity<Object> handleHttpMediaTypeNotSupported(
            @Nullable HttpMediaTypeNotSupportedException ex, @Nullable HttpHeaders headers, @Nullable HttpStatusCode status, @Nullable WebRequest request) {

        logger.error("HttpMediaTypeNotSupportedException (Content-Type) : {}", ex);
        ErrorDto errorDto = ErrorDto.builder()
                .errorCode(ErrorConstants.UNCATEGORIZED_ERROR_CODE)
                .errorMessage(ErrorConstants.UNCATEGORIZED_ERROR_MESSAGE)
                .build();
        return ResponseEntity.status(HttpStatus.UNSUPPORTED_MEDIA_TYPE).body(PaymentResponse.builder().status(0).errors(List.of(errorDto)).build());
    }


    @Override
    protected ResponseEntity<Object> handleHttpMediaTypeNotAcceptable(
            @Nullable HttpMediaTypeNotAcceptableException ex, @Nullable HttpHeaders headers, @Nullable HttpStatusCode status, @Nullable WebRequest request) {
        logger.error("HttpMediaTypeNotAcceptableException (Accept) : ");
        ErrorDto errorDto = ErrorDto.builder()
                .errorCode(ErrorConstants.UNCATEGORIZED_ERROR_CODE)
                .errorMessage(ErrorConstants.UNCATEGORIZED_ERROR_MESSAGE)
                .build();
        return ResponseEntity.status(HttpStatus.NOT_ACCEPTABLE).body(PaymentResponse.builder().status(0).errors(List.of(errorDto)).build());

    }


    @Override
    protected ResponseEntity<Object> handleNoResourceFoundException(
            @Nullable NoResourceFoundException ex, @Nullable HttpHeaders headers, @Nullable HttpStatusCode status, @Nullable WebRequest request) {
        logger.error("NoResourceFoundException : ");
        ErrorDto errorDto = ErrorDto.builder()
                .errorCode(ErrorConstants.UNCATEGORIZED_ERROR_CODE)
                .errorMessage(ErrorConstants.UNCATEGORIZED_ERROR_MESSAGE)
                .build();
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(PaymentResponse.builder().status(0).errors(List.of(errorDto)).build());

    }


    @Override
    protected ResponseEntity<Object> handleMissingPathVariable(
            @Nullable MissingPathVariableException ex, @Nullable HttpHeaders headers, @Nullable HttpStatusCode status, @Nullable WebRequest request) {

        logger.error("MissingPathVariableException (Path-Variable) : ");
        ErrorDto errorDto = ErrorDto.builder()
                .errorCode(ErrorConstants.UNCATEGORIZED_ERROR_CODE)
                .errorMessage(ErrorConstants.UNCATEGORIZED_ERROR_MESSAGE)
                .build();
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(PaymentResponse.builder().status(0).errors(List.of(errorDto)).build());
    }

    @ExceptionHandler({PaymentException.class, SQLException.class})
    public ResponseEntity<Object> handleSecurityException(PaymentException ex) {
        ErrorDto errorDto = ErrorDto.builder()
                .errorCode(ex.getErrorCode())
                .errorMessage(ex.getErrorMessage())
                .build();
        return generateResponseWithErrors(List.of(errorDto));
    }

    @ExceptionHandler(ValidationException.class)
    public ResponseEntity<Object> handleValidationException(ValidationException ex) {
        if (CollectionUtils.isEmpty(ex.getErrorMessages())) {
            ErrorDto errorDto = ErrorDto.builder()
                    .errorCode(ex.getErrorCode())
                    .errorMessage(ex.getErrorMessage())
                    .build();
            return generateResponseWithErrors(List.of(errorDto));
        }
        return generateResponseWithErrors(ex.getErrorMessages());
    }


    @Override
    protected ResponseEntity<Object> handleMissingServletRequestParameter(@Nullable MissingServletRequestParameterException ex, @Nullable HttpHeaders headers, @Nullable HttpStatusCode status, @Nullable WebRequest request) {
        logger.error("handleMissingServletRequestParameter  : "+ex+" param"+ex.getParameterName());
        ErrorDto errorDto = ErrorDto.builder().errorCode(ErrorConstants.REQUIRED_ERROR_CODE).errorMessage(MessageFormat.format(ErrorConstants.REQUIRED_ERROR_MESSAGE, ex.getParameterName())).build();
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(PaymentResponse.builder().status(PaymentConstants.RESPONSE_FAILURE).errors(List.of(errorDto)).build());
    }


    /**
     * Handle JsonProcessingException and JsonMappingException.
     *
     * @param ex RuntimeException
     * @return ResponseEntity
     */
    @ExceptionHandler(value = {JsonProcessingException.class, JsonMappingException.class})
    public ResponseEntity<Object> handleJsonException(RuntimeException ex) {
        logger.error("Error in JsonProcessingException or JsonMappingException", ex);
        ErrorDto errorDto = ErrorDto.builder().errorCode(ErrorConstants.JSON_ERROR_CODE).errorMessage(MessageFormat.format(ErrorConstants.JSON_ERROR_MESSAGE, ex.getMessage())).build();
        return ResponseEntity.status(HttpStatus.ACCEPTED).body(PaymentResponse.builder().status(0).errors(List.of(errorDto)).build());
    }

    @ExceptionHandler(value = {JwtException.class})
    public ResponseEntity<Object> handleJwtException(JwtException ex, WebRequest request) {
        logger.error("Error in Authorization ", ex);
        ErrorDto errorDto = ErrorDto.builder()
                .errorCode(String.valueOf(HttpStatus.UNAUTHORIZED.value()))
                .errorMessage(ex.getMessage())
                .build();

        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(
                PaymentResponse.builder()
                        .status(0)
                        .errors(List.of(errorDto))
                        .build());
    }

    @ExceptionHandler(value = {Exception.class})
    public ResponseEntity<Object> handleGenericException(Exception ex, WebRequest request) {
        ErrorDto errorDto;

        logger.error("Error in handleGenericException ", ex);
        if (ex.getCause() instanceof PGPEncryptException pgpEncryptException) {
            errorDto = ErrorDto.builder()
                    .errorCode(pgpEncryptException.errCode)
                    .errorMessage(pgpEncryptException.errMsg)
                    .build();
        } else {
            errorDto = ErrorDto.builder()
                    .errorCode(ErrorConstants.UNCATEGORIZED_ERROR_CODE)
                    .errorMessage(ErrorConstants.UNCATEGORIZED_ERROR_MESSAGE)
                    .build();
        }

        return ResponseEntity.internalServerError().body(
                PaymentResponse.builder()
                        .status(0)
                        .errors(List.of(errorDto))
                        .build());
    }

    @ExceptionHandler(value = {IllegalArgumentException.class, IllegalStateException.class})
    protected ResponseEntity<Object> handleConflict(RuntimeException ex, WebRequest request) {
        logger.error("Error in handleConflict ", ex);
        ErrorDto errorDto = ErrorDto.builder()
                .errorCode(String.valueOf(HttpStatus.CONFLICT.value()))
                .errorMessage(ex.getMessage())
                .build();
        return ResponseEntity.status(HttpStatus.CONFLICT).body(
                PaymentResponse.builder()
                        .status(0)
                        .errors(List.of(errorDto))
                        .build());
    }


    @ExceptionHandler(value = {JsonSyntaxException.class})
    protected ResponseEntity<Object> handleJsonException(RuntimeException ex, WebRequest request) {
        logger.error("Error in handleConflict ", ex.getCause(), ex.getMessage());
        ErrorDto errorDto = ErrorDto.builder()
                .errorCode(String.valueOf(HttpStatus.FAILED_DEPENDENCY.value()))
                .errorMessage(ex.getMessage())
                .build();
        return ResponseEntity.status(HttpStatus.FAILED_DEPENDENCY).body(
                PaymentResponse.builder()
                        .status(0)
                        .errors(List.of(errorDto))
                        .build());
    }

    /**
     * @return - : List<ErrorDto>
     * @Method- createFieldErrors
     * @Method-Description: Create ConstraintVoilation and MethodArgument Exception in Generic Error
     * @Input type : List<AggAPIFieldValidationErrorResponseDto>
     * @Exception or @Error :
     */

    private List<ErrorDto> createFieldErrors(List<FieldValidationErrorResponse> fielderrors) {
        Map<String, String> fieldErrordata;

        fieldErrordata = fielderrors
                .stream()
                .collect(Collectors.toMap(FieldValidationErrorResponse::getField, FieldValidationErrorResponse::getErrorMessage));
        return fieldErrordata
                .entrySet()
                .stream()
                .map(entry -> ErrorDto
                        .builder()
                        .errorCode(ErrorConstants.REQUIRED_ERROR_CODE)
                        .errorMessage(entry.getValue()).build())
                .toList();
    }

    private ResponseEntity<Object> generateResponseWithErrors(List<ErrorDto> errors) {
        return ResponseEntity.ok().body(
                PaymentResponse.builder()
                        .status(0)
                        .errors(errors)
                        .build());
    }





    //Error handle for @Valid method RequestBody and @Validate For Validating Path Variables and Request Parameters--Ex:: @Size(min = 5, max = 10)
    @ExceptionHandler(value = MethodArgumentTypeMismatchException.class)
    public ResponseEntity<Object>
    handleMethodArgumentTypeMismatchException(MethodArgumentTypeMismatchException constraintException, WebRequest request) {
        logger.error("handleMethodArgumentTypeMismatchException  : ");
        ErrorDto errorDto = ErrorDto.builder()
                .errorCode(ErrorConstants.UNCATEGORIZED_ERROR_CODE)
                .errorMessage(ErrorConstants.UNCATEGORIZED_ERROR_MESSAGE)
                .build();
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(PaymentResponse.builder().status(0).errors(List.of(errorDto)).build());

    }








    /**
     * @return - : ResponseEntity<Object>
     * @Method- handleConstraintViolationException
     * @Method-Description: Handle method argument(Field param) not valid exception.
     * @Input type : ConstraintViolationException,WebRequest
     * @Exception or @Error :ConstraintViolationException
     */

    //Error handle for @Valid method RequestBody and @Validate For Validating Path Variables and Request Parameters--Ex:: @Size(min = 5, max = 10)
    @ExceptionHandler(value = ConstraintViolationException.class)
    public ResponseEntity<Object>
    handleConstraintViolationException(ConstraintViolationException constraintException, WebRequest request) {

        String exceptionOcurredUri = (request != null) ? ((ServletWebRequest) request).getRequest().getRequestURI() : PaymentConstants.PATTERN_EMPTY;
        List<FieldValidationErrorResponse> fielderrors;

        fielderrors = generateContraintVoilationFieldErrorResponse(constraintException);
        logger.info("Inside Contraint Voilation ::Filed Errors::  ************** :" + fielderrors.toString());
        List<ErrorDto> errorData = createFieldErrors(fielderrors);


        return generateResponseWithErrors(errorData);

    }


    /**
     * @return - : ResponseEntity<Object>
     * @Method- handleMethodArgumentNotValid
     * @Method-Description: Handle method argument(requestBody) not valid exception.
     * @Input type : MethodArgumentNotValidException,HttpHeaders,HttpStatusCode,WebRequest
     * @Exception or @Error :MethodArgumentNotValidException
     */


    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(
            @NonNull MethodArgumentNotValidException methodException, @NonNull HttpHeaders headers, @NonNull HttpStatusCode status, @NonNull WebRequest request) {

        String exceptionOcurredUri = ((ServletWebRequest) request).getRequest().getRequestURI();
        List<FieldValidationErrorResponse> fielderrors;

        fielderrors = generateMethodArgumentFieldErrorResponse(methodException);
        logger.info("Inside Contraint Method Argument ::Filed Errors::  ************** :", fielderrors.toString());
        List<ErrorDto> errorData = createFieldErrors(fielderrors);

        return generateResponseWithErrors(errorData);

    }


    /**
     * @return - : List<FieldValidationErrorResponse>
     * @Method- generateMethodArgumentFieldErrorResponse
     * @Method-Description: Generate method (requestBody) argument exception
     * @Input type : MethodArgumentNotValidException
     * @Exception or @Error :
     */

    //Method  exception Utility method
    private List<FieldValidationErrorResponse> generateMethodArgumentFieldErrorResponse(MethodArgumentNotValidException ex) {
        List<FieldValidationErrorResponse> filederrors = new ArrayList<>();
        BiFunction<String, String, String> messageInterPolate = (message, field) -> {
            if (StringUtils.isNotBlank(message) && message.contains("{0}")) {
                return MessageFormat.format(message, field);
            }
            return message;
        };
        if (Objects.nonNull(ex)) {
            ex.getBindingResult().getFieldErrors().forEach(error -> filederrors.add(new FieldValidationErrorResponse(error.getField(), messageInterPolate.apply(error.getDefaultMessage(), error.getField()))));
        }
        return filederrors;
    }


    /**
     * @return - : List<FieldValidationErrorResponse>
     * @Method- generateContraintVoilationFieldErrorResponse
     * @Method-Description: Generate method(Field) argument exception
     * @Input type : ConstraintViolationException
     * @Exception or @Error :
     */

    private List<FieldValidationErrorResponse> generateContraintVoilationFieldErrorResponse(ConstraintViolationException ex) {
        List<FieldValidationErrorResponse> filederrors = new ArrayList<>();
        BiFunction<String, String, String> messageInterPolate = (message, field) -> {
            if (StringUtils.isNotBlank(message) && message.contains("{0}")) {
                return MessageFormat.format(message, field);
            }
            return message;
        };

        if (Objects.nonNull(ex)) {
            Set<ConstraintViolation<?>> violations = ex.getConstraintViolations();
            violations.forEach(error -> filederrors.add(new FieldValidationErrorResponse(error.getPropertyPath().toString().substring(error.getPropertyPath().toString().lastIndexOf(".") + 1), messageInterPolate.apply(error.getMessage(), error.getPropertyPath().toString().substring(error.getPropertyPath().toString().lastIndexOf(".") + 1)))));
        }
        return filederrors;
    }

    /**
     * Handle Message Not Readable exception.
     *
     * @param ex      the exception to handle
     * @param headers the headers to use for the response
     * @param status  the status code to use for the response
     * @param request the current request
     * @return ResponseEntity
     */
    @Override
    protected ResponseEntity<Object> handleHttpMessageNotReadable(HttpMessageNotReadableException ex, @Nullable HttpHeaders headers, @Nullable HttpStatusCode status, @Nullable WebRequest request) {
        String reason = PaymentUtil.getParsingError(ex.getCause());
        ErrorDto errorDto = ErrorDto.builder().errorCode(ErrorConstants.INVALID_ERROR_CODE).errorMessage(MessageFormat.format(ErrorConstants.INVALID_ERROR_MESSAGE, PaymentConstants.REQ_OBJECT, reason)).build();
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(PaymentResponse.builder().status(PaymentConstants.RESPONSE_FAILURE).errors(List.of(errorDto)).build());
    }


}