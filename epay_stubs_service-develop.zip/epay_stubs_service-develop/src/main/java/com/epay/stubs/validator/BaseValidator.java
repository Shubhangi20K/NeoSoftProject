package com.epay.stubs.validator;


import com.epay.stubs.dto.ErrorDto;
import com.epay.stubs.exceptions.ValidationException;
import com.epay.stubs.util.ErrorConstants;
import com.epay.stubs.util.PaymentConstants;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.EnumUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.regex.Pattern;

import static com.epay.stubs.util.ErrorConstants.*;
import static com.epay.stubs.util.PaymentConstants.INCORRECT_FORMAT;

/**
 * Class Name:BaseValidator
 * *
 * Description: BaseValidator for payment service
 * *
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
public class BaseValidator {
    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    List<ErrorDto> errorDtoList = new ArrayList<>();

    /**
     * Check mandatory field
     *
     * @param value     String
     * @param fieldName String
     */
    protected void checkMandatoryField(String value, String fieldName) {
        if (StringUtils.isEmpty(value) || StringUtils.equals(value, "null")) {
            addError(fieldName, ErrorConstants.REQUIRED_ERROR_CODE, ErrorConstants.REQUIRED_ERROR_MESSAGE);
            throwIfErrors();
        }
    }

    /**
     * Check mandatory field
     *
     * @param value     UUID
     * @param fieldName String
     */
    protected void checkMandatoryField(Object value, String fieldName) {
        if (ObjectUtils.isEmpty(value)) {
            addError(fieldName, ErrorConstants.REQUIRED_ERROR_CODE, ErrorConstants.REQUIRED_ERROR_MESSAGE);
            throwIfErrors();
        }
    }

    /**
     * Check mandatory collection
     *
     * @param collection Collection
     * @param fieldName  String
     */
    protected void checkMandatoryCollection(Collection<?> collection, String fieldName) {
        if (CollectionUtils.isEmpty(collection)) {
            addError(fieldName, ErrorConstants.REQUIRED_ERROR_CODE, ErrorConstants.REQUIRED_ERROR_MESSAGE);
            throwIfErrors();
        }
    }

    /**
     * Check mandatary fields
     *
     * @param fieldName String
     * @param values    String...
     */
    protected void checkMandatoryFields(String fieldName, String... values) {
        boolean allEmpty = Arrays.stream(values).allMatch(StringUtils::isEmpty);
        if (allEmpty) {
            addError(fieldName, ErrorConstants.REQUIRED_ERROR_CODE, ErrorConstants.REQUIRED_ERROR_MESSAGE);
            throwIfErrors();
        }
    }

    /**
     * Check mandatory date field
     *
     * @param date      Long
     * @param fieldName String
     */
    protected void checkMandatoryDateField(Long date, String fieldName) {
        if (ObjectUtils.isEmpty(date) || date < 0) {
            addError(fieldName, ErrorConstants.REQUIRED_ERROR_CODE, ErrorConstants.REQUIRED_ERROR_MESSAGE);
            throwIfErrors();
        }
    }

    protected void validateFieldLength(String value, int maxLength, String fieldName) {
        if (StringUtils.isNotEmpty(value) && value.length() != maxLength) {
            addError(fieldName, ErrorConstants.FIXED_FIELD_LENGTH_ERROR_CODE, MessageFormat.format(ErrorConstants.FIXED_FIELD_LENGTH_ERROR_MESSAGE, fieldName, maxLength));
            throwIfErrors();
        }
    }

    protected void validateFieldLengthMax(String value, int maxLength, String fieldName) {
        if (StringUtils.isNotEmpty(value) && value.length() > maxLength) {
            addError(FIXED_FIELD_LENGTH_ERROR_CODE, FIXED_FIELD_LENGTH_ERROR_MESSAGE, fieldName, maxLength);
            throwIfErrors();
        }
    }


    protected void validateFieldWithRegex(String value, int maxLength, String regex, String fieldName, String message) {
        if (StringUtils.isNotEmpty(value) && (value.length() > maxLength || validate(value, regex))) {
            addError(fieldName, INVALID_ERROR_CODE, message + " " + maxLength);
            throwIfErrors();
        }
    }

    protected void validateFieldWithRegex(String value, String regex, String fieldName, String reason) {
        if (StringUtils.isNotEmpty(value) && validate(value, regex)) {
            addError(fieldName, INVALID_ERROR_CODE, MessageFormat.format(INVALID_ERROR_MESSAGE, fieldName, reason));
            throwIfErrors();
        }
    }

    /**
     * Validate if given
     *
     * @param enumName  String
     * @param fieldName String
     * @param enumClass Class
     * @param <E>       Enum Class Name
     */
    protected <E extends Enum<E>> void validateFieldValue(String enumName, String fieldName, Class<E> enumClass) {
        if (StringUtils.isNotEmpty(enumName) && !EnumUtils.isValidEnum(enumClass, enumName)) {
            addError(INVALID_ERROR_CODE, INVALID_ERROR_MESSAGE, fieldName, PaymentConstants.VALID_VALUES_ARE + EnumUtils.getEnumList(enumClass).stream().map(Enum::name).toList());
            throwIfErrors();
        }
    }

    /**
     * validate given field value from given list.
     *
     * @param value       String
     * @param validValues List of values
     * @param fieldName   String
     */
    protected void validateFieldValue(String value, List<String> validValues, String fieldName) {
        boolean isValid = validValues.stream().anyMatch(validValue -> validValue.equalsIgnoreCase(value));
        if (!isValid) {
            addError(INVALID_ERROR_CODE, INVALID_ERROR_MESSAGE, fieldName, "Invalid format");
            throwIfErrors();
        }
    }


    protected boolean validate(String value, String regex) {
        return !Pattern.matches(regex, value);
    }

    protected void checkForLeadingTrailingAndSingleSpace(String value, String fieldName) {
        if (StringUtils.isNotEmpty(value.trim()) && !value.equals(value.trim())) {
            addError(fieldName, ErrorConstants.TRAILING_SPACES_ERROR_CODE, ErrorConstants.TRAILING_SPACES_ERROR_MESSAGE);
            throwIfErrors();
        }
    }


    protected void validateAmount(BigDecimal amount, String fieldName) {
        if (amount.signum() <= 0) {
            errorDtoList.clear();
            addError(fieldName, INVALID_ERROR_CODE, MessageFormat.format(INVALID_ERROR_MESSAGE, fieldName, "Amount must be greater than 0"));
            throwIfErrors();
        } else if(amount.scale() > 2){
            logger.info("validate Payment Initiation, Validating up to 2 decimal point: {}",amount);
            errorDtoList.clear();
            addError(INVALID_ERROR_CODE, MessageFormat.format(INVALID_ERROR_MESSAGE, fieldName, "Validating up to 2 decimal point"));
            throwIfErrors();
        }else if (StringUtils.isNotEmpty(amount.toString()) && (amount.precision()- amount.scale()) > 18) {
            logger.info("field {} exceeds maxLength {}", fieldName, 18);
            addError(INVALID_ERROR_CODE, "The maximum allowed length for Debit amount before decimal is 18.");
            throwIfErrors();
        }else {
            validateFieldWithRegex(amount.toString(), PaymentConstants.AMOUNT_REGEX, fieldName, INCORRECT_FORMAT);
            throwIfErrors();
        }
    }

    protected void checkAllCaps(String value, String field) {
        if (!value.matches(PaymentConstants.CAPS_REGEX)) {
            addError(field, ErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(ErrorConstants.INVALID_ERROR_MESSAGE, field, "field should be capital only"));
            throwIfErrors();
        }
    }

    protected void addError(String fieldName, String errorCode, String errorMessage) {
        errorDtoList.add(ErrorDto.builder().errorCode(errorCode).errorMessage(MessageFormat.format(errorMessage, fieldName)).build());
    }

    protected void addError(String errorCode, String errorMessage, Object... fieldNames) {
        errorDtoList.add(ErrorDto.builder().errorCode(errorCode).errorMessage(MessageFormat.format(errorMessage, fieldNames)).build());
    }

    protected void throwIfErrors() {
        if (CollectionUtils.isNotEmpty(errorDtoList)) {
            throw new ValidationException(errorDtoList);
        }
    }
}
