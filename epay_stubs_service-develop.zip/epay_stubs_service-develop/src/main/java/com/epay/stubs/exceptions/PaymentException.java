package com.epay.stubs.exceptions;
import lombok.AllArgsConstructor;
import lombok.Data;
/**
 * Class Name: PaymentException
 * <p>
 * Description:
 * <p>
 * Author: VCE2645(Siddhesh Nikam)
 * Copyright (c) 2024 [State Bank of India]
 * ALl rights reserved
 * <p>
 * Version: 1.0
 */
@Data
@AllArgsConstructor
public class PaymentException  extends RuntimeException {

    private String errorCode;
    private String errorMessage;


}

