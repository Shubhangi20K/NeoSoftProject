package com.epay.stubs.externalservice;

import com.epay.stubs.config.InbConfigDeatils;
import com.epay.stubs.exceptions.PaymentException;
import com.epay.stubs.util.ErrorConstants;
import com.epay.stubs.util.InbEncryptionDecryptionUtil;
import com.epay.stubs.util.InbErrorConstants;
import com.epay.stubs.util.PaymentConstants;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.util.retry.Retry;

import javax.net.ssl.SSLContext;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.text.MessageFormat;
import java.time.Duration;
import java.util.Optional;
import java.util.function.Supplier;

/**
 * Class Name: PaymentWebClientService
 * <p>
 * Description:
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * ALl rights reserved
 * <p>
 * Version: 1.0
 */

@Component
@RequiredArgsConstructor
public class PaymentWebClientService {

    /**
     * @return: Encrypted DV Response from bank.
     * @methodName: Process DV Request.
     * @@Method-Description: DV Web Client connection code.
     * @param: SBIDVResponseConn
     * @Exception: or @Error :Exception
     */
    LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private final InbConfigDeatils nbConfigDeatils;
    private final InbEncryptionDecryptionUtil nbEncryptionDecryptionUtil;

    /**
     * @return: DV Response from bank.
     * @methodName: Process DV Request.
     * @@Method-Description: Process DV Request.
     * @param: processingDoubleVerRequest
     * @Exception: or @Error :Exception
     */

    public String processingDoubleVerRequest(String PlainDVRequestAndChecksum){

        try {
            String encryptedDVData = Optional.ofNullable(URLEncoder.encode(nbEncryptionDecryptionUtil.encrypt(PlainDVRequestAndChecksum), PaymentConstants.UTF_EIGHT)).filter(x -> !x.isEmpty()).orElseThrow(() -> new PaymentException(InbErrorConstants.ENCRYPTION_ERROR_CODE, InbErrorConstants.ENCRYPTION_ERROR_MESSAGE));
            logger.info("Payment Callback Encrypted and Encoded Double Verification {} " + encryptedDVData);

            String DVResponse = Optional.ofNullable(SBIDVResponseConn(nbConfigDeatils.getSbiNburl(),
                                    (PaymentConstants.SBIINB_MERCH_CODE_CONST)
                                    .concat(PaymentConstants.SBIINB_MERCH_CODE_VAL)
                    .concat(PaymentConstants.SBIINB_ENC_DATA).concat(encryptedDVData)))
                    .filter(x -> !x.isEmpty()).orElseThrow(() -> new PaymentException(InbErrorConstants.DOUBLE_VERIFICATION_ERROR_CODE, InbErrorConstants.DOUBLE_VERIFICATION_ERROR_MESSAGE));
            logger.info("Payment Callback Encrypted Double Verification Response {} ", DVResponse);

            String decryptedDVResponse = URLDecoder.decode(nbEncryptionDecryptionUtil.decrypt(DVResponse.trim().replaceAll(PaymentConstants.NEW_LINE_REGEX, PaymentConstants.PATTERN_EMPTY).replace(PaymentConstants.PATTERN_SPACE, PaymentConstants.PATTERN_EMPTY)), StandardCharsets.UTF_8);
            logger.info("Payment Callback Decrypted and Decode Double Verification Response {} ", decryptedDVResponse);
            return decryptedDVResponse;
        } catch (Exception e) { // Exception throw by INB Bank Algorithm
            logger.error("Exception While processingDoubleVerRequest  {}", e);
            throw new PaymentException(InbErrorConstants.DOUBLE_VERIFICATION_ERROR_CODE, InbErrorConstants.DOUBLE_VERIFICATION_ERROR_MESSAGE);
        }
    }
   
    public String SBIDVResponseConn(String bankdvurl, String encryptedData){
        logger.info("SBIINB DV Request posting parameters DV Url {} and encryptedData {} ",bankdvurl,encryptedData);

        try{
        SSLContext sc = SSLContext.getInstance(PaymentConstants.HTTPS_PROTOCOLS_VALUE);
        sc.init(null, null, new SecureRandom());
        System.setProperty(PaymentConstants.JAVA_PROTOCAL_HANDLER_KEY, PaymentConstants.JAVA_PROTOCAL_HANDLER_VALUE);
        System.setProperty(PaymentConstants.HTTPS_PROXY_SET_KEY, PaymentConstants.HTTPS_PROXY_SET_VALUE);
        System.setProperty(PaymentConstants.HTTPS_PROTOCOLS_KEY, PaymentConstants.HTTPS_PROTOCOLS_VALUE);
        System.setProperty(PaymentConstants.HTTPS_PROXY_HOST_KEY, PaymentConstants.HTTPS_PROXY_HOST_VALUE);
        System.setProperty(PaymentConstants.HTTPS_PROXY_PORT_KEY, PaymentConstants.HTTPS_PROXY_PORT_VALUE);

        WebClient webClient = WebClient.builder()
                .baseUrl(bankdvurl)
                .build();
        logger.info("webClient URL for SBIINB {} ",webClient);


        return webClient.post().header(PaymentConstants.REQUESTPROPERTY, PaymentConstants.URL_ENCODED_CONTENT_TYPE)
                .bodyValue(encryptedData).retrieve().onStatus(status -> {
                            logger.info("SBIINB DV Response received {} ",status);
                            return !status.is2xxSuccessful();
                        },
                        clientResponse ->
                                clientResponse.bodyToMono(String.class)
                                        .flatMap(errorBody -> Mono.error(((Supplier<RuntimeException>) () -> new PaymentException(ErrorConstants.EXTERNAL_SERVICE_ERROR_CODE, MessageFormat.format(ErrorConstants.EXTERNAL_SERVICE_ERROR_MESSAGE, PaymentConstants.SBI_INB_SERVICE))).get()
                                        ))
                ).bodyToMono(String.class).
                        doOnNext(body -> {
                    logger.info("responseCode SBIINB {} ",body);
                }).doOnError(error -> {
                    logger.info("error responseCode SBIINB {} ",error);
                }).onErrorResume(error -> {
                    logger.info("error responseCode SBIINB {} ",error);
                    return Mono.error(() -> new PaymentException(ErrorConstants.EXTERNAL_SERVICE_ERROR_CODE, MessageFormat.format(ErrorConstants.EXTERNAL_SERVICE_ERROR_MESSAGE, PaymentConstants.SBI_INB_SERVICE)));
                })
                .retryWhen(Retry.fixedDelay(3, Duration.ofSeconds(1))
                        .filter(throwable -> throwable instanceof PaymentException)
                        .doBeforeRetry(retrySignal ->
                                logger.info("Retrying attempt {} due to error: {}", retrySignal.totalRetries() + 1, retrySignal.failure().getMessage())
                        ))
                .block();
        } catch (Exception e) { // Exception throw by INB Bank Algorithm
            logger.error("Exception While SBIDVResponseConn  {}", e);
            throw new PaymentException(ErrorConstants.EXTERNAL_SERVICE_ERROR_CODE, MessageFormat.format(ErrorConstants.EXTERNAL_SERVICE_ERROR_MESSAGE, PaymentConstants.SBI_INB_SERVICE));
        }
    }

    public String otherINBDVResponseConn(String bankdvurl, String encryptedData){

        LoggerUtility logger = LoggerFactoryUtility.getLogger(PaymentWebClientService.class);

        logger.info("Other INB DV Request posting parameters DV Url {} and encryptedData {} ",bankdvurl,encryptedData);
        try{
        SSLContext sc = SSLContext.getInstance(PaymentConstants.HTTPS_PROTOCOLS_VALUE);
        sc.init(null, null, new SecureRandom());
        System.setProperty(PaymentConstants.UAT_JAVA_PROTOCAL_HANDLER_KEY, PaymentConstants.UAT_JAVA_PROTOCAL_HANDLER_VALUE);
        System.setProperty(PaymentConstants.UAT_HTTPS_PROXY_SET_KEY, PaymentConstants.UAT_HTTPS_PROXY_SET_VALUE);
        System.setProperty(PaymentConstants.UAT_HTTPS_PROTOCOLS_KEY, PaymentConstants.UAT_HTTPS_PROTOCOLS_VALUE);
        System.setProperty(PaymentConstants.UAT_HTTPS_PROXY_HOST_KEY, PaymentConstants.UAT_HTTPS_PROXY_HOST_VALUE);
        System.setProperty(PaymentConstants.UAT_HTTPS_PROXY_PORT_KEY, PaymentConstants.UAT_HTTPS_PROXY_PORT_VALUE);

        WebClient webClient = WebClient.builder()
                .baseUrl(bankdvurl)
                .build();
        logger.info("webClient URL for other INB {} ",webClient);


        return webClient.post().header(PaymentConstants.REQUESTPROPERTY, PaymentConstants.URL_ENCODED_CONTENT_TYPE)
                .bodyValue(encryptedData).retrieve().onStatus(status -> {
                            logger.info("DV Response received status for other INB {} ",status);
                            return !status.is2xxSuccessful();
                        },
                        clientResponse ->
                                clientResponse.bodyToMono(String.class)
                                        .flatMap(errorBody -> Mono.error(((Supplier<RuntimeException>) () -> new PaymentException(ErrorConstants.EXTERNAL_SERVICE_ERROR_CODE, MessageFormat.format(ErrorConstants.EXTERNAL_SERVICE_ERROR_MESSAGE, PaymentConstants.SBI_INB_SERVICE))).get()
                                        ))
                ).bodyToMono(String.class).
                doOnNext(body -> {
                    logger.info("responseCode for other INB {} ",body);
                }).doOnError(error -> {
                    logger.info("error responseCode for other INB {} ",error);
                }).onErrorResume(error -> {
                    logger.info("error responseCode for other INB {} ",error);
                    return Mono.error(() -> new PaymentException(ErrorConstants.EXTERNAL_SERVICE_ERROR_CODE, MessageFormat.format(ErrorConstants.EXTERNAL_SERVICE_ERROR_MESSAGE, PaymentConstants.OTHER_INB_SERVICE)));
                })
                .retryWhen(Retry.fixedDelay(3, Duration.ofSeconds(1))
                        .filter(throwable -> throwable instanceof PaymentException)
                        .doBeforeRetry(retrySignal ->
                                logger.info("Retrying attempt {} due to error: {}", retrySignal.totalRetries() + 1, retrySignal.failure().getMessage())
                        ))
                .block();
        } catch (Exception e) { // Exception throw by INB Bank Algorithm
            logger.error("Exception While otherINBDVResponseConn  {}", e);
            throw new PaymentException(ErrorConstants.EXTERNAL_SERVICE_ERROR_CODE, MessageFormat.format(ErrorConstants.EXTERNAL_SERVICE_ERROR_MESSAGE, PaymentConstants.OTHER_INB_SERVICE));
        }
    }
}
