package com.epay.stubs.entity;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;

@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "MERCHANT_ORDER_SUMMARY")
public class PaymentOrderSummary implements Serializable {

    @EmbeddedId
    OrderSummaryEmbeddedId orderSummaryEmbeddedId;

    @Column(name = "LAST_TXN_BOOKING_DATE")
    private Long lastTxnBookingDate;

    @Column(name = "DAILY_TXN_AMOUNT")
    private BigDecimal dailyTxnAmount;

    @Column(name = "WEEKLY_TXN_AMOUNT")
    private BigDecimal weeklyTxnAmount;

    @Column(name = "MONTHLY_TXN_AMOUNT")
    private BigDecimal monthlyTxnAmount;

    @Column(name = "QUARTERLY_TXN_AMOUNT")
    private BigDecimal quarterlyTxnAmount;

    @Column(name = "HALF_YEARLY_TXN_AMOUNT")
    private BigDecimal halfYearlyTxnAmount;

    @Column(name = "ANNUALLY_TXN_AMOUNT")
    private BigDecimal annuallyTxnAmount;

    @Column(name = "CREATED_BY")
    private String createdBy;

    @Column(name = "UPDATED_BY")
    private String updatedBy;

    @Column(name = "CREATED_DATE")
    private Long createdDate;

    @Column(name = "UPDATED_DATE")
    private Long updatedDate;

//    @Column(name = "PARTITION_DATE")
//    private Date partitionDate;
}
