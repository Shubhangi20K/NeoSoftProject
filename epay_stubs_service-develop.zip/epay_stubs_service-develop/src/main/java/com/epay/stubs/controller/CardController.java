package com.epay.stubs.controller;

import com.epay.stubs.model.request.PaymentRequestCard;
import com.epay.stubs.model.response.*;
import com.epay.stubs.service.CardCallbackService;
import com.epay.stubs.service.CardInitiationIntlService;
import com.epay.stubs.service.CardInitiationService;
import com.epay.stubs.util.PaymentConstants;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

/**
 * Class Name: CardController
 * *
 * Description: Card Stubs Service
 * *
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@RestController
@RequiredArgsConstructor
@RequestMapping("/cards")
public class CardController {

    LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private final CardInitiationService cardInitiationService;
    private final CardCallbackService cardCallbackService;
    private final CardInitiationIntlService cardInitiationINTLService;

    /**
     * get card status for tokenVault
     *
     * @param tokenRequest
     * @return TokenAltResponse
     */
    @PostMapping("/tokenVault/v3/tokenize")
    public TokenAltResponse getAltIdApiResponse(@RequestBody String tokenRequest) {
        logger.info("Card Tokenize Request", tokenRequest);
        return cardInitiationService.getAltIdApiResponse(tokenRequest);
    }

    /**
     * PVrqEncAPI
     *
     * @param pVrqRequest
     * @return PVrqEncResponse
     */
    @CrossOrigin("*")
    @PostMapping("/3dsserverapi/v5/pVrq/8642/{atrn}")
    public PVrqEncResponse getPVrq(@RequestBody String pVrqRequest, @PathVariable("atrn") String atrn) {
        logger.info("PVrqRequest ::  {} ", pVrqRequest);
        return cardInitiationService.getPvRq(pVrqRequest);
    }

    @CrossOrigin("*")
    @PostMapping("/callback/visamaster")
    public PVrqEncResponse getPArq(@RequestBody String pArqRequest) {
        logger.info("PArqRequest ::  {} ", pArqRequest);
        return cardCallbackService.getPArq(pArqRequest);
    }

    /**
     * get card authentication status for SaleAPI
     *
     * @param saleAPIRequest
     * @return SaleAPIResponse
     */
    @CrossOrigin("*")
    @PostMapping("/saleservice/api/v1/sale")
    public SaleAPIResponse getSaleAPI(@RequestBody String saleAPIRequest) {
        logger.info("SaleAPIRequest ::  {} ", saleAPIRequest);
        return cardInitiationService.getSaleAPI(saleAPIRequest);
    }

    /**
     * get card authentication status for Visa Master cards
     *
     * @param paymentRequestCard
     * @return PaymentResponse
     */
    @CrossOrigin("*")
    @PostMapping("/visamaster/auth")
    public PaymentResponse<?> getCardAuthorizationStatus(@RequestBody PaymentRequestCard paymentRequestCard) {
        logger.info("Payment Initiated for Visa & Master Cards paymentRequestCard");
        if(paymentRequestCard.getOperatingMode().equalsIgnoreCase(PaymentConstants.DOM)) {
            return cardInitiationService.getCardAuthenticationStatus(paymentRequestCard);
        }
        else{
            return cardInitiationINTLService.getCardAuthenticationStatus(paymentRequestCard);
        }
    }

    /**
     * get card authentication status for Rupay Master cards
     *
     * @param paymentRequestCard
     * @return PaymentResponse
     */
    @CrossOrigin("*")
    @PostMapping("/rupay/auth")
    @Operation(summary = "RUPAY Card Authentication API",description = "This API is used for Card Authentication.")
    public PaymentResponse<?> initiationRupay(@Valid @RequestBody PaymentRequestCard paymentRequestCard) {
        logger.info("Payment Initiated for Rupay Cards paymentRequestCard");
        if(paymentRequestCard.getOperatingMode().equalsIgnoreCase(PaymentConstants.DOM)) {
            return cardInitiationService.getCardAuthenticationStatusRupay(paymentRequestCard);
        }else {
            return  cardInitiationINTLService.getCardAuthenticationStatusRupay(paymentRequestCard);
        }
    }

    /**
     * get card authentication status for Checkbin
     *
     * @param binCheckRequest
     * @return BinCheckResponse
     */
    @CrossOrigin("*")
    @PostMapping("/authentication/api/v1/checkbin")
    public SaleEncResponse getBinCheck(@RequestBody String binCheckRequest) {
        logger.info("BinCheckRequest ::  {} ", binCheckRequest);
        return cardInitiationService.getBinCheck(binCheckRequest);
    }


    @CrossOrigin("*")
    @PostMapping("/authentication/api/v1/generateOtp")
    @Operation(summary = "RUPAY Card Authentication API",description = "This API is used for Card Authentication.")
    public SaleEncResponse generateOTP(@Valid @RequestBody String generateOtpRequest) {
        logger.info("Payment Initiated for Rupay Cards paymentRequestCard");
        return cardInitiationService.generateOTP(generateOtpRequest);
    }
}
