package com.epay.stubs.model.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.LinkedHashMap;

/**
 * Class Name:PArqRequest
 * *
 * Description: Card Stubs Service
 * *
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PArqRequest {
    private String messageType;
    private String deviceChannel;
    private String merchantTransID;
    private String messageVersion;
    private String messageCategory;
    private String threeDSServerTransID;
    private String threeDSRequestorID;
    private String threeDSRequestorName;
    private String threeDSRequestorURL;
    private String threeDSCompInd;
    private String threeDSRequestorAuthenticationInd;
    private LinkedHashMap<String, String>  threeDSRequestorAuthenticationInfo;
    private String threeDSReqAuthMethod;
    private String threeDSReqAuthTimestamp;
    private String threeDSReqAuthData;
    private String acctNumber;
    private String acctType;
    private String addrMatch;
    private String cardExpiryDate;
    private String cardholderName;
    private String mcc;
    private String merchantName;
    private String merchantUrl;
    private String merchantCountryCode;
    private String acquirerBIN;
    private String acquirerID;
    private String acquirerMerchantID;
    private String purchaseCurrency;
    private String purchaseExponent;
    private String purchaseAmount;
    private String purchaseDate;
    private LinkedHashMap<String, String> mobilePhone;
    private LinkedHashMap<String, String>  workPhone;
    private String email;
    private LinkedHashMap<String, String>  homePhone;
    private String transType;
    private String threeRIInd;
    private String threeDSRequestorFinalAuthRespURL;
    private String browserAcceptHeader;
    private String browserIP;
    private String browserJavaEnabled;
    private String browserJavascriptEnabled;
    private String browserLanguage;
    private String browserColorDepth;
    private String browserScreenHeight;
    private String browserScreenWidth;
    private String browserTZ;
    private String browserUserAgent;
    private String p_messageVersion;
}
