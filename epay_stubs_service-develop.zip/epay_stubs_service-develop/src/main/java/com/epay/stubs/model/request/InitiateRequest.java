package com.epay.stubs.model.request;

import lombok.*;

/**
 * Class Name:InitiateRequest
 * *
 * Description: Card Stubs Service
 * *
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Builder
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class InitiateRequest {
    private String pgInstanceId;
    private String merchantId;
    private String merchantReferenceNo;
    private String pan;
    private String cardExpDate;
    private String browserUserAgent;
    private String ipAddress;
    private String httpAccept;
    private String authAmount;
    private String currencyCode;
    private String cvd2;
    private String orderDesc;
    private String ext1;
    private String ext2;
    private String amountInInr;
    private String originalAmount;
    private String merchantResponseUrl;
    private String transaction_type_indicator;
    private String purposeOfAuthentication;
    private String tokenAuthenticationValue;
    private String nameOnCard;
    private String email;
}
