package com.epay.stubs.service;


import com.epay.stubs.dao.*;
import com.epay.stubs.dto.*;
import com.epay.stubs.exceptions.PaymentException;
import com.epay.stubs.externalservice.response.CallbackAcknowledgement;
import com.epay.stubs.model.response.UpiCallbackResponse;
import com.epay.stubs.util.PaymentConstants;
import com.epay.stubs.util.enums.TransactionStatus;
import com.epay.stubs.validator.PaymentValidator;
import com.google.gson.Gson;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

/**
 * Class Name:UpiCallbackService
 * *
 * Description: Upi Stubs Callback Service
 * *
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@RequiredArgsConstructor
@Service
public class UpiCallbackService {

    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private final TransactionDao transactionDao;
    private final PaymentValidator paymentValidator;
    private final UpiPaymentDao upiPaymentDao;
    private final PaymentDao paymentDao;
    private static final Gson GSON = new Gson();

    public CallbackAcknowledgement processCallback(UpiCallbackResponse statusResponse) {

        logger.info("Inside processCallback Encrypted response :: {}", statusResponse);
        try {
            var apiResp = statusResponse;
            UpiFinalResponseDto statusfinalResponse=UpiFinalResponseDto.builder().apiResp(statusResponse).build();
            logCallbackResponse(apiResp.getPspRefNo(), apiResp.getCustRefNo(), statusResponse.toString(), statusfinalResponse);
            TransactionDto transactionDto = transactionDao.getValidPaymodePaymentAckReq(apiResp.getPspRefNo(), PaymentConstants.UPI_PAYMODE);
            if (transactionDto == null || !paymentValidator.validateWebAndDvAmt(transactionDto.getDebitAmt(), apiResp.getAmount())) {
                logger.warn("Invalid Transaction OR Amount Mismatch for ATRN : {}", apiResp.getPspRefNo());
                return buildAcknowledgement(apiResp.getPspRefNo(), "FAILED", "Invalid transaction or Amount mismatch");
            }
            if (TransactionStatus.BOOKED.equals(transactionDto.getTransactionStatus())) {
                upiPaymentDao.processUpiResponse(UpiProcessResponseDto.builder().amount(apiResp.getAmount()).status_desc(apiResp.getStatusDesc()).sbirefNo(apiResp.getCustRefNo()).txnrefNo(apiResp.getPspRefNo()).status(apiResp.getStatus()).build());
                return buildAcknowledgement(apiResp.getPspRefNo(), "SUCCESS", "Request Processed Successfully");
            }
            return buildAcknowledgement(apiResp.getPspRefNo(), "SUCCESS", "Request Processed Successfully");
        } catch (PaymentException e) {
            return handleCallbackFailure(e, statusResponse.toString());
        }
    }
    private void logCallbackResponse(String pspRefNo, String custRefNo, String decryptedResponse, UpiFinalResponseDto statusResponse) {
        paymentDao.saveResponseLog(decryptedResponse, pspRefNo, custRefNo,
                PaymentConstants.UPI_CALLBACK_RESPONSE_TYPE, PaymentConstants.CREATED_BY_UPI_CALLBACK);
        var apiResp = statusResponse.getApiResp();
        upiPaymentDao.saveFinalResponse(pspRefNo, String.valueOf(apiResp.getUpiTransRefNo()), apiResp.getNpciTransId(), custRefNo, apiResp.getAmount(),
                apiResp.getStatus(), apiResp.getStatusDesc(), "NA", decryptedResponse, apiResp.getPayerVPA(), apiResp.getPayeeVPA(),
                System.currentTimeMillis(), "CALLBACK_SERVICE");
    }

    private CallbackAcknowledgement buildAcknowledgement(String pspRefNo, String status, String message) {
        return CallbackAcknowledgement.builder().pspRefNo(pspRefNo).status(status).message(message).build();
    }

    private CallbackAcknowledgement handleCallbackFailure(PaymentException e, String decryptedResponse) {
        logger.error("Callback processing error", e);
        String fallbackPspRefNo = "N/A";
        UpiFinalResponseDto statusResponse;
        String errorMsg = e.getMessage() == null ? e.getErrorMessage() : e.getMessage();
        try {
            if (decryptedResponse != null) {
                statusResponse = GSON.fromJson(decryptedResponse, UpiFinalResponseDto.class);
                var apiResp = statusResponse.getApiResp();
                fallbackPspRefNo = apiResp.getPspRefNo();
                logCallbackResponse(apiResp.getPspRefNo(), apiResp.getCustRefNo(), decryptedResponse, statusResponse);
            }
        } catch (Exception ex) {
            logger.warn("Could not save fallback response : {}" + ex.getMessage());
            errorMsg = ex.getMessage();
        }
        return buildAcknowledgement(fallbackPspRefNo, "FAILED", errorMsg);
    }

    public UpiAccesTokenResponseDto getUpiAccesToken(String upiAccessTokenRequest) {
        UpiAccesTokenResponseDto upiAccesToken = UpiAccesTokenResponseDto.builder()
                .access_token("b1763525-f76b-417c-a86d-3b999c7327b9")
                .token_type("bearer")
                .refresh_token("6046e4bd-4b7e-4007-98fc-6915f10e52cf")
                .expires_in(179)
                .build();
        logger.info("UpiAccesTokenResponseDto : {} ",upiAccesToken);
        return upiAccesToken;
    }

    public UpiGenericVpaQrWebResponse meCollectInitiateWeb(String request) {
        UpiGenericVpaQrWebResponse upiCollectCollectInitiateWeb = UpiGenericVpaQrWebResponse.builder()
                .resp("LS0tLS1CRUdJTiBQR1AgTUVTU0FHRS0tLS0tClZlcnNpb246IERpZGlzb2Z0IE9wZW5QR1AgTGlicmFyeSBmb3IgSmF2YSAzLjIKCmhRRU1BeFR0YTRkenBVN3RBUWYvZkQydDFncjRBWHdvNTlNQW5sNFlINjVZcmtiOG1zNlFwTzh2bENKcDFINE4KWTNaOFhkUGh6MWZMaTlNS0lMRlpIQXZzakRNSW5HZVR0NUtsUU5iakFjdFZrNC9ndkFlTjhWMDlWcG95STlHSwp2enNHRE9iY1ErMXNVNnZUQkNXcHVxNzIzemZLNVIwL2xIZUhMaGd1TWVoUU5yY1FMYVY1NXRJenh3VXRZQlNrCnEyRk1NeEl5K1hZQ0E0SkRWUDBSeXhhU1RFSDdQK3V6aHA0a0JTWVdnT2h0dVlQZ1FpcFR4aGJEdk5Cc0grbFkKOERJT0RPZTcxQUhBWmdGa2QxUnpQQkVUVTcwYWhlRStqR1UwL09XaGhWQmc5SnJjQlZTS3g5U1NtZm9CU0FhVAo1VmNXQ0pwK1lSYUswdlFJZ3dFVVJVckRHdUY3VHBxNkVPVXpsWGdCQk5MRVVBRk9jY1Y1QTh6MFFuMnI5c2IyCjRLbkkxN2o2cEs5d1BnTktCK1l0R05uWlNDN0gyUTZCWlZLRzl2T0N3QUhLVm5SYkhhZmtmNEJ0VS9GUWlDMjkKdTlnNE5lZ3dzbXdtYTlJUlA0SGRxeFpueERmVUVINkZqM1JYWWlqSmlqdm9QZVJQQ0tuZ0FCYThGM0U0ZFB0dQpYR3hld3hpcjRjNWxlbDJXbXRKRGxRV1N0dmJMdDZMQW85VWZuYWpsOTBTRkZWVkwvYlZGQkpmZzBwTC85U3QzClVBWmZMNktrYkRTRGFHY09uV0NyenJudklDU2N4Q2Jud3QvMm53Zm5Oc2t1Y1FQVFc1R3pzZ0VOZW96SmdBTFYKUDZITEpsZjBJQm9jSGcvbjhpZTV5clVlM09Sd291STgyUjhFS3F5Mm1RTVNrTDBkWHVZaGVOcy8rcGp2MU03eApMN1pHTjd4b3pHRU1Zay9nTUllRnp4eXp5M2VXSkRlZk4yNjVBQTJwYkhNSFpTampHQ2VxODhTNkc3dDJTZGdHCmhDWWtVYTJlUUJ4ZWNJUFJrUzJXSW5idDg4dGduRDh3b3A3MXlPb1JicGpwcFN3K2lHT1JRR1Exbk5BcGNXM1cKN2ZWQy9PeG1ScDg5Q0ZPTm5jdUgzTkRFZ09BazFwZVFBekp6UVBjb1Z1UHUycmdjZDJkRi9QSnBibm80NlRJegprZUhJTURYWGJBdFZwR3c2R05OL09GOEJRam5wQ1g5ZjRaRmd5ckV1K1kydG50a2pPWi93UVBvMDNJVnB1cmZVCnBoRWlxZHd1Tm1vMTdVZFVzdEFYM2pyNGpOYThWV2krNDBMTGk0Y1ExeUdnRFI2eXVpWlk3YVZhNStNTEVnOVUKclpWKzRnTGZkOEVEMDhTZ3IzV05CM0xIajJyclJGVWVPVDhHdVhtRkVlRlorcUhqZ1o0NEJGN2lQTDRwNGdhdwp6ZlRUSWV3RllNVFhjcGUzNGxtUlZ5TXNaM1ZnLzJ3cDNPNm5CampxN3l1NmdsRmN5RUgyY05MWnRGcmtoTGphClJCRlovYmR6Z0owWTNsODloaVR5bXJyZDY4RThBS0MvUmlWbWo0cU9UN0ZQbkZsbm5ZTlptOFZOSjEzQUJ0L2IKN01aWGlZVkJsc3pEMlY5bGMra2MwTzkrZHVibjhKemFhcXBKUjJJNjg5VXppazF0cWVXai9neTA5V3Zwcm9PbgpsMjJ5ek90bEhmb0szcVZBMW9nV2s0aXBnZ1lCVktwVGxnSmJXUjRMZkUybEdZMHphNFFFbVBLMytUUTFaOUJECm5vOFpqNEUzbnE4aUM4MjJsaEFQd2pTcUpVOVVXTGZmU1JnbUZJMHBwWGhpNXBlZ1E5MFByTTA2MjJrT2FDemIKT1FCUXE2YzRyakZ2T3BTSG1PLzFDeEVaZUhNeGxSOFBubjVWakxwN0N5WDhrSCtqQ01nTHhzU2FuZTh1cU9tTApoZkpSZkNZUzA0bzZ5OFdQbnVaM0xsRktFQk1XVWJxL0xTeFBFOHh1Y09Ba2ZhZ3UzcWFjUHVBS0hDSy9CVWI3CjhWRVc5Ky9KOHFLVDhCRjZjaUVWNHBMM3FuY044c1lsaGdEbEZxTTZ2cHhFVVVvaXZYQmlFM2tRa2Z6R1JoNS8KclFqK096L0Y2aDNPRFRTSHVHRUdUYmRQaUNqV052bExzbDZwclFyeUY2VUFXVDVvM0VBTEJwaC9tVjVudkNwQQpWZ01xbzBhWHJ2U0tib3hQS1ppd05aNGprZ0pIb2tJbmVFWGhGcHFKQXNTZzd6L0diSXlTSkZqbGVzWC9YWGVJCmhyaVVaWmJSTGJMQy9FU3FxK0NEVUc1dXBybWIzaUFhQ1VnWmd3TG9JazVsQ1pWTXVvUGMybXhNeG9IcytQUkcKQ29telQ4bmdWZTNIdHkySlozZm85QXJ1Slg2OU5pYmJONkNCYWxGMlpHVEkrNDBYS1RNbWN1UllTTkIwT1FhbgpLTDI3VHJVcmJNbXUxazU1Wktvb25WQ25zSUZQaFNwbnIvYmtENDZiSzFNRm5FMEt4MzA4Tks3c3N0UDZaSG9xCjBzOHYrUHkwcHJQamw1QlJ2eDVjZW9KQVZkaWFiWUtDTktOSllicGRRVkwrTVdxblJ4cDdhcHVKQXNQK3JGU24KMUI2QXBqR2RBNTVGb0Z3SWgwaXE4NEZHTEM0VzNyT00vbFFDdjdyUHo2U1EzQUN3N0RtemV2TG11cFZzRW8zbQo5QUh1U2MwTDlJR2gwb0pVQnN0ckpPaWptTkxLTEx3ZXV0TXlXOXIxeEtpZ2Z3PT0KPVRGN2kKLS0tLS1FTkQgUEdQIE1FU1NBR0UtLS0tLQo=").build();
        logger.info("UpiGenericVpaQrWebResponse : {} ",upiCollectCollectInitiateWeb);
        return upiCollectCollectInitiateWeb;
    }
}


