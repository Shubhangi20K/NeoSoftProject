package com.epay.stubs.repository;

import com.epay.stubs.entity.PaymentLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.UUID;

/**
 * Class Name:PaymentRepository
 * *
 * Description:
 * *
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
@Repository
public interface PaymentRepository extends JpaRepository<PaymentLog, UUID>{

}
