package com.epay.stubs.entity;

import lombok.*;

@Data
@Builder
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class PostingData {

    private String postURL;

    private String data;

    private String key;

    private String merchantCode;

    private String atrn;
}
