package com.epay.stubs.util.enums;

import com.epay.stubs.exceptions.PaymentException;
import com.epay.stubs.util.ErrorConstants;

import java.text.MessageFormat;
import java.util.Arrays;

public enum VisaCallbackParams {
    cres;
    public static VisaCallbackParams getParameters(String cres) {
        return Arrays.stream(values()).filter(p -> p.name().equalsIgnoreCase(cres)).findFirst().orElseThrow(() -> new PaymentException(ErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(ErrorConstants.INVALID_ERROR_MESSAGE, "cres", "Valid Values are " + Arrays.toString(VisaCallbackParams.values()))));
    }
}
