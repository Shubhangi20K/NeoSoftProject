package com.epay.stubs.util.enums;

import com.epay.stubs.exceptions.PaymentException;
import com.epay.stubs.util.ErrorConstants;
import lombok.Getter;

import java.text.MessageFormat;
import java.util.Arrays;

@Getter
public enum OperatingMode {
    DOM("Domestic"), INTL ("International");

    private final String label;
    OperatingMode(String label) {
        this.label = label;
    }

    public static OperatingMode getOperatingMode(String label) {
        return Arrays.stream(values()).filter(p -> p.getLabel().equalsIgnoreCase(label)).findFirst().orElseThrow(() -> new PaymentException(ErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(ErrorConstants.INVALID_ERROR_MESSAGE, "OperatingMode", "Valid OperatingMode are " + Arrays.toString(OperatingMode.values()))));
    }
}
