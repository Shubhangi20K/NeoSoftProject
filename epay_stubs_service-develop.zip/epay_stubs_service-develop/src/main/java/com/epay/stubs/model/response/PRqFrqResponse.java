package com.epay.stubs.model.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Class Name:PRqFrqResponse
 * *
 * Description: Card Payment Service
 * *
 * Author: VCE2656 - Vinod Bhosale (Dev Lead SBIePAY)
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PRqFrqResponse {
    private String messageVersion;
    private String messageType;
    private String threeDSServerTransID;
    private String acsTransID;
    private String dsTransID;
    private String merchantTransID;
    private String eci;
    private String authenticationValue;
    private String transStatus;
    private String errorCode;
    private String errorDesc;
    private String pmessageVersion;
}
