package com.epay.stubs.model.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Class Name:SaleAuthRequest
 * *
 * Description: Card Stubs Service
 * *
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SaleAuthRequest {
    private String pgInstanceId;
    private String merchantId;
    private String acquiringBankId;
    private String action;
    private String transactionTypeCode;
    private String deviceCategory;
    private String pan;
    private String expiryDateYYYY;
    private String expiryDateMM;
    private String cvv2;
    private String nameOnCard;
    private String currencyCode;
    private String amount;
    private String merchantReferenceNo;
    private String orderDesc;
    private String mpiTransactionId;
    private String threeDsStatus;
    private String threeDsEci;
    private String threeDsXid;
    private String threeDsCavvAav;
    private String cryptogram;
    private String altIdFlag;
    private String threeDsVersion;
    private String threeDsTxnId;
}
