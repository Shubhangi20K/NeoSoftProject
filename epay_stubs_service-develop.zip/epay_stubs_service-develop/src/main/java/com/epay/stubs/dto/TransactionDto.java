package com.epay.stubs.dto;

import com.epay.stubs.util.enums.*;
import lombok.*;

import java.math.BigDecimal;
import java.util.Date;

/**
 * Class Name:CardPaymentDao
 * *
 * Description: Stubs Payment Service
 * *
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Setter
@Getter
@ToString
@AllArgsConstructor
@NoArgsConstructor
@Builder(toBuilder = true)
public class TransactionDto {

    private String atrnNum;
    private String merchantId;

    /* Order Information */
    private String orderRefNumber;
    private String sbiOrderRefNumber;

    /* Payment Information */
    private String payMode;

    private BigDecimal orderAmount;
    private BigDecimal debitAmt;

    private String channelBank;
    private String cin;
    private String pushResponse;

    private String payProcId;
    private String paymodeType;
    private String gtwMapId;
    private String gatewayIssueMECode;
    private BigDecimal availableRefundAmount;
    private BigDecimal chargeBackAmount;
    private String bankReferenceNumber;
    /* Transaction Information */
    private String failReason;


    /* Status Information */
    private TransactionStatus transactionStatus;
    private PaymentStatus paymentStatus;
    private SettelmentStatus settlementStatus;
    private RefundStatus refundStatus;
    private CancellationStatus cancellationStatus;
    private String chargeBackStatus;
    /* Audit Information */
    private String createdBy;
    private String updatedBy;
    private Long createdDate;
    private Long updatedDate;
    private String currencyCode;
    private String gstin;
    //private String custVpaId;
    private Date paymentSuccessDate;


}