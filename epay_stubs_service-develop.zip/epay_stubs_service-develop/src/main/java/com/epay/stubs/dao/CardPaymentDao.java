package com.epay.stubs.dao;

import com.epay.stubs.dto.*;
import com.epay.stubs.entity.CardSummeryEntity;
import com.epay.stubs.exceptions.PaymentException;
import com.epay.stubs.mapper.CardPaymentMapper;
import com.epay.stubs.model.response.SaleAPIResponse;
import com.epay.stubs.repository.CardSummeryRepository;
import com.epay.stubs.util.ErrorConstants;
import com.epay.stubs.util.PaymentConstants;
import com.epay.stubs.util.enums.PaymentStatus;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.sql.Timestamp;
import java.text.MessageFormat;

/**
 * Class Name:CardPaymentDao
 * *
 * Description: Stubs Payment Service
 * *
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */

@Component
@RequiredArgsConstructor
public class CardPaymentDao {

    private final CardSummeryRepository cardSummeryRepository;
    private final CardPaymentMapper cardPaymentMapper;
    private final PaymentOrderSummeryDao paymentOrderSummeryDao;
    private final TransactionDao transactionDao;
    private final PaymentDao paymentDao;
    private final StatusUpdatePaymentDao statusUpdatePaymentDao;
    private final OrderDao orderDao;

    LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());

    public CardSummeryEntity findBythreeDsSummery(String threeDsTransID) {
        return cardSummeryRepository.findByThreeDsServerTransId(threeDsTransID)
                .orElseThrow(() -> new PaymentException(ErrorConstants.NOT_FOUND_ERROR_CODE, MessageFormat.format(ErrorConstants.NOT_FOUND_ERROR_MESSAGE, PaymentConstants.THREE_DS_CONST)));
    }

    public CardSummeryEntity findByAtrnNumSummery(String threeDsTransID) {
        return cardSummeryRepository.findByAtrnNum(threeDsTransID).orElseThrow(() -> new PaymentException(ErrorConstants.NOT_FOUND_ERROR_CODE, MessageFormat.format(ErrorConstants.NOT_FOUND_ERROR_MESSAGE, PaymentConstants.ATRN_CONST)));
    }
    public void saveCardSummery(String atrn,String altId,String mId,String amount,String threeDsServerTransId,String responseData,String hash) {
        CardSummeryDto cardSummeryDto = CardSummeryDto.builder()
                .atrnNum(atrn)
                .altId(altId)
                .merchantId(mId)
                .debitAmount(amount)
                .threeDsServerTransId(threeDsServerTransId)
                .card_summery(responseData.getBytes())
                .creationDate((new Timestamp(System.currentTimeMillis()).getTime()))
                .card_hash(hash)
                .build();

        CardSummeryEntity cardSummeryEntity = cardPaymentMapper.mapToCardSummeryEntity(cardSummeryDto);
        cardSummeryRepository.save(cardSummeryEntity);
    }
    public void processSaleApiResponse(SaleAPIResponse saleAPIResponse,TransactionDto transactionDto) {
        logger.info("processSaleApiResponse()- saleAPIResponse  ::  {} transactionDto {} ", saleAPIResponse,transactionDto);
        switch (saleAPIResponse.getStatus()) {
            case PaymentConstants.PG_SUCCESS -> {
                logger.info("Success Case: paymentSuccessPendingStatusUpdateGen()- before Sale API response update  ::  {} ", PaymentConstants.SUCCESS);
                statusUpdatePaymentDao.paymentSuccessPendingStatusUpdateGen(PaymentStatus.SUCCESS.toString(),saleAPIResponse.getMerchantReferenceNo(), saleAPIResponse.getTransactionId(),PaymentConstants.CREATED_BY_WIBMOPG,transactionDto.getPayMode());
                logger.info("Success Case: paymentSuccessPendingStatusUpdateGen()- after Sale API response update  ::  {} ", PaymentConstants.SUCCESS);
            }
            default -> {
                logger.info("Default Case: paymentFailureStatusUpdate()- before Sale API response update  ::  {} ", PaymentConstants.FAILED);
                statusUpdatePaymentDao.paymentFailureStatusUpdate(transactionDto.getAtrnNum(),saleAPIResponse.getTransactionId() == null ? PaymentConstants.ZERO : saleAPIResponse.getTransactionId(),saleAPIResponse.getPgErrorDetail() == null ? PaymentConstants.NA : saleAPIResponse.getPgErrorDetail(),PaymentConstants.CREATED_BY_WIBMOPG);
                logger.info("Default Case: paymentFailureStatusUpdate()- Sale API response  ::  {} ", PaymentConstants.FAILED);
            }
        }
    }
}
