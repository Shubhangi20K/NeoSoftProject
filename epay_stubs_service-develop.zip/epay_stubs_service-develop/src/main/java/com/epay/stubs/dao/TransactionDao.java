package com.epay.stubs.dao;

import com.epay.stubs.dto.TransactionDto;
import com.epay.stubs.entity.MerchantOrderPayments;
import com.epay.stubs.exceptions.PaymentException;
import com.epay.stubs.mapper.TransactionMapper;
import com.epay.stubs.repository.TransactionRepository;
import com.epay.stubs.util.ErrorConstants;
import com.epay.stubs.util.PaymentConstants;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.text.MessageFormat;

/**
 * Class Name: TransactionDao
 * *
 * Description:
 * Copyright (c) 2024 [State Bank of India]
 * ALl rights reserved
 * *
 * Version: 1.0
 */
@Component
@RequiredArgsConstructor
public class TransactionDao {

    private final TransactionRepository transactionRepository;
    private final TransactionMapper transactionMapper;

    public TransactionDto getValidPaymentAckReq(String atrn, String paymentStatus) {
        MerchantOrderPayments merchantOrderPayments = transactionRepository.findByAtrnNumAndTransactionStatus(atrn, paymentStatus)
                .orElseThrow(() -> new PaymentException(ErrorConstants.INVALID_ERROR_CODE, MessageFormat
                        .format(ErrorConstants.INVALID_ERROR_MESSAGE, PaymentConstants.atrn, PaymentConstants.ATRN_NOT_FOUND)));
        return transactionMapper.mapToTransactionDto(merchantOrderPayments);
    }

    public TransactionDto getValidPaymentAckReq(String atrn, String paymentStatus, String payMode) {
        MerchantOrderPayments merchantOrderPayments = transactionRepository.findByAtrnNumAndTransactionStatusAndPayMode(atrn, paymentStatus, payMode)
                .orElseThrow(() -> new PaymentException(ErrorConstants.INVALID_ERROR_CODE, MessageFormat
                        .format(ErrorConstants.INVALID_ERROR_MESSAGE, PaymentConstants.atrn, PaymentConstants.ATRN_NOT_FOUND)));
        return transactionMapper.mapToTransactionDto(merchantOrderPayments);
    }


    public TransactionDto getValidPaymodePaymentAckReq(String atrn, String payMode) {
        MerchantOrderPayments merchantOrderPayments = transactionRepository.findByAtrnNumAndPayMode(atrn, payMode)
                .orElseThrow(() -> new PaymentException(ErrorConstants.INVALID_ERROR_CODE, MessageFormat
                        .format(ErrorConstants.INVALID_ERROR_MESSAGE, PaymentConstants.atrn, PaymentConstants.ATRN_NOT_FOUND)));
        return transactionMapper.mapToTransactionDto(merchantOrderPayments);
    }


    public TransactionDto getTransactionDetails(String atrn) {
        MerchantOrderPayments byAtrn = transactionRepository.findByAtrnNum(atrn);
        return transactionMapper.mapToTransactionDto(byAtrn);
    }

}
