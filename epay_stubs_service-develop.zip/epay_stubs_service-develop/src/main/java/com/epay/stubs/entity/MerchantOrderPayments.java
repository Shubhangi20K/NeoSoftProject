package com.epay.stubs.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * Class Name:CardPaymentDao
 * *
 * Description: Stubs Payment Service
 * All rights reserved
 * *
 * Version:1.0
 */
@Data
@Entity
@Table(name = "MERCHANT_ORDER_PAYMENTS")
public class MerchantOrderPayments {

    @Id
    @Column(name = "ATRN_NUM", nullable = false, updatable = false, unique = true)
    private String atrnNum;

    @Column(name = "MERCHANT_ID")
    private String merchantId;

    @Column(name = "order_ref_number")
    private String orderRefNumber;

    @Column(name = "sbi_order_ref_number")
    private String sbiOrderRefNumber;

//    @Column(name = "merchant_token_id") 2
//    private UUID merchantTokenId;

    @Column(name = "bank_reference_number")
    private String bankReferenceNumber;

    @Column(name = "pay_mode")
    private String payMode;

    @Column(name = "CURRENCY_CODE")
    private String currencyCode;

    @Column(name = "order_amount")
    private BigDecimal orderAmount;

    @Column(name = "payment_status")
    private String paymentStatus;

//    @Column(name = "txn_request_count") 1
//    private Long txnRequestCount;

    @Column(name = "transaction_status ")
    private String transactionStatus;

    @Column(name = "fail_reason")
    private String failReason;

    @Column(name = "debit_amt")
    private BigDecimal debitAmt;

    @Column(name = "GST_IN")
    private String gstin;

    @Column(name = "CHANNEL_BANK")
    private String channelBank;

    @Column(name = "SETTLEMENT_STATUS")
    private String settlementStatus;

    @Column(name = "REFUND_STATUS")
    private String refundStatus;

    @Column(name = "CANCELLATION_STATUS")
    private String cancellationStatus;

    @Column(name = "CIN")
    private String cin;

    @Column(name = "GTW_MAP_ID")
    private String gtwMapId;

    @Column(name = "PAY_PROC_ID")
    private String payProcId; //this is pay proc id e.g. Visa, Master, Rupay

    @Column(name = "PAY_PROC_TYPE")
    private String paymodeType; //this is Pay proc type e.g. onus, offus

    @Column(name = "GTW_ISSUE_MECODE")
    private String gatewayIssueMECode; //merchant wise and/or payment wise ME code received from bank

    @Column(name = "PUSH_RESPONSE")
    @Lob
    private String pushResponse;

    @Column(name = "created_by")
    private String createdBy;

//    @Column(name = "cust_vpa_id") 3
//    private String custVpaId;

    @Column(name = "updated_by")
    private String updatedBy;

    @Column(name = "CREATED_DATE")
    private Long createdDate;

    @Column(name = "updated_date")
    private Long updatedDate;

    @Column(name = "PAYMENT_SUCCESS_DATE")
    private Date paymentSuccessDate;

    @Column(name = "available_refund_amount")
    private BigDecimal availableRefundAmount;

    @Column(name = "CHARGEBACK_AMOUNT")
    private BigDecimal chargeBackAmount;

    @Column(name = "CHARGEBACK_STATUS")
    private String chargeBackStatus;

    @Column(name = "PUSH_STATUS")
    private String pushStatus;

    @Column(name = "POOLING_STATUS")
    private String poolingStatus;

//    @Column(name = "PARTITION_DATE")
//    private Date partitionDate    ;


}