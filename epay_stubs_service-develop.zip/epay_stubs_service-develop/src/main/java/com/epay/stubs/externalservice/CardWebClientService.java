package com.epay.stubs.externalservice;

import com.epay.stubs.config.CardConfigDeatils;
import com.epay.stubs.exceptions.PaymentException;
import com.epay.stubs.util.ErrorConstants;
import com.epay.stubs.util.PaymentConstants;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.text.MessageFormat;
import java.util.HashMap;
import java.util.function.Supplier;

/**
 * Class Name:CardWebClientService
 * *
 * Description: Stubs Payment Service
 * *
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@RequiredArgsConstructor
@Component
public class CardWebClientService {

    private final CardConfigDeatils cardConfigDeatils;
    LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
   
    public <T> T initiateCardWebClient(String url, String requestPayload, Class<T> responseDto, HashMap<String, String> requestHeaders) {

        logger.info("Card URL and Request headers ::  {} {}", url, requestHeaders);
        logger.info("Request - {} ",requestPayload);
        try {

            WebClient webClient = WebClient.builder().baseUrl(url)
                    .defaultHeader(HttpHeaders.ORIGIN, cardConfigDeatils.getCorsOrigin())
                    .build();
            return webClient.post().headers(httpHeaders -> requestHeaders.forEach(httpHeaders::add))

                    .bodyValue(requestPayload).retrieve().onStatus(status -> {
                                logger.info("Card Response-code  received ::  {} ", status);
                                return !status.is2xxSuccessful();
                            },
                            clientResponse ->
                                    clientResponse.bodyToMono(String.class)
                                            .flatMap(errorBody -> Mono.error(((Supplier<RuntimeException>) () -> new PaymentException(ErrorConstants.EXTERNAL_SERVICE_ERROR_CODE, MessageFormat.format(ErrorConstants.EXTERNAL_SERVICE_ERROR_MESSAGE, PaymentConstants.CARDS_SERVICE))).get()
                                            ))
                    ).bodyToMono(responseDto).
                    doOnNext(body -> {
                        logger.info("Card Response received  :  {} ", body);
                    }).map(body -> {
                        logger.info("Card Received processing Response :  {} ", body);
                        return body;
                    }).doOnError(error -> {
                        logger.error("Error while getting:: Card Response ::  {} ", error);
                    }).onErrorResume(error -> {
                        logger.error("Error processing  while getting:: Card Response ::  {} ", error);
                        return Mono.error(() -> new PaymentException(ErrorConstants.EXTERNAL_SERVICE_ERROR_CODE, MessageFormat.format(ErrorConstants.EXTERNAL_SERVICE_ERROR_MESSAGE, PaymentConstants.CARDS_SERVICE)));
                    }).block(); //SYNCHRONOUS CALLING--
        } catch (Exception e) { // Exception throw by Card PG
            logger.error("Exception While initiateCardWebClient  {}", e);
            throw new PaymentException(ErrorConstants.EXTERNAL_SERVICE_ERROR_CODE, MessageFormat.format(ErrorConstants.EXTERNAL_SERVICE_ERROR_MESSAGE, PaymentConstants.CARDS_SERVICE));
        }
    }

}
