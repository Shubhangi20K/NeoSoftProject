package com.epay.stubs.util;

public class InbErrorConstants {

    private InbErrorConstants() {}

    public static final String WEB_RESPONSE_ERROR_CODE = "3101";
    public static final String WEB_RESPONSE_ERROR_MESSAGE = "Error While Decrypting Web Response";

    public static final String WEB_CHECKSUM_ERROR_CODE = "3102";
    public static final String WEB_CHECKSUM_MISMATCH_ERROR_MESSAGE = "Web Checksum Mismatched";

    public static final String DV_CHECKSUM_ERROR_CODE = "3103";
    public static final String DV_CHECKSUM_MISMATCH_ERROR_MESSAGE = "Double Verification Checksum Mismatched";

    public static final String AMOUNT_ERROR_CODE = "3104";
    public static final String AMOUNT_ERROR_MESSAGE = "Invalid Transaction Amount.";

    public static final String BANK_REF_NO_ERROR_CODE = "3105";
    public static final String BANK_REF_NO_ERROR_MESSAGE = "Invalid Bank Reference Number";

    public static final String ENCRYPTION_ERROR_CODE = "3106";
    public static final String ENCRYPTION_ERROR_MESSAGE = "Exception While Encrypting Web Request in ";

    public static final String DOUBLE_VERIFICATION_ERROR_CODE = "3107";
    public static final String DOUBLE_VERIFICATION_ERROR_MESSAGE = "Empty Double Verification Response";

    public static final String INVALID_REQUEST_PARAMETER_ERROR_CODE = "3108";
    public static final String INVALID_REQUEST_PARAMETER_ERROR_MESSAGE = "Invalid Request Parameters";

}
