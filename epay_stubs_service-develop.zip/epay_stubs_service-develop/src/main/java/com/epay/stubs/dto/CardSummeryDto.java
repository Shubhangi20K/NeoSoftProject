package com.epay.stubs.dto;

import lombok.*;

import java.util.UUID;


@Builder
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class CardSummeryDto {
    private UUID id;
    private String atrnNum;
    private String altId;
    private String merchantId;
    private String debitAmount;
    private String threeDsServerTransId;
    private byte[] card_summery;
    private Long creationDate;
    private String card_hash;

}
