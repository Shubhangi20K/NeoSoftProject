package com.epay.stubs.util;

import com.epay.stubs.config.CardConfigDeatils;
import com.epay.stubs.dto.CardOnBoardDetailsResponseDto;
import com.epay.stubs.dto.TransactionDto;
import com.epay.stubs.exceptions.PaymentException;
import com.epay.stubs.model.request.*;
import com.epay.stubs.model.response.*;
import com.epay.stubs.validator.PaymentValidator;
import com.google.gson.Gson;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import com.sbipg.mlehelper.beans.AES;
import com.sbipg.mlehelper.beans.EncryptedRequestData;
import com.sbipg.mlehelper.util.DecryptionUtil;
import com.sbipg.mlehelper.util.EncryptionUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.security.interfaces.RSAPrivateKey;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;


/**
 * Class Name:CardCallbackUtil
 * *
 * Description: Card Stubs Service
 * *
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */

@Component
@RequiredArgsConstructor
public class CardCallbackUtil {
    
    private final CardEncryptionDecryptionUtil cardEncryptionDecryptionUtil;
    private final PaymentValidator PaymentValidator;
    private final CardConfigDeatils cardConfigDeatils;
    LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());

    /**
     * @return: ACSResponse
     * @methodName: getRedirectTransStatus
     * @@Method-Description: Process setting acs data
     * @param: paymentRequest
     * @Exception: or @Error :Exception
     */
    public ACSResponse  getRedirectTransStatus(String paymentRequest){
        byte[] valueDecoded = org.apache.commons.codec.binary.Base64.decodeBase64(paymentRequest.trim());
        return Optional.ofNullable(new Gson().fromJson(new String(valueDecoded,StandardCharsets.UTF_8), ACSResponse.class)).orElseThrow(() -> new PaymentException(CardErrorConstants.PROCESS_SERVICE_ERROR_CODE, MessageFormat.format(CardErrorConstants.PROCESS_SERVICE_ERROR_MESSAGE,PaymentConstants.ACS)));
    }

    /**
     * @return: String
     * @methodName: createpRqFrqPayload
     * @@Method-Description: Process setting prqfrq payload
     * @param: transData, cardSummeryResponse
     * @Exception: or @Error :Exception
     */
    public String  createpRqFrqPayload(String transData, CardSummaryResponse cardSummaryResponse){
        return new Gson().toJson(PRqFrqRequest.builder()
                .messageType(PaymentConstants.messageType_PRQFRQ).messageVersion(cardConfigDeatils.getP_messageVersion()).threeDSServerTransID(cardSummaryResponse.getThreeDSServerTransID())
                .acsTransID(cardSummaryResponse.getAcsTransID()).dsTransID(cardSummaryResponse.getDsTransID()).merchantTransID(cardSummaryResponse.getMerchantTransID())
                .acquirerID(cardConfigDeatils.getAcquirerID()).acsAuthResponse(transData.trim()).p_messageVersion(cardConfigDeatils.getP_messageVersion()).build());
    }

    /**
     * @return: String
     * @methodName: createSaleRequestPayload
     * @@Method-Description: Process setting sale payload
     * @param: cardAuthorizationEntity transactionDto pRqFrqResponse, cardOnboardDto,cardSummeryResponse
     * @Exception: or @Error :Exception
     */
    public String  createSaleRequestPayload(TransactionDto transactionDto, PRqFrqResponse pRqFrqResponse, CardOnBoardDetailsResponseDto cardOnboardDto, CardSummaryResponse cardSummaryResponse){
        List<String> getCardDetails = getCardDetails(cardSummaryResponse.getPaymentCard());

        return new Gson().toJson(SaleAuthRequest.builder()
                .pgInstanceId(cardConfigDeatils.getPgInstanceId()).merchantId(cardOnboardDto.getPgMerchantId()).acquiringBankId(cardConfigDeatils.getAcquiringBankId()).action(PaymentConstants.action)
                .transactionTypeCode(cardConfigDeatils.getTransactionTypeCode()).deviceCategory(PaymentConstants.ZERO).currencyCode(cardConfigDeatils.getINR())
                .amount(PaymentValidator.cardAmountConverter(transactionDto.getDebitAmt())).merchantReferenceNo(transactionDto.getAtrnNum())
                .orderDesc(PaymentConstants.NA).mpiTransactionId(cardSummaryResponse.getThreeDSServerTransID())
                .threeDsXid(PaymentConstants.XID_CONST)
                .threeDsStatus(pRqFrqResponse.getTransStatus() == null ? cardSummaryResponse.getTransStatus() : pRqFrqResponse.getTransStatus())
                .threeDsEci(pRqFrqResponse.getEci() == null ? cardSummaryResponse.getEci() : pRqFrqResponse.getEci())
                .threeDsCavvAav(pRqFrqResponse.getAuthenticationValue() == null ? cardSummaryResponse.getAuthenticationValue() : pRqFrqResponse.getAuthenticationValue())
                .threeDsTxnId(pRqFrqResponse.getDsTransID() == null ? cardSummaryResponse.getEci() : pRqFrqResponse.getDsTransID())
                .threeDsVersion(cardSummaryResponse.getP_messageVersion().startsWith(PaymentConstants.TWO_ONLY) ? PaymentConstants.PMSG_VERSION2 : PaymentConstants.PMSG_VERSION1)
                .cryptogram(cardSummaryResponse.getVar2())
                .pan(getCardDetails.get(0))
                .expiryDateYYYY(PaymentConstants.TWENTY.concat(cardSummaryResponse.getTokenExpiryDate().substring(cardSummaryResponse.getTokenExpiryDate().length() - 2)))
                .expiryDateMM(cardSummaryResponse.getTokenExpiryDate().substring(0,2))
                .cvv2(getCardDetails.get(3))
                .nameOnCard(getCardDetails.get(4))
                .build());
    }

    /**
     * @return: String
     * @methodName: getEncryptedPayload
     * @@Method-Description: Process setting encryption data
     * @param: requestPayload
     * @Exception: or @Error :Exception
     */

    public String  getEncryptedPayload( String requestPayload) {
        final KeyStore.PrivateKeyEntry entry = cardEncryptionDecryptionUtil.loadPriavteKeys();
        final RSAPrivateKey privateKey  = (RSAPrivateKey) entry.getPrivateKey();
        try{
        AES aes = AES.init();
        final String encSymmetricKey = EncryptionUtil.encryptDEK(aes.getKey(), cardEncryptionDecryptionUtil.loadPublicKeysServer());
        return cardEncryptionDecryptionUtil.getJsonString(EncryptedRequestData.buildRequest(EncryptionUtil.encrypt(EncryptionUtil.digitalSignWithRSA(requestPayload, privateKey), aes), encSymmetricKey, aes));
        } catch (Exception e) { // Exception throw by WIMBO PG  Jar
            logger.error("Exception While Encrypt Payload {}", e);
            throw new PaymentException(ErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(ErrorConstants.INVALID_ERROR_MESSAGE, PaymentConstants.ENCRYPTION,PaymentConstants.ENCRYPTION_ERROR));
        }
    }

    /**
     * @return: String
     * @methodName: getDecryptedResponse
     * @@Method-Description: Process setting decryption data
     * @param: responsePayload
     * @Exception: or @Error :Exception
     */

    public String  getDecryptedResponse( String responsePayload ) {
        RSAPrivateKey privateKey = (RSAPrivateKey) cardEncryptionDecryptionUtil.loadPriavteKeys().getPrivateKey();
        SaleEncResponse respRupayBean = new Gson().fromJson(responsePayload, SaleEncResponse.class);
        try {
        SecretKey decryptedSymmetricKey = DecryptionUtil.decryptDEK(respRupayBean.getResponseSymmetricEncKey(), privateKey);
        String signedResponse = DecryptionUtil.decrypt(respRupayBean.getSignedEncResponsePayload(), respRupayBean.getIv(), decryptedSymmetricKey);

        if (!DecryptionUtil.verifySignature(signedResponse, cardEncryptionDecryptionUtil.loadPublicKeysServer())) {
            throw new PaymentException(ErrorConstants.INVALID_ERROR_CODE,MessageFormat.format(ErrorConstants.INVALID_ERROR_MESSAGE,PaymentConstants.DECRYPTION,PaymentConstants.DECRYPTION_ERROR));
        }
        return Optional.ofNullable(DecryptionUtil.getJsonFromJws(signedResponse)).orElseThrow(() -> new PaymentException(CardErrorConstants.PROCESS_SERVICE_ERROR_CODE, MessageFormat.format(CardErrorConstants.PROCESS_SERVICE_ERROR_MESSAGE,PaymentConstants.DECRYPTION_CONST)));
        } catch (Exception e) { // Exception throw by WIMBO PG  Jar
            logger.error("Exception While Decrypt Payload PG response {}", e);
            throw new PaymentException(ErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(ErrorConstants.INVALID_ERROR_MESSAGE, PaymentConstants.DECRYPTION,PaymentConstants.DECRYPTION_ERROR));
        }
    }

    /**
     * @return: String
     * @methodName: getDecryptedPayload
     * @@Method-Description: Process setting decryption data
     * @param: encryptedResponse
     * @Exception: or @Error :Exception
     */

    public String  getDecryptedPayload( String encryptedResponse ) {
        PVrqEncResponse object_pArq= new Gson().fromJson(encryptedResponse, PVrqEncResponse.class);
        String signedEncResponsePayload_pArq = object_pArq.getSignedEncResponsePayload();
        String responseSymmetricEncKey_pArq = object_pArq.getResponseSymmetricEncKey();
        String iv_pArq = object_pArq.getIv();
        final RSAPrivateKey privateKey = (RSAPrivateKey) cardEncryptionDecryptionUtil.loadPriavteKeys().getPrivateKey();
        try{
        SecretKey decryptedSymmetricKey_pArq =  DecryptionUtil.decryptDEK(responseSymmetricEncKey_pArq,privateKey);
        String decryptedResponse = DecryptionUtil.decrypt(signedEncResponsePayload_pArq,iv_pArq, decryptedSymmetricKey_pArq);

        if(!DecryptionUtil.verifySignature(decryptedResponse, cardEncryptionDecryptionUtil.loadPublicKeysServer())) {
            throw new PaymentException(ErrorConstants.INVALID_ERROR_CODE,MessageFormat.format(ErrorConstants.INVALID_ERROR_MESSAGE,PaymentConstants.DECRYPTION,PaymentConstants.DECRYPTION_ERROR));
        }
        return Optional.ofNullable(DecryptionUtil.getJsonFromJws(decryptedResponse)).orElseThrow(() -> new PaymentException(CardErrorConstants.PROCESS_SERVICE_ERROR_CODE, MessageFormat.format(CardErrorConstants.PROCESS_SERVICE_ERROR_MESSAGE,PaymentConstants.DECRYPTION_CONST)));
        } catch (Exception e) { // Exception throw by WIMBO PG  Jar
            logger.error("Exception While Decrypt Payload {}", e);
            throw new PaymentException(ErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(ErrorConstants.INVALID_ERROR_MESSAGE, PaymentConstants.DECRYPTION,PaymentConstants.DECRYPTION_ERROR));
        }
    }

    /**
     * @return: List<String>
     * @methodName: getCardDetails
     * @@Method-Description: Process setting card details
     * @param: cardAuthorizationEntity
     * @Exception: or @Error :Exception
     */
    public  List<String> getCardDetails(String cardAuthorizationEntity){
        byte[] tokenDecrypted = org.apache.commons.codec.binary.Base64.decodeBase64(cardAuthorizationEntity);
        String paymentRequestCard = new String(tokenDecrypted, StandardCharsets.UTF_8);
        return Stream.of(paymentRequestCard.split(PaymentConstants.PIPE_REGEX))
                .map (String::new)
                .collect(Collectors.toList());
    }

    /**
     * @return: String
     * @methodName: createSaleRupayRequestPayload
     * @@Method-Description: Process setting sale api payload
     * @param: cardAuthorizationEntity,altIDResponse, transactionDto, cardOnboardDto,pgTransactionId
     * @Exception: or @Error :Exception
     */

    public String  createSaleRupayRequestPayload(String cardDetails ,TokenAltResponse altIDResponse,TransactionDto transactionDto,CardOnBoardDetailsResponseDto cardOnboardDto,String pgTransactionId) {
        List<String> cardData = getCardDetails(cardDetails);
        String month=cardData.get(1)==null ? PaymentConstants.TWO_ZERO : cardData.get(1);
        String year=cardData.get(2)==null ? PaymentConstants.TWO_ZERO : cardData.get(2);

        return new Gson().toJson(SaleAPIRequest.builder()
                .pgInstanceId(cardConfigDeatils.getPgInstanceId())
                .merchantId(cardOnboardDto.getPgMerchantId())
                .pgTransactionId(pgTransactionId.isEmpty() ? cardData.get(7) : pgTransactionId)
                .merchantReferenceNo(transactionDto.getAtrnNum())
                .altId(cardEncryptionDecryptionUtil.decrypt(altIDResponse, cardEncryptionDecryptionUtil.generateSecretKey(cardConfigDeatils.getTokenSecretKey())))
                .altExpiry(month.concat(year))
                .tokenAuthenticationValue(altIDResponse.getVar2())
                .build());
    }

    /**
     * @return: String
     * @methodName: createAltIdPayload
     * @@Method-Description: Process setting alt id payload
     * @param: cardAuthorizationEntity,transactionDto, rupayTransactionId, cardOnboardDto
     * @Exception: or @Error :Exception
     */

    /*public String createAltIdPayload(String cardDetails,TransactionDto transactionDto, CardOnBoardDetailsResponseDto cardOnboardDto,String pgTxnId) {
        List<String>  cardData=getCardDetails(cardDetails);
        String saleTokenRequestJson = new Gson().toJson(CardTokenRequest.builder()
                .expiryYear(cardData.get(2)).expiryMonth(cardData.get(1)).pan(cardData.get(0)).email(PaymentConstants.emailConst).securityCode(cardData.get(3)).countryCode(PaymentConstants.IN).build());
        List<String> encryptedData = encryptCardDetails(saleTokenRequestJson);

        return cardEncryptionDecryptionUtil.getJsonString(TokenAltRequest.builder()
                .encryptedData(encryptedData.get(1).replaceAll(PaymentConstants.REPLACE_REGEX, PaymentConstants.EMPTY))
                .iv(encryptedData.get(0)).clientReferenceId(transactionDto.getAtrnNum()).merchantId(cardConfigDeatils.getMerchantId_Token()).acquirerMerchantId(cardOnboardDto.getWibMomId())
                .acquirerInstanceId(cardOnboardDto.getDpaId()).cardType(PaymentConstants.R_CONST)
                .authCode(pgTxnId.isEmpty() ? cardData.get(6) : pgTxnId)
                .tokenRequestorId(cardConfigDeatils.getTokenRequesterId_R()).provider(PaymentConstants.GC).amount(PaymentValidator.cardAmountConverter(transactionDto.getDebitAmt())).currency(cardConfigDeatils.getINR())
                .userConsent(PaymentConstants.YES).merchantName(cardOnboardDto.getLegalName().substring(0, Math.min(cardOnboardDto.getLegalName().length(), 20)))
                .build());
    }*/

    /**
     * @return: String
     * @methodName: createResendOTPPayload
     * @@Method-Description: Process setting resend otp payload
     * @param: cardOnboardDto,atrn,otp,pgtransactionid
     * @Exception: or @Error :Exception
     */
    public String createResendOTPPayload(CardOnBoardDetailsResponseDto cardOnboardDto,String atrn,String pgtransactionid){
        return new Gson().toJson(ResendOTPRequest.builder()
                .pgInstanceId(cardConfigDeatils.getPgInstanceId_2())
                .merchantId(cardOnboardDto.getPgMerchantId())
                .merchantReferenceNo(atrn)
                .pgTransactionId(pgtransactionid)
                .cardHolderStatus(PaymentConstants.GC)
                .build());
    }

    /**
     * @return: String
     * @methodName: createVerifyOTPPayload
     * @@Method-Description: Process setting verify otp payload
     * @param: cardOnboardDto,atrn,otp,pgtransactionid
     * @Exception: or @Error :Exception
     */
    public String createVerifyOTPPayload(CardOnBoardDetailsResponseDto cardOnboardDto,String atrn,String otp,String pgtransactionid){
        return new Gson().toJson(VerifyOTPRequest.builder().pgInstanceId(cardConfigDeatils.getPgInstanceId_2()).merchantId(cardOnboardDto.getPgMerchantId())
                .merchantReferenceNo(atrn).pgTransactionId(pgtransactionid).otp(otp)
                .build());
    }

    /**
     * @return: List<String>
     * @methodName: encryptCardDetails
     * @@Method-Description: Process setting card encryption data
     * @param: cardData
     * @Exception: or @Error :Exception
     */

    private  List<String> encryptCardDetails(String cardData){
        List<String> listData = new ArrayList<>();
        SecureRandom secureRandom = new SecureRandom();
        byte[] nonce = new byte[16]; // 96 bits is a common choice for the nonce size
        secureRandom.nextBytes(nonce);
        String ivConverted = cardEncryptionDecryptionUtil.byteArrayToHexString(nonce);
        listData.add(ivConverted);
        SecretKey secretKey = cardEncryptionDecryptionUtil.generateSecretKey(cardConfigDeatils.getTokenSecretKey());
        byte[] IV = ivConverted.getBytes();
            String encryptPayloadTokenReq = cardEncryptionDecryptionUtil.encrypt(cardData.getBytes(), secretKey, IV);
            listData.add(encryptPayloadTokenReq);
        //return listData;
        return Optional.of(listData).orElseThrow(() -> new PaymentException(CardErrorConstants.PROCESS_SERVICE_ERROR_CODE, MessageFormat.format(CardErrorConstants.PROCESS_SERVICE_ERROR_MESSAGE,PaymentConstants.ENCRYPTION_CONST)));
    }

}
