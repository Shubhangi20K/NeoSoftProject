package com.epay.stubs.validator;

/**
 * Class Name: PaymentCardValidator
 * *
 * Description: Card Payment Service
 * *
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */

import com.epay.stubs.exceptions.PaymentException;
import com.epay.stubs.model.request.PaymentInitiationRequest;
import com.epay.stubs.model.request.PaymentRequestCard;
import com.epay.stubs.model.response.ACSResponse;
import com.epay.stubs.util.CardErrorConstants;
import com.epay.stubs.util.CardInitiationUtil;
import com.epay.stubs.util.ErrorConstants;
import com.epay.stubs.util.PaymentConstants;
import com.epay.stubs.util.enums.*;
import com.epay.stubs.validator.BaseValidator;
import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.google.gson.Gson;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.text.MessageFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

import static com.epay.stubs.util.ErrorConstants.INVALID_ERROR_CODE;
import static com.epay.stubs.util.ErrorConstants.INVALID_ERROR_MESSAGE;
import static com.epay.stubs.util.PaymentConstants.*;


@Component
@RequiredArgsConstructor
public class PaymentCardValidator extends BaseValidator {

    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private final CardInitiationUtil cardInitiationUtil;
    //All Cards Validations Started
    public void validateCardCallbackRequest(Map<String, String> allRequestParams, String paymentRequest) {

        if(allRequestParams.size()>1){
            errorDtoList.clear();
            allRequestParams.forEach( (k,v) -> validateOpModeValue(allRequestParams.toString(), Arrays.stream(VisaCallbackParams.values()).map(Enum::name).toList(),PaymentConstants.REQ_OBJECT,PaymentConstants.UNRECOGNIZED_FIELD+String.join(PaymentConstants.COMMA,k)) );
            throwIfErrors();
        }

        byte[] valueDecoded = org.apache.commons.codec.binary.Base64.decodeBase64(paymentRequest.trim());
        String isDuplicateKeys= validateDuplicateJsonObjects(new String(valueDecoded,StandardCharsets.UTF_8));
        if(!isDuplicateKeys.isEmpty()){
            throw new PaymentException(ErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(ErrorConstants.INVALID_ERROR_MESSAGE, PaymentConstants.REQ_OBJECT,PaymentConstants.DUPLICATE_FIELD+isDuplicateKeys));
        }
        String[] strArray = jsonStringToArray(new String(valueDecoded,StandardCharsets.UTF_8));
        String missingKeys =getMissingKeys(new HashSet<>(Arrays.stream(strArray).collect(Collectors.toSet())));
        if(!missingKeys.isEmpty()){
            throw new PaymentException(ErrorConstants.REQUIRED_ERROR_CODE, MessageFormat.format(ErrorConstants.REQUIRED_ERROR_MESSAGE, missingKeys));
        }
        ACSResponse acsResponse = new Gson().fromJson(new String(valueDecoded,StandardCharsets.UTF_8), ACSResponse.class);
        PaymentInitiationRequest paymentInitiationRequest=getCallbackCardsRequest(acsResponse);
        nullCheckVISAFields(paymentInitiationRequest);
        emptyCheckVISAFields(paymentInitiationRequest);
        checkLeadingTrailingSpace(paymentInitiationRequest);
        validateFieldsLength(paymentInitiationRequest);
        validateFieldsType(paymentInitiationRequest);
    }

    public String[] jsonStringToArray(String jsonString) {
    try {
        ArrayList<String> stringArray = new ArrayList<>();
        JSONArray jsonArray = new JSONArray();
        JSONObject jsonObject = new JSONObject(jsonString);
        Iterator<String> keys = jsonObject.keys();
        while(keys.hasNext()){
            jsonArray.put(keys.next());
        }

        for (int i = 0; i < jsonArray.length(); i++) {
            stringArray.add(jsonArray.getString(i));
        }
        int size = stringArray.size();
        return stringArray.toArray(new String[size]);
    } catch (JSONException e) {
        throw new RuntimeException(e);
    }
    }

    private void nullCheckVISAFields(PaymentInitiationRequest paymentInitiationRequest) {
        errorDtoList.clear();
        nullFieldCheck(paymentInitiationRequest.getThreeDSServerTransID(), PaymentConstants.THREE_DS_CONST);
        nullFieldCheck(paymentInitiationRequest.getAcsTransID(), PaymentConstants.ACS_TXN_ID_CONST);
        nullFieldCheck(paymentInitiationRequest.getMessageType(), PaymentConstants.MSG_TYPE_CONST);
        nullFieldCheck(paymentInitiationRequest.getMessageVersion(), PaymentConstants.M_VER_CONST);
        nullFieldCheck(paymentInitiationRequest.getChallengeCompletionInd(), PaymentConstants.C_CONST);
        nullFieldCheck(paymentInitiationRequest.getTransStatus(), PaymentConstants.TXN_STATUS_CONST);
        throwIfErrors();
    }
    private void emptyCheckVISAFields(PaymentInitiationRequest paymentInitiationRequest) {
        errorDtoList.clear();
        emptyFieldCheck(paymentInitiationRequest.getThreeDSServerTransID(), PaymentConstants.THREE_DS_CONST);
        emptyFieldCheck(paymentInitiationRequest.getAcsTransID(), PaymentConstants.ACS_TXN_ID_CONST);
        emptyFieldCheck(paymentInitiationRequest.getMessageType(), PaymentConstants.MSG_TYPE_CONST);
        emptyFieldCheck(paymentInitiationRequest.getMessageVersion(), PaymentConstants.M_VER_CONST);
        emptyFieldCheck(paymentInitiationRequest.getChallengeCompletionInd(), PaymentConstants.C_CONST);
        emptyFieldCheck(paymentInitiationRequest.getTransStatus(), PaymentConstants.TXN_STATUS_CONST);
        throwIfErrors();
    }

    public void validateRupayCardCallbackRequest(Map<String, String> allRequestParams) {
        PaymentInitiationRequest paymentInitiationRequest=getCallbackRupayCardsRequest(allRequestParams);
        nullCheckCardFields(paymentInitiationRequest);
        emptyCheckCardFields(paymentInitiationRequest);
        checkRupayLeadingTrailingSpace(paymentInitiationRequest);
        validateRupayFieldsLength(paymentInitiationRequest);
        validateRupayFieldsType(paymentInitiationRequest);
    }
    private void nullCheckCardFields(PaymentInitiationRequest paymentInitiationRequest) {
        errorDtoList.clear();
        nullFieldCheck(paymentInitiationRequest.getAmount(), PaymentConstants.AMOUNT_CONST);
        nullFieldCheck(paymentInitiationRequest.getCurrency_code(), PaymentConstants.CURRENCY_CONST);
        nullFieldCheck(paymentInitiationRequest.getMerchant_reference_no(), PaymentConstants.MERCH_REF_NO_CONST);
        nullFieldCheck(paymentInitiationRequest.getStatus(), PaymentConstants.STATUS);
        nullFieldCheck(paymentInitiationRequest.getErrorcode(), PaymentConstants.ERROR_CODE);
        nullFieldCheck(paymentInitiationRequest.getErrormsg(), PaymentConstants.ERROR_MSG);
        nullFieldCheck(paymentInitiationRequest.getPg_error_code(), PaymentConstants.PG_ERROR_CODE);
        nullFieldCheck(paymentInitiationRequest.getPg_error_detail(), PaymentConstants.PG_ERROR_DETAILS);
        throwIfErrors();
    }
    private void emptyCheckCardFields(PaymentInitiationRequest paymentInitiationRequest) {
        errorDtoList.clear();
        emptyFieldCheck(paymentInitiationRequest.getAmount(), PaymentConstants.AMOUNT_CONST);
        emptyFieldCheck(paymentInitiationRequest.getCurrency_code(), PaymentConstants.CURRENCY_CONST);
        emptyFieldCheck(paymentInitiationRequest.getMerchant_reference_no(), PaymentConstants.MERCH_REF_NO_CONST);
        emptyFieldCheck(paymentInitiationRequest.getStatus(), PaymentConstants.STATUS);
        emptyFieldCheck(paymentInitiationRequest.getErrorcode(), PaymentConstants.ERROR_CODE);
        emptyFieldCheck(paymentInitiationRequest.getErrormsg(), PaymentConstants.ERROR_MSG);
        emptyFieldCheck(paymentInitiationRequest.getPg_error_code(), PaymentConstants.PG_ERROR_CODE);
        emptyFieldCheck(paymentInitiationRequest.getPg_error_detail(), PaymentConstants.PG_ERROR_DETAILS);
        throwIfErrors();
    }

    //Card Callback Call

    private void checkRupayLeadingTrailingSpace(PaymentInitiationRequest paymentInitiationRequest) {
        errorDtoList.clear();
        checkForLeadingTrailingAndSingleSpace(paymentInitiationRequest.getAmount(), PaymentConstants.AMOUNT_CONST);
        checkForLeadingTrailingAndSingleSpace(paymentInitiationRequest.getCurrency_code(), PaymentConstants.CURRENCY_CONST);
        checkForLeadingTrailingAndSingleSpace(paymentInitiationRequest.getMerchant_reference_no(), PaymentConstants.MERCH_REF_NO_CONST);
        checkForLeadingTrailingAndSingleSpace(paymentInitiationRequest.getStatus(), PaymentConstants.STATUS);
        checkForLeadingTrailingAndSingleSpace(paymentInitiationRequest.getErrorcode(), PaymentConstants.ERROR_CODE);
        checkForLeadingTrailingAndSingleSpace(paymentInitiationRequest.getErrormsg(), PaymentConstants.ERROR_MSG);
        checkForLeadingTrailingAndSingleSpace(paymentInitiationRequest.getPg_error_code(), PaymentConstants.PG_ERROR_CODE);
        checkForLeadingTrailingAndSingleSpace(paymentInitiationRequest.getPg_error_detail(), PaymentConstants.PG_ERROR_DETAILS);
    }

    private void validateRupayFieldsLength(PaymentInitiationRequest paymentInitiationRequest) {
        errorDtoList.clear();
        validateMaxFieldLength(paymentInitiationRequest.getAmount(), PaymentConstants.AMOUNT_CONST, AMOUNT_MAX_LENGTH);
        validateMaxFieldLength(paymentInitiationRequest.getCurrency_code(), PaymentConstants.CURRENCY_CONST,PAY_PROC_TYPE_LENGTH);
        validateFixedLength(paymentInitiationRequest.getMerchant_reference_no(), PaymentConstants.MERCH_REF_NO_CONST,ATRN_LENGTH);
        validateMaxFieldLength(paymentInitiationRequest.getStatus(), PaymentConstants.STATUS,PAY_PROC_ID_LENGTH);
        validateMaxFieldLength(paymentInitiationRequest.getErrorcode(), PaymentConstants.ERROR_CODE,PAY_PROC_TYPE_LENGTH);
        validateMaxFieldLength(paymentInitiationRequest.getErrormsg(), PaymentConstants.ERROR_MSG, PaymentConstants.CHANNEL_BANK_LENGTH);
        validateMaxFieldLength(paymentInitiationRequest.getPg_error_code(), PaymentConstants.PG_ERROR_CODE,PaymentConstants.PAY_PROC_ID_LENGTH);
        validateMaxFieldLength(paymentInitiationRequest.getPg_error_detail(), PaymentConstants.PG_ERROR_DETAILS,PaymentConstants.CHANNEL_BANK_LENGTH);
    }

    private void validateRupayFieldsType(PaymentInitiationRequest paymentInitiationRequest) {
        errorDtoList.clear();
        validateAmount(new BigDecimal(paymentInitiationRequest.getAmount()), PaymentConstants.AMOUNT_CONST);
        validateFieldWithRegex(String.valueOf(paymentInitiationRequest.getAmount()), PaymentConstants.AMOUNT_REGEX, PaymentConstants.AMOUNT_CONST,MessageFormat.format(PaymentConstants.INVALID_FORMAT_MESSAGE, PaymentConstants.AMOUNT_CONST));
        validateFieldWithRegex(paymentInitiationRequest.getCurrency_code(), NUMBER_ONLY, PaymentConstants.CURRENCY_CONST,MessageFormat.format(PaymentConstants.INVALID_FORMAT_MESSAGE, PaymentConstants.CURRENCY_CONST));
        validateFieldWithRegex(paymentInitiationRequest.getMerchant_reference_no(), PaymentConstants.ATRN_ARRN_REGEX_DIGIT, PaymentConstants.MERCH_REF_NO_CONST,MessageFormat.format(PaymentConstants.INVALID_FORMAT_MESSAGE, PaymentConstants.MERCH_REF_NO_CONST));
        validateFieldWithRegex(paymentInitiationRequest.getStatus(), PaymentConstants.CHAR_NUMBERS_REGEX, PaymentConstants.STATUS,MessageFormat.format(PaymentConstants.INVALID_FORMAT_MESSAGE, PaymentConstants.STATUS));
        validateFieldWithRegex(paymentInitiationRequest.getErrorcode(), PaymentConstants.CHAR_NUMBERS_REGEX, PaymentConstants.ERROR_CODE,MessageFormat.format(PaymentConstants.INVALID_FORMAT_MESSAGE, PaymentConstants.ERROR_CODE));
        validateFieldWithRegex(paymentInitiationRequest.getErrormsg(), PaymentConstants.CHAR_NUMBERS_REGEX, PaymentConstants.ERROR_MSG,MessageFormat.format(PaymentConstants.INVALID_FORMAT_MESSAGE, PaymentConstants.ERROR_MSG));
        validateFieldWithRegex(paymentInitiationRequest.getPg_error_code(), PaymentConstants.CHAR_NUMBERS_REGEX, PaymentConstants.PG_ERROR_CODE,MessageFormat.format(PaymentConstants.INVALID_FORMAT_MESSAGE, PaymentConstants.PG_ERROR_CODE));
        validateFieldWithRegex(paymentInitiationRequest.getPg_error_detail(), PaymentConstants.CHAR_NUMBERS_REGEX, PaymentConstants.PG_ERROR_DETAILS,MessageFormat.format(PaymentConstants.INVALID_FORMAT_MESSAGE, PaymentConstants.PG_ERROR_DETAILS));
    }

    private void checkLeadingTrailingSpace(PaymentInitiationRequest paymentInitiationRequest) {
        errorDtoList.clear();
        checkForLeadingTrailingAndSingleSpace(paymentInitiationRequest.getThreeDSServerTransID(), PaymentConstants.THREE_DS_CONST);
        checkForLeadingTrailingAndSingleSpace(paymentInitiationRequest.getAcsTransID(), PaymentConstants.ACS_TXN_ID_CONST);
        checkForLeadingTrailingAndSingleSpace(paymentInitiationRequest.getMessageType(), PaymentConstants.MSG_TYPE_CONST);
        checkForLeadingTrailingAndSingleSpace(paymentInitiationRequest.getMessageVersion(), PaymentConstants.M_VER_CONST);
        checkForLeadingTrailingAndSingleSpace(paymentInitiationRequest.getChallengeCompletionInd(), PaymentConstants.C_CONST);
        checkForLeadingTrailingAndSingleSpace(paymentInitiationRequest.getTransStatus(), PaymentConstants.TXN_STATUS_CONST);
    }

    private void validateFieldsLength(PaymentInitiationRequest paymentInitiationRequest) {
        errorDtoList.clear();
        validateMaxFieldLength(paymentInitiationRequest.getThreeDSServerTransID(), PaymentConstants.THREE_DS_CONST, CARDHOLDER_LENGTH);
        validateMaxFieldLength(paymentInitiationRequest.getAcsTransID(), PaymentConstants.ACS_TXN_ID_CONST,CARDHOLDER_LENGTH);
        validateMaxFieldLength(paymentInitiationRequest.getMessageType(), PaymentConstants.MSG_TYPE_CONST,PAY_PROC_ID_LENGTH);
        validateMaxFieldLength(paymentInitiationRequest.getMessageVersion(), PaymentConstants.M_VER_CONST,OPMODE_LENGTH);
        validateFixedLength(paymentInitiationRequest.getChallengeCompletionInd(), PaymentConstants.C_CONST, PaymentConstants.UPI_STATUS_Q_LENGTH);
        validateFixedLength(paymentInitiationRequest.getTransStatus(), PaymentConstants.TXN_STATUS_CONST,PaymentConstants.UPI_STATUS_Q_LENGTH);
    }

    private void validateFieldsType(PaymentInitiationRequest paymentInitiationRequest) {
        errorDtoList.clear();
        validateOpModeValue(paymentInitiationRequest.getTransStatus(), Arrays.stream(YesNoType.values()).map(Enum::name).toList(),PaymentConstants.TXN_STATUS_CONST,MessageFormat.format(PaymentConstants.INVALID_FORMAT_MESSAGE, PaymentConstants.TXN_STATUS_CONST));
        validateOpModeValue(paymentInitiationRequest.getChallengeCompletionInd(), Arrays.stream(YesNoType.values()).map(Enum::name).toList(),PaymentConstants.C_CONST,MessageFormat.format(PaymentConstants.INVALID_FORMAT_MESSAGE, PaymentConstants.C_CONST));
        validateFieldWithRegex(paymentInitiationRequest.getThreeDSServerTransID(), UUID_REGEX, PaymentConstants.THREE_DS_CONST,MessageFormat.format(PaymentConstants.INVALID_FORMAT_MESSAGE, PaymentConstants.THREE_DS_CONST));
        validateFieldWithRegex(paymentInitiationRequest.getAcsTransID(), PaymentConstants.UUID_REGEX, PaymentConstants.ACS_TXN_ID_CONST,MessageFormat.format(PaymentConstants.INVALID_FORMAT_MESSAGE, PaymentConstants.ACS_TXN_ID_CONST));
        validateFieldWithRegex(paymentInitiationRequest.getMessageType(), PaymentConstants.ALLOWED_ALPHABET_REGEX, PaymentConstants.MSG_TYPE_CONST,MessageFormat.format(PaymentConstants.INVALID_FORMAT_MESSAGE, PaymentConstants.MSG_TYPE_CONST));
        validateFieldWithRegex(paymentInitiationRequest.getMessageVersion(), PaymentConstants.MVER_REGEX, PaymentConstants.M_VER_CONST,MessageFormat.format(PaymentConstants.INVALID_FORMAT_MESSAGE, PaymentConstants.M_VER_CONST));
        validateFieldWithRegex(paymentInitiationRequest.getChallengeCompletionInd(), PaymentConstants.ALLOWED_ALPHABET_REGEX, PaymentConstants.C_CONST,MessageFormat.format(PaymentConstants.INVALID_FORMAT_MESSAGE, PaymentConstants.C_CONST));
        validateFieldWithRegex(paymentInitiationRequest.getTransStatus(), PaymentConstants.ALLOWED_ALPHABET_REGEX, PaymentConstants.TXN_STATUS_CONST,MessageFormat.format(PaymentConstants.INVALID_FORMAT_MESSAGE, PaymentConstants.TXN_STATUS_CONST));
    }

    public String validateDuplicateJsonObjects(String jsonString) {
        try {
            JsonFactory factory = new JsonFactory();
            JsonParser parser = factory.createParser(jsonString);
            Set<String> seenKeys = new HashSet<>();
            Set<String> duplicateKeys = new HashSet<>();

            String currentKeys;
            while (!parser.isClosed()) {
                JsonToken token = parser.nextToken();

                if (JsonToken.FIELD_NAME.equals(token)) {
                    currentKeys = parser.currentName();
                    if (!seenKeys.add(currentKeys)) {
                        duplicateKeys.add(currentKeys);
                    }
                }
            }
            return  String.join(PaymentConstants.COMMA, duplicateKeys);
        }catch (Exception e){
            throw new PaymentException(CardErrorConstants.PROCESS_SERVICE_ERROR_CODE, MessageFormat.format(CardErrorConstants.PROCESS_SERVICE_ERROR_MESSAGE, ACS));
        }
    }
    static String getMissingKeys(Set<String> requestSet){
        String[] stringArray = {"threeDSServerTransID", "acsTransID", "messageType","messageVersion","challengeCompletionInd","transStatus"};
        Set<String> missingKeys= Arrays.stream(stringArray).collect(Collectors.toSet());
        missingKeys.removeAll(requestSet);
        return String.join(PaymentConstants.COMMA, missingKeys);
    }
    public static Set<String> matchSetKeys(Set<String> set1,Set<String> set2) {
        return set1.stream()
                .filter(set2::contains)
                .collect(Collectors.toSet());
    }


    //Rupay OTP Verify And Resend
    public void validateVerifyRequest(PaymentInitiationRequest paymentInitiationRequest) {
        checkLeadingTrailingSpaceVerify(paymentInitiationRequest);
        validateCardFieldsLengthVerify(paymentInitiationRequest);
        validateCardFieldsTypeVerify(paymentInitiationRequest);
    }

    private void checkLeadingTrailingSpaceVerify(PaymentInitiationRequest paymentInitiationRequest) {
        errorDtoList.clear();
        checkForLeadingTrailingAndSingleSpace(paymentInitiationRequest.getAtrn(), ATRN_CONST_SMALL);
        checkForLeadingTrailingAndSingleSpace(paymentInitiationRequest.getApiType(), PaymentConstants.apiType);
        checkForLeadingTrailingAndSingleSpace(paymentInitiationRequest.getPgtransactionid(), PaymentConstants.pgtransactionid);
        checkForLeadingTrailingAndSingleSpace(paymentInitiationRequest.getOtp(), PaymentConstants.otp);
    }

    private void validateCardFieldsLengthVerify(PaymentInitiationRequest paymentInitiationRequest) {
        errorDtoList.clear();
        validateFixedLength(paymentInitiationRequest.getAtrn(), PaymentConstants.ATRN_CONST_SMALL,ATRN_LENGTH);
        validateMaxFieldLength(paymentInitiationRequest.getApiType(), PaymentConstants.apiType,PAYMODE_LENGTH);
        validateMaxFieldLength(paymentInitiationRequest.getPgtransactionid(), PaymentConstants.pgtransactionid,CARDHOLDER_LENGTH);
        validateMaxFieldLength(paymentInitiationRequest.getOtp(), PaymentConstants.otp, PaymentConstants.OTP_LENGTH);
    }

    private void validateCardFieldsTypeVerify(PaymentInitiationRequest paymentInitiationRequest) {
        errorDtoList.clear();
        validateFieldWithRegex(paymentInitiationRequest.getAtrn(), PaymentConstants.ATRN_ARRN_REGEX_DIGIT, PaymentConstants.ATRN_CONST_SMALL,MessageFormat.format(PaymentConstants.INVALID_FORMAT_MESSAGE, PaymentConstants.ATRN_CONST_SMALL));
        validateFieldWithRegex(paymentInitiationRequest.getPgtransactionid(), PaymentConstants.ALPHANUMERIC_REGEX, PaymentConstants.pgtransactionid,MessageFormat.format(PaymentConstants.INVALID_FORMAT_MESSAGE, PaymentConstants.pgtransactionid));
        validateFieldWithRegex(paymentInitiationRequest.getOtp(), PaymentConstants.NUMBER_ONLY, PaymentConstants.otp,MessageFormat.format(PaymentConstants.INVALID_FORMAT_MESSAGE, PaymentConstants.otp));
        validateOpModeValue(paymentInitiationRequest.getApiType(), Arrays.stream(RupayVerifyParams.values()).map(Enum::name).toList(),PaymentConstants.apiType,MessageFormat.format(PaymentConstants.INVALID_FORMAT_MESSAGE, PaymentConstants.apiType));
    }

    public void validateResendRequest(PaymentInitiationRequest paymentInitiationRequest) {
        checkLeadingTrailingSpaceForCardResend(paymentInitiationRequest);
        validateCardFieldsLengthResend(paymentInitiationRequest);
        validateCardFieldsTypeResend(paymentInitiationRequest);
    }

    private void checkLeadingTrailingSpaceForCardResend(PaymentInitiationRequest paymentInitiationRequest) {
        errorDtoList.clear();
        checkForLeadingTrailingAndSingleSpace(paymentInitiationRequest.getAtrn(), ATRN_CONST_SMALL);
        checkForLeadingTrailingAndSingleSpace(paymentInitiationRequest.getApiType(), PaymentConstants.apiType);
        checkForLeadingTrailingAndSingleSpace(paymentInitiationRequest.getPgtransactionid(), PaymentConstants.pgtransactionid);
    }

    private void validateCardFieldsLengthResend(PaymentInitiationRequest paymentInitiationRequest) {
        errorDtoList.clear();
        validateFixedLength(paymentInitiationRequest.getAtrn(), PaymentConstants.ATRN_CONST_SMALL,ATRN_LENGTH);
        validateMaxFieldLength(paymentInitiationRequest.getApiType(), PaymentConstants.apiType,PAYMODE_LENGTH);
        validateMaxFieldLength(paymentInitiationRequest.getPgtransactionid(), PaymentConstants.pgtransactionid,CARDHOLDER_LENGTH);
    }

    private void validateCardFieldsTypeResend(PaymentInitiationRequest paymentInitiationRequest) {
        errorDtoList.clear();
        validateFieldWithRegex(paymentInitiationRequest.getAtrn(), PaymentConstants.ATRN_ARRN_REGEX_DIGIT, PaymentConstants.ATRN_CONST_SMALL,MessageFormat.format(PaymentConstants.INVALID_FORMAT_MESSAGE, PaymentConstants.ATRN_CONST_SMALL));
        validateFieldWithRegex(paymentInitiationRequest.getPgtransactionid(), PaymentConstants.ALPHANUMERIC_REGEX, PaymentConstants.pgtransactionid,MessageFormat.format(PaymentConstants.INVALID_FORMAT_MESSAGE, PaymentConstants.pgtransactionid));
        validateOpModeValue(paymentInitiationRequest.getApiType(), Arrays.stream(RupayResendParams.values()).map(Enum::name).toList(),PaymentConstants.apiType,MessageFormat.format(PaymentConstants.INVALID_FORMAT_MESSAGE, PaymentConstants.apiType));
    }

    //Card Initiate Call
    public void validateCardRequest(PaymentInitiationRequest paymentInitiationRequest) {
        checkLeadingTrailingSpaceForCard(paymentInitiationRequest);
        validateCardFieldsLength(paymentInitiationRequest);
        validateCardFieldsType(paymentInitiationRequest);

        /*if(isCardExpired(paymentInitiationRequest.getExpiryMonth().concat(FORWARDSLASH).concat(paymentInitiationRequest.getExpiryYear()))){
            throw new PaymentException(ErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(ErrorConstants.INVALID_ERROR_MESSAGE, PaymentConstants.REQ_OBJECT,CARD_DETAILS_EXPIRED));
        }*/
    }
    public static boolean isCardExpired(String expiryDate) {
        SimpleDateFormat sdf = new SimpleDateFormat("MM/yy");
        sdf.setLenient(false);
        try {
            Date expiry = sdf.parse(expiryDate);
            return expiry.before(new Date());
        } catch (ParseException e) {
            return true; // Invalid format, consider it expired
        }
    }

    private void checkLeadingTrailingSpaceForCard(PaymentInitiationRequest paymentInitiationRequest) {
        errorDtoList.clear();
        checkForLeadingTrailingAndSingleSpace(paymentInitiationRequest.getPaymode(), PaymentConstants.PAYMODE_CONST);
        checkForLeadingTrailingAndSingleSpace(paymentInitiationRequest.getAtrn(), PaymentConstants.ATRN_CONST_SMALL);
        checkForLeadingTrailingAndSingleSpace(paymentInitiationRequest.getOperatingMode(), PaymentConstants.OPMODE_CONST);
        checkForLeadingTrailingAndSingleSpace(paymentInitiationRequest.getPayProcId(), PaymentConstants.PAYPROCID_CONST);
        checkForLeadingTrailingAndSingleSpace(paymentInitiationRequest.getPayProcType(), PaymentConstants.PAYPROCTYPE_CONST);
        checkForLeadingTrailingAndSingleSpace(paymentInitiationRequest.getAltNumber(), PaymentConstants.ALTNUMBER);
        checkForLeadingTrailingAndSingleSpace(paymentInitiationRequest.getExpiryMonth(), PaymentConstants.EXP_MONTH);
        checkForLeadingTrailingAndSingleSpace(paymentInitiationRequest.getExpiryYear(), PaymentConstants.EXP_YEAR);
        checkForLeadingTrailingAndSingleSpace(paymentInitiationRequest.getCvv(), PaymentConstants.CVV_CONST);
        checkForLeadingTrailingAndSingleSpace(paymentInitiationRequest.getCardHolderName(), PaymentConstants.CARDHOLDER_CONST);
    }

    private void validateCardFieldsLength(PaymentInitiationRequest paymentInitiationRequest) {
        errorDtoList.clear();
        validateMaxFieldLength(paymentInitiationRequest.getPaymode(),PaymentConstants.PAYMODE_CONST, PAYMODE_LENGTH);
        validateFixedLength(paymentInitiationRequest.getAtrn(), PaymentConstants.ATRN_CONST_SMALL,ATRN_LENGTH);
        validateMaxFieldLength(paymentInitiationRequest.getOperatingMode(), PaymentConstants.OPMODE_CONST,OPMODE_LENGTH);
        validateMaxFieldLength(paymentInitiationRequest.getPayProcId(), PaymentConstants.PAYPROCID_CONST,PAY_PROC_ID_LENGTH);
        validateMaxFieldLength(paymentInitiationRequest.getPayProcType(), PaymentConstants.PAYPROCTYPE_CONST, PaymentConstants.PAY_PROC_TYPE_LENGTH);
        validateFixedLength(paymentInitiationRequest.getAltNumber(), PaymentConstants.ALTNUMBER,PaymentConstants.CARD_NUMBER_LENGTH);
        validateFixedLength(paymentInitiationRequest.getCvv(), PaymentConstants.CVV,PaymentConstants.CVV_FIRST_LENGTH);
        validateFixedLength(paymentInitiationRequest.getExpiryMonth(), EXP_MONTH,PaymentConstants.EXPIRY_MONTH_LENGTH);
        validateFixedLength(paymentInitiationRequest.getExpiryYear(), EXP_YEAR,PaymentConstants.EXPIRY_YEAR_LENGTH);
        validateMaxFieldLength(paymentInitiationRequest.getCardHolderName(),PaymentConstants.ACHOLDER,PaymentConstants.CARDHOLDER_LENGTH);
    }

    private void validateCardFieldsType(PaymentInitiationRequest paymentInitiationRequest) {
        errorDtoList.clear();
        validateOpModeValue(paymentInitiationRequest.getPaymode(), Arrays.stream(PayModeCard.values()).map(Enum::name).toList(),PaymentConstants.PAYMODE_CONST,MessageFormat.format(PaymentConstants.INVALID_FORMAT_MESSAGE, PaymentConstants.PAYMODE_CONST));
        validateOpModeValue(paymentInitiationRequest.getOperatingMode(), Arrays.stream(OperatingMode.values()).map(Enum::name).toList(),PaymentConstants.OPMODE_CONST,MessageFormat.format(PaymentConstants.INVALID_FORMAT_MESSAGE, PaymentConstants.OPMODE_CONST));
        validateOpModeValue(paymentInitiationRequest.getPayProcType(), Arrays.stream(PayProcType.values()).map(Enum::name).toList(), PaymentConstants.PAYPROCTYPE_CONST,MessageFormat.format(PaymentConstants.INVALID_FORMAT_MESSAGE, PaymentConstants.PAYPROCTYPE_CONST));
        validateFieldWithRegex(paymentInitiationRequest.getAtrn(), PaymentConstants.ATRN_ARRN_REGEX_DIGIT, PaymentConstants.ATRN_CONST_SMALL,MessageFormat.format(PaymentConstants.INVALID_FORMAT_MESSAGE, PaymentConstants.ATRN_CONST_SMALL));
        validateFieldWithRegex(paymentInitiationRequest.getAltNumber(), PaymentConstants.ALT_NUMBER, PaymentConstants.ALTNUMBER,MessageFormat.format(PaymentConstants.INVALID_FORMAT_MESSAGE, PaymentConstants.ALTNUMBER));
        validateFieldWithRegex(paymentInitiationRequest.getExpiryMonth(), PaymentConstants.MONTH_REGEX, PaymentConstants.EXP_MONTH,MessageFormat.format(PaymentConstants.INVALID_FORMAT_MESSAGE, PaymentConstants.EXP_MONTH));
        validateFieldWithRegex(paymentInitiationRequest.getExpiryYear(), PaymentConstants.YEAR_REGEX, PaymentConstants.EXP_YEAR,MessageFormat.format(PaymentConstants.INVALID_FORMAT_MESSAGE, PaymentConstants.EXP_YEAR));
        validateFieldWithRegex(paymentInitiationRequest.getCvv(), PaymentConstants.CVV_NUMBER, PaymentConstants.CVV_CONST,MessageFormat.format(PaymentConstants.INVALID_FORMAT_MESSAGE, PaymentConstants.CVV_CONST));
        validateFieldWithRegex(paymentInitiationRequest.getCardHolderName(), PaymentConstants.ALLOWED_ALPHABET_REGEX, CARDHOLDER_CONST,MessageFormat.format(PaymentConstants.INVALID_FORMAT_MESSAGE, PaymentConstants.CARDHOLDER_CONST));
    }
    public void amountCheck(PaymentRequestCard paymentRequestCard){
        errorDtoList.clear();
      /*  validateMaxFieldLength(paymentRequestCard.getMerchPostedAmount().trim(), PaymentConstants.MERCHPOSTAMOUNT_CONST,PaymentConstants.AMOUNT_MAX_LENGTH);
        validateMaxFieldLength(paymentRequestCard.getTransactionAmount().trim(), PaymentConstants.TXNAMOUNT_CONST,PaymentConstants.AMOUNT_MAX_LENGTH);
        validateAmountRegex(paymentRequestCard.getMerchPostedAmount().trim(), PaymentConstants.AMOUNT_REGEX, PaymentConstants.MERCHPOSTAMOUNT_CONST,MessageFormat.format(PaymentConstants.INVALID_FORMAT_MESSAGE, PaymentConstants.MERCHPOSTAMOUNT_CONST));
        validateAmountRegex(paymentRequestCard.getTransactionAmount().trim(), PaymentConstants.AMOUNT_REGEX, PaymentConstants.TXNAMOUNT_CONST,MessageFormat.format(PaymentConstants.INVALID_FORMAT_MESSAGE, PaymentConstants.TXNAMOUNT_CONST));
        validateAmount(new BigDecimal(paymentRequestCard.getTransactionAmount().trim()), PaymentConstants.TXNAMOUNT_CONST);
        validateAmount(new BigDecimal(paymentRequestCard.getMerchPostedAmount().trim()), PaymentConstants.MERCHPOSTAMOUNT_CONST);*/
    }

    //Function Group
    public void validateOpModeValue(String value, List<String> validValues, String fieldName, String message) {
        boolean isValid = validValues.stream().anyMatch(validValue -> validValue.equals(value));
        if (!isValid) {
            errorDtoList.clear();
            addError(INVALID_ERROR_CODE, INVALID_ERROR_MESSAGE, fieldName, message);
            throwIfErrors();
        }
    }

    private void validateFixedLength(String value, String field,int fieldLength) {
        if (value.length() != fieldLength) {
            errorDtoList.clear();
            addError(field, ErrorConstants.FIXED_FIELD_LENGTH_ERROR_CODE, MessageFormat.format(ErrorConstants.FIXED_FIELD_LENGTH_ERROR_MESSAGE, field, fieldLength));
            throwIfErrors();
        }
    }

    private void validateMaxFieldLength(String value, String field,int fieldLength) {
        if (value.length() > fieldLength) {
            errorDtoList.clear();
            addError(field, ErrorConstants.MAX_LENGTH_ERROR_CODE, MessageFormat.format(ErrorConstants.MAX_LENGTH_ERROR_MESSAGE, field, fieldLength));
            throwIfErrors();
        }
    }

    public void validateAmountRegex(String value, String regex, String fieldName, String reason) {
        if (StringUtils.isNotEmpty(value) && validate(value, regex)) {
            errorDtoList.clear();
            addError(fieldName, INVALID_ERROR_CODE, MessageFormat.format(INVALID_ERROR_MESSAGE, fieldName, reason));
            throwIfErrors();
        }
    }

    public PaymentInitiationRequest getCallbackCardsRequest(ACSResponse acsResponse){
        return Optional.of(PaymentInitiationRequest.builder()
                .threeDSServerTransID(acsResponse.getThreeDSServerTransID())
                .acsTransID(acsResponse.getAcsTransID())
                .messageType(acsResponse.getMessageType())
                .messageVersion(acsResponse.getMessageVersion())
                .challengeCompletionInd(acsResponse.getChallengeCompletionInd())
                .transStatus(acsResponse.getTransStatus())
                .build()).orElseThrow(() -> new PaymentException(CardErrorConstants.PROCESS_SERVICE_ERROR_CODE, MessageFormat.format(CardErrorConstants.PROCESS_SERVICE_ERROR_MESSAGE,PaymentConstants.ACS)));
    }

    public PaymentInitiationRequest getCallbackRupayCardsRequest(Map<String, String> allRequestParams){
        return Optional.of(PaymentInitiationRequest.builder()
                .amount(allRequestParams.get(PaymentConstants.AMOUNT))
                        .currency_code(allRequestParams.get(PaymentConstants.CURRENCY_CONST))
                        .merchant_reference_no(allRequestParams.get(PaymentConstants.MERCH_REF_NO_CONST))
                        .status(allRequestParams.get(PaymentConstants.STATUS))
                        .errorcode(allRequestParams.get(PaymentConstants.ERROR_CODE))
                        .errormsg(allRequestParams.get(PaymentConstants.ERROR_MSG))
                        .pg_error_code(allRequestParams.get(PaymentConstants.PG_ERROR_CODE))
                        .pg_error_detail(allRequestParams.get(PaymentConstants.PG_ERROR_DETAILS))
                .build()).orElseThrow(() -> new PaymentException(CardErrorConstants.PROCESS_SERVICE_ERROR_CODE, MessageFormat.format(CardErrorConstants.PROCESS_SERVICE_ERROR_MESSAGE,PaymentConstants.ACS)));
    }

    private void nullFieldCheck(String value,String fieldName) {
        if (Objects.isNull(value)) {
            addError(fieldName, ErrorConstants.REQUIRED_ERROR_CODE, MessageFormat.format(ErrorConstants.REQUIRED_ERROR_MESSAGE, fieldName));

        }
    }
    private void emptyFieldCheck(String value, String fieldName) {
        if (value.trim().isEmpty()) {
            addError(fieldName, ErrorConstants.REQUIRED_ERROR_CODE, MessageFormat.format(ErrorConstants.REQUIRED_ERROR_MESSAGE, fieldName));

        }
    }
}
