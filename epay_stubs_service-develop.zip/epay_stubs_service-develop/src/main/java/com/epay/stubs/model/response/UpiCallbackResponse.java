package com.epay.stubs.model.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class UpiCallbackResponse {
    @JsonProperty("pspRefNo")
    private String pspRefNo;
    @JsonProperty("upiTransRefNo")
    private Long upiTransRefNo;
    @JsonProperty("npciTransId")
    private String npciTransId;
    @JsonProperty("custRefNo")
    private String custRefNo;
    @JsonProperty("amount")
    private BigDecimal amount;
    @JsonProperty("txnAuthDate")
    private String txnAuthDate;
    @JsonProperty("status")
    private String status;
    @JsonProperty("statusDesc")
    private String statusDesc;
  //  private UpiAddInfoStatusQuery addInfo;
  @JsonProperty("payerVPA")
    private String payerVPA;
    @JsonProperty("payeeVPA")
    private String payeeVPA;
    @JsonProperty("txn_type")
    private String txn_type;
    @JsonProperty("ref_url")
    private String ref_url;
    @JsonProperty("errCode")
    private String errCode;
    @JsonProperty("txn_note")
    private String txn_note;
    @JsonProperty("pspSpamRefNo")
    private Integer pspSpamRefNo;

}