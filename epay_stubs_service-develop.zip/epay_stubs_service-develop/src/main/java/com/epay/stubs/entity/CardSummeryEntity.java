package com.epay.stubs.entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.Date;
import java.util.UUID;

@Data
@Entity
@Table(name = "CARD_PAYMENT_SUMMARY")
public class CardSummeryEntity {

   @Id
   @GeneratedValue(strategy = GenerationType.UUID)
   @Column(name = "id", nullable = false, updatable = false, unique = true)
   private UUID id;

   @Column(name = "ATRN_NUM")
   private String atrnNum;

   @Column(name = "ALT_ID")
   private String altId;

   @Column(name = "MERCHANT_ID")
   private String merchantId;

   @Column(name = "DEBIT_AMOUNT")
   private String debitAmount;

   @Lob
   @Column(name = "CARD_SUMMERY")
   private byte[] card_summery;

   @Column(name = "THREEDS_SERVER_TRANSID")
   private String threeDsServerTransId;

   @Column(name = "CREATED_DATE")
   private Long creationDate;

   @Column(name = "CARD_HASH")
   private String card_hash;
}
