package com.epay.stubs.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.math.BigDecimal;

/**
 * Class Name:UpiFinalResponse
 * *
 * Description: Upi Final Response
 * *
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */

@Entity
@Table(name="UPI_FINAL_RESPONSE")
public class UpiFinalResponse {

    @Id
    @Column(name = "ATRN_NUM", nullable = false, length = 20)
    private String atrnNum;

    @Column(name = "UPI_TRANS_ID", length = 30)
    private String upiTransId;

    @Column(name = "NPCI_TRANS_ID", length = 40)
    private String npciTransId;

    @Column(name = "CUST_REF_NO", length = 30)
    private String custRefNo;

    @Column(name = "AMOUNT", precision = 20, scale = 2)
    private BigDecimal amount;

    @Column(name = "STATUS", length = 1)
    private String status;

    @Column(name = "STATUS_DESCRIPTION", length = 500)
    private String statusDescription;

    @Column(name = "RESPONSE_CODE", length = 10)
    private String responseCode;

    @Column(name = "PACKET", length = 2000)
    private String packet;

    @Column(name = "PAYER_VA", length = 255)
    private String payerVa;

    @Column(name = "PAYEE_VA", length = 255)
    private String payeeVa;

    @Column(name = "CREATED_DATE", nullable = false)
    private Long createdDate;

    @Column(name = "CREATED_BY", nullable = false, length = 100)
    private String createdBy;

}
