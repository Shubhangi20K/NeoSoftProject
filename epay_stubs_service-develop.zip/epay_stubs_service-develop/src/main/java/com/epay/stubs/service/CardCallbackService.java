package com.epay.stubs.service;

import com.epay.stubs.config.CardConfigDeatils;
import com.epay.stubs.dao.PaymentDao;
import com.epay.stubs.dao.CardPaymentDao;
import com.epay.stubs.dao.OrderDao;
import com.epay.stubs.dto.*;
import com.epay.stubs.entity.Order;
import com.epay.stubs.exceptions.PaymentException;
import com.epay.stubs.externalservice.CardAdminConfigDetailsClientService;
import com.epay.stubs.externalservice.CardWebClientService;
import com.epay.stubs.mapper.CardPaymentMapper;
import com.epay.stubs.model.response.*;
import com.epay.stubs.util.*;
import com.google.gson.Gson;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.text.MessageFormat;
import java.util.HashMap;
import java.util.Optional;

/**
 * Class Name:CardCallbackService
 * *
 * Description: Card Stub Service
 * *
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */

@RequiredArgsConstructor
@Service
public class CardCallbackService {

    private final CardConfigDeatils cardConfigDeatils;
    private final CardCallbackUtil cardCallbackUtil;
    private final CardPaymentDao cardPaymentDao;
    private final CardWebClientService cardWebClientService;
    private final PaymentDao paymentDao;
    private final OrderDao orderDao;
    private final CardPaymentMapper cardPaymentMapper;
    private final CardAdminConfigDetailsClientService cardAdminConfigDetailsClientService;
    private final CardInitiationUtil cardInitiationUtil;
    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());

    /**
     * @return: SaleAPIResponse
     * @methodName: proccesSaleRequest
     * @@Method-Description: Process sale request
     * @param: transactionDto,pRqFrqResponse,cardOnboardDto,cardSummeryResponse
     * @Exception: or @Error :Exception
     */

    public SaleAPIResponse proccesSaleRequest(TransactionDto transactionDto, PRqFrqResponse pRqFrqResponse, CardOnBoardDetailsResponseDto cardOnboardDto, CardSummaryResponse cardSummaryResponse)  {
        String saleRequestPayload = cardCallbackUtil.createSaleRequestPayload(transactionDto , pRqFrqResponse, cardOnboardDto, cardSummaryResponse);
        paymentDao.saveRequestLog(saleRequestPayload,transactionDto.getAtrnNum(),PaymentConstants.SALE_REQ,PaymentConstants.CREATED_BY_WIBMOPG);
        logger.info("Sale API Request {}", saleRequestPayload);
        String encryptedPrqFrqRequest = cardCallbackUtil.getEncryptedPayload(saleRequestPayload);
        HashMap<String, String> cardRequestHeaders = cardInitiationUtil.createThreeDsRequestHeader(cardConfigDeatils.getApi_key(),cardConfigDeatils.getPgInstanceId());
        String apiResponse = cardWebClientService.initiateCardWebClient(cardConfigDeatils.getSaleAuthURL(), encryptedPrqFrqRequest, String.class, cardRequestHeaders);
        logger.info("Sale API Response {}", apiResponse);
        String decryptedRequestPayload= cardCallbackUtil.getDecryptedPayload(apiResponse);
        SaleAPIResponse saleAPIResponse= new Gson().fromJson(decryptedRequestPayload, SaleAPIResponse.class);
        logger.info("Sale API Response {}", saleAPIResponse);
        paymentDao.saveResponseLog(decryptedRequestPayload,transactionDto.getAtrnNum(),saleAPIResponse.getTransactionId(),PaymentConstants.SALE_RESP,PaymentConstants.CREATED_BY_WIBMOPG);
        cardPaymentDao.processSaleApiResponse(saleAPIResponse,transactionDto);
        return Optional.of(saleAPIResponse).orElseThrow(() -> new PaymentException(CardErrorConstants.PROCESS_SERVICE_ERROR_CODE, MessageFormat.format(CardErrorConstants.PROCESS_SERVICE_ERROR_MESSAGE,PaymentConstants.SALE)));
    }
    /**
     * @return: PRqFrqResponse
     * @methodName: processPrqFrqRequest
     * @@Method-Description: Process prqFrq request
     * @param: atrn,paymentRequest,cardSummeryResponse
     * @Exception: or @Error :Exception
     */

    public PRqFrqResponse processPrqFrqRequest(String atrn, String paymentRequest, CardSummaryResponse cardSummaryResponse)  {
        String pRqFrqRequestPayload = cardCallbackUtil.createpRqFrqPayload(paymentRequest, cardSummaryResponse);
        paymentDao.saveRequestLog(pRqFrqRequestPayload,atrn,PaymentConstants.pRqFrq_REQ,PaymentConstants.CREATED_BY_WIBMOPG);
        logger.info("prqFrq Request {}",pRqFrqRequestPayload);
        String encryptedPrqFrqRequest = cardCallbackUtil.getEncryptedPayload(pRqFrqRequestPayload);
        HashMap<String, String> cardRequestHeaders = cardInitiationUtil.createThreeDsRequestHeader(cardConfigDeatils.getApi_key(),cardConfigDeatils.getPgInstanceId_1());
        String apiResponse = cardWebClientService.initiateCardWebClient(cardSummaryResponse.getAuthenticationUrl(), encryptedPrqFrqRequest, String.class, cardRequestHeaders);
        logger.info("prqFrq Response {}",apiResponse);
        String decryptedRequestPayload= cardCallbackUtil.getDecryptedPayload(apiResponse);
        PRqFrqResponse pRqFrqResponse= new Gson().fromJson(decryptedRequestPayload, PRqFrqResponse.class);
        paymentDao.saveResponseLog(decryptedRequestPayload,atrn,pRqFrqResponse.getThreeDSServerTransID(),PaymentConstants.pRqFrq_RESP,PaymentConstants.CREATED_BY_WIBMOPG);
        return Optional.of(pRqFrqResponse).orElseThrow(() -> new PaymentException(CardErrorConstants.PROCESS_SERVICE_ERROR_CODE, MessageFormat.format(CardErrorConstants.PROCESS_SERVICE_ERROR_MESSAGE,PaymentConstants.pRqFrq)));
    }

    /**
     * @return: CardOnBoardDetailsResponseDto
     * @methodName: getConfigDetails
     * @@Method-Description: Process getting config data
     * @param: merchantId
     * @Exception: or @Error :Exception
     */

    public CardOnBoardDetailsResponseDto getConfigDetails(String merchantId) {
        ResponseDto<CardOnBoardDetailsResponseDto> cardConfigDetails = cardAdminConfigDetailsClientService.getCardConfigDetails(merchantId);
        return Optional.of(cardPaymentMapper.mapToCardOnBoardDetailsResponseDto(cardConfigDetails.getData().getFirst())).orElseThrow(() -> new PaymentException(CardErrorConstants.PROCESS_SERVICE_ERROR_CODE, MessageFormat.format(CardErrorConstants.PROCESS_SERVICE_ERROR_MESSAGE,PaymentConstants.Card_Onboard)));
    }


    /**
     * @return: PaymentFinalResponse
     * @methodName: getRedirectObject
     * @@Method-Description: Process setting response data
     * @param: TransactionDto,Status
     * @Exception: or @Error :Exception
     */
    public PaymentFinalResponse getRedirectObject(TransactionDto transactionDto, String status,String responseReason) {
        Order order = orderDao.getOrderDetails(transactionDto);
        return PaymentFinalResponse.builder()
                .mId(transactionDto.getMerchantId())
                .merchnat_order_Ref_No(transactionDto.getOrderRefNumber())
                .Sbi_Ref_No(transactionDto.getSbiOrderRefNumber())
                .order_Amount(String.valueOf(transactionDto.getOrderAmount()))
                .debit_Amount(String.valueOf(transactionDto.getDebitAmt()))
                .atrn(transactionDto.getAtrnNum())
                .status(status)
                .reason(responseReason.replaceAll(PaymentConstants.SPECIAL_CHAR_REGEX,PaymentConstants.EMPTY))
                .cin_no(transactionDto.getCin())
                .other_Details(order.getOtherDetails())
                .bank_Name(transactionDto.getChannelBank())
                .bank_Trace_No(transactionDto.getBankReferenceNumber())
                .bank_Code(transactionDto.getPayMode())
                .customer_Id(order.getCustomerId())
                .order_Retry_Count(String.valueOf(order.getOrderRetryCount()))
                .build();
    }


    public PVrqEncResponse getPArq(String pArqRequest) {
        PVrqEncResponse pVrqResponse = PVrqEncResponse.builder().signedEncResponsePayload("OQvLubO8ri7DO/85WT2RXPb3QB8non25+590ooRm/bMdk9buF/qvv/yARn1MsdXOJ0TWyb+lFiWmCHVp2agbfRfhXPaQ9O1Xb0bK13SCTkMN/qMgOyDRnqmFHsrP03esr6zQLhFYmnvSNx3t7Mm/Eg+eu6N3jURMoELxwi2XcQ1OAqs1i/BqGQqi4BKHbNCjikxYW2RS9c+oEhDCk5v2KHfnZDbIztJUZRqPJiCahCYybONuTZ3muNRbZkH7IehkoGgtPQzXNvvUBN88MGmS7IqtNdHPnE3yn+8mKOmryuiaIFEgvaRv1QOgOz/3QNkE6TCyxWoagvni9btx1EkXAo1A2D0KIlaEDgy4/MXJ9u+6tXUZJW9OtQwrwbJgBpLuJcDJz3IiBxmPhpty6jwQJt+iqmO7WHRutuPiJ9IkjoA3LGloId9qTSYGpG3GqqxqfGorp4M5Niuo0SgX2yBNgdWNevU489sgJ+2XIkRvoJ9dmQL/6FjMBI3S4hfRFANf5htU6Ef1hzFnb+qimTLMj2mC/6KLNJGVGMLRQ4VtjNK4weZZxjK4w6hHa3a0/7I8wEOFYFlAsBfEg/Ri5IgAhPq6n78g5Hmet15d0TvQGmg0DxGEW9t/tfRpm09viuyaSHI3diTJprjWsF79ha5PhjDTSEtml40w8FakvNC/IC2vkn+rGEoAIrfjsFR7IwZO0D0aUl71NhrQJIP9go2ZGOWLe1UMtEfPzhYZOkdjXhtp3pCOcsrG90CiVEjeYmzV8sMqI7FpTGk31OeYIJ3/KJE75ZpZI1Tvrb8fnEUqibJPCzDDydEREwYmU9Me1ndtpzEaoTulWnEHGNNr9MyW3At4eWn17Q9WmzMGZHGuVV8OPUTDGn5gQA3XcXT2cq5zKy7vNvGbIX0JjY6x+LyeP1J7wJwVheFKYXYAiCoYVAUqz4sni2z2QN2zsx5PR4Kt8cG8e+MCXT/yntycL0QyRiqqiwOLzf70UBlS1jxFDLeYU5zRR6owYiUWOVTpiiLMrwQuebdf5upbnAzgbW+D6XIHes8SQXoqMyN1t+ZffMlFxFsmODpFZYC560sBEdAi9G6sL08XhBwXl9tGXe97ArCTJu04TQqt2nwiumc0p2nUjTRWsNfgv9Z4mmS146sEDF1tIyNC0RJzYcd2Wnww8ODhMCdYMbM7v80x2jsnJAyIAU4v2Z4xrLL2PdGlsJmqXeI2Uvg2XvDP6S4U1+EfnpJLaXGZuCwv+XmZgR85RwABH46scRqwXgkGLKfyqQyMs0WsqxLteqQr5JfGL41FHE95eOchKqWnqzYUnXCnSEroVqHWuOq3PHt1UkZo/98aM/i6aJ1HS8/UBS6WtRIluFNLUIt92dU6pLa3ZITOnCk9vRi1OjbfYpFwuIp46I1aq6/Dl0zExHhH8d3OOZzCC/IXa/TSyI/m2f/AsQUK4g/JuN2WJH3GEsBUfsGx+A4NGKUMW40l6KN6qL9lZ8ihxK31n0F0mYHkuo6w5afo9pL/YHI2gPdEDR3+eXyZZXjrYfVdebE/PycHXjABlnXudgrDsmgfVAj5v9pYPH2YWuIHKIjSw+tM1CSex8GF3y6keWWhd3hB8JG0bB7QFxhEl+PoBpDtyVxaR3j3vfxQrAZ0eO6q98JT0alzjIwb8MOwVmSHSN1sJLT0ybgfgSkqORQ06lyzODnH0NS2K2Ym4EDm0DWzIv7cONOitUlguAGh/ON3QCpyTlvmWHq5c3RbNH9L5U5tZfUBMPwG5apmo/IIoIyLCTBZpggGnN6WEg39Ugr6biuXx+fy3XYlyZ3mHmrAVIuCxZhMxxbj1ehmwc+v42JeKlYIuMGezIGXf3yDFy9bxzAmqU7z98qnXgy7VVDH3rY7vpnIhLgDjsoiu3cXRSqhDsy2vCD8HSnWU8G17Npx8aX73SJJ99QzIVqeZjNSvQ2A7QTKM6fVC3UnrjZ+qSgfBwVvV917GjuXAwN5NsHW9DHDe1Iru7ChT/tblYZLsykm9zxHEnmaqjkDYHcQp1ptVBF4qhOzqwiRv0riDQZyGTzh5bZVZzJ7u/T9IUT688QIX6Yi88mhO4j7lfo4cQWpNlt5rzqad/XCxL02TT6LrbMR9CA+0T3fGzsFlH6+vBIue9+9bUH2Hja8q4/Va5XeVc/oentCO4WX4vDlhebu5OwIbT2/AxqsrZeI5lzn/C0LidovNNHvBPtFnYAx2t+Px1Dlo+wvhKd7RVB21BEScEPZcWM9zztcWMCGq9S4R3sU/HFTab2EWS/gX1xCZOuKqHKJm79EVw853ZW15aP23Jb0nurqhWoTr1cy85hov2Hlz2/kiLe+cRaE+brwgUsrnlSiezUMLrRLh7MzuA/GEi75Qv2xFaCSJkc5UIm8sZ1djQ5NS4mXVxR392lkolgn1WbbHGCpZ5uRSFTJ1lFpSDB1VKOqv9S/NNcCb4jYa0z1CdXQ6Z7Cwwjpcb/EUXZ0L4J2ZZboefNIeEcWj4w277mnupwoRlE9M5TpAO4guVLdgNCuDue3R2T3yKUjoFg6z/kPEWzH5MHXuKxJS/C48mrzFNGHer4+G1vUKe7+fU3mdWrDRrsL1lFKLl60NhccAOJHw/qWiTp8kAq870hI7iwWJbvKYxeqXXtun389DgRfqdSkEjgYNXsyusP8FznwVonlJAeDJgtVsFi+dypG8dhbRLncH8JCF+0hWECgpSC+g/G72q9qs0/rirg5/U18uMSaxLdWOxsCU6GGhGYW6eRObSfTqc7HkeNcIGKrA4Po47iiEk2ZEOVRZXI6fiYYZpvC5ajEnET04u3aXMxshGCVbNmaDunWOCyeXnJNg7xH0rhYcX1eqE77uYhSM2ZvzZOf+MOscDxHk7llUdqPFfeGQ22ghe4ZUNW+RDCGwvgdd3paB6uXtuuWVAuoYaztVhHGAnH0yHsBZYVATO7nhMjed4G4tW8dLJ4XgpNDJ9UowZJcUwbn1zuli28r2dco3+8+JLrbNCfGFMsQj+5PSBU7UQdoTTiKnL2dyPQhslFaOJhTVFMoumQy8T94hdgL+1MZbVbFK/deMVpY1vpJqb2YZjmYewkX6XW7DJ02UXoYjzWSIvIUjMoYEWgCci9RtAkFCxJLUhtbZL7Jn9UpWyDe/taT7kgHNVkicVfMrDQFzxBVGvF3zxEcR31MiNvZKE0NzCNxutmtTtRSF0g3EqSt9wrgNUm36DPTGQx9cMmLA5bEAstehmFd4V8Bjlcbo7NFRDlB+XaiVgaIJloLcGMivq7pl4Ok2/Wkx9e2h4tziQaqKDhTqMZbqgnezw+PXei8gz+ZES4e3OsVeDLxOSJc5qfxFA7W4HsKF7wxC1G7x94h+kZYofojp2NPGcFke10LIrGJGbDgEBVXj/jCML4+Anw0Vcg/WyFh37rJIJzLrNfklZYoL6PM")
                .iv("Sit+bFKaPSBsl0QX").responseSymmetricEncKey("lZ8kPgtur6LYBz0simkaNGPpt5NWrLMBYtYLazXYwlTiSUNbjFQqGUUV1uOhJKucSIiPuON+cAsNnFiv5Twa6vJ3m7vW5cGUOOd32brCStjoavJmMYW0EFfVK/jBhMV2zTzUbgHsOjXedVYc8b4J/p8ELrr1FC87GB9YivcXuH1UBlcOBoHpLfdTuM/Vv5+uhW7RPjedhDSKma4/YYmJxtMU6a3FBYBMjEwRcINJKmTrdleo1iyeBKMDJN0JVyfzmO91mXqiIWavlyKFkKXEVNCKvH/qkRCxfy942mTpQcKYy3WyJA7F5KVnkA97MoRvF+TNVEfMfmPfJ2eVpsigbQ==").statusCode("PG99200").build();
        return pVrqResponse;
    }
}
