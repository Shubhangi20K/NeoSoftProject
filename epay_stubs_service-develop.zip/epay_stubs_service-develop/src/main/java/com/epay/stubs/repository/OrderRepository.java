package com.epay.stubs.repository;

import com.epay.stubs.entity.Order;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;

/**
 * Class Name: OrderRepository
 * *
 * Description:
 * *
 * Copyright (c) 2024 [State Bank of India]
 * ALl rights reserved
 * *
 * Version: 1.0
 */

@Repository
public interface OrderRepository extends JpaRepository<Order, UUID> {
    Optional<Order> findBySbiOrderRefNumberAndOrderRefNumber(String sbiOrderRefNumber, String OrderRefNumber);
}

