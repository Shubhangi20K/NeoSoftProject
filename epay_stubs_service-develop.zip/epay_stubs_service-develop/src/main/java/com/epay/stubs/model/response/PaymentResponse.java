package com.epay.stubs.model.response;

import lombok.Data;

/**
 * Class Name: PaymentResponse
 * *
 * Description:
 * *
 * Copyright (c) 2024 [State Bank of India]
 * ALl rights reserved
 * *
 * Version: 1.0
 */
import com.epay.stubs.dto.ErrorDto;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;

import java.util.List;

@AllArgsConstructor
@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PaymentResponse<T> {
    private List<T> data;
    private Integer status;
    private List<ErrorDto> errors;

    @Override
    public String toString() {
        return "ResponseDto{" +
                "status=" + status +
                ", data=" + data +
                '}';
    }
}