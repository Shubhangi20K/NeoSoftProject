package com.epay.stubs.model.response;

import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;

@Data
@Builder
public class InbPostURLResponse {
    String orderNumber;
    String orderId;
    String atrn;
    String status;
    BigDecimal amount;

}
