package com.epay.stubs.controller;


import com.epay.stubs.dto.UpiAccesTokenResponseDto;
import com.epay.stubs.dto.UpiGenericVpaQrWebResponse;
import com.epay.stubs.externalservice.response.CallbackAcknowledgement;
import com.epay.stubs.model.response.UpiCallbackResponse;
import com.epay.stubs.service.UpiCallbackService;
import com.epay.stubs.service.UpiQrPaymentService;
import com.epay.stubs.service.UpiVpaPaymentService;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * @class :UpiPaymentController
 * @implSpec- The purpose of this class is used to UPIPaymentGateway-operation .
 * @version- v1
 * @Exception or @Error :
 */

@RestController
@RequiredArgsConstructor
@RequestMapping("/upi")
public class UpiPaymentController {
    LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());

    private final UpiCallbackService upiCallbackService;
    private final UpiQrPaymentService upiQrPaymentService;
    private final UpiVpaPaymentService upiVpaPaymentService;

    /**
     * @return -JSON : UpiAccesTokenResponseDto
     * @apiName: UPI Access Token
     * @apiUrl: /upi/oauth/token
     * @RequestParam : upiAccessTokenRequest
     * @Method: Post
     * @consumes: MediaType.APPLICATION_JSON_VALUE,
     * @produces: @produces- MediaType.APPLICATION_JSON_VALUE
     */
    @PostMapping("/oauth/token")
    public UpiAccesTokenResponseDto getUpiAccesToken(@RequestBody String upiAccessTokenRequest) {
        logger.info("UPI Token API ::  {} ", upiAccessTokenRequest);
        return upiCallbackService.getUpiAccesToken(upiAccessTokenRequest);
    }

    /**
     * @return - String
     * @apiName: QR Verify
     * @apiUrl: /upi/upi/mandate/signVerifyIntent
     * @RequestParam : encryptedRequest
     * @Method: Post
     * @consumes: MediaType.APPLICATION_JSON_VALUE,
     * @produces: @produces- MediaType.APPLICATION_JSON_VALUE
     */
    @PostMapping("/mandate/signVerifyIntent")
    public String getSignVerifyIntent (@RequestBody String encryptedRequest){
        logger.info("UPI validateVPA ::  {} ", encryptedRequest);
        return upiQrPaymentService.signVerifyIntent(encryptedRequest);
    }

    /**
     * @return - UpiGenericVpaQrWebResponse
     * @apiName: VPA Validation
     * @apiUrl: /upi/upi/web/v2.0/validateVPAWeb
     * @RequestParam : upiRequest
     * @Method: Post
     * @consumes: MediaType.APPLICATION_JSON_VALUE,
     * @produces: @produces- MediaType.APPLICATION_JSON_VALUE
     */
    @PostMapping("/web/v2.0/validateVPAWeb")
    public UpiGenericVpaQrWebResponse getValidateVPAWeb(@RequestBody String upiRequest) {
        logger.info("UPI validateVPA ::  {} ", upiRequest);
        return upiVpaPaymentService.getValidateVPAWeb(upiRequest);
    }

    /**
     * @return - UpiGenericVpaQrWebResponse
     * @apiName: UPI VPA Collect
     * @apiUrl: /upi/upi/web/v2.0/meCollectInitiateWeb
     * @RequestParam : request
     * @Method: Post
     * @consumes: MediaType.APPLICATION_JSON_VALUE,
     * @produces: @produces- MediaType.APPLICATION_JSON_VALUE
     */
    @PostMapping("/web/v2.0/meCollectInitiateWeb")
    public UpiGenericVpaQrWebResponse meCollectInitiateWeb(@RequestBody String request) {
        logger.info("UPI Collect CollectInitiateWeb ::  {} ", request);
        return upiCallbackService.meCollectInitiateWeb(request);
    }

    /**
     * @return - UpiGenericVpaQrWebResponse
     * @apiName: UPI STATUS QUERY
     * @apiUrl: /upi/upi/web/v2.0/meTranStatusQueryWeb
     * @RequestParam : statusQueryRequest
     * @Method: Post
     * @consumes: MediaType.APPLICATION_JSON_VALUE,
     * @produces: @produces- MediaType.APPLICATION_JSON_VALUE
     */
    @PostMapping("/web/v2.0/meTranStatusQueryWeb")
    public UpiGenericVpaQrWebResponse meTranStatusQueryWeb(@RequestBody String statusQueryRequest) {
        logger.info("UPI StatusQuery TranStatusQueryWeb ::  {} ", statusQueryRequest);
        return upiQrPaymentService.meTranStatusQueryWeb(statusQueryRequest);
    }

    /**
     * @return - CallbackAcknowledgement
     * @apiName: UPI CALLBACK
     * @apiUrl: /upi/callback
     * @RequestParam : upicallbackrequest
     * @Method: Post
     * @consumes: MediaType.APPLICATION_JSON_VALUE,
     * @produces: @produces- MediaType.APPLICATION_JSON_VALUE
     */
    @CrossOrigin("*")
    @PostMapping("/callback")
    public ResponseEntity<CallbackAcknowledgement> handleCallback(@RequestBody UpiCallbackResponse upicallbackrequest) {
        logger.info("Inside UpiPaymentController getParameter response msg :: {}", upicallbackrequest);
        return ResponseEntity.ok(upiCallbackService.processCallback(upicallbackrequest));
    }
}
