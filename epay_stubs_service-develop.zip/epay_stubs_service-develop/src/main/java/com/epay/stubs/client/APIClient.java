package com.epay.stubs.client;

import com.epay.stubs.exceptions.PaymentException;
import com.epay.stubs.model.response.PaymentResponse;
import com.epay.stubs.util.ErrorConstants;
import com.sbi.epay.authentication.util.EPayAuthenticationConstant;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import io.netty.handler.ssl.SslContextBuilder;
import io.netty.handler.ssl.util.InsecureTrustManagerFactory;
import lombok.RequiredArgsConstructor;
import org.slf4j.MDC;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.netty.http.client.HttpClient;
import org.springframework.http.HttpStatusCode;

import java.net.URI;
import java.text.MessageFormat;

@RequiredArgsConstructor
public class APIClient {

    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private final String baseUrl;
    private final WebClient webClient;

    public APIClient(String baseUrl, String corsOrigin) {
        this.baseUrl = baseUrl;
        this.webClient = WebClient.builder().clientConnector(new ReactorClientHttpConnector(HttpClient.create().secure(t -> t.sslContext(SslContextBuilder.forClient().trustManager(InsecureTrustManagerFactory.INSTANCE))))).defaultHeader(HttpHeaders.ORIGIN, corsOrigin).build();
    }

    protected String getBaseUrl() {
        return baseUrl;
    }

    protected WebClient getWebClient() {
        return webClient;
    }
    public APIClient(String baseUrl) {
        this.baseUrl = baseUrl;
        this.webClient = WebClient.builder().baseUrl(baseUrl).build();
    }

    protected HttpHeaders prepareHttpHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);
        headers.add(EPayAuthenticationConstant.X_CORRELATION_ID, MDC.get(EPayAuthenticationConstant.CORRELATION_ID));
        return headers;
    }

    protected <T, R> PaymentResponse<R> post(String urlPath, T requestBody, ParameterizedTypeReference<PaymentResponse<R>> typeReference) {
        URI uri = URI.create(getBaseUrl() + urlPath);
        logger.info("Calling uri: {}", uri);
        logger.debug("Request body: {}", requestBody);
        return getWebClient().post().uri(uri).headers(httpHeaders -> httpHeaders.addAll(prepareHttpHeaders())).bodyValue(requestBody).retrieve().onStatus(HttpStatusCode::is4xxClientError, clientResponse -> Mono.error(new PaymentException(ErrorConstants.EXTERNAL_SERVICE_ERROR_CODE, MessageFormat.format(ErrorConstants.EXTERNAL_SERVICE_ERROR_MESSAGE, getServiceName())))).onStatus(HttpStatusCode::is5xxServerError, clientResponse -> Mono.error(new PaymentException(ErrorConstants.EXTERNAL_SERVICE_ERROR_CODE, MessageFormat.format(ErrorConstants.EXTERNAL_SERVICE_ERROR_MESSAGE, getServiceName())))).bodyToMono(typeReference).block();
    }

    /**
     * Return current service name.
     *
     * @return String
     */
    private String getServiceName() {
        return this.getClass().getSimpleName().replaceAll("Client", "").replaceAll("Services", "");
    }

    protected <T> PaymentResponse<T> get(String urlPath, ParameterizedTypeReference<PaymentResponse<T>> typeReference) {
        URI uri = URI.create(getBaseUrl() + urlPath);
        logger.info("Calling uri: {}", uri);
        return getWebClient().get().uri(uri).headers(httpHeaders -> httpHeaders.addAll(prepareHttpHeaders())).retrieve().onStatus(HttpStatusCode::is4xxClientError, clientResponse -> Mono.error(new PaymentException(ErrorConstants.EXTERNAL_SERVICE_ERROR_CODE, MessageFormat.format(ErrorConstants.EXTERNAL_SERVICE_ERROR_MESSAGE, getServiceName())))).onStatus(HttpStatusCode::is5xxServerError, clientResponse -> Mono.error(new PaymentException(ErrorConstants.EXTERNAL_SERVICE_ERROR_CODE, MessageFormat.format(ErrorConstants.EXTERNAL_SERVICE_ERROR_MESSAGE, getServiceName())))).bodyToMono(typeReference).block();
    }


    protected <T, R> PaymentResponse<R> postCallBack(String urlPath, T requestBody, ParameterizedTypeReference<PaymentResponse<R>> typeReference) {
        URI uri = URI.create(getBaseUrl() + urlPath);
        logger.info("Calling uri: {}", uri);
        logger.debug("Request body: {}", requestBody);
        return getWebClient().post().uri(uri).contentType(MediaType.APPLICATION_FORM_URLENCODED).headers(httpHeaders -> httpHeaders.addAll(prepareHttpHeaders())).bodyValue(requestBody).retrieve().onStatus(HttpStatusCode::is4xxClientError, clientResponse -> Mono.error(new PaymentException(ErrorConstants.EXTERNAL_SERVICE_ERROR_CODE, MessageFormat.format(ErrorConstants.EXTERNAL_SERVICE_ERROR_MESSAGE, getServiceName()))))
                .onStatus(HttpStatusCode::is5xxServerError, clientResponse -> Mono.error(new PaymentException(ErrorConstants.EXTERNAL_SERVICE_ERROR_CODE, MessageFormat.format(ErrorConstants.EXTERNAL_SERVICE_ERROR_MESSAGE, getServiceName()))))
                .bodyToMono(typeReference).block();
    }
}