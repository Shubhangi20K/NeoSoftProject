package com.epay.stubs.model.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;

import static com.epay.stubs.util.PaymentConstants.CHANNEL_BANK_IS_REQUIRED;
import static com.epay.stubs.util.PaymentConstants.CHANNEL_BANK_IS_REQUIRED;

/**
 * Class Name:PaymentInitiationRequest
 * *
 * Description: Card Stubs Service
 * *
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */

@Data
@Builder
public class PaymentInitiationRequest {

    private String operatingMode;

    private String mId;

    private String status;

    private String virtualAddress;

    private String payGtwMapId;

    private String atrn;

    private String payProcId;

    private String paymode;

    private String payProcType;

    private String gtwMapsId;

    private String pgBankCode;

    private BigDecimal merchPostedAmount;

    private BigDecimal transactionAmount;

    private String upiAddress;

    @NotBlank(message = CHANNEL_BANK_IS_REQUIRED)
    private String channelBank;

    private String altNumber;

    private String expiryMonth;

    private String expiryYear;

    private String cvv;

    private String cardHolderName;

    private String apiType;

    private String threeDSServerTransID;

    private String acsTransID;

    private String messageType;

    private String messageVersion;

    private String challengeCompletionInd;

    private String transStatus;

    private String amount;

    private String currency_code;

    private String merchant_reference_no;

    private String errorcode;

    private String errormsg;

    private String pg_error_code;

    private String pg_error_detail;

    private String pgtransactionid;

    private String otp;

}
