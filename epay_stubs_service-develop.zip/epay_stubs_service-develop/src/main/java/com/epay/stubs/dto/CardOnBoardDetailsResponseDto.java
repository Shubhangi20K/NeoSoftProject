package com.epay.stubs.dto;

import lombok.*;

import java.io.Serializable;

/**
 * Class Name:
 * *
 * Description: Stubs Payment Service

 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CardOnBoardDetailsResponseDto extends BaseDto implements Serializable {
    private long mapId;
    private String aggregatorId;
    private String merchantId;
    private String pgMerchantId;
    private String wibMomId;
    private String wibMotId;
    private String dpaId;
    private String status;
    private String creationDate;
    private String createdBy;
    private String createdBySessionId;
    private String modifiedDate;
    private String modifiedBy;
    private String modifiedBySessionId;
    private String creationdtNum;
    private String remarks;
    private String payGtwId;
    private String operatingModeId;
    private String currencyCode;
    private String accessMediumCode;
    private String countryCode;
    private String dbaName;
    private String legalName;
}
