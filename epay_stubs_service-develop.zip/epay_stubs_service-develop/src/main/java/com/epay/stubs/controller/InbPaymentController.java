package com.epay.stubs.controller;

import com.epay.stubs.model.response.InbPostURLResponse;
import com.epay.stubs.service.InbPaymentService;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @class :InbPaymentController
 * @implSpec- The purpose of this class is used to UPIPaymentGateway-operation .
 * @version- v1
 *
 */

@RestController
@RequiredArgsConstructor
@RequestMapping("/inb")
public class InbPaymentController {

    private final InbPaymentService inbPaymentService;
    LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());

    /**
     * @return -JSON : InbPostURLResponse
     * @apiName: Inb PostURL
     * @apiUrl: /inb/inbPostURL
     * @Method: Post
     * @consumes: MediaType.APPLICATION_JSON_VALUE,
     * @produces: @produces- MediaType.APPLICATION_JSON_VALUE
     */
    @PostMapping("/inbPostURL")
    public InbPostURLResponse getPostUrl() {
        logger.info("INB PostURL");
        return inbPaymentService.getPostUrl();
    }

}
