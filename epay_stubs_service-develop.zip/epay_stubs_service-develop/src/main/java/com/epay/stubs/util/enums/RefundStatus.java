package com.epay.stubs.util.enums;

import com.epay.stubs.exceptions.PaymentException;
import com.epay.stubs.util.ErrorConstants;

import java.text.MessageFormat;
import java.util.Arrays;

/**
 * Class Name:CardPaymentDao
 * *
 * Description: Card Stubs Service
 * *
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */

public enum RefundStatus {

    CANCELLATION_BOOKED, REFUND_BOOKED, CANCELLATION_IN_PROCESS, REFUND_IN_PROCESS, REFUND_PROCESSED;

    public static RefundStatus getRefundStatus(String refundStatus) {
        return Arrays.stream(values()).filter(p -> p.name().equalsIgnoreCase(refundStatus)).findFirst().orElseThrow(() -> new PaymentException(ErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(ErrorConstants.INVALID_ERROR_MESSAGE, "Refund status", "Valid refund status are " + Arrays.toString(RefundStatus.values()))));
    }
}
