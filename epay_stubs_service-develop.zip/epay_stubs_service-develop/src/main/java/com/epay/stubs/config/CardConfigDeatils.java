package com.epay.stubs.config;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

/**
 * Class Name:CardConfigDeatils
 * *
 * Description: Card Stubs Service
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */

@Data
@Configuration
public class CardConfigDeatils {
    @Value("${epay.payment.card.reverse_url}")
    private String reverseURL;

    @Value("${epay.payment.card.callback_url}")
    private String callbackUrl;

    @Value("${epay.payment.card.callbackg_url_rupay}")
    private String callback_Url_Rupay;

   @Value("${epay.payment.card.pvReqURL}")
    private String pvReqURL;

    @Value("${epay.payment.card.checkbin_Url}")
    private String checkbinURL;

    @Value("${epay.payment.card.initiate_url}")
    private String initiateURL;

    @Value("${epay.payment.card.generateOtp_url}")
    private String generateOtpURL;

    @Value("${epay.payment.card.resendOtp_url}")
    private String resendOtpURL;

    @Value("${epay.payment.card.verifyOtp_url}")
    private String verifyOtpURL;

    @Value("${epay.payment.card.authorize_url}")
    private String authorizeURL;

    @Value("${epay.payment.card.token_url}")
    private String tokenURL;

    @Value("${epay.payment.card.api_key}")
    private String api_key;

    @Value("${epay.payment.card.clientId}")
    private String clientId;

    @Value("${epay.payment.card.clientApiUser}")
    private String clientApiUser;

    @Value("${epay.payment.card.clientApiKey}")
    private String clientApiKey;

    @Value("${epay.payment.card.tokenSecretKey}")
    private String tokenSecretKey;

    @Value("${epay.payment.card.merchantId_Token}")
    private String merchantId_Token;

    @Value("${epay.payment.card.tokenRequesterId_MC}")
    private String tokenRequesterId_MC;

    @Value("${epay.payment.card.tokenRequesterId_VS}")
    private String tokenRequesterId_VS;

    @Value("${epay.payment.card.tokenRequesterId_R}")
    private String tokenRequesterId_R;

    @Value("${epay.payment.card.pgInstanceId_1}")
    private String pgInstanceId_1;

    @Value("${epay.payment.card.pgInstanceId_2}")
    private String pgInstanceId_2;

    @Value("${epay.payment.card.pgInstanceId}")
    private String pgInstanceId;

    @Value("${epay.payment.card.acquirerBIN_MASTER}")
    private String acquirerBin_Master;

    @Value("${epay.payment.card.acquirerBIN_VISA}")
    private String acquirerBin_Visa;

    @Value("${epay.payment.card.acquiringBankId}")
    private String acquiringBankId;

    @Value("${epay.payment.card.acquirerID}")
    private String acquirerID;

    @Value("${epay.payment.card.acquireInstanceId}")
    private String acquireInstanceId;

    @Value("${epay.payment.card.MCC}")
    private String MCC;

    @Value("${epay.payment.card.deviceChannel}")
    private String deviceChannel;

    @Value("${epay.payment.card.p_messageVersion}")
    private String p_messageVersion;

    @Value("${epay.payment.card.messageCategory}")
    private String messageCategory;

    @Value("${epay.payment.card.vaultId}")
    private String vaultId;

    @Value("${epay.payment.card.INR}")
    private String INR;

    @Value("${epay.payment.card.USD}")
    private String USD;

    @Value("${epay.payment.card.paymentsRedirectUrl}")
    private String paymentsRedirectUrl;

    @Value("${epay.payment.card.saleAuthURL}")
    private String saleAuthURL;

    @Value("${epay.payment.card.transactionTypeCode}")
    private String transactionTypeCode;

    @Value("${https_protocols}")
    private String https_protocols;

    @Value("${https_proxySet}")
    private String https_proxySet;

    @Value("${https_proxyHost}")
    private String https_proxyHost;

    @Value("${https_proxyPort}")
    private String https_proxyPort;

    @Value("${epay.payment.card.cardOnboardURL}")
    private String cardOnboardURL;

    @Value("${external.api.admin.services.base.path}")
    private String adminServiceBaseURL;

    @Value("${wibmo.client_jks_filename}")
    private String client_jks_filename;

    @Value("${wibmo.client_jks_file_pwd}")
    private String client_jks_file_pwd;

    @Value("${wibmo.client_alias_name}")
    private String client_alias_name;

    @Value("${wibmo.client_alias_pwd}")
    private String client_alias_pwd;

    @Value("${wibmo.server_pk_alias_name}")
    private String server_pk_alias_name;

    @Value("${security.cors.origin}")
    private String corsOrigin;

    @Value("${epay.payment.card.finalResponse_Url}")
    private String finalResponseUrl;

    @Value("${external.api.transaction.services.base.path}")
    private String transactionServiceBaseURL;

    @Value("${external.api.ui.service.redirectView}")
    private String merchantResponseView;

    @Value("${external.api.paymentCallBackUrl}")
    private String paymentCallbackUrl;

    @Value("${key.aek}")
    private String aek;

    //INTL Constants
    @Value("${epay.payment.card.callback_url_intl}")
    private String callbackUrl_intl;

    @Value("${epay.payment.card.callbackg_url_rupay_intl}")
    private String callback_Url_Rupay_intl;

    @Value("${epay.payment.card.reverse_url_intl}")
    private String reverseURL_intl;

    @Value("${epay.payment.card.pvReqURL_intl}")
    private String pvReqURL_intl;

    @Value("${epay.payment.card.checkbin_Url_intl}")
    private String checkbinURL_intl;

    @Value("${epay.payment.card.initiate_url_intl}")
    private String initiateURL_intl;

    @Value("${epay.payment.card.generateOtp_url_intl}")
    private String generateOtpURL_intl;

    @Value("${epay.payment.card.resendOtp_url_intl}")
    private String resendOtpURL_intl;

    @Value("${epay.payment.card.verifyOtp_url_intl}")
    private String verifyOtpURL_intl;

    @Value("${epay.payment.card.authorize_url_intl}")
    private String authorizeURL_intl;

    @Value("${epay.payment.card.token_url_intl}")
    private String tokenURL_intl;

    @Value("${epay.payment.card.api_key_intl}")
    private String api_key_intl;

    @Value("${epay.payment.card.clientId_intl}")
    private String clientId_intl;

    @Value("${epay.payment.card.clientApiUser_intl}")
    private String clientApiUser_intl;

    @Value("${epay.payment.card.clientApiKey_intl}")
    private String clientApiKey_intl;

    @Value("${epay.payment.card.tokenSecretKey_intl}")
    private String tokenSecretKey_intl;

    @Value("${epay.payment.card.tokenSecretKey_1_intl}")
    private String tokenSecretKey_1_intl;

    @Value("${epay.payment.card.merchantId_Token_intl}")
    private String merchantId_Token_intl;

    @Value("${epay.payment.card.tokenRequesterId_MC_intl}")
    private String tokenRequesterId_MC_intl;

    @Value("${epay.payment.card.tokenRequesterId_VS_intl}")
    private String tokenRequesterId_VS_intl;

    @Value("${epay.payment.card.tokenRequesterId_R_intl}")
    private String tokenRequesterId_R_intl;

    @Value("${epay.payment.card.acquiringBankId_intl}")
    private String acquiringBankId_intl;

    @Value("${epay.payment.card.acquirerMerchantId_intl}")
    private String acquirerMerchantId_intl;

    @Value("${epay.payment.card.acquireInstanceId_intl}")
    private String acquireInstanceId_intl;

    @Value("${epay.payment.card.saleAuthURL_intl}")
    private String saleAuthURL_intl;

    @Value("${wibmo.client_jks_filename_intl}")
    private String client_jks_filename_intl;

    @Value("${wibmo.client_jks_file_pwd_intl}")
    private String client_jks_file_pwd_intl;

    @Value("${wibmo.client_alias_name_intl}")
    private String client_alias_name_intl;

    @Value("${wibmo.client_alias_pwd_intl}")
    private String client_alias_pwd_intl;

    @Value("${wibmo.server_pk_alias_name_intl}")
    private String server_pk_alias_name_intl;

}
