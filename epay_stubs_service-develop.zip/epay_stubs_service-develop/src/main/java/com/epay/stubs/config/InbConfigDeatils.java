package com.epay.stubs.config;


import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

/**
 * Class Name:NbConfigDeatils
 * *
 * Description:
 * *
 * Copyright (c) 2024 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */

@Data
@Configuration
public class InbConfigDeatils {

    @Value("${epay.payment.sbiinb.bankdvurl}")
    private String sbiNburl;

}
