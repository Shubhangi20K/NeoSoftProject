package com.epay.stubs.dto;

import lombok.*;

import java.math.BigDecimal;
import java.util.UUID;

@Builder
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class PaymentOrderSummeryDto {

    private UUID id;
    private String aggregatorId;
    private String merchantId;
    private String paymodeCode;
    private Long lastTxnBookingDate;
    private BigDecimal dailyTxnAmount;
}
