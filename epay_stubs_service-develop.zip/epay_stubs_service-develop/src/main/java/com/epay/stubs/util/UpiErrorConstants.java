package com.epay.stubs.util;

public class UpiErrorConstants {


    public static final String PGP_DECRYPTION_ERROR_RESPONSE_CODE = "3403";
    public static final String PGP_DECRYPTION_ERROR_RESPONSE_MESSAGE = "Error while PGP decryption";

    public static final String PGP_ENCRYPTION_ERROR_CODE = "3404";
    public static final String PGP_ENCRYPTION_ERROR_MESSAGE = "Error during PGP Encryption";



}