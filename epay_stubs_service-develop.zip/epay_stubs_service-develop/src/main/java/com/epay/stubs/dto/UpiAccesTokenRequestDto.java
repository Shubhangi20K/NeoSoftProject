package com.epay.stubs.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UpiAccesTokenRequestDto implements Serializable {


    @JsonProperty(value = "clientId")
    String clientId;


    @JsonProperty(value = "clientSecretKey")
    String clientSecretKey;


    @JsonProperty(value = "oAuthUserId")
    String oAuthUserId;


    @JsonProperty(value = "oauthPassword")
    String oauthPassword;


    @JsonProperty(value = "grantType")
    String grantType ;

}
