package com.epay.stubs.model.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;
import jakarta.validation.constraints.NotBlank;
import lombok.*;

import java.io.Serializable;

/**
 * Class Name: PaymentRequestCard
 * *
 * Description: Card Stubs Service
 * *
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PaymentRequestCard implements Serializable {
    @NotBlank(message = "{paymentInitiationRequest.error.NotBlank}")
    @SerializedName(value = "paymode")
    @JsonProperty(value = "paymode")
    private String paymode;

    @NotBlank(message = "{paymentInitiationRequest.error.NotBlank}")
    @SerializedName(value = "atrn")
    @JsonProperty(value = "atrn")
    private String atrn;

    @NotBlank(message = "{paymentInitiationRequest.error.NotBlank}")
    @SerializedName(value = "operatingMode")
    @JsonProperty(value = "operatingMode")
    private String operatingMode;

    @NotBlank(message = "{paymentInitiationRequest.error.NotBlank}")
    @SerializedName(value = "payProcId")
    @JsonProperty(value = "payProcId")
    private String payProcId;

    @NotBlank(message = "{paymentInitiationRequest.error.NotBlank}")
    @SerializedName(value = "payProcType")
    @JsonProperty(value = "payProcType")
    private String payProcType;

   /* @NotBlank(message = "{paymentInitiationRequest.error.NotBlank}")
    @SerializedName(value = "merchPostedAmount")
    @JsonProperty(value = "merchPostedAmount")
    private String merchPostedAmount;

    @NotBlank(message = "{paymentInitiationRequest.error.NotBlank}")
    @SerializedName(value = "transactionAmount")
    @JsonProperty(value = "transactionAmount")
    private String transactionAmount;
*/
    @NotBlank(message = "{paymentInitiationRequest.error.NotBlank}")
    @SerializedName(value = "altNumber")
    @JsonProperty(value = "altNumber")
    private String altNumber;

    @NotBlank(message = "{paymentInitiationRequest.error.NotBlank}")
    @SerializedName(value = "expiryMonth")
    @JsonProperty(value = "expiryMonth")
    private String expiryMonth;

    @NotBlank(message = "{paymentInitiationRequest.error.NotBlank}")
    @SerializedName(value = "expiryYear")
    @JsonProperty(value = "expiryYear")
    private String expiryYear;

    @NotBlank(message = "{paymentInitiationRequest.error.NotBlank}")
    @SerializedName(value = "cvv")
    @JsonProperty(value = "cvv")
    private String cvv;

    @NotBlank(message = "{paymentInitiationRequest.error.NotBlank}")
    @SerializedName(value = "cardHolderName")
    @JsonProperty(value = "cardHolderName")
    private String cardHolderName;

}
