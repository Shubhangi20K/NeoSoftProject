package com.epay.stubs.dao;

import com.epay.stubs.dto.PaymentOrderSummeryDto;
import com.epay.stubs.dto.TransactionDto;
import com.epay.stubs.entity.OrderSummaryEmbeddedId;
import com.epay.stubs.entity.PaymentOrderSummary;
import com.epay.stubs.repository.PaymentOrderSummeryRepository;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Optional;
import java.util.function.Predicate;

/**
 * Class Name: PaymentOrderSummeryDao
 * *
 * Description:
 * *
 * ALl rights reserved
 * *
 * Version: 1.0
 */

@Component
@RequiredArgsConstructor
public class PaymentOrderSummeryDao {

    private final PaymentOrderSummeryRepository paymentOrderSummeryRepository;
    LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    public Optional<PaymentOrderSummary> getDailyTxnAmtIs(PaymentOrderSummeryDto dailyTxnAmtDto) {
        return paymentOrderSummeryRepository.getDailyTxnAmt(dailyTxnAmtDto.getMerchantId(), dailyTxnAmtDto.getPaymodeCode());
    }


    public void updateTransactionSummary(TransactionDto transactionDto, PaymentOrderSummary merchantOrderSummery) {
        BigDecimal dailyTxnAmount = merchantOrderSummery.getDailyTxnAmount() != null ? merchantOrderSummery.getDailyTxnAmount() : BigDecimal.ZERO;
        logger.debug("dailyTxnAmount  {} ", dailyTxnAmount);

        Predicate<BigDecimal> checkDailyAmount = (dailyTxnAmountData) -> dailyTxnAmountData.compareTo(BigDecimal.ZERO) > 0;
        logger.debug("checkDailyAmount  {} ", checkDailyAmount);

        if (checkDailyAmount.test(dailyTxnAmount)) {
            logger.debug("if  {} ", checkDailyAmount);

            merchantOrderSummery.setDailyTxnAmount((transactionDto.getDebitAmt().add(merchantOrderSummery.getDailyTxnAmount() != null ? merchantOrderSummery.getDailyTxnAmount() : BigDecimal.ZERO)));
            merchantOrderSummery.setWeeklyTxnAmount(transactionDto.getDebitAmt().add(merchantOrderSummery.getWeeklyTxnAmount() != null ? merchantOrderSummery.getWeeklyTxnAmount() : BigDecimal.ZERO));
            merchantOrderSummery.setMonthlyTxnAmount(transactionDto.getDebitAmt().add(merchantOrderSummery.getMonthlyTxnAmount() != null ? merchantOrderSummery.getMonthlyTxnAmount() : BigDecimal.ZERO));
            merchantOrderSummery.setQuarterlyTxnAmount(transactionDto.getDebitAmt().add(merchantOrderSummery.getQuarterlyTxnAmount() != null ? merchantOrderSummery.getQuarterlyTxnAmount() : BigDecimal.ZERO));
            merchantOrderSummery.setHalfYearlyTxnAmount(transactionDto.getDebitAmt().add(merchantOrderSummery.getHalfYearlyTxnAmount() != null ? merchantOrderSummery.getHalfYearlyTxnAmount() : BigDecimal.ZERO));
            merchantOrderSummery.setAnnuallyTxnAmount(transactionDto.getDebitAmt().add(merchantOrderSummery.getAnnuallyTxnAmount() != null ? merchantOrderSummery.getAnnuallyTxnAmount() : BigDecimal.ZERO));
            merchantOrderSummery.setUpdatedBy(transactionDto.getMerchantId());
            merchantOrderSummery.setUpdatedDate(new Timestamp(System.currentTimeMillis()).getTime());
            logger.debug("before save if  {} ", merchantOrderSummery);
            paymentOrderSummeryRepository.save(merchantOrderSummery);
            logger.debug("save if  {} ", merchantOrderSummery);
        } else {
            logger.debug("else  {} ", checkDailyAmount);

            PaymentOrderSummary paymentOrderSummary = PaymentOrderSummary.builder().
                    orderSummaryEmbeddedId(OrderSummaryEmbeddedId.builder().merchantId(transactionDto.getMerchantId()).paymodeCode(transactionDto.getPayMode()).build())
                    .lastTxnBookingDate(new Timestamp(System.currentTimeMillis()).getTime())
                    .dailyTxnAmount(transactionDto.getDebitAmt().add(dailyTxnAmount))
                    .weeklyTxnAmount(transactionDto.getDebitAmt().add(dailyTxnAmount))
                    .monthlyTxnAmount(transactionDto.getDebitAmt().add(dailyTxnAmount))
                    .quarterlyTxnAmount(transactionDto.getDebitAmt().add(dailyTxnAmount))
                    .halfYearlyTxnAmount(transactionDto.getDebitAmt().add(dailyTxnAmount))
                    .annuallyTxnAmount(transactionDto.getDebitAmt().add(dailyTxnAmount))
                    .createdBy(transactionDto.getMerchantId())
                    .createdDate(new Timestamp(System.currentTimeMillis()).getTime())
                    .build();
            logger.debug("before save else  {} ", paymentOrderSummary);
            paymentOrderSummeryRepository.save(paymentOrderSummary);
            logger.debug("save else  {} ", paymentOrderSummary);
        }
    }

}
