package com.epay.stubs.util;

import com.epay.stubs.config.InbConfigDeatils;
import com.epay.stubs.exceptions.PaymentException;
import com.epay.stubs.externalservice.PaymentWebClientService;
import com.epay.stubs.validator.PaymentValidator;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.exc.UnrecognizedPropertyException;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.text.MessageFormat;
import java.util.Arrays;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Class Name:PaymentUtil
 * *
 * Description:
 * *
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */

@Component
@RequiredArgsConstructor
public class PaymentUtil {
    LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private  final InbEncryptionDecryptionUtil inbEncryptionDecryptionUtil;
    private final InbConfigDeatils inbConfigDeatils;
    private final PaymentWebClientService paymentWebClientService;
    private final PaymentValidator paymentValidator;

    /**
     * @return: key, value
     * @methodName: Web and DV Decrypted Data set in map.
     * @@Method-Description: Process DecryptedData and set in map.
     * @param: getDecryptedData
     * @Exception: or @Error :Exception
     */
    public Map<String,String> getDecryptedData(String decResponse) {
        return Optional.of(Arrays.stream(decResponse.split(PaymentConstants.PIPE_CONST))
                .map(kv -> kv.split(PaymentConstants.PATTERN_EQUAL_TO_CONST))
                .filter(kvArray -> kvArray.length == 2)
                .collect(Collectors.toMap(kv -> kv[0], kv ->StringUtils.isBlank(kv[1])?PaymentConstants.NA:kv[1])))
                .orElseThrow(() ->new PaymentException(InbErrorConstants.WEB_CHECKSUM_ERROR_CODE, InbErrorConstants.WEB_CHECKSUM_MISMATCH_ERROR_MESSAGE));
    }

    /**
     * @return: webRequestData and Checksum
     * @methodName: Create Web Request for SBI Bank.
     * @@Method-Description: Process Create Web Request and checksum.
     * @param: createEncrptedWebReq
     * @Exception: or @Error :Exception
     */
/*    public String createWebRequest(String atrn, BigDecimal amountFromDB) {
        logger.info("Payment Initiation amountFromDB {} for SBI INB : ", amountFromDB);

        StringBuilder webReqData = new StringBuilder();

        logger.info("Payment Initiation amt {} for SBI INB : ", amountFromDB.toString().replaceAll(PaymentConstants.COMMA_CONST,PaymentConstants.EMPTY));
        webReqData.append(MessageFormat.format(PaymentConstants.SBIINB_WEB_REQUEST,atrn,amountFromDB.toString().replaceAll(PaymentConstants.COMMA_CONST,PaymentConstants.EMPTY), inbConfigDeatils.getCancelUrl(), inbConfigDeatils.getSbiRedirectUrl()));
        logger.info("Payment Initiation using builder webReqData {} for SBI INB : ", webReqData);

        String checkSum = inbEncryptionDecryptionUtil.getSHA2Checksum(webReqData.toString());
        logger.info("Payment Initiation Web Request {} ,and checkSum{} , and ATRN {} for SBI INB : ", webReqData,checkSum,atrn);
        return   Optional.of(webReqData.toString()
                        .concat(PaymentConstants.SBIINB_CHECKSUM)
                        .concat(checkSum)).filter(x->!x.isEmpty())
                .orElseThrow(() ->new PaymentException(InbErrorConstants.ENCRYPTION_ERROR_CODE, InbErrorConstants.ENCRYPTION_ERROR_MESSAGE));
    }*/
    /**
     * Parse exception error message.
     * @param cause JsonProcessingException
     * @return error message
     */
    public static String getParsingError(Throwable cause) {
        if (cause instanceof UnrecognizedPropertyException unrecognizedPropertyException) {
            return PaymentConstants.UNRECOGNIZED_FIELD + unrecognizedPropertyException.getPropertyName();
        } else if (cause instanceof JsonParseException jsonParseException && StringUtils.startsWithIgnoreCase(jsonParseException.getMessage(),PaymentConstants.DUPLICATE_FIELD)) {
            return jsonParseException.getMessage().substring(0, jsonParseException.getMessage().indexOf(PaymentConstants.NEWLINE_REGEX)).replaceAll(PaymentConstants.SINGLE_QUOTE,PaymentConstants.PATTERN_EMPTY);
        } else if (cause instanceof JsonMappingException jsonMappingException) {
            Optional<String> fieldName = jsonMappingException.getPath().stream().map(JsonMappingException.Reference::getFieldName).reduce((first, second) -> second);
            if (fieldName.isPresent()) {
                return PaymentConstants.INVALID_INPUT_FIELD + fieldName.get();
            }
        }
        return PaymentConstants.INVALID_INPUT;
    }
}