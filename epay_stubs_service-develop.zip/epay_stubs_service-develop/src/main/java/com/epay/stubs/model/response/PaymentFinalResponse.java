package com.epay.stubs.model.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PaymentFinalResponse {
    private String mId;
    private String merchnat_order_Ref_No;
    private String Sbi_Ref_No;
    private String order_Amount;
    private String debit_Amount;
    private String atrn;
    private String status;
    private String reason;
    private String cin_no;
    private String other_Details;
    private String bank_Name;
    private String bank_Trace_No;
    private String bank_Code;
    private String customer_Id;
    private String order_Retry_Count;
}