package com.epay.stubs.service;
/**
 * Class Name: CardInitiationIntlService
 * *
 * Description: Card Payment Service
 * *
 * Author: VCE2656 - Vinod Bhosale (Dev Lead SBIePAY)
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */

import com.epay.stubs.config.CardConfigDeatils;
import com.epay.stubs.dao.CardPaymentDao;
import com.epay.stubs.dao.PaymentDao;
import com.epay.stubs.dao.StatusUpdatePaymentDao;
import com.epay.stubs.dao.TransactionDao;
import com.epay.stubs.dto.CardOnBoardDetailsResponseDto;
import com.epay.stubs.dto.ErrorDto;
import com.epay.stubs.dto.ResponseDto;
import com.epay.stubs.dto.TransactionDto;
import com.epay.stubs.exceptions.PaymentException;
import com.epay.stubs.externalservice.CardAdminConfigDetailsClientService;
import com.epay.stubs.externalservice.CardWebClientService;
import com.epay.stubs.mapper.CardPaymentMapper;
import com.epay.stubs.model.request.PaymentInitiationRequest;
import com.epay.stubs.model.request.PaymentRequestCard;
import com.epay.stubs.model.response.*;
import com.epay.stubs.util.*;
import com.epay.stubs.util.enums.PayProcIdRupayCard;
import com.epay.stubs.util.enums.PayProcIdVisaMasterCard;
import com.epay.stubs.util.enums.PaymentStatus;
import com.epay.stubs.validator.PaymentCardValidator;
import com.google.gson.Gson;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.text.MessageFormat;
import java.util.*;

@RequiredArgsConstructor
@Service
public class CardInitiationIntlService {
    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private final CardIntlUtil cardINTLUtil;
    private final CardEncryptionDecryptionINTLUtil cardEncryptionDecryptionUtil;
    private final CardPaymentDao cardPaymentDao;
    private final TransactionDao transactionDao;
    private final CardConfigDeatils cardConfigDeatils;
    private final CardWebClientService cardWebClientService;
    private final CardAdminConfigDetailsClientService cardAdminConfigDetailsClientService;
    private final PaymentDao paymentDao;
    private final CardPaymentMapper cardPaymentMapper;
    private final StatusUpdatePaymentDao statusUpdatePaymentDao;
    private final PaymentCardValidator validateCardRequest;
    /**
     * @return: PaymentResponse<CardVisaResponseDto>
     * @methodName: getCardAuthenticationStatus
     * @@Method-Description: Process getting card authentication status
     * @param: paymentRequestCard
     * @Exception: or @Error :Exception
     */

    public PaymentResponse<?>  getCardAuthenticationStatus(PaymentRequestCard paymentRequestCard) {
        PaymentInitiationRequest paymentInitiationRequest = getInitiationCardsRequest(paymentRequestCard);
        validateCardRequest.validateCardRequest(paymentInitiationRequest);
        validateCardRequest.validateOpModeValue(paymentInitiationRequest.getPayProcId(), Arrays.stream(PayProcIdVisaMasterCard.values()).map(Enum::name).toList(), PaymentConstants.PAYPROCID_CONST, MessageFormat.format(PaymentConstants.INVALID_FORMAT_MESSAGE, PaymentConstants.PAYPROCID_CONST));
        TransactionDto transactionDto = transactionDao.getValidPaymentAckReq(paymentRequestCard.getAtrn(), PaymentStatus.BOOKED.toString(), paymentRequestCard.getPaymode());
        logger.info("transactionDto {} for reference no {} ", transactionDto, transactionDto.getAtrnNum());

        CardVisaResponseDto cardVisaResponseDto = CardVisaResponseDto.builder()
                .atrn(paymentRequestCard.getAtrn())
                .availableAuthMode("VISA MASTER Redirection")
                .cardPaymentStatus("Pending")
                .creq("eyJ0aHJlZURTU2VydmVyVHJhbnNJRCI6IjA3MGIzMDkyLTMyODEtNDZlMy05NmUzLTkwZTBjNTM3ODFhMyIsImFjc1RyYW5zSUQiOiIxZjVkM2I0YS0xZWE1LTRmMWMtYjE5My00YTRjY2I4OGZmMTIiLCJtZXNzYWdlVHlwZSI6IkNSZXEiLCJtZXNzYWdlVmVyc2lvbiI6IjIuMi4wIiwiY2hhbGxlbmdlV2luZG93U2l6ZSI6IjA0In0")
                .postURL("https://crqsbiacs.sbi/acs/BRW/CReqCreate?acsTransId=1f5d3b4a-1ea5-4f1c-b193-4a4ccb88ff12&timestamp=1748240107899&nonce=fmcnctym&signature=1ae3f82f2b3017852eb48c22e73a71a6c77b835dc5ba52bb696bddc2c30fe874").build();

        logger.info("PaymentVisaCard Response {} ", cardVisaResponseDto);
        return PaymentResponse.<CardVisaResponseDto>builder().data(List.of(cardVisaResponseDto)).status(PaymentConstants.API_RESPONSE_STATUS_SUCCESS).build();

    }

    /**
     * @return: PaymentResponse<CardVisaResponseDto>
     * @methodName: getCardAuthenticationStatusRupay
     * @@Method-Description: Process getting card authentication status
     * @param: paymentRequestCard
     * @Exception: or @Error :Exception
     */
    public PaymentResponse<?>  getCardAuthenticationStatusRupay(PaymentRequestCard paymentRequestCard) {
        PaymentInitiationRequest paymentInitiationRequest=getInitiationCardsRequest(paymentRequestCard);
        validateCardRequest.validateCardRequest(paymentInitiationRequest);
        validateCardRequest.validateOpModeValue(paymentInitiationRequest.getPayProcId(), Arrays.stream(PayProcIdRupayCard.values()).map(Enum::name).toList(),PaymentConstants.PAYPROCID_CONST,MessageFormat.format(PaymentConstants.INVALID_FORMAT_MESSAGE, PaymentConstants.PAYPROCID_CONST));

        TransactionDto transactionDto = transactionDao.getValidPaymentAckReq(paymentRequestCard.getAtrn(), PaymentStatus.BOOKED.toString());
        logger.info("transactionDto {} for reference no {} ",transactionDto,transactionDto.getAtrnNum());
        CardOnBoardDetailsResponseDto cardOnboardDto=getConfigDetails(transactionDto.getMerchantId());
        logger.info("Merchant Onboard Details Fetched cardOnBoardDetailsResponseDto {} for reference no {} ",cardOnboardDto,transactionDto.getAtrnNum());
        BinCheckResponse sbiPGBinCheckResponse = processBinCheck(transactionDto,paymentRequestCard);
        logger.info("Check Bin response sbiPGBinCheckResponse {} for reference no {} ",sbiPGBinCheckResponse,transactionDto.getAtrnNum());
        if(PaymentConstants.successBin.equalsIgnoreCase(sbiPGBinCheckResponse.getStatus()) && !PaymentConstants.ONE.equalsIgnoreCase(sbiPGBinCheckResponse.getAvailableAuthMode())) {
            GenerateOTPResponse generateOTPResponse = processGenerateOTP(cardOnboardDto,transactionDto,paymentRequestCard);
            logger.info("Inside Rupay Generate OTP generateOTPResponse {} for reference no {} ",generateOTPResponse,transactionDto.getAtrnNum());
            if (PaymentConstants.success.equalsIgnoreCase(generateOTPResponse.getStatus())){
                CardRupaySeamlessResponseDto cardRupaySeamlessResponseDto = CardRupaySeamlessResponseDto.builder().status(generateOTPResponse.getStatus()).atrn(transactionDto.getAtrnNum()).availableAuthMode(PaymentConstants.RUPAY_Seamless).validityPeriod(generateOTPResponse.getValidityPeriod()).errorcode(generateOTPResponse.getErrorcode()).errormsg(generateOTPResponse.getErrormsg()).pgTransactionId(generateOTPResponse.getPgTransactionId()).build();
                return Optional.ofNullable(PaymentResponse.<CardRupaySeamlessResponseDto>builder().data(List.of(cardRupaySeamlessResponseDto)).status(PaymentConstants.API_RESPONSE_STATUS_SUCCESS).build()).orElseThrow(() -> new PaymentException(CardErrorConstants.PROCESS_SERVICE_ERROR_CODE, MessageFormat.format(CardErrorConstants.PROCESS_SERVICE_ERROR_MESSAGE,PaymentConstants.GenerateOTP)));
            }else{
                return Optional.ofNullable(PaymentResponse.<CardRupaySeamlessResponseDto>builder().status(0).errors(List.of(getResponseDto(generateOTPResponse.getErrorcode(),generateOTPResponse.getErrormsg(),transactionDto.getAtrnNum(),generateOTPResponse.getPgTransactionId()))).build()).orElseThrow(() -> new PaymentException(CardErrorConstants.PROCESS_SERVICE_ERROR_CODE, MessageFormat.format(CardErrorConstants.PROCESS_SERVICE_ERROR_MESSAGE,PaymentConstants.GenerateOTP)));
            }
        }else if(PaymentConstants.successBin.equalsIgnoreCase(sbiPGBinCheckResponse.getStatus())){
            InitiateResponse initiateResponse = processInitiate2(cardOnboardDto, transactionDto, paymentRequestCard);
            logger.info("Inside Rupay initiateResponse {} for reference no {} ",initiateResponse, transactionDto.getAtrnNum());
            if (PaymentConstants.success.equalsIgnoreCase(initiateResponse.getStatus())) {
                Map<String, String> initiate2Map = cardEncryptionDecryptionUtil.getMapData(initiateResponse.getRedirectURL());
                CardRupayResponseDto cardRupayResponseDto = CardRupayResponseDto.builder().status(initiateResponse.getStatus()).atrn(transactionDto.getAtrnNum()).initiate2API(initiate2Map.get(PaymentConstants.RedirectURL)).accuCardholderId(initiate2Map.get(PaymentConstants.AccuCardholderId)).accuGuid(initiate2Map.get(PaymentConstants.AccuGuid)).accuReturnURL(cardConfigDeatils.getReverseURL_intl()).session(initiateResponse.getSession()).accuRequestId(initiateResponse.getAccuRequestId()).availableAuthMode(PaymentConstants.RUPAY_Redirection).build();
                return Optional.ofNullable(PaymentResponse.<CardRupayResponseDto>builder().data(List.of(cardRupayResponseDto)).status(PaymentConstants.API_RESPONSE_STATUS_SUCCESS).build()).orElseThrow(() -> new PaymentException(CardErrorConstants.PROCESS_SERVICE_ERROR_CODE, MessageFormat.format(CardErrorConstants.PROCESS_SERVICE_ERROR_MESSAGE,PaymentConstants.Initiate2)));
            } else {
                return Optional.ofNullable(PaymentResponse.<CardRupayResponseDto>builder().status(0).errors(List.of(getResponseDto(initiateResponse.getErrorcode(),initiateResponse.getErrormsg(),transactionDto.getAtrnNum(),initiateResponse.getPgTransactionId()))).build()).orElseThrow(() -> new PaymentException(CardErrorConstants.PROCESS_SERVICE_ERROR_CODE, MessageFormat.format(CardErrorConstants.PROCESS_SERVICE_ERROR_MESSAGE,PaymentConstants.Initiate2)));
            }
        }else {
            return Optional.ofNullable(PaymentResponse.<CardRupayResponseDto>builder().status(0).errors(List.of(getResponseDto(sbiPGBinCheckResponse.getErrorcode(),sbiPGBinCheckResponse.getErrormsg(),transactionDto.getAtrnNum(),transactionDto.getAtrnNum()))).build()).orElseThrow(() -> new PaymentException(CardErrorConstants.PROCESS_SERVICE_ERROR_CODE, MessageFormat.format(CardErrorConstants.PROCESS_SERVICE_ERROR_MESSAGE,PaymentConstants.CheckBin)));
        }
    }
    /**
     * @return: SaleAPIResponse
     * @methodName: processSaleRequest
     * @@Method-Description: Process sale request
     * @param: cardOnboardDto,  transactionDto,  paymentRequestCard,  altIDResponse,  pArqResponse
     * @Exception: or @Error :Exception
     */

    public SaleAPIResponse processSaleRequest(CardOnBoardDetailsResponseDto cardOnboardDto, TransactionDto transactionDto, PaymentRequestCard paymentRequestCard, PArqResponse pArqResponse)  {
        SaleAPIResponse saleAPIResponse;
        String saleRequestPayload = cardINTLUtil.createSaleSeamRequestPayload(cardOnboardDto,transactionDto , paymentRequestCard, pArqResponse);
        paymentDao.saveRequestLog(saleRequestPayload,transactionDto.getAtrnNum(),PaymentConstants.SALE_REQ,PaymentConstants.CREATED_BY_WIBMOPG);
        logger.info("Sale API Request {} for reference no {} ",saleRequestPayload,transactionDto.getAtrnNum());
        String encryptedSaleRequest = cardINTLUtil.getEncryptedPayload(saleRequestPayload);
        HashMap<String, String> cardRequestHeaders = cardINTLUtil.createThreeDsRequestHeader(cardConfigDeatils.getApi_key_intl(),cardConfigDeatils.getPgInstanceId());
        String apiResponse = cardWebClientService.initiateCardWebClient(cardConfigDeatils.getSaleAuthURL_intl(), encryptedSaleRequest, String.class, cardRequestHeaders);
        logger.info("Sale API Response {} for reference no {} ",apiResponse,transactionDto.getAtrnNum());
        String decryptedRequestPayload= cardINTLUtil.getDecryptedPayload(apiResponse);
        saleAPIResponse= new Gson().fromJson(decryptedRequestPayload, SaleAPIResponse.class);
        paymentDao.saveResponseLog(decryptedRequestPayload,transactionDto.getAtrnNum(),saleAPIResponse.getTransactionId(),PaymentConstants.SALE_RESP,PaymentConstants.CREATED_BY_WIBMOPG);
        cardPaymentDao.processSaleApiResponse(saleAPIResponse,transactionDto);
        return Optional.of(saleAPIResponse).orElseThrow(() -> new PaymentException(CardErrorConstants.PROCESS_SERVICE_ERROR_CODE, MessageFormat.format(CardErrorConstants.PROCESS_SERVICE_ERROR_MESSAGE,PaymentConstants.SALE)));
    }

    /**
     * @return: PVrqResponse
     * @methodName: processPvrqVersioning
     * @@Method-Description: Process pVrq request
     * @param: transactionDto,  paymentRequestCard,  tokenAltResponse
     * @Exception: or @Error :Exception
     */

    public PVrqResponse processPvrqVersioning(TransactionDto transactionDto, PaymentRequestCard paymentRequestCard) {
        String pvrqVersioningRequestPayload = cardINTLUtil.createPvrqVersioningPayload(paymentRequestCard);
        logger.info("pVrq Request {} for reference no {} ",pvrqVersioningRequestPayload,transactionDto.getAtrnNum());
        paymentDao.saveRequestLog(pvrqVersioningRequestPayload,transactionDto.getAtrnNum(),PaymentConstants.PVRQ_REQ,PaymentConstants.CREATED_BY_WIBMOPG);
        String signedEncRequestPayload = cardINTLUtil.getEncryptedpvrqPayload(pvrqVersioningRequestPayload);
        HashMap<String, String> cardRequestHeaders = cardINTLUtil.createThreeDsRequestHeader(cardConfigDeatils.getApi_key_intl(),cardConfigDeatils.getAcquirerID());
        String pVrqApiResponse = cardWebClientService.initiateCardWebClient(cardConfigDeatils.getPvReqURL_intl()+paymentRequestCard.getAtrn(), signedEncRequestPayload, String.class, cardRequestHeaders);
        logger.info("pVrq Response {} for reference no {} ",pVrqApiResponse,transactionDto.getAtrnNum());
        String decryptedRequestPayload= cardINTLUtil.getDecryptedPayload(pVrqApiResponse);
        paymentDao.saveResponseLog(decryptedRequestPayload,transactionDto.getAtrnNum(),transactionDto.getAtrnNum(),PaymentConstants.PVRQ_RESP,PaymentConstants.CREATED_BY_WIBMOPG);
        return Optional.ofNullable(new Gson().fromJson(decryptedRequestPayload, PVrqResponse.class)).orElseThrow(() -> new PaymentException(CardErrorConstants.PROCESS_SERVICE_ERROR_CODE, MessageFormat.format(CardErrorConstants.PROCESS_SERVICE_ERROR_MESSAGE,PaymentConstants.messageType_PVRQ)));
    }

    /**
     * @return: PArqResponse
     * @methodName: processParqAuthentication
     * @@Method-Description: Process pArq request
     * @param: transactionDto, cardOnboardDto,  paymentRequestCard,  altIDResponse,  pArqResponse
     * @Exception: or @Error :Exception
     */

    public PArqResponse processParqAuthentication(TransactionDto transactionDto,CardOnBoardDetailsResponseDto cardOnboardDto, PaymentRequestCard paymentRequestCard,PVrqResponse pVrqResponse)  {
        String createParqRequestPayload = cardINTLUtil.createParqPayload(transactionDto, cardOnboardDto, paymentRequestCard, pVrqResponse);
        logger.info("pVrq createParqRequestPayload {} for reference no {} ",createParqRequestPayload, transactionDto.getAtrnNum());
        paymentDao.saveRequestLog(createParqRequestPayload, transactionDto.getAtrnNum(), PaymentConstants.PARQ_REQ, PaymentConstants.CREATED_BY_WIBMOPG);
        String signedEncRequestPayload = cardINTLUtil.getEncryptedpvrqPayload(createParqRequestPayload);
        HashMap<String, String> cardRequestHeaders = cardINTLUtil.createThreeDsRequestHeader(cardConfigDeatils.getApi_key_intl(), cardConfigDeatils.getPgInstanceId_1());
        String pArqApiResponse = cardWebClientService.initiateCardWebClient(pVrqResponse.getThreeDSServerPaRqURL(), signedEncRequestPayload, String.class, cardRequestHeaders);
        logger.info("pVrq Response {} for reference no {} ",pArqApiResponse,transactionDto.getAtrnNum());
        String decryptedRequestPayload = cardINTLUtil.getDecryptedPayload(pArqApiResponse);
        paymentDao.saveResponseLog(decryptedRequestPayload, transactionDto.getAtrnNum(), pVrqResponse.getThreeDSServerTransID(),PaymentConstants.PARQ_RESP, PaymentConstants.CREATED_BY_WIBMOPG);
        cardPaymentDao.saveCardSummery(transactionDto.getAtrnNum(), cardINTLUtil.maskAltId(paymentRequestCard.getAltNumber(),6,4),transactionDto.getMerchantId(), String.valueOf(transactionDto.getDebitAmt()), pVrqResponse.getThreeDSServerTransID(),
                cardINTLUtil.saveSummaryData(cardINTLUtil.getAltIdToken(paymentRequestCard),pVrqResponse, new Gson().fromJson(decryptedRequestPayload, PArqResponse.class)), cardINTLUtil.hashValue(paymentRequestCard.getAltNumber()));
        return Optional.ofNullable(new Gson().fromJson(decryptedRequestPayload, PArqResponse.class)).orElseThrow(() -> new PaymentException(CardErrorConstants.PROCESS_SERVICE_ERROR_CODE, MessageFormat.format(CardErrorConstants.PROCESS_SERVICE_ERROR_MESSAGE,PaymentConstants.messageType_PVRQ)));
    }

    /**
     * @return: GenerateOTPResponse
     * @methodName: processGenerateOTP
     * @@Method-Description: Process Generate OTP request
     * @param: cardOnboardDto,transactionDto, paymentRequestCard
     * @Exception: or @Error :Exception
     */

    public GenerateOTPResponse processGenerateOTP(CardOnBoardDetailsResponseDto cardOnboardDto,TransactionDto transactionDto, PaymentRequestCard paymentRequestCard) {
        String generateOTPRequestPayload = cardINTLUtil.createGenerateOTPRequest(cardOnboardDto, transactionDto, paymentRequestCard);
        paymentDao.saveRequestLog(generateOTPRequestPayload, transactionDto.getAtrnNum(), PaymentConstants.GenerateOTP_REQ, PaymentConstants.CREATED_BY_WIBMOPG);
        logger.info("Generate OTP API generateOTPRequestPayload {} for reference no {} ",generateOTPRequestPayload, transactionDto.getAtrnNum());
        String signedEncRequestPayload = cardINTLUtil.getEncryptedpvrqPayload(generateOTPRequestPayload);
        HashMap<String, String> cardRequestHeaders = cardINTLUtil.createThreeDsRequestHeader(cardConfigDeatils.getApi_key_intl(), cardConfigDeatils.getPgInstanceId_2());
        String apiResponse = cardWebClientService.initiateCardWebClient(cardConfigDeatils.getGenerateOtpURL_intl().trim(), signedEncRequestPayload, String.class, cardRequestHeaders);
        logger.info("Generate OTP API Response {} for reference no {} ",apiResponse, transactionDto.getAtrnNum());
        String decryptedResponse = cardINTLUtil.getDecryptedResponse(apiResponse);
        GenerateOTPResponse  generateOTPResponse = new Gson().fromJson(decryptedResponse, GenerateOTPResponse.class);
        paymentDao.saveResponseLog(generateOTPResponse.toString(), transactionDto.getAtrnNum(),generateOTPResponse.getPgTransactionId(), PaymentConstants.GenerateOTP_RESP, PaymentConstants.CREATED_BY_WIBMOPG);
        cardPaymentDao.saveCardSummery(transactionDto.getAtrnNum(), cardINTLUtil.maskAltId(paymentRequestCard.getAltNumber(),6,4),transactionDto.getMerchantId(),String.valueOf(transactionDto.getDebitAmt()),transactionDto.getAtrnNum(), getCardByte(paymentRequestCard,PaymentConstants.NA,PaymentConstants.NA), cardINTLUtil.hashValue(paymentRequestCard.getAltNumber()));
        return Optional.of(generateOTPResponse).orElseThrow(() -> new PaymentException(CardErrorConstants.PROCESS_SERVICE_ERROR_CODE, MessageFormat.format(CardErrorConstants.PROCESS_SERVICE_ERROR_MESSAGE,PaymentConstants.GenerateOTP)));
    }

    /**
     * @return: BinCheckResponse
     * @methodName: processBinCheck
     * @@Method-Description: Process bin check request
     * @param: transactionDto, paymentRequestCard
     * @Exception: or @Error :Exception
     */

    public BinCheckResponse processBinCheck(TransactionDto transactionDto, PaymentRequestCard paymentRequestCard) {
        String checkBinRequestPayload = cardINTLUtil.createCheckBinRequest(paymentRequestCard);
        paymentDao.saveRequestLog(checkBinRequestPayload,transactionDto.getAtrnNum(),PaymentConstants.checkBin_REQ,PaymentConstants.CREATED_BY_WIBMOPG);
        logger.info("binCheck API checkBinRequestPayload {} for reference no {} ",checkBinRequestPayload, transactionDto.getAtrnNum());
        String signedEncRequestPayload = cardINTLUtil.getEncryptedpvrqPayload(checkBinRequestPayload);
        HashMap<String, String> cardRequestHeaders = cardINTLUtil.createAuthorizationRequestHeader(cardConfigDeatils.getApi_key_intl(),cardConfigDeatils.getPgInstanceId_2(),cardConfigDeatils.getPgInstanceId_2());
        String apiResponse = cardWebClientService.initiateCardWebClient(cardConfigDeatils.getCheckbinURL_intl(), signedEncRequestPayload, String.class, cardRequestHeaders);
        logger.info("binCheck ResponseCode {} for reference no {} ",apiResponse,transactionDto.getAtrnNum());
        String decryptedResponse = cardINTLUtil.getDecryptedResponse(apiResponse);
        paymentDao.saveResponseLog(new Gson().fromJson(decryptedResponse, BinCheckResponse.class).toString(),transactionDto.getAtrnNum(),transactionDto.getAtrnNum(),PaymentConstants.checkBin_RESP,PaymentConstants.CREATED_BY_WIBMOPG);
        return Optional.ofNullable(new Gson().fromJson(decryptedResponse, BinCheckResponse.class)).orElseThrow(() -> new PaymentException(CardErrorConstants.PROCESS_SERVICE_ERROR_CODE, MessageFormat.format(CardErrorConstants.PROCESS_SERVICE_ERROR_MESSAGE,PaymentConstants.CheckBin)));
    }

    /**
     * @return: InitiateResponse
     * @methodName: processInitiate2
     * @@Method-Description: Process Initiate2 request
     * @param: cardOnboardDto,transactionDto, paymentRequestCard
     * @Exception: or @Error :Exception
     */

    public InitiateResponse processInitiate2(CardOnBoardDetailsResponseDto cardOnboardDto,TransactionDto transactionDto, PaymentRequestCard paymentRequestCard) {
        String initiate2RquestPayload = cardINTLUtil.createInitiate2Request(cardOnboardDto,transactionDto,paymentRequestCard);
        paymentDao.saveRequestLog(initiate2RquestPayload,transactionDto.getAtrnNum(),PaymentConstants.Initiate2_REQ,PaymentConstants.CREATED_BY_WIBMOPG);
        logger.info("Initiate 2 API initiate2RquestPayload {} for reference no {} ",initiate2RquestPayload,transactionDto.getAtrnNum());
        String signedEncRequestPayload = cardINTLUtil.getEncryptedpvrqPayload(initiate2RquestPayload);
        HashMap<String, String> cardRequestHeaders = cardINTLUtil.createAuthorizationRequestHeader(cardConfigDeatils.getApi_key_intl(),cardConfigDeatils.getPgInstanceId_2(),cardConfigDeatils.getPgInstanceId_2());
        String apiResponse = cardWebClientService.initiateCardWebClient(cardConfigDeatils.getInitiateURL_intl(), signedEncRequestPayload, String.class, cardRequestHeaders);
        logger.info("Initiate 2 API Response {} ",apiResponse);
        String decryptedResponse = cardINTLUtil.getDecryptedResponse(apiResponse);
        InitiateResponse  initiateResponse = new Gson().fromJson(decryptedResponse, InitiateResponse.class);
        paymentDao.saveResponseLog(initiateResponse.toString(),transactionDto.getAtrnNum(),initiateResponse.getPgTransactionId(),PaymentConstants.Initiate2_RESP,PaymentConstants.CREATED_BY_WIBMOPG);
        String pgTransactionId = initiateResponse.getPgTransactionId()==null ? PaymentConstants.NA : initiateResponse.getPgTransactionId();
        String rupayTransactionId = initiateResponse.getRupayTransactionId()==null ? PaymentConstants.NA : initiateResponse.getRupayTransactionId();
        cardPaymentDao.saveCardSummery(transactionDto.getAtrnNum(), cardINTLUtil.maskAltId(paymentRequestCard.getAltNumber(),6,4),transactionDto.getMerchantId(),String.valueOf(transactionDto.getDebitAmt()),pgTransactionId,getCardByte(paymentRequestCard,rupayTransactionId,pgTransactionId), cardINTLUtil.hashValue(paymentRequestCard.getAltNumber()));
        return Optional.of(initiateResponse).orElseThrow(() -> new PaymentException(CardErrorConstants.PROCESS_SERVICE_ERROR_CODE, MessageFormat.format(CardErrorConstants.PROCESS_SERVICE_ERROR_MESSAGE,PaymentConstants.Initiate2)));
    }

    public CardOnBoardDetailsResponseDto getConfigDetails(String merchantId) {
        ResponseDto<CardOnBoardDetailsResponseDto> cardConfigDetails = cardAdminConfigDetailsClientService.getCardConfigDetails(merchantId);
        return Optional.of(cardPaymentMapper.mapToCardOnBoardDetailsResponseDto(cardConfigDetails.getData().getFirst())).orElseThrow(() -> new PaymentException(CardErrorConstants.PROCESS_SERVICE_ERROR_CODE, MessageFormat.format(CardErrorConstants.PROCESS_SERVICE_ERROR_MESSAGE,PaymentConstants.Card_Onboard)));
    }

    public String getCardByte(PaymentRequestCard paymentRequestCard,String rupayTransactionId,String pgTransactionId){
        return Base64.getEncoder().encodeToString((paymentRequestCard.getAltNumber().concat(PaymentConstants.PIPE_CONST)).concat(paymentRequestCard.getExpiryMonth().concat(PaymentConstants.PIPE_CONST)).concat(paymentRequestCard.getExpiryYear().concat(PaymentConstants.PIPE_CONST)).concat(paymentRequestCard.getCvv().concat(PaymentConstants.PIPE_CONST)).concat(paymentRequestCard.getCardHolderName().concat(PaymentConstants.PIPE_CONST)).concat(paymentRequestCard.getPayProcId().concat(PaymentConstants.PIPE_CONST)).concat(rupayTransactionId.concat(PaymentConstants.PIPE_CONST)).concat(pgTransactionId).getBytes());
    }
    /**
     * @return: ErrorDto
     * @methodName: getResponseDto
     * @@Method-Description: Process getting card response Error Codes
     * @param: paymentRequestCard
     * @Exception: or @Error :Exception
     */
    public ErrorDto  getResponseDto(String errorCode,String errorMessage,String atrn,String bankReferenceNumber){
        statusUpdatePaymentDao.paymentFailureStatusUpdate(atrn, bankReferenceNumber == null ? PaymentConstants.ZERO : bankReferenceNumber,errorCode == null ? PaymentConstants.NA : errorCode.concat(PaymentConstants.PIPE).concat(errorMessage), PaymentConstants.CREATED_BY_WIBMOPG);
        return ErrorDto.builder().errorCode(ErrorConstants.CARD_INITIATION_ERROR_CODE).errorMessage(ErrorConstants.CARD_INITIATION_ERROR_MESSAGE).build();
    }

    public PaymentInitiationRequest getInitiationCardsRequest(PaymentRequestCard paymentRequestCard){
        return Optional.of(PaymentInitiationRequest.builder()
                .atrn(paymentRequestCard.getAtrn())
                .paymode(paymentRequestCard.getPaymode())
                .operatingMode(paymentRequestCard.getOperatingMode())
                .payProcId(paymentRequestCard.getPayProcId())
                .payProcType(paymentRequestCard.getPayProcType())
                .altNumber(paymentRequestCard.getAltNumber())
                .expiryMonth(paymentRequestCard.getExpiryMonth())
                .expiryYear(paymentRequestCard.getExpiryYear())
                .cvv(paymentRequestCard.getCvv())
                .cardHolderName(paymentRequestCard.getCardHolderName())
                .build()).orElseThrow(() -> new PaymentException(CardErrorConstants.PROCESS_SERVICE_ERROR_CODE, MessageFormat.format(CardErrorConstants.PROCESS_SERVICE_ERROR_MESSAGE,PaymentConstants.Authentication)));
    }

}
