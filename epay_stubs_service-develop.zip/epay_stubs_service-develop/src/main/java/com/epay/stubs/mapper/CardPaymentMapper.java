package com.epay.stubs.mapper;

import com.epay.stubs.dto.CardOnBoardDetailsResponseDto;
import com.epay.stubs.dto.CardSummeryDto;
import com.epay.stubs.entity.CardSummeryEntity;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;

@Mapper(builder = @Builder(disableBuilder = true), componentModel = "spring")
public interface CardPaymentMapper {
    CardOnBoardDetailsResponseDto mapToCardOnBoardDetailsResponseDto(CardOnBoardDetailsResponseDto source);
    CardSummeryEntity mapToCardSummeryEntity(CardSummeryDto source);
}
