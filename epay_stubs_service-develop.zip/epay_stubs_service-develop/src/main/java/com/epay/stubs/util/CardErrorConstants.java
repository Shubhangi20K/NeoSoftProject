package com.epay.stubs.util;

/**
 * Class Name:
 * *
 * Description: Customer creation for given Merchant.
 * *
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */


public class CardErrorConstants {

    //Card Payments
    public static final String PROCESS_SERVICE_ERROR_CODE = "3201";
    public static final String PROCESS_SERVICE_ERROR_MESSAGE = "Failed In Processing {0} Service  ";

    public static final String AMOUNT_MISMATCHED_ERROR_CODE = "3202";
    public static final String AMOUNT_MISMATCHED_ERROR_MESSAGE = "Request Amount is mismatched";

}
