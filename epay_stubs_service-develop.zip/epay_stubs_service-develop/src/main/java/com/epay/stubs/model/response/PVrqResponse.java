package com.epay.stubs.model.response;

import lombok.*;

import java.util.LinkedHashMap;

/**
 * Class Name:PVrqResponse
 * *
 * Description: Card Stubs Service
 * *
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */

//@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Setter
@Getter
public class PVrqResponse {
    private String messageType;
    private String deviceChannel;
    private String p_messageVersion;
    private String acsStartVersion;
    private String acsEndVersion;
    private String dsStartVersion;
    private String dsEndVersion;
    private String merchantTransID;
    private String threeDSServerPaRqURL;
    private String threeDSServerTransID;
    private String threeDSACSMethodURL;
    private String threeDSJSBrowserDetailFetchURL;
    private String acsInfoInd[];
    private String scheme;
    private String errorCode;
    private LinkedHashMap<String, String> threeDSMethodDataFormPost;
    private String threeDSMethodData;
}
