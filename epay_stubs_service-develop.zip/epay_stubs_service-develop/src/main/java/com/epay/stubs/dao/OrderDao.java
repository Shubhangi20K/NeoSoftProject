package com.epay.stubs.dao;

import com.epay.stubs.dto.TransactionDto;
import com.epay.stubs.entity.Order;
import com.epay.stubs.exceptions.PaymentException;
import com.epay.stubs.repository.OrderRepository;
import com.epay.stubs.util.ErrorConstants;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.text.MessageFormat;

/**
 * Class Name: OrderDao
 * *
 * Description:
 * Copyright (c) 2024 [State Bank of India]
 * ALl rights reserved
 * *
 * Version: 1.0
 */
@Component
@RequiredArgsConstructor
public class OrderDao {

    private final OrderRepository orderRepository;

    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());

    public Order getOrderDetails(TransactionDto transactionDto) {

        return orderRepository.findBySbiOrderRefNumberAndOrderRefNumber(transactionDto.getSbiOrderRefNumber(), transactionDto.getOrderRefNumber())
                .orElseThrow(() -> new PaymentException(ErrorConstants.NOT_FOUND_ERROR_CODE, MessageFormat
                        .format(ErrorConstants.NOT_FOUND_ERROR_MESSAGE, "Order")));
    }


}
