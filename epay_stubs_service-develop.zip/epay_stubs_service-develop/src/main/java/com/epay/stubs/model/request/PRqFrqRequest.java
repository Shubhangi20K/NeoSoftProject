package com.epay.stubs.model.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Class Name:PRqFrqRequest
 * *
 * Description: Card Stubs Service
 * *
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PRqFrqRequest {
    private String messageType;
    private String messageVersion;
    private String threeDSServerTransID;
    private String acsTransID;
    private String dsTransID;
    private String merchantTransID;
    private String acquirerID;
    private String acsAuthResponse;
    private String p_messageVersion;
}
