package com.epay.stubs.model.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Class Name:SaleEncResponse
 * *
 * Description: Card Stubs Service
 *
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SaleEncResponse {
    private String signedEncResponsePayload;
    private String responseSymmetricEncKey;
    private String iv;
    private String clientReferenceId;
    private String statusCode;
    private String errorMessage;
    private String var1;
    private String var2;
    private String var3;
}
