package com.epay.stubs.model.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * Class Name: PaymentRequestVerifyCard
 * *
 * Description: Card Payment Service
 * *
 * Author: VCE2656 - Vinod Bhosale (Dev Lead SBIePAY)
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PaymentRequestVerifyCard implements Serializable {

    @NotBlank(message = "{paymentInitiationRequest.error.NotBlank}")
    @SerializedName(value = "atrn")
    @JsonProperty(value = "atrn")
    private String atrn;

    @NotBlank(message = "{paymentInitiationRequest.error.NotBlank}")
    @SerializedName(value = "pgtransactionid")
    @JsonProperty(value = "pgtransactionid")
    private String pgtransactionid;

    @NotBlank(message = "{paymentInitiationRequest.error.NotBlank}")
    @SerializedName(value = "apiType")
    @JsonProperty(value = "apiType")
    private String apiType;

    @NotBlank(message = "{paymentInitiationRequest.error.NotBlank}")
    @SerializedName(value = "otp")
    @JsonProperty(value = "otp")
    private String otp;

}
