package com.epay.stubs.model.response;

import com.google.gson.annotations.SerializedName;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * Class Name:TokenResponse
 * *
 * Description: Card Payment Service
 *
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ACSResponse implements Serializable {
    @NotBlank(message = "threeDSServerTransID is required")
    @SerializedName(value = "threeDSServerTransID")
    private String threeDSServerTransID;
    @NotBlank(message = "acsTransID is required")
    @SerializedName(value = "acsTransID")
    private String acsTransID;
    @NotBlank(message = "messageType is required")
    @SerializedName(value = "messageType")
    private String messageType;
    @NotBlank(message = "messageVersion is required")
    @SerializedName(value = "messageVersion")
    private String messageVersion;
    @NotBlank(message = "challengeCompletionInd is required")
    @SerializedName(value = "challengeCompletionInd")
    private String challengeCompletionInd;
    @NotBlank(message = "transStatus is required")
    @SerializedName(value = "transStatus")
    private String transStatus;
}
