package com.epay.stubs.dto;


import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UpiGenericVpaQrWebResponse implements Serializable {

    @SerializedName(value = "resp")
    @JsonProperty(value = "resp")
    private String resp;
}
