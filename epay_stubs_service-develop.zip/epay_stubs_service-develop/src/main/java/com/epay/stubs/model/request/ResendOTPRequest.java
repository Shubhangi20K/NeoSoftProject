package com.epay.stubs.model.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Class Name:ResendOTPRequest
 * *
 * Description: Card Stubs Service
 * *
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ResendOTPRequest {
    private String pgInstanceId;
    private String merchantId;
    private String merchantReferenceNo;
    private String pgTransactionId;
    private String cardHolderStatus;
}
