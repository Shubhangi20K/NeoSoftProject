package com.epay.stubs.service;

import com.epay.stubs.model.response.InbPostURLResponse;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.math.BigDecimal;

/**
 * Class Name:InbPaymentService
 * *
 * Description:
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */

@RequiredArgsConstructor
@Service
public class InbPaymentService {

    LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());

    public InbPostURLResponse getPostUrl() {
        InbPostURLResponse inbPostURLResponse = InbPostURLResponse.builder()
                .orderNumber("100000117869")
                .orderId("CRED2333")
                .atrn("UP003174348836635487")
                .status("Payment Successful")
                .amount(BigDecimal.valueOf(2)).build();
        logger.info("InbPostURLResponse : {}",inbPostURLResponse);
        return inbPostURLResponse;
    }

}
