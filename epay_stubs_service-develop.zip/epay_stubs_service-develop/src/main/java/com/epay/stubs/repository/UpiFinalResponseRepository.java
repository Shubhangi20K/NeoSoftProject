package com.epay.stubs.repository;

import com.epay.stubs.entity.UpiFinalResponse;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.math.BigDecimal;

public interface UpiFinalResponseRepository extends JpaRepository<UpiFinalResponse,String> {
    @Modifying
    @Transactional
    @Query(value = "INSERT INTO UPI_FINAL_RESPONSE " +
            "(ATRN_NUM, UPI_TRANS_ID, NPCI_TRANS_ID, CUST_REF_NO, AMOUNT, STATUS, STATUS_DESCRIPTION, " +
            "RESPONSE_CODE, PACKET, PAYER_VA, PAYEE_VA, CREATED_DATE, CREATED_BY) " +
            "VALUES (:atrnNum, :upiTransId, :npciTransId, :custRefNo, :amount, :status, :statusDescription, " +
            ":responseCode, :packet, :payerVa, :payeeVa, :createdDate, :createdBy)", nativeQuery = true)
    void insertFinalResponse(@Param("atrnNum") String atrnNum, @Param("upiTransId") String upiTransId, @Param("npciTransId") String npciTransId, @Param("custRefNo") String custRefNo,
            @Param("amount") BigDecimal amount, @Param("status") String status, @Param("statusDescription") String statusDescription, @Param("responseCode") String responseCode,
            @Param("packet") String packet, @Param("payerVa") String payerVa, @Param("payeeVa") String payeeVa, @Param("createdDate") Long createdDate, @Param("createdBy") String createdBy
    );
}
