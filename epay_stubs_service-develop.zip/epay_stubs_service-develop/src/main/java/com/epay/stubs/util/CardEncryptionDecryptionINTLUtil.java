package com.epay.stubs.util;

import com.epay.stubs.config.CardConfigDeatils;
import com.epay.stubs.exceptions.PaymentException;
import com.epay.stubs.model.response.TokenAltResponse;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.apache.commons.codec.binary.Hex;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

import javax.crypto.Cipher;
import javax.crypto.Mac;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.security.SignatureException;
import java.security.interfaces.RSAPublicKey;
import java.text.MessageFormat;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Class Name:CardEncryptionDecryptionUtil
 * *
 * Description: Card Payment Service
 * *
 * Author: VCE2656 - Vinod Bhosale (Dev Lead SBIePAY)
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@RequiredArgsConstructor
@Component
public class CardEncryptionDecryptionINTLUtil {

    LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());

    private final CardConfigDeatils cardConfigDeatils;

    //**************************** Encryption Util Start *********************

    public Map<String, String> getMapData(String xmlResponse) throws NullPointerException,ClassCastException{
        String []dataStr = xmlResponse.split("\\?");
        String[] respData = dataStr[1].split("\\&");

        Map<String, String> mapRespData = new ConcurrentHashMap<>();
        mapRespData.put(PaymentConstants.RedirectURL,dataStr[0]+"?");
        for(String str: respData){
            String tempData[] = str.split("=");

            if(tempData.length>1)
                mapRespData.put(tempData[0].trim(), tempData[1]==null ? "" : tempData[1].trim());

        }

        return mapRespData;
    }

   
    public String generateHashWithTimeStamp(String vaultId, String clientId, String apiUser, String apiKey, String salt, long timestamp){
        String data = timestamp+"|"+vaultId+"|"+clientId +"|"+apiUser+"|"+apiKey;
        try{
        String digest = getDigest(PaymentConstants.HMAC_256, salt, data , false);
            digest=PaymentConstants.WTV_CONST+timestamp+":"+digest;
        return digest;
        } catch (Exception e) { // Exception throw by Card PG
            logger.error("Exception While generateHashWithTS  {}", e);
            throw new PaymentException(ErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(ErrorConstants.INVALID_ERROR_MESSAGE, PaymentConstants.CHECKSUM,PaymentConstants.CHECKSUM_ERROR));
        }
    }

   
    public String getDigest(String algorithm, String sharedSecret, String data, boolean toLower) throws SignatureException {
        try{
        Mac sha256HMAC = Mac.getInstance(algorithm);
        SecretKeySpec secretKey = new SecretKeySpec(sharedSecret.getBytes(), algorithm);
        sha256HMAC.init(secretKey);
        byte[] hashByte = sha256HMAC.doFinal(data.getBytes());
        String hashString = toHex(hashByte);
        return toLower ? hashString.toLowerCase() : hashString;
        } catch (Exception e) { // Exception throw by Card PG
            logger.error("Exception While getDigest  {}", e);
            throw new PaymentException(ErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(ErrorConstants.INVALID_ERROR_MESSAGE, PaymentConstants.GET_BYTES,PaymentConstants.GET_BYTES_ERROR));
        }
    }

    public String toHex(byte[] bytes) {
        BigInteger bi = new BigInteger(1, bytes);
        return String.format("%0" + (bytes.length << 1) + "X", bi);
    }

   
    public String encrypt(byte[] plaintext, SecretKey key, byte[] IV) {
        // Get Cipher Instance
        try{
        Cipher cipher = Cipher.getInstance(PaymentConstants.AES_PADDING);
        // Create GCMParameterSpec
        GCMParameterSpec gcmParameterSpec = new GCMParameterSpec(16 * 8, IV);

        // Initialize Cipher for ENCRYPT_MODE
        cipher.init(Cipher.ENCRYPT_MODE, key, gcmParameterSpec);

        // Perform Encryption
        byte[] cipherText = cipher.doFinal(plaintext);

        return new String(Hex.encodeHex(cipherText));
        } catch (Exception e) { // Exception throw by Card PG
            logger.error("Exception While Encrypt  {}", e);
            throw new PaymentException(ErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(ErrorConstants.INVALID_ERROR_MESSAGE, PaymentConstants.ENCRYPTION,PaymentConstants.ENCRYPTION_ERROR));
        }
    }

   
    public String decrypt(TokenAltResponse tokenAltResponse, SecretKey key) {
        try{
        char[] cipherText = tokenAltResponse.getEncTokenInfo().toCharArray();
        String ivResp = tokenAltResponse.getIv();
        byte[] IV = ivResp.getBytes();
            // Get Cipher Instance
            Cipher cipher = Cipher.getInstance(PaymentConstants.AES_PADDING);
            // Create GCMParameterSpec
            GCMParameterSpec gcmParameterSpec = new GCMParameterSpec(16 * 8, IV);
            // Initialize Cipher for DECRYPT_MODE
            cipher.init(Cipher.DECRYPT_MODE, key, gcmParameterSpec);
            // Perform Decryption
            byte[] decryptedText = cipher.doFinal(Hex.decodeHex(cipherText));
            return new String(decryptedText, StandardCharsets.UTF_8);
        } catch (Exception e) { // Exception throw by Card PG
            logger.error("Exception While Decrypt  {}", e);
            throw new PaymentException(ErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(ErrorConstants.INVALID_ERROR_MESSAGE, PaymentConstants.DECRYPTION,PaymentConstants.DECRYPTION_ERROR));
        }
    }

    // Helper method to convert a byte array to a hex string
    public String byteArrayToHexString(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            sb.append(String.format("%02X", b));
        }
        return sb.toString();
    }

    public SecretKey generateSecretKey(String secretKeyString) {
        secretKeyString = secretKeyString.replace("-", "");
        SecretKey secretKey = new SecretKeySpec(secretKeyString.getBytes(), 0,
                secretKeyString.length(), PaymentConstants.AES_ALGO);
        return secretKey;
    }

   
    public String getJsonString(Object o) {
        try{
        com.fasterxml.jackson.databind.ObjectWriter ow = new com.fasterxml.jackson.databind.ObjectMapper().writer().withDefaultPrettyPrinter();
        return ow.writeValueAsString(o);
        } catch (Exception e) { // Exception throw by Card PG
            logger.error("Exception While getJsonString  {}", e);
            throw new PaymentException(ErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(ErrorConstants.INVALID_ERROR_MESSAGE, PaymentConstants.JSON_FORMAT,PaymentConstants.JSON_FORMAT_ERROR));
        }
    }

   
    public KeyStore.PrivateKeyEntry loadPriavteKeys() {
        try{
        ClassPathResource classPathResource = new ClassPathResource(cardConfigDeatils.getClient_jks_filename_intl());
        char[] password = cardConfigDeatils.getClient_jks_file_pwd_intl().toCharArray();
        char[] aliasPwdChars = cardConfigDeatils.getClient_alias_pwd_intl().toCharArray();
        KeyStore keystore = KeyStore.getInstance(PaymentConstants.JKS_CONST);
        keystore.load(classPathResource.getInputStream(), password);

            return  (KeyStore.PrivateKeyEntry) keystore.getEntry(Objects.requireNonNull(cardConfigDeatils.getClient_alias_name_intl()), new KeyStore.PasswordProtection(aliasPwdChars));
        } catch (Exception e) { // Exception throw by Card PG
            logger.error("Exception While loadPriavteKeys  {}", e);
            throw new PaymentException(ErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(ErrorConstants.INVALID_ERROR_MESSAGE, PaymentConstants.GET_KEY,PaymentConstants.GET_KEY_ERROR));
        }
    }
   
    public RSAPublicKey loadPublicKeysServer() {
        try {
            ClassPathResource classPathResource = new ClassPathResource(cardConfigDeatils.getClient_jks_filename_intl());
            char[] password = cardConfigDeatils.getClient_jks_file_pwd_intl().toCharArray();
            KeyStore keystore = KeyStore.getInstance(PaymentConstants.JKS_CONST);
            keystore.load(classPathResource.getInputStream(), password);

            return (RSAPublicKey) keystore.getCertificate(cardConfigDeatils.getServer_pk_alias_name_intl()).getPublicKey();
        } catch (Exception e) { // Exception throw by Card PG
            logger.error("Exception While loadPublicKeysServer  {}", e);
            throw new PaymentException(ErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(ErrorConstants.INVALID_ERROR_MESSAGE, PaymentConstants.GET_KEY,PaymentConstants.GET_KEY_ERROR));
        }
    }
//**************************** Encryption Util End *********************
}
