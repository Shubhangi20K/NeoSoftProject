package com.epay.stubs.util;

import com.epay.stubs.config.InbConfigDeatils;
import com.epay.stubs.exceptions.PaymentException;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.apache.commons.codec.binary.Base64;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Component;

import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.text.MessageFormat;
import java.util.Arrays;

/**
 * Class Name:NbEncryptionDecryptionUtil
 * *
 * Description:
 * *
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */

@Component
@RequiredArgsConstructor
public class InbEncryptionDecryptionUtil {

    private final InbConfigDeatils inbConfigDeatils;
    private static final LoggerUtility logger = LoggerFactoryUtility.getLogger(InbEncryptionDecryptionUtil.class);

    public String getSHA2Checksum(String data) {
        MessageDigest md;
        StringBuffer hexString = new StringBuffer();
        try{
            md = MessageDigest.getInstance("SHA-256");
            md.update(data.getBytes());
            byte byteData[] = md.digest();
            StringBuffer sb = new StringBuffer();
            for (int i = 0; i < byteData.length; i++) {
                sb.append(Integer.toString((byteData[i] & 0xff) + 0x100, 16).substring(1));
            }
            for (int i = 0; i < byteData.length; i++) {
                String hex = Integer.toHexString(0xff & byteData[i]);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
        return hexString.toString();
        } catch (Exception e) { // Exception throw by INB Bank Algorithm
            logger.error("Exception While Decrypt  {} {}", e.getCause(),e.getMessage());
            throw new PaymentException(ErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(ErrorConstants.INVALID_ERROR_MESSAGE, PaymentConstants.CHECKSUM,PaymentConstants.CHECKSUM_ERROR));
        }
    }

   
    public String encrypt(String data)
    {
        ClassPathResource path = new ClassPathResource(PaymentConstants.SBIINB_KEY_PATH);
        byte[] key;
        try{
        key = returnByte(path.getInputStream());

        String encData;

            Cipher cipher = Cipher.getInstance(PaymentConstants.SBIINB_AES_GCM_NOPADDING);
            int blockSize = cipher.getBlockSize();
            byte[] iv = new byte[cipher.getBlockSize()];
            byte[] dataBytes = data.getBytes();
            int plaintextLength = dataBytes.length;
            int remainder = plaintextLength % blockSize;
            if (remainder != 0) {
                plaintextLength += blockSize - remainder;
            }
            byte[] plaintext = new byte[plaintextLength];
            System.arraycopy(dataBytes, 0, plaintext, 0, dataBytes.length);
            SecretKeySpec keySpec = new SecretKeySpec(key, PaymentConstants.AES_ALGO);
            SecureRandom randomSecureRandom = SecureRandom.getInstance(PaymentConstants.SHA1PRNG);
            randomSecureRandom.nextBytes(iv);
            GCMParameterSpec parameterSpec = new GCMParameterSpec(128, iv);
            cipher.init(1, keySpec, parameterSpec);
            byte[] results = cipher.doFinal(plaintext);
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            outputStream.write(iv);
            outputStream.write(results);
            byte[] encryptedData = outputStream.toByteArray();
            encData = Base64.encodeBase64String(encryptedData);
            encData = encData.replace("\n", "").replace("\r", "");
            encData = encData.replaceAll("\r\n", "");
            encData = encData.replaceAll("\r", "");
            encData = encData.replaceAll("\n", "");
            encData = encData.replaceAll(" ", "");

        return encData;
        } catch (Exception e) { // Exception throw by INB Bank Algorithm
            logger.error("Exception While Decrypt  {} {}", e.getCause(),e.getMessage());
            throw new PaymentException(InbErrorConstants.ENCRYPTION_ERROR_CODE, InbErrorConstants.ENCRYPTION_ERROR_MESSAGE.concat(PaymentConstants.SBI_INB_SERVICE));
        }
    }

   
    public String decrypt(String encData) {
        String decdata;
        try{
            ClassPathResource path = new ClassPathResource(PaymentConstants.SBIINB_KEY_PATH);
            byte[] key = returnByte(path.getInputStream());

            Cipher cipher = Cipher.getInstance(PaymentConstants.SBIINB_AES_GCM_NOPADDING);
            SecretKeySpec keySpec = new SecretKeySpec(key, "AES");
            byte[] results = Base64.decodeBase64(encData);
            byte[] iv = Arrays.copyOfRange(results, 0, cipher.getBlockSize());
            cipher.init(2, keySpec, new GCMParameterSpec(128, iv));
            byte[] results1 = Arrays.copyOfRange(results, cipher.getBlockSize(), results.length);
            byte[] ciphertext = cipher.doFinal(results1);
            decdata = new String(ciphertext, StandardCharsets.UTF_8).trim();

        return decdata;
        } catch (Exception e) { // Exception throw by INB Bank Algorithm
            logger.error("Exception While Decrypt  {} {}", e.getCause(),e.getMessage());
            throw new PaymentException(InbErrorConstants.WEB_RESPONSE_ERROR_CODE, InbErrorConstants.WEB_RESPONSE_ERROR_MESSAGE);
        }
    }

   
    private static byte[] returnByte(InputStream inputData) {
        try{
        return inputData.readAllBytes();
        } catch (Exception e) { // Exception throw by INB Bank Algorithm
            logger.error("Exception While Decrypt  {} {}", e.getCause(),e.getMessage());
            throw new PaymentException(ErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(ErrorConstants.INVALID_ERROR_MESSAGE, PaymentConstants.GET_BYTES,PaymentConstants.GET_BYTES_ERROR));
        }
    }
}
