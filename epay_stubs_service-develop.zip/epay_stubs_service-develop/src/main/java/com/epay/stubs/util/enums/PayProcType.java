package com.epay.stubs.util.enums;

import com.epay.stubs.exceptions.PaymentException;
import com.epay.stubs.util.ErrorConstants;

import java.text.MessageFormat;
import java.util.Arrays;

public enum PayProcType {
    ONUS, OFFUS;
    public static PayProcType getPayProdType(String payProcType) {
        return Arrays.stream(values()).filter(p -> p.name().equalsIgnoreCase(payProcType)).findFirst().orElseThrow(() -> new PaymentException(ErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(ErrorConstants.INVALID_ERROR_MESSAGE, "PayProcType", "Valid Values are "+ Arrays.toString(PayProcType.values()))));
    }
}
