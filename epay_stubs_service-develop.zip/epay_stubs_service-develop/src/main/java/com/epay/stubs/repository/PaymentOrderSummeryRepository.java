package com.epay.stubs.repository;

import com.epay.stubs.entity.PaymentOrderSummary;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;

/**
 * Class Name:PaymentOrderSummeryRepository
 * *
 * Description:
 * *
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */

@Repository
public interface PaymentOrderSummeryRepository extends JpaRepository<PaymentOrderSummary, UUID> {
    @Query(value = "SELECT u.ID, u.MERCHANT_ID, u.PAYMODE_CODE, u.LAST_TXN_BOOKING_DATE, u.DAILY_TXN_AMOUNT, u.WEEKLY_TXN_AMOUNT, u.MONTHLY_TXN_AMOUNT, u.QUARTERLY_TXN_AMOUNT,u.HALF_YEARLY_TXN_AMOUNT, u.ANNUALLY_TXN_AMOUNT, u.CREATED_BY, u.UPDATED_BY, u.UPDATED_DATE, u.CREATED_DATE FROM MERCHANT_ORDER_SUMMARY u WHERE u.MERCHANT_ID =:mId AND u.PAYMODE_CODE =:payMode", nativeQuery = true)
    Optional<PaymentOrderSummary> getDailyTxnAmt(@Param("mId") String mId, @Param("payMode") String payMode);
}
