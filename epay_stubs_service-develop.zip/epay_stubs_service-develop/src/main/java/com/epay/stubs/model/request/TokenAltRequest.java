package com.epay.stubs.model.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Class Name:TokenAltRequest
 * *
 * Description: Card Stubs Service
 * *
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TokenAltRequest {
    private String encryptedData;
    private String iv;
    private String clientReferenceId;
    private String merchantId;
    private String acquirerMerchantId;
    private String acquirerInstanceId;
    private String cardType;
    private String authCode;
    private String provider;
    private String amount;
    private String currency;
    private String tokenRequestorId;
    private String userConsent;
    private String merchantName;
}
