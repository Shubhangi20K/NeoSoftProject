package com.epay.stubs.externalservice;


import com.epay.stubs.config.CardConfigDeatils;
import com.epay.stubs.dto.CardOnBoardDetailsResponseDto;
import com.epay.stubs.dto.ResponseDto;
import com.epay.stubs.exceptions.PaymentException;
import com.epay.stubs.util.ErrorConstants;
import com.epay.stubs.util.PaymentConstants;
import com.google.gson.Gson;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.text.MessageFormat;

@Component
@RequiredArgsConstructor
public class CardAdminConfigDetailsClientService {
    LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private final CardConfigDeatils cardConfigDeatils;

    /**
     * @return -JSON : merchantId
     * @methodName: getCardConfigDetails
     * @@Method-Description: The purpose of this method is used to get card config data from admin service
     * @param:
     * @Exception or @Error :m
     */

    public ResponseDto<CardOnBoardDetailsResponseDto> getCardConfigDetails(String merchantId) {
        logger.info("getCardConfigDetails() -for Admin service call    ::  {} ", merchantId);
        try {
            String jsonRequest = new Gson().toJson(merchantId);
            WebClient webClient = WebClient.builder().baseUrl(cardConfigDeatils.getAdminServiceBaseURL() + cardConfigDeatils.getCardOnboardURL())
                    .defaultHeader(HttpHeaders.ORIGIN, cardConfigDeatils.getCorsOrigin())
                    .build();

            ResponseDto<CardOnBoardDetailsResponseDto> responseCardConfigDetails;
            responseCardConfigDetails = webClient.post()
                    .header(PaymentConstants.REQUESTPROPERTY, PaymentConstants.APPLICATION_JSON)
                    .header(PaymentConstants.ACCEPT_ACTION, PaymentConstants.APPLICATION_JSON)
                    .bodyValue(jsonRequest)
                    .retrieve()
                    .onStatus(
                            status -> !status.is2xxSuccessful(),
                            clientResponse -> Mono.error(new RuntimeException("Non-success status code received: " + clientResponse.statusCode()))
                    )
                    .bodyToMono(new ParameterizedTypeReference<ResponseDto<CardOnBoardDetailsResponseDto>>() {
                    })
                    .block();

            return responseCardConfigDetails;

        }  catch (Exception e) {
            throw new PaymentException(ErrorConstants.EXTERNAL_SERVICE_ERROR_CODE, MessageFormat.format(ErrorConstants.EXTERNAL_SERVICE_ERROR_MESSAGE, PaymentConstants.CARDS_SERVICE));
        }
    }
}
