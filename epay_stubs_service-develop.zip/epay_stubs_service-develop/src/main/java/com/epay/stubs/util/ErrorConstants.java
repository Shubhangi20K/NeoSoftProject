package com.epay.stubs.util;

/**
 * Class Name:ErrorConstants
 * *
 * Description:
 * *
 * Author:VCE2645(Siddhesh Nikam)
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */

public class ErrorConstants {

    private ErrorConstants () {}

    public static final String REQUIRED_ERROR_CODE = "3001";
    public static final String REQUIRED_ERROR_MESSAGE = "{0} is required.";

    public static final String INVALID_ERROR_CODE = "3002";
    public static final String INVALID_ERROR_MESSAGE = "{0} is invalid. Reason: {1}.";

    public static final String NOT_FOUND_ERROR_CODE = "3003";
    public static final String NOT_FOUND_ERROR_MESSAGE = "{0} was not found.";

    public static final String ALREADY_EXISTS_ERROR_CODE = "3004";
    public static final String ALREADY_EXISTS_ERROR_MESSAGE = "{0} already exists.";

    public static final String FAILED_TO_GENERATE_ERROR_CODE = "3005";
    public static final String FAILED_TO_GENERATE_ERROR_MESSAGE = "Failed to generate {0}.";

    public static final String UNCATEGORIZED_ERROR_CODE="3006";
    public static final String UNCATEGORIZED_ERROR_MESSAGE="An unexpected error occurred while processing your request.";

    public static final String MAX_LENGTH_ERROR_CODE = "3007";
    public static final String MAX_LENGTH_ERROR_MESSAGE = "The maximum allowed length for {0} is {1}.";

    public static final String INVALID_FORMAT_ERROR_CODE = "3008";
    public static final String INVALID_FORMAT_ERROR_MESSAGE = "Invalid format for {0}. Expected format: {1}.";

    public static final String EXCEEDED_MAX_LENGTH_ERROR_CODE = "3009";
    public static final String EXCEEDED_MAX_LENGTH_ERROR_MESSAGE = "Invalid format or exceeded maximum length for {0}.";

    public static final String TRAILING_SPACES_ERROR_CODE = "3010";
    public static final String TRAILING_SPACES_ERROR_MESSAGE = "{0} contains leading or trailing spaces. Please provide a valid value.";

    public static final String JSON_ERROR_CODE = "3011";
    public static final String JSON_ERROR_MESSAGE = "Invalid JSON data provided in {0}.";

    public static final String EXTERNAL_SERVICE_ERROR_CODE = "3012";
    public static final String EXTERNAL_SERVICE_ERROR_MESSAGE = "{0} Service is Down. Please try again";

    public static final String FIXED_FIELD_LENGTH_ERROR_CODE = "3013";
    public static final String FIXED_FIELD_LENGTH_ERROR_MESSAGE = "The fixed length required for {0} is {1}.";


    public static final String CARD_INITIATION_ERROR_CODE = "3014";
    public static final String CARD_INITIATION_ERROR_MESSAGE = "The card authentication is failed.";

    /*Generic Payment Global Exception Handler Error Code/Message*/



}
