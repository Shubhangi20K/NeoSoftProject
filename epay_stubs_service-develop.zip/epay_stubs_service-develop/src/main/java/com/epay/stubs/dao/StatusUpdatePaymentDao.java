package com.epay.stubs.dao;


import com.epay.stubs.dto.TransactionDto;
import com.epay.stubs.entity.Order;
import com.epay.stubs.repository.OrderRepository;
import com.epay.stubs.util.enums.OrderStatus;
import com.epay.stubs.util.enums.PaymentStatus;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;

/**
 * Class Name:StatusUpdatePaymentDao
 * *
 * Description:
 * Copyright (c) 2024 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */

@RequiredArgsConstructor
@Service
public class StatusUpdatePaymentDao {


    private final PaymentDao paymentDao;
    private final TransactionDao transactionDao;
    private final OrderDao orderDao;
    private final OrderRepository orderRepository;

    LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());

    public void paymentFailureStatusUpdate(String txnRefNo, String sbiRefNumber, String failureReason, String createdBy) {
        logger.debug("default Status Update DV txnRefNo  {} ", txnRefNo);
        paymentDao.updateFailPendingTransactionStatusGen(PaymentStatus.FAILED.toString(), PaymentStatus.FAILED.toString(), sbiRefNumber, failureReason, txnRefNo, createdBy, new Timestamp(System.currentTimeMillis()).getTime());
    }

    public void paymentSuccessPendingStatusUpdateGen(String paymentStatus, String txnRefNo, String sbiRefNumber, String createdBy,String payMode) {
        paymentDao.updateSuccessTransactionStatusGen(paymentStatus, txnRefNo, sbiRefNumber, createdBy, new Timestamp(System.currentTimeMillis()).getTime());

        if (!paymentStatus.equalsIgnoreCase(PaymentStatus.PENDING.toString())) {
            TransactionDto transactionDto = transactionDao.getValidPaymentAckReq(txnRefNo, paymentStatus,payMode);
            updatePaymentOrderStatusPaid(transactionDto);
        }
    }

    private void updatePaymentOrderStatusPaid(TransactionDto transactionDto) {
        Order order = orderDao.getOrderDetails(transactionDto);
        order.setStatus(OrderStatus.PAID);
        order.setUpdatedBy(transactionDto.getUpdatedBy());
        order.setUpdatedDate(transactionDto.getUpdatedDate());
        orderRepository.save(order);
    }

}
