package com.epay.stubs.model.response;

import lombok.*;

/**
 * Class Name:BinCheckResponse
 * *
 * Description: Card Payment Service
 * *
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */


@Builder
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class BinCheckResponse {
    private String status;
    private String errorcode;
    private String errormsg;
    private String qualifiedInternetpin;
    private String authenticationNotRequired;
    private String availableAuthMode;
    private String additionalProductsSupported;
}
