package com.epay.stubs.model.request;

/**
 * Class Name: SaleAPIRequest
 * *
 * Description: Card Stubs Service
 * *
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SaleAPIRequest {
    private String pgInstanceId;
    private String merchantId;
    private String pgTransactionId;
    private String merchantReferenceNo;
    private String altId;
    private String altExpiry;
    private String tokenAuthenticationValue;

}
