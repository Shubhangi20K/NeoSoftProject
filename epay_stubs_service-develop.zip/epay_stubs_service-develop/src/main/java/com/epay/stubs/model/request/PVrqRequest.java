package com.epay.stubs.model.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Class Name:PVrqRequest
 * *
 * Description: Card Stubs Service
 * *
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PVrqRequest {
    private String messageType;
    private String deviceChannel;
    private String merchantTransID;
    private String acctNumber;
    private String acquirerBIN;
    private String acquirerID;
    private String threeDSRequestorMethodNotificationRespURL;
    private String p_messageVersion;
}
