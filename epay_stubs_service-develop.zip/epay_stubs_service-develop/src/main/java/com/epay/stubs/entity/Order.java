package com.epay.stubs.entity;

import com.epay.stubs.util.enums.OrderStatus;
import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.annotation.CreatedDate;

import java.math.BigDecimal;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
@Entity
@Table(name = "MERCHANT_ORDERS")
public class Order {

    @Id
    @Column(name = "SBI_ORDER_REF_NUMBER", nullable = false, updatable = false, unique = true)
    private String sbiOrderRefNumber;

    @Column(name = "merchant_id")
    private String mId;

    @Column(name = "customer_id")
    private String customerId;

    @Column(name = "currency_code")
    private String currencyCode;

    @Column(name = "order_amount")
    private BigDecimal orderAmount;

    @Column(name = "order_ref_number")
    private String orderRefNumber;

    @Enumerated(EnumType.STRING)
    private OrderStatus status;

    @Column(name = "other_details", columnDefinition = "CLOB")
    private String otherDetails;
    private Long expiry;

    @Column(name = "multi_accounts", columnDefinition = "CLOB")
    private String multiAccounts;

    @Column(name = "payment_mode")
    private String paymentMode;

    @Column(name = "order_hash")
    private String orderHash;

    @Column(name = "created_by")
    private String createdBy;

    @Column(name = "updated_by")
    private String updatedBy;

    @CreatedDate
    @Column(name = "created_date")
    private Long createdDate;

    @Column(name = "updated_date")
    private Long updatedDate;

    @Column(name = "return_url")
    private String returnUrl;

    @Column(name = "order_retry_count")
    private Integer orderRetryCount;

    @Column(name = "THIRD_PARTY_DETAILS", columnDefinition = "CLOB")
    private String thirdPartyDetails;

    @Column(name = "MERCHANT_TYPE")
    private String merchantType;

}