package com.epay.stubs.model.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Class Name:AuthResponseBean
 * *
 * Description: Card Stubs Service
 * *
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SaleAPIResponse {
    private String transactionId;
    private String status;
    private String pgErrorCode;
    private String pgErrorDetail;
    private String approvalCode;
    private String rrn;
    private String rupayTransactionId;
    private String creditDebitCardFlag;
    private String merchantReferenceNo;
    private String orderDesc;
    private String ext1;
    private String ext2;
    private String ext3;
    private String ext4;
    private String ext5;
    private String ext6;
    private String ext7;
    private String ext8;
    private String ext9;
}

