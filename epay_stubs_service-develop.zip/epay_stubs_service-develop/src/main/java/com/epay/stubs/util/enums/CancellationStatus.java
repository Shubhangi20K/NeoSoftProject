package com.epay.stubs.util.enums;

public enum CancellationStatus {
}
