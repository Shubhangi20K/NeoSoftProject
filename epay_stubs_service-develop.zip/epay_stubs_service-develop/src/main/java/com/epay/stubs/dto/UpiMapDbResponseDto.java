package com.epay.stubs.dto;

import lombok.*;

import java.math.BigDecimal;

/**
 * Class Name: UpiMapWebResponseDto
 * *
 * Description:
 * *
 * Copyright (c) 2024 [State Bank of India]
 * ALl rights reserved
 * *
 * Version: 1.0
 */

@Builder
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class UpiMapDbResponseDto {

    private BigDecimal amount;
    private String status_desc;
    private String txnrefNo;
    private String sbirefNo;
    private String checkSum;
    private String status;
}
