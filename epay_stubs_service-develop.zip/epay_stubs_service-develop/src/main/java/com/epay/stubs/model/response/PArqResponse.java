package com.epay.stubs.model.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Class Name:PArqResponse
 * *
 * Description: Card Stubs Service
 * *
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PArqResponse {
    private String messageVersion;
    private String p_messageVersion;
    private String threeDSServerTransID;
    private String threeDSServerRefNumber;
    private String acsTransID;
    private String acsReferenceNumber;
    private String dsReferenceNumber;
    private String dsTransID;
    private String messageType;
    private String transStatus;
    private String acsChallengeMandated;
    private String acsChallengeReqUrl;
    private String authenticationType;
    private String messageCategory;
    private String merchantTransID;
    private String cReq;
    private String authenticationUrl;
    private String merchantCancelChallengeAuthUrl;
    private String acsURL;
    private String errorCode;
    private String errorComponent;
    private String errorDescription;
    private String errorDetail;
    private String errorMessageType;
    private String eci; //New Added on INTL case 01-06-2024
    private String authenticationValue; //New Added on INTL case 01-06-2024
}
