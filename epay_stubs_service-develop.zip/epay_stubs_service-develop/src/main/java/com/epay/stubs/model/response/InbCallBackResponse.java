package com.epay.stubs.model.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class InbCallBackResponse {

    private String sbirefNo;

    private BigDecimal amount;

    private String txnrefNo;

    private String status;

    private String status_desc;

    private String checkSum;


}
