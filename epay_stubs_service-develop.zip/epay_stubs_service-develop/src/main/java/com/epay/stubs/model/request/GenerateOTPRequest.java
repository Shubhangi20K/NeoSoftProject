package com.epay.stubs.model.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Class Name:GenerateOTPRequest
 * *
 * Description: Card Stubs Service
 * *
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class GenerateOTPRequest {
    private String pgInstanceId;
    private String merchantId;
    private String merchantReferenceNo;
    private String pan;
    private String cardExpDate;
    private String cvd2;
    private String nameOnCard;
    private String email;
    private String cardHolderStatus;
    private String amount;
    private String currencyCode;
    private String customerIpAddress;
    private String browserUserAgent ;
    private String httpAccept;
    private String ext1;
    private String ext2;
    private String amountInInr;
    private String originalAmount;
    private String purposeOfAuthentication ;
    private String tokenAuthenticationValue;
    private String orderDesc;
}
