package com.epay.stubs.model.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Class Name:CardVisaResponseDto
 * *
 * Description: Card Payment Service
 * *
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@AllArgsConstructor
@Data
@Builder
@NoArgsConstructor
@JsonIgnoreProperties
public class CardRupayResponseDto {
    private String initiate2API;
    @JsonProperty("AccuCardholderId")
    private String accuCardholderId;
    @JsonProperty("AccuGuid")
    private String accuGuid;
    @JsonProperty("AccuReturnURL")
    private String accuReturnURL;
    @JsonProperty("AccuRequestId")
    private String accuRequestId;
    private String session;
    private String availableAuthMode;
    private String status;
    private String errorcode;
    private String errormsg;
    private String atrn;
}
