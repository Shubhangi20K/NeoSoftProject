package com.epay.stubs.util.enums;

/**
 * Class Name:PaymentStatus
 * *
 * Description:
 * *
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */

public enum PaymentStatus {
    BOOKED, PAYMENT_INITIATION_START,SUCCESS, FAILED,PENDING
}
