package com.epay.stubs.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;


@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UpiAccesTokenResponseDto implements Serializable {

    @SerializedName(value = "access_token")
    @JsonProperty(value = "access_token")
    private String access_token;
    @SerializedName(value = "token_type")
    @JsonProperty(value = "token_type")
    private String token_type;
    @SerializedName(value = "refresh_token")
    @JsonProperty(value = "refresh_token")
    private String refresh_token;
    @JsonProperty(value = "expires_in")
    @SerializedName(value = "expires_in")
    private int expires_in;

}
