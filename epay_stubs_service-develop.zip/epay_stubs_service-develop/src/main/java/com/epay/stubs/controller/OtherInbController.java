package com.epay.stubs.controller;


import com.epay.stubs.model.response.OtherInbMerchantPostURLResponse;
import com.epay.stubs.service.OtherInbService;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @class :OtherInbController
 * @implSpec- The purpose of this class is used to UPIPaymentGateway-operation .
 * @version- v1
 * @Exception or @Error :
 */
@RestController
@RequiredArgsConstructor
@RequestMapping("/other-inb")
public class OtherInbController {

    private final OtherInbService otherInbService;
    LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());

    /**
     * @return -JSON : OtherInbMerchantPostURLResponse
     * @apiName: OtherInb MerchantPost URL
     * @apiUrl: /other-inb/otherInb-MerchantPostURL
     * @Method: Post
     * @consumes: MediaType.APPLICATION_JSON_VALUE,
     * @produces: @produces- MediaType.APPLICATION_JSON_VALUE
     */
    @PostMapping("/otherInb-MerchantPostURL")
    public OtherInbMerchantPostURLResponse getPostUrl() {
        logger.info("OtherINB Merchant PostURL");
        return otherInbService.getPostUrl();
    }

}
