package com.epay.stubs.model.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Class Name:InitiateResponse
 * *
 * Description: Card Stubs Service
 * *
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class InitiateResponse {
    private String pgTransactionId;
    private String rupayTransactionId;
    private String redirectURL;
    private String accuRequestId;
    private String session;
    private String status;
    private String errorcode;
    private String errormsg;
}
