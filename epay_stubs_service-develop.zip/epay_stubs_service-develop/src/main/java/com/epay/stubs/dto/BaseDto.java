package com.epay.stubs.dto;

import lombok.Data;

/**
 * Class Name: BaseDto
 * *
 * Description:
 * *
 * Copyright (c) 2024 [State Bank of India]
 * ALl rights reserved
 * *
 * Version: 1.0
 */
@Data
public class BaseDto {
    private String createdBy;
    private String updatedBy;
    private Long createdDate;
    private Long updatedDate;
}
