package com.epay.stubs.dto;

import com.epay.stubs.model.response.UpiCallbackResponse;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.google.gson.annotations.SerializedName;
import jakarta.validation.constraints.NotBlank;
import lombok.*;

@Getter
@Setter
@ToString
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonPropertyOrder
public class UpiFinalResponseDto {
    @NotBlank(message = "ApiResp can not be blank")
    @SerializedName(value = "apiResp")
    @JsonProperty(value = "apiResp")
    UpiCallbackResponse apiResp;
}
