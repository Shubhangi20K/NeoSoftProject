package com.epay.stubs.service;
/**
 * Class Name: CardInitiationService
 * *
 * Description: Card Stubs Service
 * *
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */

import com.epay.stubs.config.CardConfigDeatils;
import com.epay.stubs.dao.CardPaymentDao;
import com.epay.stubs.dao.PaymentDao;
import com.epay.stubs.dao.StatusUpdatePaymentDao;
import com.epay.stubs.dao.TransactionDao;
import com.epay.stubs.dto.*;
import com.epay.stubs.dto.CardOnBoardDetailsResponseDto;
import com.epay.stubs.exceptions.PaymentException;
import com.epay.stubs.externalservice.CardAdminConfigDetailsClientService;
import com.epay.stubs.externalservice.CardWebClientService;
import com.epay.stubs.mapper.CardPaymentMapper;
import com.epay.stubs.model.request.PaymentInitiationRequest;
import com.epay.stubs.model.request.PaymentRequestCard;
import com.epay.stubs.model.request.PaymentRequestCard;
import com.epay.stubs.model.response.*;
import com.epay.stubs.util.*;
import com.epay.stubs.util.enums.PayProcIdRupayCard;
import com.epay.stubs.util.enums.PayProcIdVisaMasterCard;
import com.epay.stubs.util.enums.PaymentStatus;
import com.epay.stubs.validator.PaymentCardValidator;
import com.google.gson.Gson;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.text.MessageFormat;
import java.util.*;

@RequiredArgsConstructor
@Service
public class CardInitiationService {
    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private final CardInitiationUtil cardInitiationUtil;
    private final CardEncryptionDecryptionUtil cardEncryptionDecryptionUtil;
    private final CardPaymentDao cardPaymentDao;
    private final TransactionDao transactionDao;
    private final CardConfigDeatils cardConfigDeatils;
    private final CardWebClientService cardWebClientService;
    private final CardAdminConfigDetailsClientService cardAdminConfigDetailsClientService;
    private final PaymentDao paymentDao;
    private final CardPaymentMapper cardPaymentMapper;
    private final StatusUpdatePaymentDao statusUpdatePaymentDao;
    private final PaymentCardValidator validateCardRequest;
    /**
     * @return: PaymentResponse<CardVisaResponseDto>
     * @methodName: getCardAuthenticationStatus
     * @@Method-Description: Process getting card authentication status
     * @param: paymentRequestCard
     * @Exception: or @Error :Exception
     */

    public PaymentResponse<?> getCardAuthenticationStatus(PaymentRequestCard paymentRequestCard) {
        PaymentInitiationRequest paymentInitiationRequest = getInitiationCardsRequest(paymentRequestCard);
        validateCardRequest.validateCardRequest(paymentInitiationRequest);
        validateCardRequest.validateOpModeValue(paymentInitiationRequest.getPayProcId(), Arrays.stream(PayProcIdVisaMasterCard.values()).map(Enum::name).toList(), PaymentConstants.PAYPROCID_CONST, MessageFormat.format(PaymentConstants.INVALID_FORMAT_MESSAGE, PaymentConstants.PAYPROCID_CONST));
        TransactionDto transactionDto = transactionDao.getValidPaymentAckReq(paymentRequestCard.getAtrn(), PaymentStatus.BOOKED.toString(), paymentRequestCard.getPaymode());
        logger.info("transactionDto {} for reference no {} ", transactionDto, transactionDto.getAtrnNum());

        CardVisaResponseDto cardVisaResponseDto = CardVisaResponseDto.builder()
                .atrn(paymentRequestCard.getAtrn())
                .availableAuthMode("VISA MASTER Redirection")
                .cardPaymentStatus("Pending")
                .creq("eyJ0aHJlZURTU2VydmVyVHJhbnNJRCI6IjA3MGIzMDkyLTMyODEtNDZlMy05NmUzLTkwZTBjNTM3ODFhMyIsImFjc1RyYW5zSUQiOiIxZjVkM2I0YS0xZWE1LTRmMWMtYjE5My00YTRjY2I4OGZmMTIiLCJtZXNzYWdlVHlwZSI6IkNSZXEiLCJtZXNzYWdlVmVyc2lvbiI6IjIuMi4wIiwiY2hhbGxlbmdlV2luZG93U2l6ZSI6IjA0In0")
                .postURL("https://crqsbiacs.sbi/acs/BRW/CReqCreate?acsTransId=1f5d3b4a-1ea5-4f1c-b193-4a4ccb88ff12&timestamp=1748240107899&nonce=fmcnctym&signature=1ae3f82f2b3017852eb48c22e73a71a6c77b835dc5ba52bb696bddc2c30fe874").build();

        logger.info("PaymentVisaCard Response {} ", cardVisaResponseDto);
        return PaymentResponse.<CardVisaResponseDto>builder().data(List.of(cardVisaResponseDto)).status(PaymentConstants.API_RESPONSE_STATUS_SUCCESS).build();
    }

    /**
     * @return: ErrorDto
     * @methodName: getResponseDto
     * @@Method-Description: Process getting card response Error Codes
     * @param: paymentRequestCard
     * @Exception: or @Error :Exception
     */
    public ErrorDto  getResponseDto(String errorCode,String errorMessage,String atrn,String bankReferenceNumber){
        statusUpdatePaymentDao.paymentFailureStatusUpdate(atrn, bankReferenceNumber == null ? PaymentConstants.ZERO : bankReferenceNumber,errorCode == null ? PaymentConstants.NA : errorCode.concat(PaymentConstants.PIPE).concat(errorMessage), PaymentConstants.CREATED_BY_WIBMOPG);
        return ErrorDto.builder().errorCode(ErrorConstants.CARD_INITIATION_ERROR_CODE).errorMessage(ErrorConstants.CARD_INITIATION_ERROR_MESSAGE).build();
    }

     /**
     * @return: PaymentResponse<CardVisaResponseDto>
     * @methodName: getCardAuthenticationStatusRupay
     * @@Method-Description: Process getting card authentication status
     * @param: paymentRequestCard
     * @Exception: or @Error :Exception
     */
     public PaymentResponse<?>  getCardAuthenticationStatusRupay(PaymentRequestCard paymentRequestCard) {
         PaymentInitiationRequest paymentInitiationRequest=getInitiationCardsRequest(paymentRequestCard);
         validateCardRequest.validateCardRequest(paymentInitiationRequest);
         validateCardRequest.validateOpModeValue(paymentInitiationRequest.getPayProcId(), Arrays.stream(PayProcIdRupayCard.values()).map(Enum::name).toList(),PaymentConstants.PAYPROCID_CONST,MessageFormat.format(PaymentConstants.INVALID_FORMAT_MESSAGE, PaymentConstants.PAYPROCID_CONST));
         TransactionDto transactionDto = transactionDao.getValidPaymentAckReq(paymentRequestCard.getAtrn(), PaymentStatus.BOOKED.toString(),paymentRequestCard.getPaymode());
         logger.info("transactionDto {} for reference no {} ",transactionDto,transactionDto.getAtrnNum());
         CardOnBoardDetailsResponseDto cardOnboardDto=getConfigDetails(transactionDto.getMerchantId());
         logger.info("Merchant Onboard Details Fetched cardOnBoardDetailsResponseDto {} for reference no {} ",cardOnboardDto,transactionDto.getAtrnNum());
         BinCheckResponse sbiPGBinCheckResponse = processBinCheck(transactionDto,paymentRequestCard);
         logger.info("Check Bin response sbiPGBinCheckResponse {} for reference no {} ",sbiPGBinCheckResponse,transactionDto.getAtrnNum());
         if(PaymentConstants.successBin.equalsIgnoreCase(sbiPGBinCheckResponse.getStatus()) && !PaymentConstants.ONE.equalsIgnoreCase(sbiPGBinCheckResponse.getAvailableAuthMode())) {
             GenerateOTPResponse generateOTPResponse = processGenerateOTP(cardOnboardDto,transactionDto,paymentRequestCard);
             logger.info("Inside Rupay Generate OTP generateOTPResponse {} for reference no {} ",generateOTPResponse,transactionDto.getAtrnNum());
             if (PaymentConstants.success.equalsIgnoreCase(generateOTPResponse.getStatus())){
                 CardRupaySeamlessResponseDto cardRupaySeamlessResponseDto = CardRupaySeamlessResponseDto.builder().status(generateOTPResponse.getStatus()).atrn(transactionDto.getAtrnNum()).availableAuthMode(PaymentConstants.RUPAY_Seamless).validityPeriod(generateOTPResponse.getValidityPeriod()).errorcode(generateOTPResponse.getErrorcode()).errormsg(generateOTPResponse.getErrormsg()).pgTransactionId(generateOTPResponse.getPgTransactionId()).build();
                 return Optional.ofNullable(PaymentResponse.<CardRupaySeamlessResponseDto>builder().data(List.of(cardRupaySeamlessResponseDto)).status(PaymentConstants.API_RESPONSE_STATUS_SUCCESS).build()).orElseThrow(() -> new PaymentException(CardErrorConstants.PROCESS_SERVICE_ERROR_CODE, MessageFormat.format(CardErrorConstants.PROCESS_SERVICE_ERROR_MESSAGE,PaymentConstants.GenerateOTP)));
             }else{
                 return Optional.ofNullable(PaymentResponse.<CardRupaySeamlessResponseDto>builder().status(0).errors(List.of(getResponseDto(generateOTPResponse.getErrorcode(),generateOTPResponse.getErrormsg(),transactionDto.getAtrnNum(),generateOTPResponse.getPgTransactionId()))).build()).orElseThrow(() -> new PaymentException(CardErrorConstants.PROCESS_SERVICE_ERROR_CODE, MessageFormat.format(CardErrorConstants.PROCESS_SERVICE_ERROR_MESSAGE,PaymentConstants.GenerateOTP)));
             }
         }else if(PaymentConstants.successBin.equalsIgnoreCase(sbiPGBinCheckResponse.getStatus())){
             InitiateResponse initiateResponse = processInitiate2(cardOnboardDto, transactionDto, paymentRequestCard);
             logger.info("Inside Rupay initiateResponse {} for reference no {} ",initiateResponse, transactionDto.getAtrnNum());
             if (PaymentConstants.success.equalsIgnoreCase(initiateResponse.getStatus())) {
                 Map<String, String> initiate2Map = cardEncryptionDecryptionUtil.getMapData(initiateResponse.getRedirectURL());
                 CardRupayResponseDto cardRupayResponseDto = CardRupayResponseDto.builder().status(initiateResponse.getStatus()).atrn(transactionDto.getAtrnNum()).initiate2API(initiate2Map.get(PaymentConstants.RedirectURL)).accuCardholderId(initiate2Map.get(PaymentConstants.AccuCardholderId)).accuGuid(initiate2Map.get(PaymentConstants.AccuGuid)).accuReturnURL(cardConfigDeatils.getReverseURL()).session(initiateResponse.getSession()).accuRequestId(initiateResponse.getAccuRequestId()).availableAuthMode(PaymentConstants.RUPAY_Redirection).build();
                 return Optional.ofNullable(PaymentResponse.<CardRupayResponseDto>builder().data(List.of(cardRupayResponseDto)).status(PaymentConstants.API_RESPONSE_STATUS_SUCCESS).build()).orElseThrow(() -> new PaymentException(CardErrorConstants.PROCESS_SERVICE_ERROR_CODE, MessageFormat.format(CardErrorConstants.PROCESS_SERVICE_ERROR_MESSAGE,PaymentConstants.Initiate2)));
             } else {
                 return Optional.ofNullable(PaymentResponse.<CardRupayResponseDto>builder().status(0).errors(List.of(getResponseDto(initiateResponse.getErrorcode(),initiateResponse.getErrormsg(),transactionDto.getAtrnNum(),initiateResponse.getPgTransactionId()))).build()).orElseThrow(() -> new PaymentException(CardErrorConstants.PROCESS_SERVICE_ERROR_CODE, MessageFormat.format(CardErrorConstants.PROCESS_SERVICE_ERROR_MESSAGE,PaymentConstants.Initiate2)));
             }
         }else {
             return Optional.ofNullable(PaymentResponse.<CardRupayResponseDto>builder().status(0).errors(List.of(getResponseDto(sbiPGBinCheckResponse.getErrorcode(),sbiPGBinCheckResponse.getErrormsg(),transactionDto.getAtrnNum(),transactionDto.getAtrnNum()))).build()).orElseThrow(() -> new PaymentException(CardErrorConstants.PROCESS_SERVICE_ERROR_CODE, MessageFormat.format(CardErrorConstants.PROCESS_SERVICE_ERROR_MESSAGE,PaymentConstants.CheckBin)));
         }
     }
    /**
     * @return: SaleAPIResponse
     * @methodName: processSaleRequest
     * @@Method-Description: Process sale request
     * @param: cardOnboardDto,  transactionDto,  paymentRequestCard,  altIDResponse,  pArqResponse
     * @Exception: or @Error :Exception
     */
    public SaleAPIResponse processSaleRequest(CardOnBoardDetailsResponseDto cardOnboardDto, TransactionDto transactionDto, PaymentRequestCard paymentRequestCard, TokenAltResponse altIDResponse, PArqResponse pArqResponse)  {
        SaleAPIResponse saleAPIResponse;
            String saleRequestPayload = cardInitiationUtil.createSaleSeamRequestPayload(cardOnboardDto,transactionDto , paymentRequestCard, altIDResponse, pArqResponse);
            paymentDao.saveRequestLog(saleRequestPayload,transactionDto.getAtrnNum(),PaymentConstants.SALE_REQ,PaymentConstants.CREATED_BY_WIBMOPG);
            logger.info("Sale API Request {} for reference no {} ",saleRequestPayload,transactionDto.getAtrnNum());
            String encryptedSaleRequest = cardInitiationUtil.getEncryptedPayload(saleRequestPayload);
            HashMap<String, String> cardRequestHeaders = cardInitiationUtil.createThreeDsRequestHeader(cardConfigDeatils.getApi_key(),cardConfigDeatils.getPgInstanceId());
            String apiResponse = cardWebClientService.initiateCardWebClient(cardConfigDeatils.getSaleAuthURL(), encryptedSaleRequest, String.class, cardRequestHeaders);
            logger.info("Sale API Response {} for reference no {} ",apiResponse,transactionDto.getAtrnNum());
            String decryptedRequestPayload= cardInitiationUtil.getDecryptedPayload(apiResponse);
            saleAPIResponse= new Gson().fromJson(decryptedRequestPayload, SaleAPIResponse.class);
            paymentDao.saveResponseLog(decryptedRequestPayload,transactionDto.getAtrnNum(),saleAPIResponse.getTransactionId(),PaymentConstants.SALE_RESP,PaymentConstants.CREATED_BY_WIBMOPG);
            cardPaymentDao.processSaleApiResponse(saleAPIResponse,transactionDto);
        return Optional.of(saleAPIResponse).orElseThrow(() -> new PaymentException(CardErrorConstants.PROCESS_SERVICE_ERROR_CODE, MessageFormat.format(CardErrorConstants.PROCESS_SERVICE_ERROR_MESSAGE,PaymentConstants.SALE)));
    }

    /**
     * @return: TokenAltResponse
     * @methodName: processAltIdRequest
     * @@Method-Description: Process sale request
     * @param: transactionDto, cardOnboardDto, paymentRequestCard,paymentRequestCard
     * @Exception: or @Error :Exception
     */
    public TokenAltResponse processAltIdRequest(TransactionDto transactionDto, CardOnBoardDetailsResponseDto cardOnboardDto, PaymentRequestCard paymentRequestCard){
        String altIdRequestPayload = cardInitiationUtil.createAltIdPayload(transactionDto,cardOnboardDto,paymentRequestCard, PaymentConstants.NA);
        String xAuthToken = cardEncryptionDecryptionUtil.generateHashWithTimeStamp(cardConfigDeatils.getVaultId(), cardConfigDeatils.getClientId(), cardConfigDeatils.getClientApiUser(), cardConfigDeatils.getClientApiKey(), cardConfigDeatils.getTokenSecretKey(), System.currentTimeMillis() / 1000);
        paymentDao.saveRequestLog(altIdRequestPayload,transactionDto.getAtrnNum(),PaymentConstants.ALTID_REQ,PaymentConstants.CREATED_BY_WIBMOPG);
        HashMap<String, String> cardRequestHeaders = cardInitiationUtil.createAltIdRequestHeader(cardConfigDeatils.getClientApiUser(),cardConfigDeatils.getClientApiKey(),xAuthToken,cardConfigDeatils.getClientId());
        String altIdApiResponse = cardWebClientService.initiateCardWebClient(cardConfigDeatils.getTokenURL(), altIdRequestPayload, String.class, cardRequestHeaders);
        logger.info("ALT ID Response {} for reference no {} ",altIdApiResponse,transactionDto.getAtrnNum());
        TokenAltResponse tokenAltResponse = new Gson().fromJson(altIdApiResponse, TokenAltResponse.class);
        paymentDao.saveResponseLog(tokenAltResponse.toString(),transactionDto.getAtrnNum(),tokenAltResponse.getTransactionId(),PaymentConstants.ALTID_RESP,PaymentConstants.CREATED_BY_WIBMOPG);
        return Optional.of(tokenAltResponse).orElseThrow(() -> new PaymentException(CardErrorConstants.PROCESS_SERVICE_ERROR_CODE, MessageFormat.format(CardErrorConstants.PROCESS_SERVICE_ERROR_MESSAGE,PaymentConstants.Tokenization)));
    }


    /**
     * @return: PVrqResponse
     * @methodName: processPvrqVersioning
     * @@Method-Description: Process pVrq request
     * @param: transactionDto,  paymentRequestCard,  tokenAltResponse
     * @Exception: or @Error :Exception
     */
    public PVrqResponse processPvrqVersioning(TransactionDto transactionDto, PaymentRequestCard paymentRequestCard, TokenAltResponse tokenAltResponse) {
            String pvrqVersioningRequestPayload = cardInitiationUtil.createPvrqVersioningPayload(paymentRequestCard, tokenAltResponse);
            logger.info("pVrq Request {} for reference no {} ",pvrqVersioningRequestPayload,transactionDto.getAtrnNum());
            paymentDao.saveRequestLog(pvrqVersioningRequestPayload,transactionDto.getAtrnNum(),PaymentConstants.PVRQ_REQ,PaymentConstants.CREATED_BY_WIBMOPG);
            String signedEncRequestPayload = cardInitiationUtil.getEncryptedpvrqPayload(pvrqVersioningRequestPayload);
            HashMap<String, String> cardRequestHeaders = cardInitiationUtil.createThreeDsRequestHeader(cardConfigDeatils.getApi_key(),cardConfigDeatils.getAcquirerID());
            String pVrqApiResponse = cardWebClientService.initiateCardWebClient(cardConfigDeatils.getPvReqURL()+paymentRequestCard.getAtrn(), signedEncRequestPayload, String.class, cardRequestHeaders);
            logger.info("pVrq Response {} for reference no {} ",pVrqApiResponse,transactionDto.getAtrnNum());
            String decryptedRequestPayload= cardInitiationUtil.getDecryptedPayload(pVrqApiResponse);
            paymentDao.saveResponseLog(decryptedRequestPayload,transactionDto.getAtrnNum(),tokenAltResponse.getTransactionId(),PaymentConstants.PVRQ_RESP,PaymentConstants.CREATED_BY_WIBMOPG);
        return Optional.ofNullable(new Gson().fromJson(decryptedRequestPayload, PVrqResponse.class)).orElseThrow(() -> new PaymentException(CardErrorConstants.PROCESS_SERVICE_ERROR_CODE, MessageFormat.format(CardErrorConstants.PROCESS_SERVICE_ERROR_MESSAGE,PaymentConstants.messageType_PVRQ)));
    }

    /**
     * @return: PArqResponse
     * @methodName: processParqAuthentication
     * @@Method-Description: Process pArq request
     * @param: transactionDto, cardOnboardDto,  paymentRequestCard,  altIDResponse,  pArqResponse
     * @Exception: or @Error :Exception
     */
    public PArqResponse processParqAuthentication(TransactionDto transactionDto,CardOnBoardDetailsResponseDto cardOnboardDto, PaymentRequestCard paymentRequestCard, TokenAltResponse altIDResponse, PVrqResponse pVrqResponse)  {
            String createParqRequestPayload = cardInitiationUtil.createParqPayload(transactionDto, cardOnboardDto, paymentRequestCard, altIDResponse, pVrqResponse);
            logger.info("pVrq createParqRequestPayload {} for reference no {} ",createParqRequestPayload, transactionDto.getAtrnNum());
            paymentDao.saveRequestLog(createParqRequestPayload, transactionDto.getAtrnNum(), PaymentConstants.PARQ_REQ, PaymentConstants.CREATED_BY_WIBMOPG);
            String signedEncRequestPayload = cardInitiationUtil.getEncryptedpvrqPayload(createParqRequestPayload);
            HashMap<String, String> cardRequestHeaders = cardInitiationUtil.createThreeDsRequestHeader(cardConfigDeatils.getApi_key(), cardConfigDeatils.getPgInstanceId_1());
            String pArqApiResponse = cardWebClientService.initiateCardWebClient(pVrqResponse.getThreeDSServerPaRqURL(), signedEncRequestPayload, String.class, cardRequestHeaders);
            logger.info("pVrq Response {} for reference no {} ",pArqApiResponse,transactionDto.getAtrnNum());
            String decryptedRequestPayload = cardInitiationUtil.getDecryptedPayload(pArqApiResponse);
            paymentDao.saveResponseLog(decryptedRequestPayload, transactionDto.getAtrnNum(), pVrqResponse.getThreeDSServerTransID(),PaymentConstants.PARQ_RESP, PaymentConstants.CREATED_BY_WIBMOPG);
            cardPaymentDao.saveCardSummery(transactionDto.getAtrnNum(),CardInitiationUtil.maskAltId(paymentRequestCard.getAltNumber(),6,4),transactionDto.getMerchantId(), String.valueOf(transactionDto.getDebitAmt()), pVrqResponse.getThreeDSServerTransID(),
                        cardInitiationUtil.saveSummaryData(cardInitiationUtil.getAltIdToken(paymentRequestCard,altIDResponse),pVrqResponse, new Gson().fromJson(decryptedRequestPayload, PArqResponse.class), altIDResponse), CardInitiationUtil.hashValue(paymentRequestCard.getAltNumber()));
        return Optional.ofNullable(new Gson().fromJson(decryptedRequestPayload, PArqResponse.class)).orElseThrow(() -> new PaymentException(CardErrorConstants.PROCESS_SERVICE_ERROR_CODE, MessageFormat.format(CardErrorConstants.PROCESS_SERVICE_ERROR_MESSAGE,PaymentConstants.messageType_PARQ)));
    }

    /**
     * @return: GenerateOTPResponse
     * @methodName: processGenerateOTP
     * @@Method-Description: Process Generate OTP request
     * @param: cardOnboardDto,transactionDto, paymentRequestCard
     * @Exception: or @Error :Exception
     */
    public GenerateOTPResponse processGenerateOTP(CardOnBoardDetailsResponseDto cardOnboardDto,TransactionDto transactionDto, PaymentRequestCard paymentRequestCard) {
            String generateOTPRequestPayload = cardInitiationUtil.createGenerateOTPRequest(cardOnboardDto, transactionDto, paymentRequestCard);
            paymentDao.saveRequestLog(generateOTPRequestPayload, transactionDto.getAtrnNum(), PaymentConstants.GenerateOTP_REQ, PaymentConstants.CREATED_BY_WIBMOPG);
            logger.info("Generate OTP API generateOTPRequestPayload {} for reference no {} ",generateOTPRequestPayload, transactionDto.getAtrnNum());
            String signedEncRequestPayload = cardInitiationUtil.getEncryptedpvrqPayload(generateOTPRequestPayload);
            HashMap<String, String> cardRequestHeaders = cardInitiationUtil.createThreeDsRequestHeader(cardConfigDeatils.getApi_key(), cardConfigDeatils.getPgInstanceId_2());
            String apiResponse = cardWebClientService.initiateCardWebClient(cardConfigDeatils.getGenerateOtpURL().trim(), signedEncRequestPayload, String.class, cardRequestHeaders);
            logger.info("Generate OTP API Response {} for reference no {} ",apiResponse, transactionDto.getAtrnNum());
            String decryptedResponse = cardInitiationUtil.getDecryptedResponse(apiResponse);
            GenerateOTPResponse  generateOTPResponse = new Gson().fromJson(decryptedResponse, GenerateOTPResponse.class);
            paymentDao.saveResponseLog(generateOTPResponse.toString(), transactionDto.getAtrnNum(),generateOTPResponse.getPgTransactionId(), PaymentConstants.GenerateOTP_RESP, PaymentConstants.CREATED_BY_WIBMOPG);
        cardPaymentDao.saveCardSummery(transactionDto.getAtrnNum(),CardInitiationUtil.maskAltId(paymentRequestCard.getAltNumber(),6,4),transactionDto.getMerchantId(),String.valueOf(transactionDto.getDebitAmt()),transactionDto.getAtrnNum(), getCardByte(paymentRequestCard,PaymentConstants.NA,PaymentConstants.NA),CardInitiationUtil.hashValue(paymentRequestCard.getAltNumber()));
        return Optional.of(generateOTPResponse).orElseThrow(() -> new PaymentException(CardErrorConstants.PROCESS_SERVICE_ERROR_CODE, MessageFormat.format(CardErrorConstants.PROCESS_SERVICE_ERROR_MESSAGE,PaymentConstants.GenerateOTP)));
    }

    /**
     * @return: BinCheckResponse
     * @methodName: processBinCheck
     * @@Method-Description: Process bin check request
     * @param: transactionDto, paymentRequestCard
     * @Exception: or @Error :Exception
     */
    public BinCheckResponse processBinCheck(TransactionDto transactionDto, PaymentRequestCard paymentRequestCard) {
            String checkBinRequestPayload = cardInitiationUtil.createCheckBinRequest(paymentRequestCard);
            paymentDao.saveRequestLog(checkBinRequestPayload,transactionDto.getAtrnNum(),PaymentConstants.checkBin_REQ,PaymentConstants.CREATED_BY_WIBMOPG);
            logger.info("binCheck API checkBinRequestPayload {} for reference no {} ",checkBinRequestPayload, transactionDto.getAtrnNum());
            String signedEncRequestPayload = cardInitiationUtil.getEncryptedpvrqPayload(checkBinRequestPayload);
            HashMap<String, String> cardRequestHeaders = cardInitiationUtil.createAuthorizationRequestHeader(cardConfigDeatils.getApi_key(),cardConfigDeatils.getPgInstanceId_2(),cardConfigDeatils.getPgInstanceId_2());
            String apiResponse = cardWebClientService.initiateCardWebClient(cardConfigDeatils.getCheckbinURL(), signedEncRequestPayload, String.class, cardRequestHeaders);
            logger.info("binCheck ResponseCode {} for reference no {} ",apiResponse,transactionDto.getAtrnNum());
            String decryptedResponse = cardInitiationUtil.getDecryptedResponse(apiResponse);
            paymentDao.saveResponseLog(new Gson().fromJson(decryptedResponse, BinCheckResponse.class).toString(),transactionDto.getAtrnNum(),transactionDto.getAtrnNum(),PaymentConstants.checkBin_RESP,PaymentConstants.CREATED_BY_WIBMOPG);
        return Optional.ofNullable(new Gson().fromJson(decryptedResponse, BinCheckResponse.class)).orElseThrow(() -> new PaymentException(CardErrorConstants.PROCESS_SERVICE_ERROR_CODE, MessageFormat.format(CardErrorConstants.PROCESS_SERVICE_ERROR_MESSAGE,PaymentConstants.CheckBin)));
    }

    /**
     * @return: InitiateResponse
     * @methodName: processInitiate2
     * @@Method-Description: Process Initiate2 request
     * @param: cardOnboardDto,transactionDto, paymentRequestCard
     * @Exception: or @Error :Exception
     */
    public InitiateResponse processInitiate2(CardOnBoardDetailsResponseDto cardOnboardDto,TransactionDto transactionDto, PaymentRequestCard paymentRequestCard) {
            String initiate2RquestPayload = cardInitiationUtil.createInitiate2Request(cardOnboardDto,transactionDto,paymentRequestCard);
            paymentDao.saveRequestLog(initiate2RquestPayload,transactionDto.getAtrnNum(),PaymentConstants.Initiate2_REQ,PaymentConstants.CREATED_BY_WIBMOPG);
            logger.info("Initiate 2 API initiate2RquestPayload {} for reference no {} ",initiate2RquestPayload,transactionDto.getAtrnNum());
            String signedEncRequestPayload = cardInitiationUtil.getEncryptedpvrqPayload(initiate2RquestPayload);
            HashMap<String, String> cardRequestHeaders = cardInitiationUtil.createAuthorizationRequestHeader(cardConfigDeatils.getApi_key(),cardConfigDeatils.getPgInstanceId_2(),cardConfigDeatils.getPgInstanceId_2());
            String apiResponse = cardWebClientService.initiateCardWebClient(cardConfigDeatils.getInitiateURL(), signedEncRequestPayload, String.class, cardRequestHeaders);
            logger.info("Initiate 2 API Response {} ",apiResponse);
            String decryptedResponse = cardInitiationUtil.getDecryptedResponse(apiResponse);
            InitiateResponse  initiateResponse = new Gson().fromJson(decryptedResponse, InitiateResponse.class);
            paymentDao.saveResponseLog(initiateResponse.toString(),transactionDto.getAtrnNum(),initiateResponse.getPgTransactionId(),PaymentConstants.Initiate2_RESP,PaymentConstants.CREATED_BY_WIBMOPG);
            String pgTransactionId = initiateResponse.getPgTransactionId()==null ? PaymentConstants.NA : initiateResponse.getPgTransactionId();
            String rupayTransactionId = initiateResponse.getRupayTransactionId()==null ? PaymentConstants.NA : initiateResponse.getRupayTransactionId();
            cardPaymentDao.saveCardSummery(transactionDto.getAtrnNum(),CardInitiationUtil.maskAltId(paymentRequestCard.getAltNumber(),6,4),transactionDto.getMerchantId(),String.valueOf(transactionDto.getDebitAmt()),pgTransactionId,getCardByte(paymentRequestCard,rupayTransactionId,pgTransactionId),CardInitiationUtil.hashValue(paymentRequestCard.getAltNumber()));
        return Optional.of(initiateResponse).orElseThrow(() -> new PaymentException(CardErrorConstants.PROCESS_SERVICE_ERROR_CODE, MessageFormat.format(CardErrorConstants.PROCESS_SERVICE_ERROR_MESSAGE,PaymentConstants.Initiate2)));
    }


    public CardOnBoardDetailsResponseDto getConfigDetails(String merchantId) {
        ResponseDto<CardOnBoardDetailsResponseDto> cardConfigDetails = cardAdminConfigDetailsClientService.getCardConfigDetails(merchantId);
        return Optional.of(cardPaymentMapper.mapToCardOnBoardDetailsResponseDto(cardConfigDetails.getData().getFirst())).orElseThrow(() -> new PaymentException(CardErrorConstants.PROCESS_SERVICE_ERROR_CODE, MessageFormat.format(CardErrorConstants.PROCESS_SERVICE_ERROR_MESSAGE,PaymentConstants.Card_Onboard)));
    }

       public String getCardByte(PaymentRequestCard paymentRequestCard,String rupayTransactionId,String pgTransactionId){
        return Base64.getEncoder().encodeToString((paymentRequestCard.getAltNumber().concat(PaymentConstants.PIPE_CONST)).concat(paymentRequestCard.getExpiryMonth().concat(PaymentConstants.PIPE_CONST)).concat(paymentRequestCard.getExpiryYear().concat(PaymentConstants.PIPE_CONST)).concat(paymentRequestCard.getCvv().concat(PaymentConstants.PIPE_CONST)).concat(paymentRequestCard.getCardHolderName().concat(PaymentConstants.PIPE_CONST)).concat(paymentRequestCard.getPayProcId().concat(PaymentConstants.PIPE_CONST)).concat(rupayTransactionId.concat(PaymentConstants.PIPE_CONST)).concat(pgTransactionId).getBytes());
    }

    public PaymentInitiationRequest getInitiationCardsRequest(PaymentRequestCard paymentRequestCard){
       // validateCardRequest.amountCheck(paymentRequestCard);
        return Optional.of(PaymentInitiationRequest.builder()
                .atrn(paymentRequestCard.getAtrn())
                .paymode(paymentRequestCard.getPaymode())
                .operatingMode(paymentRequestCard.getOperatingMode())
                .payProcId(paymentRequestCard.getPayProcId())
                .payProcType(paymentRequestCard.getPayProcType())
                //.merchPostedAmount(new BigDecimal(paymentRequestCard.getMerchPostedAmount().trim()))
                //.transactionAmount(new BigDecimal(paymentRequestCard.getTransactionAmount().trim()))
                .altNumber(paymentRequestCard.getAltNumber())
                .expiryMonth(paymentRequestCard.getExpiryMonth())
                .expiryYear(paymentRequestCard.getExpiryYear())
                .cvv(paymentRequestCard.getCvv())
                .cardHolderName(paymentRequestCard.getCardHolderName())
                .build()).orElseThrow(() -> new PaymentException(CardErrorConstants.PROCESS_SERVICE_ERROR_CODE, MessageFormat.format(CardErrorConstants.PROCESS_SERVICE_ERROR_MESSAGE,PaymentConstants.Authentication)));
    }

    public TokenAltResponse getAltIdApiResponse(String tokenRequest) {
        TokenAltResponse altIdApiResponse = TokenAltResponse.builder()
                .statusCode("TK0000").errorDesc(null)
                .status("Success").msg("Successfully tokenized")
                .transactionId("7a153ed8-c98d-4a29-8efa-eada7cb44404")
                .var1(null)
                .var2("/wAAAAAAbZQI+RsAmfI9go4AAAA=").var3(null)
                .clientReferenceId("DC003174789359134022")
                .tokenReferenceId("93a29809-462a-4c66-8264-9c9a3b6a28f1")
                .encTokenInfo("c10b3d0f15d3f9009764558f85402948546455a4037d7b23373bafdb92c731db")
                .paymentAccountReference("V0010013824119297720990877850")
                .iv("4836b87f6db28da9630b520e0fd86c77").build();

        logger.info("Tokenize Response ::  {} ", altIdApiResponse);
        return altIdApiResponse;
    }

    public PVrqEncResponse getPvRq(String pVrqRequest) {
        PVrqEncResponse pVrqResponse = PVrqEncResponse.builder().signedEncResponsePayload("ylpNyts72ltLdZttxl98AR53Qs+E2eaV1M/MOGWI0E8OSVdzJnRywueZKq7BNpUws4vVvbVA10Jq6VPwX3zx2M2MN8z8hYE++oq/dwdrYi2imhZ57cpLuI45UfqTGm2ydPknegMyQgDJ9WtP+aLCur1RfCY2SvFWl+WPuSfXw+dTbC6nTDzHJpTX0HHh7r9iU/gltslcBLxzydIzDqdEyvm2XFLG/G1v9uEdE+kf32qh6xhU533h9gQAw+u8/KbG+H4MurSy+o9Ni2wzufM3rqcQrVn12cDRU9eMSlHWZFsINkebUzxin82c27oJsK9484DbAES4GSeDY1+FeChVef2WMLY5QEjbj5r98U2Hfk2eKip+6XXrx4ZgaFajeYT5QG24jw3DFd8qHMfNK4jBVmtvMBF7KtlHJRqJFjq6qgncnXhTA4showiBwKhvJRRfNx1BdirL3z6yZM83ao8YJPP5XZuaMoAShS4GQfIElk3w1rVn+INeQdNvi4ABUe2g82kn8ZEQCn4FBdt94QTNmc/fHg6DHtT7752D8gxKMIHmWnhoet6G+keJqjqMnfuvNuPNxBzuUR4tlYjH7eZBI9puElAEQEBQNJngFVP6EWBc3KdwgceogDaUUMFeayaw82i1v7djIPKHd1VWeY6a7VcfRftV9VWJfBacZcFujlf64+VSsihd8IrePGo+TYw1RinMfJkgsKKeNeOm6/w+qheCRNJZvTb/vAIKN4x0v3vaWKxHuLcJgeMajjIoJiMXebNAkSzqDG5aon26ctSzG8SX1su4unaUxk4iCZTdldIZ0DyFvqgAdVFErlNbzSuavWnvLflcfzlRO1ImbSic1dlCoEaTxpemTVnzeU4KO7vwnNkteUNuypEl1+12Qr52aDz22Qh0eS4keUlwwiI16dMncRDKixkkjhitri+WEcarr2qopQauO9JkKrtqBHeSkC3SA60cBU3STwOvNGh1y/Ke6kBXh9NI9c1eX8MTAI3Ej3GKvYRUlPh2saSN5KyY6alGnMU1Yo1t5DoYtDFf2lTyeatkv5dqhdjfSMnD07LjOPowu+AF+PoOzJkvuCtMtL9p8TVp+HI/yRlocYKkc++NB+MKjTvlWDxputPhX1TtRlyuGyuFNvba7M6r8rLCnCbFSRmExNKBHOhJ/6HoHw3fazNqlW4huHSh3kqgaXKg73gBARcXI4MsI0UN+2ZzuD92q9uIsrgGUX1zk+9aFkJxvHRZZxk3QY0IxrKWurrr0KuSx5KFBMSKm9ToU5eVhQOP5NE+0uIaI/qQj0Wkeu9gBL0DUvMMs8DUMDuuNp6EqN27StDfJy1cEbUGAFh5RIe4ZrqI39xi/z17rY7KsWgajhh04Lyi0lIpxyEo8WLAIYyUSH3+WsfHNsR0fBkgf522nqq73Jmix21lKfpYNvu+snCDrx6OwUWxO8Od69R+sfmPyo+WNBZbURp3Cc3yhIXKKC5QVR83LdKvGK/Giw7ifb7t4nabUHhIvOhMs3TVyDBnpN/tHLNhn0VVfkXcNxLxSYhiVtrRg/kyCthhRildHmJJzhw/LKrOyFF7rbavckFALpou0o5lxbjwxMw0JNxK0FeiPV4qjLhyLvow54roQApdZX/S4AHHAtTjU8TisH2xiOIRqCCOCArsR6cgpMFif+5gegoFLhlaR0tDW9xoOf2NvvS6UEFF2MQuK+CrHeXvmQx5S/oHLG3mMZgKL0zmrLORCLGVnLB4FNS38PX1JqixlheSdXOUMOFI18Ry01wICQcuNUAUNvlIY5EW+ycBsBwsZzDhxhllUL5tfl5sLjNUKw26f4AzEcoOOxMQ+L7GGRuinwVZAV9uh7x5hCJR69XP15Ltq/bw1QTCsyxbvqrqeIjvsfo51yr2A1bqIcuR2acxav64mHuo1ibM5jsaDhaJ/0029ghPV6iZe+vf7iz+d2xQeMoHYcFl1+jJYF6DB68qR8dT1iADx9M/vTl0P1nhEvJxk+PJqcfZjGPGsAwbyg3ipW8lYN5AZvzaNK9Ie+CbYbsEW3lNtNhBsdS8cy3r9Agml82ylD8Lvmkghc7gUbx7/v175bpw2bA+NoKVSGsaB0JLqmelZ8a5hVTsZ4gQ0MtPmF/LrA+eKPiFway4tPALpfnUJQ6BTPndUrdGNB1sjKQIJBjOqDDLOaKmSLXUwbOja+ZAk+Mrc6IPT2s6FdlPrczV2lSYHuYavnXOu0yM3AiBuzuiJAhbXpm/Tq9BRHg55WCVpA3Iwwote9gGSy0F9vTxZvJ0WVn+S8XpXmNUXBxuhzEBNPUYYXazuXeeq78GImPShMmy4k6ZTCGt4FOivDI4aTwljnVWVk9IXPuhfAONKxJmIlhNPqBzN+s4nzcbFZ7j1g5/+AX+2ItVjQ15LCCVE+PV/AZB4wzuBnjBgESyRRUIPly2uWgLfzxKJ44doDCUOgYE64L1K4dXYIVLR8o7DCARvLNwR9C8eTTvgbFVIcxtOTWrW78lfbevbFPo/YMIuGeR4zWqtEOxLZNDb8e5ENR4X/YHr9VvikRy9dIIH54fZGzkjnG5kiE9jqvkhRNP2CeSl51P4BLqj7yU6Pm3/IbDqGRYFYzJfAg1MeMxUCID/Qi+ah8GLohYouKJRqbnio/swrcdXPAhH0DwmK2n/npCfRKGag==")
                .iv("Xfe95eieb2KUFk9P").responseSymmetricEncKey("Ber1RA2/RVDSpytQQm2MRNCaWI8GM9VujIN0L8b0l89R31iVNp8b3BvUviwyJHvfW8Az5gbehLzFoVt000YV9/NirNra+btds00D9f7PhJJVGbl5Fz2DTuFvGDwBH61V8vOc7M3zVtlGEd8EgVx76ykqm++AGOFtliatFYYvIvh6MWKpGrIcLJyGCAAS4L4D/QojVOJvK+4tqeiOwTUvN2PP9qyv8YIMZi72Y3JFfOi8kcytMah0HE7hBGqPIBM1iU5Wo3Vi4mGfyw2aKVk1BXVnebtaJy0ZDuOhdmJsTdFoKc+/nvP2n+TXwy4teqaP8O9zLkTy0dFGg7cJWQjA6A==").statusCode("PG99200").build();
        return pVrqResponse;
    }

    public SaleAPIResponse getSaleAPI(String saleAPIRequest) {
        SaleAPIResponse saleAPIResponse = SaleAPIResponse.builder().transactionId("132042759").status("50020")
                .pgErrorCode("0").pgErrorDetail("No Error").approvalCode("991636").rrn("509113196134").rupayTransactionId("")
                .creditDebitCardFlag("D").merchantReferenceNo("DC003174349280247912").orderDesc("NA")
                .ext1(null).ext2(null).ext3(null).ext4(null).ext5(null).ext6(null).ext7(null).ext8(null).ext9(null).build();
        return saleAPIResponse;
    }

    public SaleEncResponse getBinCheck(String binCheckRequest) {
        SaleEncResponse saleEncResponse = SaleEncResponse.builder()
                .signedEncResponsePayload("raxA3FZsL+17eHWFSeq/zAEFENZOrR0EWX8+B6i0P5l6I+djKUAhfttJaIr78/WUz2FIztjKjVTdMY4x5gdzMqPT1NEbaCmvNT/AFIIW/K5WoEil7WcugLc8FYp1lkEQkW2zTHctIskCQhvABbYRevJ6/FmDK3cP9BOiB5yLZtPF0fF5Isd+gvVJkr++0EQEQSpnbOdP5sdVWgs9z8wdPMCT67Fzjw9Uh0Vvw7pfEi50J/fUbAt6Tj8mjWjNV37P5IiG8R2paRdQWPDflhPRtBk9EhvF9lOiPxbkLRM+rlAxf0R9ffojsF8fQAjjsxDGYjO/Ot/8S51EVsnaNMu6avwjcwIjkHqUdCOw6rrlFDR/sP1wBd4TDgXHvK39c4S8PoVCFu3Thlutz8H4v2kVYtgaouuhV1HyWEWvvPhb/AbdoYrBZy1rn67BSTOYl36DMNDJRfqsAYckt6s1b3O/47+M/nSSI+L6BlHkIAKwbCXgbedlt7pe5uFRHg8gOcj0xgyS6dzcTGoYPl7UaIJo+Y/MHyoL82mjb+OWgPIWy1N/c4UDULW9JYfjz0W5F906ayYELMEnZb2NepK/rV3TsRZS3w1qXLVtv/oXJfHLzQAoIY8h/KOKzjvxDR9cBbPWe67juy11nVmFb+Jf1Y945QODSP3KYuJWZqwC6oVSW/syDdUIR2xwhkRSweiU8LIVQ8VMqE29LghNkC/X7nDio/+AmlgM7KHcMMxZ0tweqiU0JrfA9BMYNbyES1GPuCEC+IegWajUf4iyFgV1wSYTpwaWKOpxip6v3bAn6NpHSSxJD+1yX5WDp11TLxPAT96Bh1AClaD5nZ0MkMheEJWJVigNkUgnc7iS2yE9BS5hNPulK6DW5E5Usd8/OlY1I/MlPpdowioe+Ob+kV207uGmChvtef6VdyEwAuJ8dEwcA74srRBbjuO7cv8fF3Mm970TjiVWKA9NmAjd2us8s8GRMxkBqh/NEPTkihgJQOK2H2EjFLQUXyA+OijuuhVeDBArbcpkUvE5dc+S3whMxtE2Eg+Nnw4c2bjrbQ5+nkV8jlqIaJ/GgOoxBRYmbA==")
                .responseSymmetricEncKey("eBKWAE4LmhcY4BI0KZzo7AeyK43a+GqflItQ1xn+a4zjQIil1CYAWvqUhZdHwzxxoS1nV/tGSpdLyeBA2JJCgYzGyeS9te1PpbHXfi2YMPFEWh/tPDVTp6qmdO9X89QaTqlAxNrU4pc/+JfGY8QlVmrT8n4iG5hhL3hlpkV4w4jCwgAGAlhZCsi+zxIrNUPJsbsWd6zAjSrjhqODpv1PCmNAwWrDiy7tdVkK47toplBQpWCBOqgSTb7W90NyVpsgX3zPH0+lcJjULn8VGC/HbmdFzIiESjfflkJ1wlVQFTtPWSTbOOFS+PgjxNZqQDds4Scnjy7nqxOyZB7h9eDzGw==")
                .iv("u3xEcxaliN8zf5PK").clientReferenceId(null)
                .statusCode("PG99200").errorMessage(null)
                .var1(null)
                .var2(null).var3(null).build();
        logger.info("BinCheck response : {} ",saleEncResponse);
        return saleEncResponse;
    }

    public SaleEncResponse generateOTP(@Valid String generateOtpRequest) {
        SaleEncResponse saleEncResponse = SaleEncResponse.builder()
                .signedEncResponsePayload("WmceRtfvwio3MzfFj1PUnIrY+7tqC6rDxTn2G80YpGHyXwKIXBfpnFmueEvODPTa7BcA+IWDjp3EiU7dIb9WC3fXAldQJFkY2XNd8Mrbpn4f737AGBycFv2THJ4hitKp6BaIebArlHeFGrbtQYiJjZme6TuFJY0NhicRh80XcF6aHZkrwncXLHfC6k7YNKwjC02QtaidUnz3tKG5YeZf0OniLPFUqS2H2jxDZG3Sb6jLhVlGXTpawAbQy6VwX+bQUjBCe94EqeQpYvMuWey8zFFhFQuTg6KAJVfBxsnf5vYaWFW5Wu3AvWzYf7+ZGWMDphl0umnNk7sU1+AUWZgsCfjKKZhBVkJOh9YinYoQ/6pkHp28fR33NjHo/cvGTKzdpl4VC8hEtT6mL/Mj0b1pZ0Ash5NQrjsWETJFyTKHCNvYJrjmlbKA4IpCH5DdYdHBwZ059J1PI37TXiHw8MnUK2vTRwecHc/BZh+EsG+8GXbg/SDIlLJolCIQkXxXZ13ktyj7shK+3Eb3GgIiUr6pidCko7jYIfQEj8jWcxl+XRbbFCVoKKKO0Ma1kMQtz79iAuC8RPygSQ4ZoTow6XldUnoNBIQZPaf5F7Itqv3Nyxx6E1XnRZoJnC8b5NU7kOlJOodoCGqZxpGxJfNvXZYQlC7o6WsxoEOd1ennKpVrFn3ORrmo6XAqqgKpKI4RhHkxYwRHGeMd/326nThd6XKxqwt2vVgASUfIK4yD9+sKH6YI6Pit+6ph9ySJSr9ZA3frOTbj+s/9B4FRQxH/lhvJSOXM3bQU/AvQheUro50Vsmjj9bV+ApXryncqi/cvy5WwTX/rNEIAuKLSIq5eRaQEdyYWzkooZ9QWyFEkdBiq8qbok/RpSDNq7plAkQ==")
                .responseSymmetricEncKey("AEUexC8zz7LZSAQn9XwNBDiIMa6k2oBBUOThHJ1t6PiGIgu1+YdDPtSpP9JfWXgvwEFgfWnQnq22mHEMKVALEW5Q+LXCHra9wsZG71wwkawjV+m0UifhqV1uUWNYyLi61dh7cL2aMycfB9LsumSf8+hEitdIMsvPbehRoGJ4NGZhdI/hbQ8aOzYakGsxEe4JyQ/lefA2Gj/DiytoIJK4tqTu75BSlaVtwQqNUqCgNpHQc49NeTy+h2thd2++QSz0yiS7eCZHKzvKE058TX5+NmAHnTWkCFvdnVbrjRo96FldSvZ1Vvf8HAA0BFGSsVdUvp4uqbtQbPsNZwnNHdHZXQ==")
                .iv("QLULexVRKuaRVWd/").clientReferenceId(null)
                .statusCode("PG99200").errorMessage(null)
                .var1(null)
                .var2(null).var3(null).build();
        logger.info("GenerateOTP response : {} ",saleEncResponse);
        return saleEncResponse;
    }


}
