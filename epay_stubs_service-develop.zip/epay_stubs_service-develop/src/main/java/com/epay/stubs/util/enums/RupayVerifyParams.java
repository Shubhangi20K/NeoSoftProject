package com.epay.stubs.util.enums;

import com.epay.stubs.exceptions.PaymentException;
import com.epay.stubs.util.ErrorConstants;

import java.text.MessageFormat;
import java.util.Arrays;

public enum RupayVerifyParams {
    verifyOTP;
    public static RupayVerifyParams getParameters(String apiType) {
        return Arrays.stream(values()).filter(p -> p.name().equalsIgnoreCase(apiType)).findFirst().orElseThrow(() -> new PaymentException(ErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(ErrorConstants.INVALID_ERROR_MESSAGE, "apiType", "Valid Values are " + Arrays.toString(RupayVerifyParams.values()))));
    }
}
