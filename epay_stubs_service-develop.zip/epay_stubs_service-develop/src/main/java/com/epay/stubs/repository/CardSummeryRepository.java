package com.epay.stubs.repository;

import com.epay.stubs.entity.CardSummeryEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * Class Name:CardSummeryRepository
 * *
 * Description: Card Stubs Service
 *
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */

@Repository
public interface CardSummeryRepository extends JpaRepository<CardSummeryEntity, String> {

    Optional<CardSummeryEntity> findByThreeDsServerTransId(String threeDsServerTransId);

    Optional<CardSummeryEntity> findByAtrnNum(String atrnNum);
}
