package com.epay.stubs.model.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Class Name:CardRupaySeamlessResponseDto
 * *
 * Description: Card Stubs Service
 * *
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@AllArgsConstructor
@Data
@Builder
@NoArgsConstructor
@JsonIgnoreProperties
public class CardRupaySeamlessResponseDto {
    private String availableAuthMode;
    private String pgTransactionId;
    private String validityPeriod;
    private String status;
    private String atrn;
    private String errorcode;
    private String errormsg;
}
