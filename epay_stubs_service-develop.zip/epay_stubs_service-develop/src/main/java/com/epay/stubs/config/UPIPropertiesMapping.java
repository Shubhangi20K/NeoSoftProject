package com.epay.stubs.config;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Data
@Configuration
public class UPIPropertiesMapping {

  /*  @Value("${UPI.OAUTH_USERNAME}")
    private String oAuthUserName;

    @Value("${UPI.OAUTH_PASSWORD}")
    private String password;

    @Value("${UPI.UPI_CLIENT_ID}")
    private String clientId;

    @Value("${UPI.SECRETKEY}")
    private String clientSecret;

*//*    @Value("${UPI.OAUTH_TOKEN_URL}")
    private String upiAuthTokenUrl;*//*

    @Value("${UPI.VALIDATE_VPA_CHECK_URL}")
    private String upiValidateVpaUrl;

    @Value("${UPI.VPA_COLLECT_URL}")
    private String upiVpaCollectUrl;

    @Value("${UPI.TXN_STATUS_ENQUIRY_URL}")
    private String upiStatusQueryUrl;*/

    @Value("${UPI.EPAY_PVT_KEY_PATH}")
    private String upiPvtKeyPath;

    @Value("${UPI.UPI_SBI_PUBLIC_KEY_PATH}")
    private String upiSBIPublicKeyPath;

    @Value("${UPI_PVT_KEY_PWD}")
    private String upiPvtKeyPwd;

    @Value("${upi.server.private.key.path}")
    private String upiPrivateKeyPath;

    @Value("${upi.server.public.key.path}")
    private String upiPublicKeyPath;
}
