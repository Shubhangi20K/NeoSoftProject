package com.epay.stubs.externalservice.response;

import lombok.Builder;
import lombok.Getter;

@Getter
@Builder
public class CallbackAcknowledgement {
    private String pspRefNo;
    private String status;
    private String message;
}
