package com.epay.stubs.model.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Class Name:TokenAltResponse
 * *
 * Description: Card Stubs Service
 * *
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class TokenAltResponse {
    private String statusCode;
    private String errorDesc;
    private String status;
    private String msg;
    private String transactionId;
    private String var1;
    private String var2;
    private String var3;
    private String clientReferenceId;
    private String tokenReferenceId;
    private String tokenExpiryDate;
    private String encTokenInfo;
    private String paymentAccountReference;
    private String iv;
}
