package com.epay.stubs.config;

import com.epay.stubs.dto.UpiGenericVpaQrWebRequest;
import com.epay.stubs.exceptions.PaymentException;
import com.epay.stubs.util.ErrorConstants;
import com.epay.stubs.util.UpiErrorConstants;
import com.google.gson.Gson;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import sbi.mer.pgp.dto.PGPDto;
import sbi.mer.pgp.main.PGPEncDecUtility;

import java.io.File;

@Configuration
@RequiredArgsConstructor
public class UpiConfig {
    private final UPIPropertiesMapping upiPropertiesMapping;
    private final String globalPath = "/certs/";
    LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());

    /**
     * @return -JSON : String
     * @methodName: configurePgpRequest
     * @@Method-Description: The purpose of this method is to configure UPI pgpRequest data .
     * @param: String payload,String pgMerchantId,String requestType(DECRYPTED)
     * @Exception or @Error :
     */

    public String configurePgpEncRequest(String plainPayload, String pgMerchantId) {
        logger.info("configurePgpEncRequest() ::   plainPayload and pgMerchantId::  {} {}", plainPayload, pgMerchantId);
        try {
            PGPDto pgpRequest = new PGPDto();
            pgpRequest.setPayload(plainPayload);
            pgpRequest.setPgMerchantId(pgMerchantId);
            pgpRequest.setPrivateKeyPass(upiPropertiesMapping.getUpiPvtKeyPwd());
//            pgpRequest.setPrivateKeyPath(getFilePath(globalPath + upiPropertiesMapping.getUpiPrivateKeyPath()));
//            pgpRequest.setPublicKeyPath(getFilePath(globalPath + upiPropertiesMapping.getUpiPublicKeyPath()));

            //TODO
             pgpRequest.setPrivateKeyPath(getKeysPath(upiPropertiesMapping.getUpiPvtKeyPath()));
             pgpRequest.setPublicKeyPath(getKeysPath(upiPropertiesMapping.getUpiSBIPublicKeyPath()));

            logger.info("configurePgpEncRequest() ::   pgp dto ::  {} ", pgpRequest);
            String encryptedVpaValidationReqData = PGPEncDecUtility.getPGPEncryptedPayload(pgpRequest);
            logger.debug("configurePgpEncRequest() ::   pgp encrypted data ::  {} ", encryptedVpaValidationReqData);
            return new Gson().toJson(UpiGenericVpaQrWebRequest
                    .builder()
                    .requestMsg(encryptedVpaValidationReqData)
                    .pgMerchantId(pgMerchantId).build());
        } catch (Exception e) { // Exception throw by UPI PGP utility Jar
            logger.error("Error While Encrypt PGP request {} {}", e.getCause(), e.getMessage());
            throw new PaymentException(UpiErrorConstants.PGP_ENCRYPTION_ERROR_CODE, UpiErrorConstants.PGP_ENCRYPTION_ERROR_MESSAGE + e.getMessage());
        }
    }


    /**
     * @return -JSON : String
     * @methodName: configurePgpRequest
     * @@Method-Description: The purpose of this method is to configure UPI pgpRequest data .
     * @param: String payload,String pgMerchantId,String requestType(ENCRYPTED)
     * @Exception or @Error :
     */


    public String configurePgpDecryptRequest(String encPayload, String pgMerchantId) {
        logger.info("configurePgpDecryptRequest() ::   plainPayload and pgMerchantId::  {} {}", encPayload, pgMerchantId);
        try {
            PGPDto pgpRequest = new PGPDto();
            pgpRequest.setPayload(encPayload);
            pgpRequest.setPgMerchantId(pgMerchantId);
            pgpRequest.setPrivateKeyPass(upiPropertiesMapping.getUpiPvtKeyPwd());
         //   pgpRequest.setPrivateKeyPath(getFilePath(globalPath + upiPropertiesMapping.getUpiPrivateKeyPath()));
         //   pgpRequest.setPublicKeyPath(getFilePath(globalPath + upiPropertiesMapping.getUpiPublicKeyPath()));

            //TODO
             pgpRequest.setPrivateKeyPath(getKeysPath(upiPropertiesMapping.getUpiPvtKeyPath()));
             pgpRequest.setPublicKeyPath(getKeysPath(upiPropertiesMapping.getUpiSBIPublicKeyPath()));

            logger.info("configurePgpDecryptRequest() ::   pgp dto ::  {} ", pgpRequest);
            String decryptedUpiResponse = PGPEncDecUtility.getPGPDecryptedPayload(pgpRequest);//UpiVpaQrPaymentUtil.decryptPgpResponse(pgpRequest);
            logger.info("configurePgpDecryptRequest() ::   pgp decrypted data  ::  {} ", decryptedUpiResponse);
            return decryptedUpiResponse;
        } catch (Exception e) { // Exception throw by UPI PGP utility Jar
            logger.error("Error While Decryption PGP request {} {}", e.getCause(), e.getMessage());
            throw new PaymentException(UpiErrorConstants.PGP_DECRYPTION_ERROR_RESPONSE_CODE, UpiErrorConstants.PGP_DECRYPTION_ERROR_RESPONSE_MESSAGE + e.getMessage());
        }
    }


    private String getFilePath(String path) {
        logger.info("getFilePath() :: cert file path *********************::  {} ", path);
        File file = new File(path);
        if (!file.isFile())
            throw new PaymentException("00000", "Cert location file not found");

        String absolutePath = file.getAbsolutePath();
        logger.info("getFilePath() :: cert absolutePath  ########################::  {} ", absolutePath);

        return absolutePath;
    }


    //*********************START FOR LOCAL TESTING **********************

    /**
     * @return -JSON : String
     * @methodName: getKeysPath
     * @@Method-Description: The purpose of this method is to getPath from keys folder .
     * @param: String
     * @Exception or @Error :
     */


    public String getKeysPath(String keyPath) {
        logger.info("getKeysPath() ::  pgp prop keyPath ::  {} ", keyPath);
        String keyFilePath = getClassPathResourcesKeysPath(keyPath);
        logger.info("getKeysPath() ::  final pgp filePath ::  {} ", keyFilePath);
        return keyFilePath;
    }


    /**
     * @return -JSON : String
     * @methodName: getClassPathResourcesKeysPath
     * @@Method-Description: The purpose of this method is to get absolutePath from keys folder using ClassPathResources .
     * @param: String
     * @Exception or @Error :IOException
     */

    public String getClassPathResourcesKeysPath(String keyPath) {
        try {
            ClassPathResource classPathResource = new ClassPathResource(keyPath);
            return classPathResource.getFile().getAbsolutePath();
        } catch (Exception e) { // Exception throw by UPI PGP utility Jar
            logger.error("Error While get ClassPathResourcesKeysPath {} {}", e.getMessage(), e.getCause());
            throw new PaymentException(ErrorConstants.INVALID_ERROR_CODE, ErrorConstants.INVALID_ERROR_MESSAGE + e.getMessage());
        }

    }


    //*********************END  LOCAL TESTING **********************

    /**
     * @return - : String
     * @Method- encryptPayload
     * @Method-Description: Encrypt Request using PGP jar
     * @Input type : pgMerchantId,plainPayload
     * @Exception or @Error :
     */

    public String encryptPayload(String pgMerchantId, String plainPayload) {
        PGPDto pgpDto = configurePgpQrEncRequest(plainPayload, pgMerchantId);
        try {
            return PGPEncDecUtility.getPGPEncryptedPayload(pgpDto);
        } catch (Exception e) {
            logger.error("Error While encryptPayload {} {}", e.getCause(), e.getMessage());
            throw new PaymentException(UpiErrorConstants.PGP_ENCRYPTION_ERROR_CODE, UpiErrorConstants.PGP_ENCRYPTION_ERROR_MESSAGE + e.getMessage());
        }

    }

    /**
     * @return - : String
     * @Method- decryptPayload
     * @Method-Description: Decrypt Request using PGP jar
     * @Input type : pgMerchantId,plainPayload
     * @Exception or @Error :
     */

    public String decryptPayload(String pgMerchantId, String plainPayload) {
        PGPDto pgpDto = configureQrPgpDecryptRequest(plainPayload, pgMerchantId);
        try {
            return PGPEncDecUtility.getPGPDecryptedPayload(pgpDto);
        } catch (Exception e) { // Exception throw by UPI PGP utility Jar
            logger.error("Error While decryptPayload {} {}", e.getCause(), e.getMessage());
            throw new PaymentException(UpiErrorConstants.PGP_DECRYPTION_ERROR_RESPONSE_CODE, UpiErrorConstants.PGP_DECRYPTION_ERROR_RESPONSE_MESSAGE + e.getMessage());
        }

    }

    /**
     * @return -JSON : String
     * @methodName: configurePgpRequest
     * @@Method-Description: The purpose of this method is to configure UPI pgpRequest data .
     * @param: String payload,String pgMerchantId,String requestType(ENCRYPTED,DECRYPTED)
     * @Exception or @Error :
     */

    public PGPDto configurePgpQrEncRequest(String plainPayload, String pgMerchantId) {
        PGPDto pgpRequest = new PGPDto();
        try {
            pgpRequest.setPayload(plainPayload);
            pgpRequest.setPgMerchantId(pgMerchantId);
            pgpRequest.setPrivateKeyPass(upiPropertiesMapping.getUpiPvtKeyPwd());
            pgpRequest.setPrivateKeyPath(getFilePath(globalPath + upiPropertiesMapping.getUpiPrivateKeyPath()));
            pgpRequest.setPublicKeyPath(getFilePath(globalPath + upiPropertiesMapping.getUpiPublicKeyPath()));

            //TODO
            // pgpRequest.setPrivateKeyPath(getKeysPath(upiPropertiesMapping.getUpiPvtKeyPath()));
            // pgpRequest.setPublicKeyPath(getKeysPath(upiPropertiesMapping.getUpiSBIPublicKeyPath()));

        } catch (Exception e) { // Exception throw by UPI PGP utility Jar
            logger.error("Error While encryption PGP request {} {}", e.getCause(), e.getMessage());
            throw new PaymentException(UpiErrorConstants.PGP_ENCRYPTION_ERROR_CODE, UpiErrorConstants.PGP_ENCRYPTION_ERROR_MESSAGE + e.getMessage());
        }
        return pgpRequest;
    }

    /**
     * @return -JSON : String
     * @methodName: configurePgpRequest
     * @@Method-Description: The purpose of this method is to configure UPI pgpRequest data .
     * @param: String payload,String pgMerchantId,String requestType(ENCRYPTED,DECRYPTED)
     * @Exception or @Error :
     */

    public PGPDto configureQrPgpDecryptRequest(String encPayload, String pgMerchantId) {
        PGPDto pgpRequest = new PGPDto();
        try {
            pgpRequest.setPayload(encPayload);
            pgpRequest.setPgMerchantId(pgMerchantId);
            pgpRequest.setPrivateKeyPass(upiPropertiesMapping.getUpiPvtKeyPwd());
            pgpRequest.setPrivateKeyPath(getFilePath(globalPath + upiPropertiesMapping.getUpiPrivateKeyPath()));
            pgpRequest.setPublicKeyPath(getFilePath(globalPath + upiPropertiesMapping.getUpiPublicKeyPath()));

            //TODO
            //  pgpRequest.setPrivateKeyPath(getKeysPath(upiPropertiesMapping.getUpiPvtKeyPath()));
            // pgpRequest.setPublicKeyPath(getKeysPath(upiPropertiesMapping.getUpiSBIPublicKeyPath()));


        } catch (Exception e) { // Exception throw by UPI PGP utility Jar
            logger.error("Error While Decryption PGP request {} {}", e.getCause(), e.getMessage());
            throw new PaymentException(UpiErrorConstants.PGP_DECRYPTION_ERROR_RESPONSE_CODE, UpiErrorConstants.PGP_DECRYPTION_ERROR_RESPONSE_MESSAGE + e.getMessage());
        }
        return pgpRequest;
    }


}