package com.epay.stubs.validator;

import com.epay.stubs.util.ErrorConstants;
import com.epay.stubs.util.PaymentConstants;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.MessageFormat;
import java.util.Objects;

/**
 * Class Name:ErrorConstants
 * *
 * Description:
 * *
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
@Component
public class PaymentValidator extends BaseValidator {

    static DecimalFormat formatter = new DecimalFormat(PaymentConstants.TWO_DECIMAl_DIGIT);

    public boolean checkSum(String bankChecksum, String createdChecksum) {
        errorDtoList.clear();
        return checkSumFieldMatched(bankChecksum, createdChecksum);
    }

    private boolean checkSumFieldMatched(String bankChecksum, String createdChecksum) {
        return !bankChecksum.isEmpty() && bankChecksum.equals(createdChecksum);
    }

    public synchronized void validateDebitAmount(BigDecimal debitAmt) {
        errorDtoList.clear();
        validateAmountFormat(debitAmt);
        throwIfErrors();

    }
    void validateAmountFormat(BigDecimal debitAmt) {
        if (Objects.isNull(debitAmt) || (debitAmt.signum() <= 0)) {
            addError(ErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(ErrorConstants.INVALID_ERROR_MESSAGE, PaymentConstants.DEBIT_AMOUNT_CONST,PaymentConstants.DEBIT_AMOUNT_GREATER_ZERO_CONST));
        }
    }


    public boolean validateWebAndDvAmt(BigDecimal webAmt, BigDecimal DvAmt) {
        errorDtoList.clear();
        return  validateWebAndDVAmtFormat(webAmt,DvAmt);
    }

    private synchronized boolean validateWebAndDVAmtFormat(BigDecimal webAmt, BigDecimal dvAmt) {
        return (Objects.equals(new BigDecimal(formatter.format(webAmt)), new BigDecimal(formatter.format(dvAmt))));
    }

    // Ref no not blank, null and zero
    public boolean ValidateBankReferenceNumber(String webSbiRefNo, String dvSbiRefNo) {
        return StringUtils.isNotBlank(webSbiRefNo) && StringUtils.isNotBlank(dvSbiRefNo) && !webSbiRefNo.equals("0") && !dvSbiRefNo.equals("0");
    }

    // Ref no not blank, null and zero
    public boolean ValidateWebResponseBankReferenceNumber(String webSbiRefNo) {
        return StringUtils.isNotBlank(webSbiRefNo) && !webSbiRefNo.equals("0");
    }

    public String cardAmountConverter(BigDecimal debitAmount) {
        errorDtoList.clear();
        return cardAmountFieldValidation(debitAmount);
    }

    private String cardAmountFieldValidation(BigDecimal debitAmount) {
        return  String.valueOf(debitAmount.multiply(new BigDecimal(PaymentConstants.HUNDRED)).setScale(0, RoundingMode.DOWN));
    }

    public boolean checkResponseParamData(String decryptedWebResponse) {
               return decryptedWebResponse.contains(PaymentConstants.SBI_REF_NO) && decryptedWebResponse.contains(PaymentConstants.AMOUNT) && decryptedWebResponse.contains(PaymentConstants.TXN_REF_NO) && decryptedWebResponse.contains(PaymentConstants.STATUS) && decryptedWebResponse.contains(PaymentConstants.STATUS_DESC);
    }
}
