package com.epay.stubs.dao;

import com.epay.stubs.dto.*;

import com.epay.stubs.repository.UpiFinalResponseRepository;
import com.epay.stubs.util.PaymentConstants;
import com.epay.stubs.util.enums.PaymentStatus;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.sql.Timestamp;

@Component
@RequiredArgsConstructor
public class UpiPaymentDao {


    private final PaymentDao paymentDao;
    private final OrderDao orderDao;
    private final StatusUpdatePaymentDao statusUpdatePaymentDao;
    private final UpiFinalResponseRepository finalResponseRepository;

    LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());


    public void processUpiResponse(UpiProcessResponseDto upiProcessResponseDto) {

        logger.info("processUpiStausQueryResponse()- upiProcessStatusDto  ::  {} ", upiProcessResponseDto);
        UpiMapDbResponseDto upiMapDbResponseDto = UpiMapDbResponseDto.builder().sbirefNo(upiProcessResponseDto.getSbirefNo())
                .status(upiProcessResponseDto.getStatus())
                .status_desc(upiProcessResponseDto.getStatus_desc())
                .txnrefNo(upiProcessResponseDto.getTxnrefNo()).build();

        switch (upiMapDbResponseDto.getStatus()) {
            case PaymentConstants.UPI_STATUS_SUCCESS_CONST, PaymentConstants.UPI_STATUS_T_CONST -> {
                statusUpdatePaymentDao.paymentSuccessPendingStatusUpdateGen(PaymentStatus.SUCCESS.toString(), upiMapDbResponseDto.getTxnrefNo(), upiMapDbResponseDto.getSbirefNo(), upiProcessResponseDto.getUpdatedBy(), PaymentConstants.UPI_KEY);
            }
            case PaymentConstants.UPI_STATUS_F_CONST, PaymentConstants.UPI_STATUS_R_CONST,
                 PaymentConstants.UPI_STATUS_X_CONST, PaymentConstants.UPI_STATUS_Z_CONST -> {
                paymentDao.updateFailPendingTransactionStatusGen(PaymentStatus.FAILED.toString(), PaymentStatus.FAILED.toString(), upiMapDbResponseDto.getSbirefNo(), upiMapDbResponseDto.getStatus_desc(), upiMapDbResponseDto.getTxnrefNo(), upiProcessResponseDto.getUpdatedBy(), new Timestamp(System.currentTimeMillis()).getTime());
            }
            default -> {
                logger.info("Default Case: processUpiResponse()- upi response db update  ::  {} ", upiProcessResponseDto.getStatus());
            }
        }
    }

    public void saveFinalResponse(String atrnNum, String upiTransId, String npciTransId, String custRefNo, BigDecimal amount, String status,
                                  String statusDescription, String responseCode, String packet, String payerVa, String payeeVa, long createdDate, String createdBy) {
        finalResponseRepository.insertFinalResponse(atrnNum, upiTransId, npciTransId, custRefNo, amount, status, statusDescription, responseCode, packet, payerVa, payeeVa, createdDate, createdBy);
    }
}
