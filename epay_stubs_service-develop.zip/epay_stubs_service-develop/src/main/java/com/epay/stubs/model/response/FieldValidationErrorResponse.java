package com.epay.stubs.model.response;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.io.Serializable;

@Getter
@Setter
@ToString
@AllArgsConstructor
public class FieldValidationErrorResponse implements Serializable {

    private String field;
    private String errorMessage;

}
