package com.epay.stubs.dao;

import com.epay.stubs.dto.*;
import com.epay.stubs.entity.*;
import com.epay.stubs.mapper.TransactionMapper;
import com.epay.stubs.repository.OrderRepository;
import com.epay.stubs.repository.PaymentOrderSummeryRepository;
import com.epay.stubs.repository.PaymentRepository;
import com.epay.stubs.repository.TransactionRepository;
import com.epay.stubs.util.PaymentConstants;
import com.epay.stubs.util.enums.OrderStatus;
import com.epay.stubs.util.enums.PaymentStatus;
import com.epay.stubs.util.enums.TransactionStatus;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.Date;
import java.util.function.Predicate;

/**
 * Class Name: PaymentDAO
 * *
 * Description:
 * *
 * ALl rights reserved
 * *
 * Version: 1.0
 */
@Component
@RequiredArgsConstructor
public class PaymentDao {
    private final PaymentRepository paymentRepository;
    private final PaymentOrderSummeryRepository paymentOrderSummeryRepository;
    private final TransactionDao transactionDao;
    private final TransactionMapper transactionMapper;
    private final TransactionRepository transactionRepository;
    private final OrderDao orderDao;
    private final OrderRepository orderRepository;
    LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());

    public void saveRequestLog(String paymentApiRequest, String atrn,String requestType,String createdBy) {
        PaymentLog webRequest = PaymentLog.builder()
                .atrnNum(atrn)
                .requestType(requestType)
                .log(paymentApiRequest.getBytes())
                .createdBy(createdBy)
                .createdDate(new Timestamp(System.currentTimeMillis()).getTime())
                .build();
        paymentRepository.save(webRequest);
    }

    public void saveResponseLog(String paymentApiResponse, String atrn, String sbiRefNo, String requestType,String createdBy) {
        PaymentLog webResponse = PaymentLog.builder()
                .atrnNum(atrn)
                .sbiOrderRefNumber(sbiRefNo)
                .requestType(requestType)
                .log(paymentApiResponse.getBytes())
                .createdBy(createdBy)
                .createdDate((new Timestamp(System.currentTimeMillis()).getTime()))
                .build();
        paymentRepository.save(webResponse);
    }

    public void updateSuccessTransactionStatusGen(String paymentStatus, String transactionRefNo, String sbiRefNo, String updatedBy, Long updatedDate) {
        TransactionDto transactionDto = transactionDao.getValidPaymentAckReq(transactionRefNo, PaymentStatus.BOOKED.toString());
        transactionDto.setTransactionStatus(TransactionStatus.valueOf(paymentStatus));
        transactionDto.setPaymentStatus(PaymentStatus.valueOf(paymentStatus));
        switch (transactionDto.getPayMode()){
            case PaymentConstants.NB_CONST -> {
                if (transactionDto.getGtwMapId().equalsIgnoreCase(PaymentConstants.SBI_INB_GTW_MAP_ID))
                    transactionDto.setBankReferenceNumber(sbiRefNo);
                else
                    transactionDto.setBankReferenceNumber(transactionRefNo);
            }
            default -> transactionDto.setBankReferenceNumber(sbiRefNo);
        }
        transactionDto.setUpdatedBy(updatedBy);
        transactionDto.setUpdatedDate(updatedDate);
        transactionDto.setPaymentSuccessDate(new Date());
        MerchantOrderPayments merchantOrderPayments = transactionMapper.transactionDtoToEntity(transactionDto);
        MerchantOrderPayments merchantOrderPaymentsData = transactionRepository.save(merchantOrderPayments);
        logger.debug("After payments success update transactionData {}", merchantOrderPaymentsData);
    }

    public void updateFailPendingTransactionStatusGen(String transactionStatus, String paymentStatus, String sbiRefNo, String FailureReason, String transactionRefNo, String updatedBy, Long updatedDate) {

        TransactionDto transactionDto = transactionDao.getValidPaymentAckReq(transactionRefNo, PaymentStatus.BOOKED.toString());
        transactionDto.setTransactionStatus(TransactionStatus.valueOf(transactionStatus));
        transactionDto.setPaymentStatus(PaymentStatus.valueOf(paymentStatus));
        transactionDto.setFailReason(FailureReason);
        transactionDto.setBankReferenceNumber(sbiRefNo);
        transactionDto.setUpdatedBy(updatedBy);
        transactionDto.setUpdatedDate(updatedDate);

        logger.debug("transactionDto for payments success update {}", transactionDto);
        MerchantOrderPayments merchantOrderPayments = transactionMapper.transactionDtoToEntity(transactionDto);
        MerchantOrderPayments merchantOrderPaymentsData = transactionRepository.save(merchantOrderPayments);
        retryUpdateOrderStatusFailed(transactionDto);
        logger.debug("After payments success update transactionData {}", merchantOrderPaymentsData);
    }

    public void retryUpdateOrderStatusFailed(TransactionDto transactionDto) {
        Order order = orderDao.getOrderDetails(transactionDto);
        if (order.getOrderRetryCount() <= 0) {
            order.setStatus(OrderStatus.FAILED);
            order.setUpdatedBy(transactionDto.getUpdatedBy());
            order.setUpdatedDate(transactionDto.getUpdatedDate());
            orderRepository.save(order);
        }
    }
}
