package com.epay.stubs.model.response;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Class Name:CardVisaFrictionlessResponseDto
 * *
 * Description: Card Stubs Service
 * *
 * All rights reserved
 * *
 * Version:1.0
 */
@AllArgsConstructor
@Data
@Builder
@NoArgsConstructor
@JsonIgnoreProperties
public class CardVisaFrictionlessResponseDto {
    private String availableAuthMode;
    private String cardPaymentStatus;
    private String atrn;
}
