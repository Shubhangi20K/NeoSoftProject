package com.epay.stubs.mapper;

import com.epay.stubs.dto.TransactionDto;
import com.epay.stubs.entity.MerchantOrderPayments;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;

@Mapper(builder = @Builder(disableBuilder = true), componentModel = "spring")
public interface TransactionMapper {

    MerchantOrderPayments transactionDtoToEntity(TransactionDto transactionDto);
    TransactionDto mapToTransactionDto(MerchantOrderPayments merchantOrderPayments);
}
