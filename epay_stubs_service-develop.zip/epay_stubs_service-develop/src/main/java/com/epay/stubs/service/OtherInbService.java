package com.epay.stubs.service;


import com.epay.stubs.model.response.OtherInbMerchantPostURLResponse;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.math.BigDecimal;

/**
 * Class Name:OtherInbService
 * *
 * Description:
 * *
 * Copyright (c) 2024 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */

@RequiredArgsConstructor
@Service
public class OtherInbService {

    LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());

    public OtherInbMerchantPostURLResponse getPostUrl() {
        OtherInbMerchantPostURLResponse otherInbMerchantPostURLResponse = OtherInbMerchantPostURLResponse.builder()
                .orderNumber("100000117869")
                .orderId("CRED2333")
                .atrn("UP003174348836635487")
                .status("Payment Successful")
                .amount(BigDecimal.valueOf(2)).build();
        logger.info("OtherInbMerchantPostURL Response : {}",otherInbMerchantPostURLResponse);
        return otherInbMerchantPostURLResponse;
    }
}
