package com.epay.stubs.entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.UUID;

/**
 * Class Name: PaymentLog
 * *
 * Description:
 *
 * Copyright (c) 2024 [State Bank of India]
 * ALl rights reserved
 * *
 * Version: 1.0
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
@Entity
@Table(name = "PAYMENT_LOG_DETAILS")
@Builder
public class PaymentLog {

   @Id
   @GeneratedValue(strategy = GenerationType.UUID)
   @Column(name = "id", nullable = false, updatable = false, unique = true)
   private UUID id;

   @Column(name = "ATRN_NUM")
   private String atrnNum;

   @Column(name = "SBI_ORDER_REF_NUMBER")
   private String sbiOrderRefNumber;

   @Column(name = "REQUEST_TYPE")
   private String requestType;

   @Lob
   @Column(name = "LOG")
   private byte[] log;

   @Column(name = "CREATED_BY")
   private String createdBy;

   @Column(name = "UPDATED_BY")
   private String updatedBy;

   @Column(name = "CREATED_DATE")
   private Long createdDate;

   @Column(name = "UPDATED_DATE")
   private Long updatedDate;

}
