package com.epay.stubs.dto;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class UpiProcessResponseDto {
    private BigDecimal amount;
    private String status_desc;
    private String txnrefNo;
    private String sbirefNo;
    private String checkSum;
    private String status;
    private String createdBy;
    private String updatedBy;

}
