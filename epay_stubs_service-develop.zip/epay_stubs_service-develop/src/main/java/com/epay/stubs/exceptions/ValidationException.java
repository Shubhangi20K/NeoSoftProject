package com.epay.stubs.exceptions;
import com.epay.stubs.dto.ErrorDto;
import lombok.Getter;

import java.util.List;

/**
 * Class Name: ValidationException
 * *
 * Description:
 * *
 * Author: VCE2645(Siddhesh Nikam)
 * Copyright (c) 2024 [State Bank of India]
 * ALl rights reserved
 * *
 * Version: 1.0
 */

@Getter
public class ValidationException extends RuntimeException {

    private String errorCode;
    private String errorMessage;
    private List<ErrorDto> errorMessages;

    public ValidationException(String errorCode, String errorMessage) {
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
    }

    public ValidationException(List<ErrorDto> errorMessages) {
        this.errorMessages = errorMessages;
    }

}