--liquibase formatted sql
--changeset Operation:107

CREATE TABLE MERCHANT_TXN(
    ATRN_NUM                VARCHAR2(50 BYTE) PRIMARY KEY,
    MERCHANT_ID             VARCHAR2(20 BYTE) NOT NULL ENABLE,
    TXN_AMOUNT              NUMBER(20,2),
    MULTI_ACCOUNT           CLOB
  ) ;

--changeset Operation:107_1
ALTER TABLE MERCHANT_TXN ADD TXN_FEE NUMBER(20,2);