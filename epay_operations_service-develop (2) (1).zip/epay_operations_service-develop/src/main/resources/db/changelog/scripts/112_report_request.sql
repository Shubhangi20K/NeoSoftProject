--liquibase formatted sql
--changeset Operation:112

CREATE TABLE REPORT_REQUEST(
        RR_ID              RAW(16) DEFAULT SYS_GUID() PRIMARY KEY,
        REPORT_TYPE        VARCHAR2(250),
        REPORT_FILTER      VARCHAR2(1000 BYTE) CHECK (REPORT_FILTER IS JSON) ENABLE,
        S3_PATH            VARCHAR2(250),
        ENC_REQUIRED       NUMBER(1),
        SFTP_PATH          VARCHAR2(250),
        CREATED_DATE       NUMBER NOT NULL,
        UPDATED_DATE       NUMBER

    );