--liquibase formatted sql
--changeset Operation:112

CREATE TABLE EVENT_RECEIVED_LOG(
        ERL_ID              RAW(16) DEFAULT SYS_GUID() PRIMARY KEY,
        INTERFACE_TYPE      VARCHAR2(250),
        TOPIC               VARCHAR2(250),
        ROUTING_KEY         VARCHAR2(250),
        MESSAGE             CLOB,
        CREATED_DATE        NUMBER NOT NULL,
        UPDATED_DATE        NUMBER
 );