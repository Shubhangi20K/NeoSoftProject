--liquibase formatted sql
--changeset Operation :117

CREATE TABLE MERCHANT_TXN_PAYOUT_HISTORY(
    MTP_ID                 RAW(16) DEFAULT SYS_GUID() PRIMARY KEY,
    RF_ID                  RAW(16),
    ATRN_NUM               VARCHAR2(20),
    MERCHANT_ID            VARCHAR2(10),
    TXN_PAYOUT_AMOUNT      NUMBER(20, 2),
    BANK_ID                VARCHAR2(50),
    ACCOUNT_ID             VARCHAR2(50),
    ACCOUNT_NUMBER         VARCHAR2(50),
    CREATED_DATE           NUMBER NOT NULL,
    UPDATED_DATE           NUMBER
    );