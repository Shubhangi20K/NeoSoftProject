--liquibase formatted sql
--changeset Operation:111

CREATE TABLE PAYOUT_SCHEDULER(
    PS_ID                  RAW(16) PRIMARY KEY,
    RF_ID                  RAW(16),
    TXN_MATCHED_COUNT      NUMBER,
    STATUS                 VARCHAR2(10) DEFAULT 'PENDING' CHECK (STATUS IN ('PENDING','IN_PROCESS','SUCCESS','FAIL')) ENABLE,
    CREATED_DATE           NUMBER NOT NULL,
    UPDATED_DATE           NUMBER
);