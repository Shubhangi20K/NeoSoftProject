--liquibase formatted sql
--changeset Operation:106

CREATE TABLE PAYOUT_TXN_MAPPING(
    PTM_ID     RAW(16) DEFAULT SYS_GUID() PRIMARY KEY,
    MP_ID      RAW(16),
    RF_ID      RAW(16),
    ATRN_NUM   VARCHAR2(50 BYTE)
    );

--changeset Operation:106_1
CREATE INDEX payout_txn_mp_RF_mp_pt_IDX ON payout_txn_mapping(mp_id,rf_id,PTM_ID);