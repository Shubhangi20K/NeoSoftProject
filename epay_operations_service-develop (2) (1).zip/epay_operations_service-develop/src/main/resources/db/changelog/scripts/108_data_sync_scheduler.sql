--liquibase formatted sql
--changeset Operation:108

CREATE TABLE DATA_SYNC_SCHEDULER(
    DSS_ID               RAW(16) PRIMARY KEY,
    SCHEDULER_NAME       VARCHAR2(36),
    SCHEDULER_LAST_RUN   NUMBER,
    CREATED_DATE         NUMBER NOT NULL,
    UPDATED_DATE         NUMBER
);
