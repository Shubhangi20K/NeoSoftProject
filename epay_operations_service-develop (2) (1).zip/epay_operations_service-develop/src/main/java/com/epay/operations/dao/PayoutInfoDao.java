package com.epay.operations.dao;

import com.epay.operations.dto.PayoutInfoDto;
import com.epay.operations.entity.PayoutInfo;
import com.epay.operations.mapper.PayoutInfoMapper;
import com.epay.operations.repository.PayoutInfoRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

/**
 * Class Name:PayoutInfoDao
 * Description: PayoutInfoDao
 * Author:Saurabh Mahto(V1018841)
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
@Component
@AllArgsConstructor
public class PayoutInfoDao {

    private final PayoutInfoMapper payoutInfoMapper;
    private final PayoutInfoRepository payoutInfoRepository;

    public PayoutInfoDto save(PayoutInfoDto payoutInfoDto){
        PayoutInfo payoutInfo = payoutInfoRepository.save(payoutInfoMapper.mapToEntity(payoutInfoDto));
        return payoutInfoMapper.mapToDto(payoutInfo);
    }
}
