package com.epay.operations.entity;

import com.epay.operations.util.enums.Report;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.UUID;

@EqualsAndHashCode(callSuper = true)
@Data
@Entity
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "REPORT_REQUEST")
public class ReportRequest extends AuditEntityByDate {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(columnDefinition = "RAW(16)")
    private UUID rrId;

    @Enumerated(EnumType.STRING)
    private Report reportType;

    private String reportFilter;
    @Column(name = "S3_PATH")
    private String s3Path;
    private String sftpPath;

    @Column(name = "ENC_REQUIRED")
    private boolean encryptionRequired;

}
