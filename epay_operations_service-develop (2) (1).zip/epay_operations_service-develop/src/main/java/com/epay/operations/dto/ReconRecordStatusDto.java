package com.epay.operations.dto;

import lombok.Getter;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 * Class Name: ReconRecordStatusDto
 * *
 * Description: Dto Class
 * *
 * Author: Saurabh Mahto
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Getter
public class ReconRecordStatusDto {
    private final List<ReconFileDetailsDto> matched = new ArrayList<>();
    private final List<ReconFileDetailsDto> duplicate = new ArrayList<>();
    private final List<ReconFileDetailsDto> unmatched = new ArrayList<>();

    public void addMatched(ReconFileDetailsDto reconFileDetailsDto) {
        matched.add(reconFileDetailsDto);
    }

    public void addUnmatched(List<ReconFileDetailsDto> reconFileDetailsDtos) {
        unmatched.addAll(reconFileDetailsDtos);
    }

    public void addDuplicate(ReconFileDetailsDto reconFileDetailsDto){
        duplicate.add(reconFileDetailsDto);
    }
}
