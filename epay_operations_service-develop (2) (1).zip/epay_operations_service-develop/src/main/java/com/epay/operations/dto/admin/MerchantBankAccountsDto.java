package com.epay.operations.dto.admin;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Class Name: MerchantBankAccountsDto
 * *
 * Description: DTO class
 * *
 * Author: Akshaya Sahasranamam
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class MerchantBankAccountsDto {

    @JsonProperty
    private String mId;
    private BankAccountInfoDto primaryAccount;
    private List<BankAccountInfoDto> secondaryAccount;

}
