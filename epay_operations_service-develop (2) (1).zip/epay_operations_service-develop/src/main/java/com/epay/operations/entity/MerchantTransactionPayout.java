package com.epay.operations.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;
import java.util.UUID;

/**
 * Class Name:MerchantTransactionPayout
 * *
 * Description: Entity class for MerchantTransactionPayout
 * *
 * Author: Akshaya Sahasranamam
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@Entity
@Table(name = "MERCHANT_TXN_PAYOUT")
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class MerchantTransactionPayout extends AuditEntityByDate {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(columnDefinition = "RAW(16)")
    private UUID mtpId;
    @Column(columnDefinition = "RAW(16)")
    private UUID rfId;
    private String atrnNum;
    @Column(name = "MERCHANT_ID")
    private String mId;
    @Column(name = "TXN_PAYOUT_AMOUNT")
    private BigDecimal transactionPayoutAmount;
    private String bankId;
    private String accountNumber;
    private String accountId;
    @Column(name = "TXN_FEE")
    private BigDecimal transactionFee;

}
