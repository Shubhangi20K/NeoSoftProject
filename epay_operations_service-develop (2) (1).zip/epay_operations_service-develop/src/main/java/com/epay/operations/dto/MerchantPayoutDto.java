package com.epay.operations.dto;

import com.epay.operations.util.enums.PayoutStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.UUID;

/**
 * Class Name:MerchantPayout
 * *
 * Description: Dto class
 * *
 * Author: Akshaya Sahasranamam
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class MerchantPayoutDto {

    private UUID mpId;
    private UUID payoutInfoId;
    private String mId;
    private BigDecimal transactionAmount;
    private BigDecimal refundedAmount;
    private String bankId;
    private boolean refundAdjusted;
    private PayoutStatus payoutStatus;
    private String accountNumber;
    private String accountId;

}