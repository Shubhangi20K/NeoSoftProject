package com.epay.operations.repository;


import com.epay.operations.entity.view.MerchantTransaction;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

/**
 * Class Name:MerchantOrderPaymentRepository
 * *
 * Description:
 * *
 * Author:SAURABH_MAHTO(V1018841)
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
@Repository
public interface MerchantTransactionRepository extends JpaRepository<MerchantTransaction, UUID> {

    List<MerchantTransaction> findByAtrnNumIn(List<String> atrn);
}