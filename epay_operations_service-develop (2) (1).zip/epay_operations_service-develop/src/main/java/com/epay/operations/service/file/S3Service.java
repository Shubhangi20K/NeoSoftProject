package com.epay.operations.service.file;

import com.epay.operations.config.aws.S3Config;
import com.epay.operations.exception.OpsException;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.*;

import java.io.InputStream;

import static com.epay.operations.util.ErrorConstant.*;
import static com.epay.operations.util.OperationsConstant.S3_FILE_NAME_FORMAT;

/**
 * Class Name: S3Service
 * Description: The S3Service class provides functionalities to interact with AWS S3 for uploading, downloading, and listing files.
 * It supports uploading files as a File, byte array, or MultipartFile, and handles the S3 client operations like put, get, and list objects.
 * It also provides error handling, logging, and custom exception throwing in case of S3 operation failures.
 * Author: Gireesh M
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * Version: 1.0
 */
@RequiredArgsConstructor
@Service
@Profile("!local")
public class S3Service implements FileService {
    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    private final S3Config s3Config;
    private final S3Client s3Client;


    /**
     * Uploads a file to S3 using byte array content.
     *
     * @param fileName    the name of the file
     * @param fileContent the content of the file as byte array
     * @return the S3 key for the uploaded file
     */
    @Override
    public String uploadFile(String fileName, byte[] fileContent) {
        String key = String.format(S3_FILE_NAME_FORMAT, System.currentTimeMillis(), fileName);
        try {
            PutObjectRequest objectRequest = PutObjectRequest.builder().bucket(s3Config.getBucket()).key(key).build();
            s3Client.putObject(objectRequest, RequestBody.fromBytes(fileContent));
            return key;
        } catch (Exception e) {
            log.error("S3 - Failed to upload file content: {} on s3 with error: {}", key, e.getMessage());
            throw new OpsException(GENERIC_ERROR_CODE, e.getMessage());
        }
    }


    /**
     * Reads file content from S3 and returns it as a ResponseBytes object.
     *
     * @param key the S3 file key
     * @return file content as ResponseBytes
     */
    @Override
    public InputStream readFile(String key) {
        log.info("Reading file[{}] from S3", key);
        try {
            GetObjectRequest getObjectRequest = GetObjectRequest.builder().bucket(s3Config.getBucket()).key(key).build();
            return s3Client.getObjectAsBytes(getObjectRequest).asInputStream();
        } catch (Exception e) {
            log.error("Failed to read file[{}] from S3 with error: {}", key, e.getMessage());
            throw new OpsException(GENERIC_ERROR_CODE, e.getMessage());
        }
    }


}