package com.epay.operations.service.sftp;

import com.epay.operations.config.OpsConfig;
import com.epay.operations.config.sftp.SftpConfig;
import com.epay.operations.exception.OpsException;
import com.epay.operations.exception.SftpClientException;
import com.epay.operations.service.file.FileService;
import com.jcraft.jsch.*;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.integration.file.remote.session.CachingSessionFactory;
import org.springframework.integration.file.remote.session.Session;
import org.springframework.stereotype.Service;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.MessageFormat;
import java.util.*;
import java.util.regex.Pattern;

import static com.epay.operations.util.ErrorConstant.*;
import static com.epay.operations.util.OperationsConstant.FILE_SEPARATOR;
import static com.sbi.epay.encryptdecrypt.service.FileEncDecService.encryptFile;


/**
 * Class Name: SftpClientService<br>
 * Description: This Service will provide methods to access with sftp.<br>
 * Author:@V0000001(Shilpa Kothre)<br>
 * Copyright (c) 2025 [State Bank of India]<br>
 * All rights reserved<br>
 * * Version:1.0
 */
@Service
@RequiredArgsConstructor
public class SftpClientService {
    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private final SftpConfig sftpConfig;
    private final FileService fileService;
    private final OpsConfig opsConfig;
    private final CachingSessionFactory<ChannelSftp.LsEntry> cachingSessionFactory;
    private ChannelSftp channelSftp = null;

    public String uploadS3File(String remoteDir, String s3Key) {
        logger.info("uploading s3 file: {} on sftp: {}", s3Key, remoteDir);
        try (Session<ChannelSftp.LsEntry> session = cachingSessionFactory.getSession(); InputStream inputStream = fileService.readFile(s3Key)) {
            createDirsIfNotExists(session, remoteDir);
            session.write(inputStream, remoteDir + "/" + s3Key);
            logger.info("s3 file: {} uploaded on sftp: {}", s3Key, remoteDir);
            return remoteDir + "/" + s3Key;
        } catch (IOException e) {
            logger.error("Error: {} while uploading s3 file: {} on sftp: {}", e.getMessage(), s3Key, remoteDir);
            return remoteDir;
        }
    }

    public void uploadFile(String remoteDir, String fileName, byte[] data) throws IOException {
        try (Session<ChannelSftp.LsEntry> session = cachingSessionFactory.getSession(); InputStream inputStream = new ByteArrayInputStream(data)) {
            createDirsIfNotExists(session, remoteDir);
            session.write(inputStream, remoteDir + "/" + fileName);
        }
    }

    private void createDirsIfNotExists(Session<ChannelSftp.LsEntry> session, String path) throws IOException {
        logger.info("Checking and then creating sftp dir for path: {}", path);
        String[] folders = path.split(Pattern.quote("/"));
        StringBuilder pathSb = new StringBuilder();
        for (String folder : folders) {
            if (StringUtils.isEmpty(folder)) continue;
            pathSb.append("/").append(folder);
            try {
                session.list(pathSb.toString());
            } catch (Exception e) {
                logger.info("Path: {} does not exist on sftp", pathSb.toString());
                session.mkdir(pathSb.toString());
                logger.info("Path: {} created on sftp", pathSb.toString());
            }
        }
    }

    private boolean dirNotExists(Session<ChannelSftp.LsEntry> session, String path) {
        try {
            session.list(path);
            return false;
        } catch (Exception e) {
            return true;
        }
    }

    /**
     * Get current directory path.
     *
     * @return String of current directory.
     */
    public final String getCurrentDirPath() {
        try {
            channelSftp = getChannelSftp();
            return channelSftp.pwd();
        } catch (Exception e) {
            logger.error("Failed to run SFTP pwd command. error: {}", e.getMessage());
            throw new SftpClientException(SFTP_ERROR_CODE, MessageFormat.format(SFTP_ERROR_MESSAGE, "Failed to run pwd command on SFTP"));
        }
    }

    /**
     * Get list of file
     *
     * @param dirPath String
     * @return list of SFTP files for given directory
     */
    public Vector<ChannelSftp.LsEntry> getListAllSftpFiles(String dirPath) {
        try {
            channelSftp = getChannelSftp();
            logger.info("Getting list of file from directory {}", dirPath);
            return channelSftp.ls(FILE_SEPARATOR + dirPath);
        } catch (Exception e) {
            logger.error("Failed to run SFTP ls command on dir {}. error: {}", dirPath, e.getMessage());
            throw new SftpClientException(SFTP_ERROR_CODE, MessageFormat.format(SFTP_ERROR_MESSAGE, "Failed to run ls command on SFTP."));
        }
    }

    /**
     * Run SFT ls command on given directory path, and get list file path with given directory name.
     *
     * @param sftpFilePath SFTP directory path
     * @return File list of given remote directory path.
     */
    public List<String> listFiles(String sftpFilePath) {
        return getListAllSftpFiles(sftpFilePath).stream().filter(sftpFile -> !sftpFile.getAttrs().isDir()).map(sftpFile -> sftpFilePath + "/" + sftpFile.getFilename()).toList();
    }

    /**
     * Delete file
     *
     * @param path String
     */
    public void removeFile(String path) {
        try {
            channelSftp = getChannelSftp();
            SftpATTRS attrs1 = channelSftp.lstat(path);
            int permissions = attrs1.getPermissions();
            logger.info("File [{}] Permission (Octal):{}", path, permissions);

            if ((permissions & 0200) != 0) {
                logger.info("Deleting file [{}]...", path);
                channelSftp.rm(path);
                logger.info("File [{}] deleted.", path);
            } else {
                logger.info("No delete Permission. Cannot Delete file.");
            }

        } catch (SftpException e) {
            if (e.id == ChannelSftp.SSH_FX_NO_SUCH_FILE) {
                logger.info("File [{}] does not exists.", path);
            }
        } catch (Exception exception) {
            logger.info("Error while deleting file [{}] from sftp", path);
        }
    }

    /**
     * @param sftp          ChannelSftp
     * @param parentPath    String
     * @param targetDirName String
     * @throws SftpException throw SFTP exception
     */
    public void deleteIfDirMatches(ChannelSftp sftp, String parentPath, String targetDirName) throws SftpException {
        Vector<ChannelSftp.LsEntry> entries = sftp.ls(parentPath);
        for (ChannelSftp.LsEntry entry : entries) {
            String name = entry.getFilename();
            // Skip current and parent directory indicators
            if (".".equals(name) || "..".equals(name)) continue;
            // Check if it's a directory and matches the target
            if (entry.getAttrs().isDir() && name.equals(targetDirName)) {
                String fullPath = parentPath + FILE_SEPARATOR + name;
                deleteDirectoryIteratively(sftp, fullPath); // Delete directory and its contents
                logger.info("Deleted directory: " + fullPath);
            }
        }
    }

    /**
     * #warn:Delete all child of given directory
     *
     * @param sftp     ChannelSftp
     * @param rootPath String
     * @throws SftpException throw SFTP exception
     */
    // Iterative deletion (non-recursive) from previous solution
    public void deleteDirectoryIteratively(ChannelSftp sftp, String rootPath) throws SftpException {
        Stack<String> dirStack = new Stack<>();
        List<String> filesToDelete = new ArrayList<>();
        List<String> dirsToDelete = new ArrayList<>();
        Vector<ChannelSftp.LsEntry> entries;
        String filename;
        String fullPath;
        dirStack.push(rootPath);
        while (!dirStack.isEmpty()) {
            String currentDir = dirStack.pop();
            entries = sftp.ls(currentDir);
            for (ChannelSftp.LsEntry entry : entries) {
                filename = entry.getFilename();
                if (".".equals(filename) || "..".equals(filename)) continue;
                fullPath = currentDir + FILE_SEPARATOR + filename;
                if (entry.getAttrs().isDir()) {
                    dirStack.push(fullPath);
                    dirsToDelete.add(fullPath);
                } else {
                    filesToDelete.add(fullPath);
                }
            }
        }
        filesToDelete.forEach(this::removeFile);
        Collections.reverse(dirsToDelete);
        for (String dir : dirsToDelete) {
            sftp.rmdir(dir);
        }
        sftp.rmdir(rootPath); // Delete root dir
    }

    /**
     * This method is used to upload file to sftp
     *
     * @param s3FileKey            File path from which file need to upload
     * @param remotePath           remote path
     * @param isEncryptionRequired encryption Needed
     */
    public String uploadFile(String s3FileKey, String remotePath, boolean isEncryptionRequired) {
        logger.info("Read the file from path : {}", s3FileKey);
        String sftpFilePath = remotePath;
        try (InputStream inputStream = fileService.readFile(s3FileKey)) {
            byte[] byteArray = inputStream.readAllBytes();
            if (isEncryptionRequired) {
                byteArray = encryptFile(byteArray, opsConfig.getSecretKey(), opsConfig.getSalt());
            }
            sftpFilePath = remotePath + FILE_SEPARATOR + s3FileKey;
            uploadFile(byteArray, remotePath, s3FileKey);
            logger.info("uploaded file : {} on sftp path {}", s3FileKey, remotePath);
        } catch (IOException e) {
            logger.error("Report file upload failed.", e);
        }

        return sftpFilePath;
    }

    /**
     * This method is used to upload file to sftp
     *
     * @param fileBytes  file which need to upload
     * @param remotePath remote path
     * @param fileName   fileName
     */
    public void uploadFile(byte[] fileBytes, String remotePath, String fileName) {
        try (InputStream fileByteStream = new ByteArrayInputStream(fileBytes)) {
            channelSftp = getChannelSftp();
            logger.info("SFTP channel created {}", channelSftp);
            ensureRemotePathExists(channelSftp, remotePath);
            channelSftp.cd(remotePath);
            channelSftp.put(fileByteStream, fileName);
            logger.info("File uploaded successfully: {}", fileName);
        } catch (SftpException e) {
            logger.error("Error While uploading file on SFTP, errorId: {}, errorMessage: {}", e.id, e.getMessage());
            throw new SftpClientException(SFTP_ERROR_CODE, MessageFormat.format(SFTP_ERROR_MESSAGE, "Error While uploading file on SFTP with sftp error id: " + e.id));
        } catch (Exception e) {
            logger.error("Error While uploading file on SFTP : {}", e.getMessage());
            throw new SftpClientException(SFTP_ERROR_CODE, MessageFormat.format(SFTP_ERROR_MESSAGE, "Error While uploading file on SFTP : " + e.getMessage()));
        }
    }

    /**
     * Create SFTP connection session.
     *
     * @return Session
     * @throws JSchException exception while create SFTP connection session.
     */
    public ChannelSftp getChannelSftp() {
        logger.info("Connecting sftp channel on server: {}", sftpConfig.getHost());
        try {
            if (Objects.nonNull(channelSftp) && channelSftp.isConnected() && !channelSftp.isClosed()) {
                logger.info("return existing channel sftp connection.");
                return channelSftp;
            }
            JSch jsch = new JSch();
            logger.info("Getting session based on credential.");
            com.jcraft.jsch.Session session = jsch.getSession(sftpConfig.getUsername(), sftpConfig.getHost(), sftpConfig.getPort());
            session.setPassword(sftpConfig.getPassword());
            session.setConfig("StrictHostKeyChecking", "no");
            session.setTimeout(sftpConfig.getSessionTimeout());
            logger.info("Connecting to SFTP server.");
            session.connect();
            logger.info("Connected to SFTP server.");
            logger.info("Create channel sftp connection.");
            channelSftp = (ChannelSftp) session.openChannel("sftp");
            channelSftp.connect();
        } catch (JSchException e) {
            logger.info("Exception occurred while creating SFTP session and Channel, Server: {}, errorMsg: {}", sftpConfig.getHost(), e.getMessage());
            throw new OpsException(GENERIC_ERROR_CODE, "Failed to connect SFTP, error: " + e.getMessage());
        }
        return channelSftp;
    }

    /**
     * This method is used to disconnect channelSftp.
     *
     * @param channelSftp channelSftp.
     */
    public void disconnectChannelSftp(ChannelSftp channelSftp) {
        if (Objects.nonNull(channelSftp) && channelSftp.isConnected() && !channelSftp.isClosed()) {
            channelSftp.disconnect();
        }
    }

    /**
     * This method is used to check whether folder present or not if not then create.
     *
     * @param channelSftp channelSftp
     * @param path        path
     * @throws SftpException exception
     */
    private void ensureRemotePathExists(ChannelSftp channelSftp, String path) throws SftpException {
        logger.info("Checking folder if not then create.");
        String[] folders = path.split(Pattern.quote("/"));
        StringBuilder currentPath = new StringBuilder();
        for (String folder : folders) {
            if (folder.trim().isEmpty()) continue;
            currentPath.append("/").append(folder.trim());
            logger.info("Checking SFTP dir[{}] exist.", folder.trim());
            if (!directoryExists(channelSftp, currentPath.toString())) {
                logger.info("Creating SFTP dir[{}] exist.", folder);
                channelSftp.mkdir(currentPath.toString());
                channelSftp.cd(currentPath.toString());
            }
        }
    }

    private boolean directoryExists(ChannelSftp channelSftp, String path) throws SftpException {
        try {
            channelSftp.cd(path);
            return true;
        } catch (SftpException e) {
            if (e.id == ChannelSftp.SSH_FX_NO_SUCH_FILE) {
                return false;
            } else {
                logger.error("Error while checking path: {} with error id: {} and message: {}", path, e.id, e.getMessage());
                throw e;
            }
        }
    }


    /**
     * Creates nested directories on the SFTP server similar to 'mkdir -p'.
     *
     * @param remotePath The nested directory path to create
     */
    public void createDir(String remotePath) {
        logger.info("Creating directory {}", remotePath);
        channelSftp = getChannelSftp();
        String[] folders = remotePath.split("/");
        String currentPath = "";
        for (String folder : folders) {
            if (folder == null || folder.trim().isEmpty()) continue;
            currentPath += "/" + folder;
            try {
                channelSftp.cd(currentPath);
                logger.debug("Directory exists: {}", currentPath);
            } catch (SftpException e) {
                try {
                    channelSftp.mkdir(currentPath);
                    channelSftp.cd(currentPath);
                    logger.info("Created directory: {}", currentPath);
                } catch (SftpException ex) {
                    logger.error("Failed to create directory[{}], errorId: {}, errorMessage: {}", currentPath, e.id, ex.getMessage());
                    throw new OpsException(GENERIC_ERROR_CODE, "Failed to create directory[" + currentPath + "], error: " + e.getMessage());
                }
            }
        }
        logger.info("Directory created {}", remotePath);
    }


    public boolean isDirExists(String filePath) {
        try {
            getChannelSftp().ls(filePath);
            logger.info("This {} directory is already exists", filePath);
            return true;
        } catch (SftpException e) {
            logger.info("This {} directory is not exists", filePath);
            return false;
        }
    }

    public InputStream readFile(String filePath) {
        try {
            logger.info("Reading sftp file from path {}", filePath);
            return getChannelSftp().get(filePath);
        } catch (SftpException e) {
            logger.error("Failed to read file from path: {}", filePath);
            return null;
        }
    }

}
