package com.epay.operations.scheduler;

import com.epay.operations.service.DataPurgeService;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.AllArgsConstructor;
import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;
import org.slf4j.MDC;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.UUID;

import static com.epay.operations.util.OperationsConstant.OPERATION;
import static com.epay.operations.util.OperationsConstant.SCENARIO;
import static org.springframework.kafka.support.KafkaHeaders.CORRELATION_ID;

/**
 * Class Name: OperationDataFlushScheduler
 * Description: Scheduler to Purg data
 * Author:Rahul Yadav (V1019439)
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */

@Component
@AllArgsConstructor
public class DataPurgeScheduler {
    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());

    private final DataPurgeService dataPurgeService;

    @Scheduled(cron = "${scheduler.cron.expression.operation.data.purge}")
    @SchedulerLock(name = "dataPurging")
    public void purgeOperationData() {
        log.info("Purge OperationData Scheduler Task Initiated at {}", System.currentTimeMillis());
        MDC.put(CORRELATION_ID, String.valueOf(UUID.randomUUID()));
        MDC.put(SCENARIO, "dataPurging");
        MDC.put(OPERATION, "purgeOperationData");
        dataPurgeService.purgeOperationData();
        log.info("Purging Scheduler Task Completed at {}", System.currentTimeMillis());
    }
}
