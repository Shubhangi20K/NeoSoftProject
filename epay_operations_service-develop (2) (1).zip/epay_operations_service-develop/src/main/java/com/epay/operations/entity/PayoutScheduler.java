package com.epay.operations.entity;

import com.epay.operations.util.enums.Status;
import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.util.UUID;

/**
 * Class Name:PayoutScheduler
 * *
 * Description: Entity class for PayoutScheduler
 * *
 * Author: Akshaya Sahasranamam
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@Entity
@Table(name = "PAYOUT_SCHEDULER")
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class PayoutScheduler extends AuditEntityByDate {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(columnDefinition = "RAW(16)")
    private UUID psId;
    @Column(columnDefinition = "RAW(16)")
    private UUID rfId;
    @Column(name = "TXN_MATCHED_COUNT")
    private int transactionMatchedCount;
    @Enumerated(EnumType.STRING)
    private Status status;

}
