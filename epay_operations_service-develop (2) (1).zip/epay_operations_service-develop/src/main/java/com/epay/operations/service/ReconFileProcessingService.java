package com.epay.operations.service;

import com.epay.operations.dao.FileConfigDao;
import com.epay.operations.dao.ReconFileDao;
import com.epay.operations.dao.ReconFileDetailsDao;
import com.epay.operations.dto.ReconFileDetailsDto;
import com.epay.operations.dto.ReconFileDto;
import com.epay.operations.dto.admin.FileConfigDto;
import com.epay.operations.service.file.FileService;
import com.epay.operations.util.enums.ReconStatus;
import com.epay.operations.util.enums.SettlementStatus;
import com.epay.operations.util.enums.Status;
import com.epay.operations.util.parser.CsvParser;
import com.epay.operations.util.parser.ExcelParser;
import com.epay.operations.util.parser.TxtParser;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.util.*;

import static com.epay.operations.util.OperationsConstant.*;

/**
 * Class Name: ReconFileProcessingService
 * *
 * Description:
 * *
 * Author:@V0000001(Shilpa Kothre)
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */

@Service
@RequiredArgsConstructor
public class ReconFileProcessingService {

    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private final ReconFileDao reconFileDao;
    private final ReconFileDetailsDao reconFileDetailsDao;
    private final FileConfigDao fileConfigDao;
    private final FileService fileService;
    private final ReconProcessingService reconProcessingService;

    public void reconFileProcessing(UUID rfId) {
        //1: Start File Processing
        ReconFileDto reconFileDto = initiateReconFileProcessing(rfId);
        try {
            logger.info("Starting processing of Recon rfId: {}", rfId);

            //2: Save Recon File Summary Data
            List<ReconFileDetailsDto> reconFileDetailsDtoList = processReconFileDetailsData(reconFileDto);

            //3: Complete File Processing
            if (CollectionUtils.isNotEmpty(reconFileDetailsDtoList)) {
                reconFileDto.setTotalRecords(reconFileDetailsDtoList.size());
                reconFileDto.setTotalAmount(reconFileDetailsDtoList.stream().map(ReconFileDetailsDto::getTransactionAmount).reduce(BigDecimal.ZERO, BigDecimal::add));
                updateReconFileStatus(reconFileDto, "Parsing Completed", Status.SUCCESS);
                logger.info("Completed parsing rfId: {} with detailRecordCount : {}", rfId, reconFileDetailsDtoList.size());
                reconProcessingService.performReconciliation(rfId);
            } else {
                updateReconFileStatus(reconFileDto, "Empty ReconFileDetails", Status.FAIL);
                logger.info("Completed parsing rfId: {} with empty detailRecordCount", rfId);
            }
        } catch (Exception e) {
            logger.error("Error during Recon File Processing for rfId : {}", rfId, e);
            updateReconFileStatus(reconFileDto, e.getMessage(), Status.FAIL);
        }
    }

    private void updateReconFileStatus(ReconFileDto reconFileDto, String remark, Status status) {
        reconFileDto.setRemark(remark);
        reconFileDto.setParsingStatus(status);
        reconFileDto.setReconStatus(Status.FAIL.equals(status) ? ReconStatus.FAIL : ReconStatus.PENDING);
        reconFileDto.setSettlementStatus(Status.FAIL.equals(status) ? SettlementStatus.FAIL : SettlementStatus.PENDING);
        reconFileDao.save(reconFileDto);
    }

    private ReconFileDto initiateReconFileProcessing(UUID rfId) {
        ReconFileDto reconFileDto = reconFileDao.findByReconFileId(rfId);
        reconFileDto.setParsingStatus(Status.IN_PROCESS);
        return reconFileDao.save(reconFileDto);
    }

    private List<ReconFileDetailsDto> processReconFileDetailsData(ReconFileDto reconFileDto) {
        //1: Load config data using config Id
        FileConfigDto fileConfigDto = fileConfigDao.loadFileConfig(reconFileDto.getConfigId());

        //2: Read file from s3 and convert into List<String[]>
        List<String[]> reconFileData = reconFileDataRetrieval(reconFileDto.getS3Path(), fileConfigDto);

        //3. Convert java object to ReconDataDetailsDto normalised form
        List<ReconFileDetailsDto> reconFileDetailsDtoList = buildReconFileDetails(reconFileData, fileConfigDto, reconFileDto.getRfId());

        //4. Save to DB
        reconFileDetailsDao.save(reconFileDetailsDtoList);
        return reconFileDetailsDtoList;
    }

    private List<String[]> reconFileDataRetrieval(String s3Path, FileConfigDto fileConfigDto) {
        logger.info("Starting downloading and process s3Path: {}", s3Path);
        try (InputStream inputStream = fileService.readFile(s3Path)) {
            return switch (fileConfigDto.getFileType()) {
                case CSV -> CsvParser.parseFile(inputStream, s3Path, fileConfigDto.getDelimiter());
                case TXT -> TxtParser.parseFile(inputStream, s3Path, fileConfigDto.getDelimiter());
                case XLS, XLSX -> ExcelParser.parseFile(inputStream, s3Path);
            };
        } catch (IOException e) {
            logger.error("Parsing Excel file failed for fileKey: {}", s3Path, e);
        }
        return Collections.emptyList();
    }

    public List<ReconFileDetailsDto> buildReconFileDetails(List<String[]> fileData, FileConfigDto fileConfigDto, UUID rfId) {
        logger.info("Starting parsing file for sftpPath: {}", fileConfigDto.getSftpPath());
        List<ReconFileDetailsDto> reconFileDetailsDtoList = new LinkedList<>();
        Map<String, Integer> headerMapping = fileConfigDto.getHeaderMapping();
        Map<String, String> valueMap = fileConfigDto.getValueMapping();
        int startPosition = fileConfigDto.getDataStartRow() == 0 ? 0 : fileConfigDto.getDataStartRow() - 1;
        for (int rowNumber = startPosition; rowNumber < fileData.size(); rowNumber++) {
            ReconFileDetailsDto reconFileDetailsDto = ReconFileDetailsDto.builder().rowNumber(rowNumber + 1).transactionAmount(BigDecimal.ZERO).rfId(rfId).atrnNum("NA").bankRefNumber("NA").mId("NA").build();
            String[] rowData = fileData.get(rowNumber);
            headerMapping.forEach((header, index) -> {
                if (index < rowData.length && rowData[index] != null && StringUtils.isNotEmpty(rowData[index].trim())) {
                    mapReconFileData(reconFileDetailsDto, header, rowData[index].trim(), valueMap);
                }
            });
            reconFileDetailsDtoList.add(reconFileDetailsDto);
        }

        logger.info("Completed parsing file for sftpPath: {}", fileConfigDto.getSftpPath());
        return reconFileDetailsDtoList;
    }

    private void mapReconFileData(ReconFileDetailsDto reconFileDetailsDto, String header, String value, Map<String, String> valueMap) {

        try {
            String headerValue = header.trim().toLowerCase();
            String mappedValue = (ObjectUtils.isNotEmpty(valueMap) && valueMap.containsKey(value)) ? valueMap.get(value) : value;
            switch (headerValue) {
                case ATRN_PARSING_KEY -> reconFileDetailsDto.setAtrnNum(mappedValue);
                case PAYMENT_AMOUNT_PARSING_KEY ->
                        reconFileDetailsDto.setTransactionAmount(new BigDecimal(mappedValue));
                case BANK_REF_NUMBER_PARSING_KEY -> reconFileDetailsDto.setBankRefNumber(mappedValue);
                default -> logger.error("header {} is not matching with configuration", header);
            }
        } catch (Exception e) {
            logger.error("Error in mapping data -- header:{} , value : {}, valueMap : {}", header, value, valueMap);
        }
    }

}
