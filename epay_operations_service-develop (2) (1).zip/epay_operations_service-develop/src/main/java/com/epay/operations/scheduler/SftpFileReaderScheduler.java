package com.epay.operations.scheduler;

import com.epay.operations.service.SftpFileReaderService;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.slf4j.MDC;
import org.springframework.scheduling.annotation.Scheduled;
import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.UUID;

import static com.epay.operations.util.OperationsConstant.*;

/**
 * Class Name: SftpFileReaderScheduler
 * *
 * Description: Scheduler to ingested sftp file
 * *
 * Author:@V0000001(Shilpa Kothre)
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@RequiredArgsConstructor
@Component
public class SftpFileReaderScheduler {

    private final SftpFileReaderService sftpFileReaderService;
    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());

    @Scheduled(cron = "${scheduler.cron.expression.sftp.recon.file}")
    @SchedulerLock(name = "SFTPReconFileReader", lockAtLeastFor = "${scheduler.lockAtLeastFor}", lockAtMostFor = "${scheduler.lockAtMostFor}")
    public void readSftpReconFiles() {
        MDC.put(CORRELATION, String.valueOf(UUID.randomUUID()));
        MDC.put(SCENARIO, "SftpFileReaderScheduler");
        MDC.put(OPERATION, "readSftpReconFiles");
        long startTime = Instant.now().toEpochMilli();
        logger.info("SFTPReconFileReader job- start time: {}", startTime);
        sftpFileReaderService.readSftpReconFiles();
        logger.info("SFTPReconFileReader job- end time: {}", Instant.now().toEpochMilli() - startTime);
    }
}
