package com.epay.operations.dto.spark;


import com.epay.operations.dto.transaction.MerchantTransactionDto;
import lombok.Data;

@Data
public class TransactionUnMatchedDto {
    private MerchantTransactionDto fileMerchantOrderPayment;
    private MerchantTransactionDto dbMerchantOrderPayment;
    private boolean isNew;
}
