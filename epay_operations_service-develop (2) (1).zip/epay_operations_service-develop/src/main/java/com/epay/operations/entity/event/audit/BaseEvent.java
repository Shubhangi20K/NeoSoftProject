package com.epay.operations.entity.event.audit;

import com.epay.operations.entity.AuditEntityByDate;
import com.epay.operations.util.enums.InterfaceType;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.MappedSuperclass;
import lombok.*;
import lombok.experimental.SuperBuilder;

@EqualsAndHashCode(callSuper = true)
@Data
@MappedSuperclass
@SuperBuilder
public class BaseEvent extends AuditEntityByDate {

    @Enumerated(EnumType.STRING)
    private InterfaceType interfaceType;
    private String topic;
    private String routingKey;
    private String message;
}
