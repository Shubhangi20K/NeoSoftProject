package com.epay.operations.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.util.UUID;


@Data
@Entity
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "PAYOUT_TXN_MAPPING")
public class PayoutTransactionMapping {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "PTM_ID", columnDefinition = "RAW(16)")
    private UUID id;

    @Column(name = "MP_ID", columnDefinition = "RAW(16)")
    private UUID payoutInfoId;
    @Column(columnDefinition = "RAW(16)")
    private UUID rfId;
    private String atrnNum;
}
