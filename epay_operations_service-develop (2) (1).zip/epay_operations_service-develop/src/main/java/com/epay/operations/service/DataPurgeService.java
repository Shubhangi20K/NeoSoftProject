package com.epay.operations.service;

import com.epay.operations.config.OpsConfig;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.LocalDateTime;
import static com.epay.operations.util.OperationsUtil.*;
/**
 * Class Name: DataFlushService
 * Description: This Service class responsible for purging (deleting) older operational data from the database.
 * Author:Rahul Yadav (V1019439)
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */

@Service
@RequiredArgsConstructor
public class DataPurgeService {
    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    private final OpsConfig opsConfig;
    private final ReconFileDtlsService reconFileDtlsService;
    private final PayoutService payoutService;
    private final DataSyncService dataSyncService;


    /**
     * Flushes older operational data from the database based on a configured retention period.
     */
    public void purgeOperationData(){
        long retentionDaysMillis =getRetentionDays(opsConfig.getPurgeRetentionDays());
        log.info("purging data older than: {}", Instant.ofEpochMilli(retentionDaysMillis));

        log.info("Data purging started for Recon file details.");
        reconFileDtlsService.purgeReconFileDetailsWithRetry(retentionDaysMillis);
        log.info("Data purging completed for recon file data");

        log.info("Data purging started for Merchant Txn Payout.");
        payoutService.purgeMerchantTransactionPayoutWithRetry(retentionDaysMillis);
        log.info("Data purging completed for Merchant Txn Payout.");

        log.info("Data purging started for Merchant Txn.");
        dataSyncService.purgeMerchantTransactionWithRetry(retentionDaysMillis);
        log.info("Data purging completed for Merchant Txn.");

        log.info("Purging done at: {}", LocalDateTime.now());
    }
}
