package com.epay.operations.dao;


import com.epay.operations.dto.admin.MerchantBankAccountsDto;
import com.epay.operations.dto.admin.MerchantInfoDto;
import com.epay.operations.externalservice.AdminServicesClient;
import com.epay.operations.model.response.BankConfigFileResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Class Name:AdminDao
 * *
 * Description:
 * *
 * Author:NIRMAL GURJAR
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
@Component
@RequiredArgsConstructor
public class AdminDao {

    private final AdminServicesClient adminServicesClient;

    /**
     * Call admin service and fetch file config for give config id.
     *
     * @param configId UUID
     * @return BankConfigFileResponse
     */
    public BankConfigFileResponse loadFileConfig(UUID configId) {
        return adminServicesClient.getBankConfigurationDetailsById(String.valueOf(configId)).getData().getFirst();
    }

    /**
     * Call admin service and fetch all bank file configs.
     *
     * @return List of BankConfigFileResponse
     */
    public List<BankConfigFileResponse> loadAllBankFilesConfiguration() {
        return adminServicesClient.loadAllBankFilesConfiguration().getData();
    }

    public List<MerchantBankAccountsDto> getMerchantBankAccountInfo(List<String> mIdList) {
        List<MerchantBankAccountsDto> merchantBankAccountsDTOs = new ArrayList<>();
        int i = 0;
        while (i < mIdList.size()) {
            int to = Math.min(mIdList.size(), 150 + i);
            merchantBankAccountsDTOs.addAll(adminServicesClient.getMerchantBankAccountDetails(mIdList.subList(i, to)).getData());
            i = i + 150;
        }
        return merchantBankAccountsDTOs;
    }

    public List<MerchantInfoDto> getMerchantInfo(List<String> mIdList) {
        List<MerchantInfoDto> merchantInfoDtoList = new ArrayList<>();
        int i = 0;
        while (i < mIdList.size()) {
            int to = Math.min(mIdList.size(), 150 + i);
            merchantInfoDtoList.addAll(adminServicesClient.getMerchantInfo(mIdList.subList(i, to)).getData());
            i = i + 150;
        }
        return merchantInfoDtoList;
    }

}
