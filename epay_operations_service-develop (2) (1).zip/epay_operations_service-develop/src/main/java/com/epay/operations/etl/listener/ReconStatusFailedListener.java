package com.epay.operations.etl.listener;

import com.epay.operations.service.ReconStatusFailedService;
import com.epay.operations.util.enums.InterfaceType;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.MDC;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import java.util.UUID;

import static com.epay.operations.util.EventMessageUtils.buildEventErrorLog;
import static com.epay.operations.util.EventMessageUtils.buildEventReceivedLog;
import static com.epay.operations.util.OperationsConstant.*;

/**
 * Class Name: ReconRecordErrorDataListener
 * Description: The implementation is for consume  recon error Record data.
 * Author: V0000001(SHILPA KOTHRE)
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * Version:1.0
 */
@Component
@RequiredArgsConstructor
public class ReconStatusFailedListener {
    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    private final ReconStatusFailedService reconStatusFailedService;
    private final ApplicationEventPublisher publisher;

    @KafkaListener(topics = "${spring.kafka.topic.recon.record.fail}")
    public void reconRecordErrorProcessing(ConsumerRecord<String, String> consumerRecord) {
        log.info("Received Kafka message: {}", consumerRecord);
        MDC.put(CORRELATION, String.valueOf(UUID.randomUUID()));
        MDC.put(SCENARIO, "ReconRecordErrorDataListener");
        MDC.put(OPERATION, "reconRecordErrorProcessing");
        try {
            publisher.publishEvent(buildEventReceivedLog(InterfaceType.OPS_RECON_FAIL_ACK_TOPIC, consumerRecord));
            String rfIdRemark = consumerRecord.value();
            UUID rfdId = UUID.fromString(rfIdRemark.substring(0,rfIdRemark.indexOf(":")));
            String remark = rfIdRemark.substring(rfIdRemark.indexOf(":") + 1);
            log.info("Received Kafka message  rfId : {} and Remark : {} ", rfdId,remark);
            reconStatusFailedService.updatedFailedRecord(rfdId,remark);
        } catch (Exception e) {
            publisher.publishEvent(buildEventErrorLog(InterfaceType.OPS_RECON_FAIL_ACK_TOPIC, consumerRecord, e.getMessage()));
            log.error("Error during RecordErrorData kafka listening message[key:{} and value: {}], error: {}", consumerRecord.key(), consumerRecord.value(), e.getMessage());
        }
    }
}
