package com.epay.operations.util.file;

import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.experimental.UtilityClass;
import org.apache.commons.lang3.StringUtils;

import java.io.File;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@UtilityClass
public class FileUtil {

    private final LoggerUtility log = LoggerFactoryUtility.getLogger(FileUtil.class);

    public static String calculateChecksum(byte[] fileData) {
        try {
            MessageDigest shaDigest = MessageDigest.getInstance("SHA-512");
            byte [] hashedBytes = shaDigest.digest(fileData);
            StringBuilder sb = new StringBuilder();
            for(byte b : hashedBytes) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException  e) {
            log.error("Fail to calculate the check sum for the file, error : {}", e);
        }
        return StringUtils.EMPTY;
    }

    public static String getFileName(String filePath) {
        File file = new File(filePath);
        String fileName = file.getName();
        int dotIndex = fileName.lastIndexOf('.');
        return (dotIndex > 0) ? fileName.substring(0, dotIndex) : fileName;
    }
}
