package com.epay.operations.etl.producer;

import com.epay.operations.config.kafka.Topics;
import com.epay.operations.dto.report.ReportDto;
import com.epay.operations.util.enums.InterfaceType;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.AllArgsConstructor;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Component;

import static com.epay.operations.util.EventMessageUtils.buildEventErrorLog;
import static com.epay.operations.util.EventMessageUtils.buildEventSendLog;
import static com.epay.operations.util.OperationsUtil.getKafkaRoutingKey;

/**
 * Class Name:ReportRequestPublisher
 * <p>
 * Description: Payout Generation success queue.
 * <p>
 * Copyright (c) [2025] [State Bank of India]
 * All rights reserved.
 * <p>
 * Author: Saurabh Mahto (V1018841)
 * Version:1.0
 */
@Component
@AllArgsConstructor
public class ReportRequestPublisher {

    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    private final KafkaMessagePublisher kafkaMessagePublisher;
    private final Topics topics;
    private final ObjectMapper objectMapper;
    private final ApplicationEventPublisher publisher;


    /**
     * @param requestType String
     * @param routingKey  String
     * @param reportDto   ReportDto
     */
    public void publish(String requestType, String routingKey, ReportDto reportDto) {
        String kafkaRoutingKey = getKafkaRoutingKey(requestType, requestType, routingKey);
        try {
            log.debug("Request for requestType : {}, routingKey : {} and value : {}", requestType, routingKey, objectMapper.writeValueAsString(reportDto));
            kafkaMessagePublisher.publish(topics.getReportGenerationTopic(), kafkaRoutingKey, objectMapper.writeValueAsString(reportDto));
            publisher.publishEvent(buildEventSendLog(InterfaceType.OPS_REPORT_GENERATION_TOPIC, topics.getReportGenerationTopic(), kafkaRoutingKey, objectMapper.writeValueAsString(reportDto)));
            log.debug("Request for report type : {} has been published", reportDto.getReportType());
        } catch (Exception e) {
            log.error("Error in publishing  report type : {}", reportDto.toString(), e.getMessage());
            publisher.publishEvent(buildEventErrorLog(InterfaceType.OPS_REPORT_GENERATION_TOPIC, topics.getReportGenerationTopic(), kafkaRoutingKey, e.getMessage()));
        }
    }
}
