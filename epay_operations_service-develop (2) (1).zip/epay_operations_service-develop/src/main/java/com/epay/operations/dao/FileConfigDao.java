package com.epay.operations.dao;

import com.epay.operations.dto.admin.FileConfigDto;
import com.epay.operations.mapper.FileConfigMapper;
import com.epay.operations.model.response.BankConfigFileResponse;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.UUID;

@Component
@RequiredArgsConstructor
public class FileConfigDao {

    private final AdminDao adminDao;
    private final FileConfigMapper fileConfigMapper;
    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());

    public FileConfigDto loadFileConfig(UUID configId) {
        logger.info("Loading file config for configId: {}", configId);

        // Step 1: Fetch from Admin service (DB)
        logger.info("Cache miss. Fetching from Admin service for configId: {}", configId);
        BankConfigFileResponse response = adminDao.loadFileConfig(configId);
        // Step 2: Return result
       return fileConfigMapper.mapToDto(response);
    }

    public List<FileConfigDto> loadAllFileConfig() {

        logger.info("Loading all file configs from cache first");
        // Step 1: Fetch from Admin service
        logger.info("Cache miss. Fetching all configs from Admin service.");
        List<BankConfigFileResponse> responseList = adminDao.loadAllBankFilesConfiguration();
        logger.info("BankConfig file info fetched from DB, saving to cache.");
        // Step 2: saving to cache
        return fileConfigMapper.mapToDto(responseList);
    }
}