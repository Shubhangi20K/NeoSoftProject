package com.epay.operations.entity;

import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.util.UUID;

/**
 * Class Name:PayoutScheduler
 * *
 * Description: Entity class for operation scheduler
 * *
 * Author: Nirmal
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@Entity
@Table(name = "DATA_SYNC_SCHEDULER")
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class DataSyncScheduler extends AuditEntityByDate {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(columnDefinition = "RAW(16)")
    private UUID dssId;
    private String schedulerName;
    private long schedulerLastRun;

}
