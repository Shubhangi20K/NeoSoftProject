package com.epay.operations.config.kafka;

import lombok.Getter;
import org.apache.kafka.clients.admin.NewTopic;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

/**
 * Class Name: Topics<br>
 * Description: kafka topic setting.<br>
 * Author:@V0000001(Shilpa Kothre)<br>
 * Copyright (c) 2025 [State Bank of India]<br>
 * All rights reserved<br>
 * Version:1.0
 */
@Getter
@Component
public class Topics {

    @Value("${spring.kafka.topic.partitions}")
    private int noOfPartitions;

    @Value("${spring.kafka.topic.replicationFactor}")
    private short replicationFactor;

    @Value("${spring.kafka.topic.recon.file}")
    private String reconFileTopic;

    @Value("${spring.kafka.topic.recon.record.match}")
    private String reconMatchRecordTopic;

    @Value("${spring.kafka.topic.recon.record.unmatched}")
    private String reconUnmatchedRecordTopic;

    @Value("${spring.kafka.topic.recon.record.duplicate}")
    private String reconDuplicateRecordTopic;

    @Value("${spring.kafka.topic.payout}")
    private String payoutTopic;

    @Value("${spring.kafka.topic.refund.adjust}")
    private String refundAdjustTopic;

   @Value("${spring.kafka.topic.report.generation}")
   private String reportGenerationTopic;

    /**
     * Create Recon file summary Apache Kafka topic.
     *
     * @return NewTopic
     */
    @Bean
    public NewTopic createReconFileProcessingTopic() {
        return new NewTopic(reconFileTopic, noOfPartitions, replicationFactor);
    }

}
