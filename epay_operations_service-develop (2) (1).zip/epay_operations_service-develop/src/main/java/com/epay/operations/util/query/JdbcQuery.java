package com.epay.operations.util.query;

import lombok.experimental.UtilityClass;

import java.util.UUID;

/**
 * Class Name: JdbcQuery<br>
 * Description: Define all JDBC native queries.<br>
 * Author: V1019620(Bhoopendra Rajput)<br>
 * Copyright (c) 2024 [State Bank of India]<br>
 * All rights reserved<br>
 * Version:1.0
 */
@UtilityClass
public class JdbcQuery {

    //Table Name
    public static final String MERCHANT_TRANSACTION = "MERCHANT_TXN";
    public static final String SPARK_RECON_STATUS_STAGE_MATCHED = "SPARK_RECON_STATUS_STAGE_MATCHED";
    public static final String SPARK_RECON_STATUS_STAGE_OTHERS = "SPARK_RECON_STATUS_STAGE_OTHERS";

    public static final String SELECT_YESTERDAY_BY_MILLIS_TEMPLATE = """
            (SELECT * FROM %s
             WHERE CREATED_DATE BETWEEN %d AND %d)
            """;

    public static String getYesterdayQuery(String table, long currentMillis) {
        long oneDayBefore = currentMillis - 24 * 60 * 60 * 1000;
        return String.format(SELECT_YESTERDAY_BY_MILLIS_TEMPLATE, table, oneDayBefore, currentMillis);
    }

    public static final String INSERT_MERCHANT_TXN = """
                INSERT INTO MERCHANT_TXN (ATRN_NUM, MERCHANT_ID, TXN_AMOUNT, MULTI_ACCOUNT, TXN_FEE)
                 SELECT ATRN_NUM, MERCHANT_ID, TXN_AMOUNT, MULTI_ACCOUNT, TXN_FEES
                  FROM MERCHANT_TXN_VIEW
                   WHERE CREATED_DATE > :LAST_RUN AND CREATED_DATE <= :CURR_RUN
            """;


    public static final String UPDATE_RECON_STATUS = """
            UPDATE RECON_FILE_DTLS rfd
            SET rfd.RECON_STATUS = :status,
            SETTLEMENT_STATUS = :settlementStatus,
            PAYOUT_STATUS = :payoutStatus,
            REMARK = :remark,
            UPDATED_DATE =:updatedDate
            WHERE  HEXTORAW(rfd.RFD_ID) IN (HEXTORAW(:rfdId))
            """;

    public static String buildQueryForRecon(UUID rfId) {
        String hexUUID = rfId.toString().replace("-", "").toUpperCase();
        return String.format("(SELECT r.* FROM RECON_FILE_DTLS r WHERE r.RF_ID = HEXTORAW('%s'))", hexUUID);
    }

    public static String buildQueryForTransaction(UUID rfId) {
        String hexUUID = rfId.toString().replace("-", "").toUpperCase();
        return String.format("(SELECT DISTINCT m.ATRN_NUM,m.MERCHANT_ID,m.TXN_AMOUNT,TO_CHAR(m.MULTI_ACCOUNT) AS MULTI_ACCOUNT FROM MERCHANT_TXN m, RECON_FILE_DTLS r WHERE r.ATRN_NUM = m.ATRN_NUM AND r.RF_ID = HEXTORAW('%s'))", hexUUID);
    }

    public String INSERT_RECON_FILE_DTLS = "INSERT INTO RECON_FILE_DTLS " +
            "(RFD_ID, RF_ID, ATRN_NUM, MERCHANT_ID, TXN_AMOUNT, ROW_NUMBER, BANK_REF_NUMBER, REMARK, CREATED_DATE) " +
            "VALUES " +
            "(:rfdId, :rfId, :atrnNum, :mId, :transactionAmount, :rowNumber, :bankRefNumber, :remark, :createdDate)";

    public String INSERT_RECON_FILE_DTLS_HISTORY = """
            INSERT INTO RECON_FILE_DTLS_HISTORY (
                RFD_ID, RF_ID, MERCHANT_ID, ROW_NUMBER, ATRN_NUM, TXN_AMOUNT,
                BANK_REF_NUMBER, RECON_STATUS, SETTLEMENT_STATUS, PAYOUT_STATUS,
                REMARK, CREATED_DATE, UPDATED_DATE
            )
            SELECT
                RFD_ID, RF_ID, MERCHANT_ID, ROW_NUMBER, ATRN_NUM, TXN_AMOUNT,
                BANK_REF_NUMBER, RECON_STATUS, SETTLEMENT_STATUS, PAYOUT_STATUS,
                REMARK, CREATED_DATE, UPDATED_DATE
            FROM RECON_FILE_DTLS
            WHERE RECON_STATUS IN ('MATCHED', 'PENDING')
            AND UPDATED_DATE < (:thresholdDate)
            """;

    public String DELETE_RECON_FILE_DTLS = """
            DELETE FROM RECON_FILE_DTLS
            WHERE RECON_STATUS IN ('MATCHED', 'PENDING')
            AND UPDATED_DATE < (:thresholdDate)
            """;


    public String INSERT_MERCHANT_TXN_PAYOUT_HISTORY = """
            INSERT INTO MERCHANT_TXN_PAYOUT_HISTORY (
                MTP_ID, RF_ID, ATRN_NUM, MERCHANT_ID, TXN_PAYOUT_AMOUNT, BANK_ID,
                ACCOUNT_ID, ACCOUNT_NUMBER, CREATED_DATE,
                UPDATED_DATE
            )
            SELECT
                mtp.MTP_ID, mtp.RF_ID, mtp.ATRN_NUM, mtp.MERCHANT_ID, mtp.TXN_PAYOUT_AMOUNT, mtp.BANK_ID,
                mtp.ACCOUNT_ID, mtp.ACCOUNT_NUMBER, mtp.CREATED_DATE,
                mtp.UPDATED_DATE
                FROM MERCHANT_TXN_PAYOUT mtp
                WHERE mtp.ATRN_NUM IN (
                    SELECT ptm.ATRN_NUM
                    FROM PAYOUT_TXN_MAPPING ptm
                    INNER JOIN MERCHANT_PAYOUT mp ON ptm.MP_ID = mp.MP_ID
                    WHERE mp.PAYOUT_STATUS = 'SUCCESS'
                    AND mp.UPDATED_DATE < (:thresholdDate)
                )
            """;


    public String DELETE_MERCHANT_TXN_PAYOUT = """
             DELETE FROM MERCHANT_TXN_PAYOUT mtp
                        WHERE mtp.ATRN_NUM IN (
                            SELECT ptm.ATRN_NUM
                            FROM PAYOUT_TXN_MAPPING ptm
                            INNER JOIN MERCHANT_PAYOUT mp ON ptm.MP_ID = mp.MP_ID
                            WHERE mp.PAYOUT_STATUS = 'SUCCESS'
                            AND mp.UPDATED_DATE < (:thresholdDate)
                        )
            """;

    public String DELETE_MERCHANT_TXN = """
            DELETE FROM MERCHANT_TXN mt
            WHERE mt.ATRN_NUM IN (
                SELECT ptm.ATRN_NUM
                FROM PAYOUT_TXN_MAPPING ptm
                INNER JOIN MERCHANT_PAYOUT mp ON ptm.MP_ID = mp.MP_ID
                WHERE mp.PAYOUT_STATUS = 'SUCCESS'
                AND mp.UPDATED_DATE < (:thresholdDate)
            )
        """;
}

