package com.epay.operations.etl.listener;

import com.epay.operations.service.ReconFileProcessingService;
import com.epay.operations.util.enums.InterfaceType;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.MDC;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import java.util.UUID;

import static com.epay.operations.util.EventMessageUtils.buildEventErrorLog;
import static com.epay.operations.util.EventMessageUtils.buildEventReceivedLog;
import static com.epay.operations.util.OperationsConstant.*;

/**
 * Class Name: ReconFileProcessingListener
 * *
 * Description: The implementation is for consume the data from SFTP Ingestion producer.
 * *
 * Author: V1019285(NIRMAL GURJAR)
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Component
@RequiredArgsConstructor
public class ReconFileProcessingListener {

    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    private final ReconFileProcessingService reconFileProcessingService;
    private final ApplicationEventPublisher publisher;

    @KafkaListener(topics = "${spring.kafka.topic.recon.file}")
    public void reconFileProcessing(ConsumerRecord<String, String> consumerRecord) {
        log.info("Received Kafka message: {}", consumerRecord);
        MDC.put(CORRELATION, String.valueOf(UUID.randomUUID()));
        MDC.put(SCENARIO, "ReconFileProcessingListener");
        MDC.put(OPERATION, "reconFileProcessing");
        try {
            publisher.publishEvent(buildEventReceivedLog(InterfaceType.OPS_RECON_FILE_TOPIC, consumerRecord));
            reconFileProcessingService.reconFileProcessing(UUID.fromString(consumerRecord.value()));
        } catch (Exception e) {
            publisher.publishEvent(buildEventErrorLog(InterfaceType.OPS_RECON_FILE_TOPIC, consumerRecord, e.getMessage()));
            log.error("Error during reconFileProcessing kafka listening message[key:{} and value: {}], error: {}", consumerRecord.key(), consumerRecord.value(), e.getMessage());
        }
    }
}
