package com.epay.operations.service;

import com.epay.operations.dao.ReportRequestDao;
import com.epay.operations.dto.PayoutInfoDto;
import com.epay.operations.dto.report.ReportDto;
import com.epay.operations.dto.report.ReportFilterDto;
import com.epay.operations.dto.report.ReportRequestDto;
import com.epay.operations.dto.report.ReportResponseDto;
import com.epay.operations.etl.producer.ReportRequestPublisher;
import com.epay.operations.service.sftp.SftpClientService;
import com.epay.operations.util.enums.Report;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.UUID;

/**
 * Class Name: PayoutReportService
 * Description: To generate different types of reports.
 * Author: V1018841(Saurabh Mahto)
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * Version:1.0
 */
@Service
@RequiredArgsConstructor
public class PayoutReportService {

    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    private final ReportRequestDao reportRequestDao;
    private final ReportRequestPublisher reportRequestPublisher;
    private final SftpClientService sftpClientService;

    public void reportGenerationRequest() {
        log.info("Getting list of MpId based upon payoutStatus and refund adjusted.");
        List<UUID> merchantPayouts = reportRequestDao.getAllMerchantPayoutForReport();
        if (CollectionUtils.isEmpty(merchantPayouts)) {
            log.info("No Pending Merchant Payout for Report generation");
            return;
        }
        PayoutInfoDto payoutInfoDto = createReportAndBuildPayoutInfo(merchantPayouts);
        log.info("Report request completed, saving payout info.");
        reportRequestDao.savePayoutInfo(payoutInfoDto, merchantPayouts);
    }

    private PayoutInfoDto createReportAndBuildPayoutInfo(List<UUID> merchantPayouts) {

        log.info("Report generation request for type : {}", Report.NEFT_PAYOUT);
        UUID neftId = reportRequest(merchantPayouts, Report.NEFT_PAYOUT);
        log.info("Report generation request for type : {}", Report.AAT_PAYOUT);
        UUID aatId = reportRequest(merchantPayouts, Report.AAT_PAYOUT);
        log.info("Report generation request for type : {}", Report.TRANSACTION_WISE_PAYOUT_MIS);
        UUID transactionMisId = reportRequest(merchantPayouts, Report.TRANSACTION_WISE_PAYOUT_MIS);
        log.info("Report generation request for type : {}", Report.MERCHANT_WISE_PAYOUT_MIS);
        UUID merchantMisId = reportRequest(merchantPayouts, Report.MERCHANT_WISE_PAYOUT_MIS);
        log.info("Report generation request for type : {}", Report.TRANSACTION_WISE_REFUND_MIS);
        UUID refundMisId = reportRequest(merchantPayouts, Report.TRANSACTION_WISE_REFUND_MIS);
        log.info("Report generated for neftReportId : {} ,aatReportId : {}, transactionMisId : {} , merchantMisId : {} , refundMisId : {}", neftId, aatId, transactionMisId, merchantMisId, refundMisId);

        return PayoutInfoDto.builder().neftReportId(neftId).aatReportId(aatId).txnMisReportId(transactionMisId).merchantMisReportId(merchantMisId).refundMisReportId(refundMisId).build();

    }

    /**
     * @param reportResponseDto ReportResponseDto
     */
    public void downloadReport(ReportResponseDto reportResponseDto) {
        // Find ReportRequest based upon oreId
        log.info("Getting data for oreId : {}", reportResponseDto.getRrId());
        ReportRequestDto reportRequestDto = reportRequestDao.getByReportRequestId(reportResponseDto.getRrId());
        // Set seFilePath in reportRequestDto
        reportRequestDto.setS3Path(reportResponseDto.getS3FilePath());
        // Save reportRequestDto in DB
        log.info("Saving s3Path into DB : {}", reportResponseDto.getS3FilePath());
        //Upload Report File on SFTP
        if (StringUtils.isNotEmpty(reportRequestDto.getSftpPath())) {
            String sftpFilePath = sftpClientService.uploadS3File(reportRequestDto.getSftpPath(), reportRequestDto.getS3Path());
            reportRequestDto.setSftpPath(sftpFilePath);
        } else {
            log.info("Sftp path does not exist, for reportRequest: {}", reportRequestDto);
        }
        reportRequestDao.update(reportRequestDto);
    }

    private UUID saveAndPublishReportRequest(ReportRequestDto reportRequestDto) {
        //Step.1 Save opsReportRequest and get oreId.
        log.info("Saving reportRequest: " + reportRequestDto);
        reportRequestDto = reportRequestDao.save(reportRequestDto);
        //Step.2 Build ReportDto.
        ReportDto reportDto = buildReportDto(reportRequestDto);
        //Step.3 Publish report request to Report service.
        log.info("Publishing reportDto to ReportService : " + reportDto);
        reportRequestPublisher.publish(reportDto.getReportType().getName(), String.valueOf(reportDto.getRrId()), reportDto);
        return reportRequestDto.getRrId();

    }

    private ReportDto buildReportDto(ReportRequestDto reportRequestDto) {
        return ReportDto.builder().reportType(reportRequestDto.getReportType()).rrId(reportRequestDto.getRrId()).reportFilter(reportRequestDto.getReportFilter()).build();
    }

    private UUID reportRequest(List<UUID> merchantPayouts, Report reportType) {
        ReportFilterDto reportFilterDto = ReportFilterDto.builder().mpIdList(merchantPayouts).build();
        String SftpPath = StringUtils.join("/PayoutReport/", LocalDate.now().format(DateTimeFormatter.ofPattern("ddMMyyyy")));
        ReportRequestDto reportRequestDto = ReportRequestDto.builder().reportFilter(reportFilterDto).sftpPath(SftpPath).encryptionRequired(false).reportType(reportType).build();
        return saveAndPublishReportRequest(reportRequestDto);
    }

    /**
     * To generate a report for Unmatched and Duplicate report.
     *
     * @param rfId       UUID file Id
     * @param reportType Report Type
     * @param sftpPath   path to upload on sftp
     */
    public void badReportRequest(UUID rfId, Report reportType, String sftpPath) {
        ReportFilterDto reportFilterDto = ReportFilterDto.builder().rfId(rfId).build();
        ReportRequestDto reportRequestDto = ReportRequestDto.builder().reportFilter(reportFilterDto).sftpPath(sftpPath).encryptionRequired(false).reportType(reportType).build();
        saveAndPublishReportRequest(reportRequestDto);
    }

}
