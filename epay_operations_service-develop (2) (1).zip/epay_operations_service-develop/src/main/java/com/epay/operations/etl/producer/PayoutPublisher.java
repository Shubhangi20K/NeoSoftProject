package com.epay.operations.etl.producer;

import com.epay.operations.config.kafka.Topics;
import com.epay.operations.util.enums.InterfaceType;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.AllArgsConstructor;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Component;

import java.util.UUID;

import static com.epay.operations.util.EventMessageUtils.buildEventErrorLog;
import static com.epay.operations.util.EventMessageUtils.buildEventSendLog;
import static com.epay.operations.util.OperationsConstant.PAYOUT_KEY;
import static com.epay.operations.util.OperationsUtil.getKafkaRoutingKey;

/**
 * Class Name:PayoutPublisher
 * <p>
 * Description: Payout initiation for given rfsId
 * <p>
 * Copyright (c) [2025] [State Bank of India]
 * All rights reserved.
 * <p>
 * Author: Akshaya Sahasranamam
 * Version:1.0
 */
@Component
@AllArgsConstructor
public class PayoutPublisher {

    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    private final KafkaMessagePublisher kafkaMessagePublisher;
    private final Topics topics;
    private final ApplicationEventPublisher publisher;

    /**
     * @param requestType String
     * @param routingKey  String
     * @param rfId        rfID
     */
    public void publish(String requestType, String routingKey, UUID rfId) {
        try {
            log.info("Payout initiation for requestType : {}, routingKey : {} and value : {}", requestType, routingKey, rfId);
            kafkaMessagePublisher.publish(topics.getPayoutTopic(), getKafkaRoutingKey(PAYOUT_KEY, requestType, routingKey), String.valueOf(rfId));
            publisher.publishEvent(buildEventSendLog(InterfaceType.OPS_PAYOUT_TOPIC, topics.getPayoutTopic(), routingKey, String.valueOf(rfId)));
            log.info("Payout initiation published");
        } catch (Exception e) {
            publisher.publishEvent(buildEventErrorLog(InterfaceType.OPS_PAYOUT_TOPIC, topics.getPayoutTopic(), routingKey, e.getMessage()));
            log.error("Error in Payout initiation queue {}", rfId, e.getMessage());
            throw e;
        }
    }
}

