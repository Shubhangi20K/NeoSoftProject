package com.epay.operations.dao;

import com.epay.operations.dto.DataSyncSchedulerDto;
import com.epay.operations.entity.DataSyncScheduler;
import com.epay.operations.mapper.DataSyncSchedulerMapper;
import com.epay.operations.repository.DataSyncSchedulerRepository;
import com.epay.operations.util.query.JdbcQuery;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class DataSyncSchedulerDao {

    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    private final DataSyncSchedulerRepository dataSyncSchedulerRepository;
    private final DataSyncSchedulerMapper dataSyncSchedulerMapper;
    private final NamedParameterJdbcTemplate jdbcTemplate;

    public void save(DataSyncSchedulerDto dataSyncSchedulerDto) {
        dataSyncSchedulerMapper.entityToDto(dataSyncSchedulerRepository.save(dataSyncSchedulerMapper.mapToEntity(dataSyncSchedulerDto)));
    }

    public DataSyncSchedulerDto findBySchedulerName(String schedulerName) {
        DataSyncScheduler dataSyncScheduler = dataSyncSchedulerRepository.findBySchedulerName(schedulerName).orElse(buildDefaultDataSyncScheduler(schedulerName));
        return dataSyncSchedulerMapper.entityToDto(dataSyncScheduler);
    }

    public void saveTransactionDataSync(long lastRun, long currRun) {
        try {
            MapSqlParameterSource param = new MapSqlParameterSource();
            param.addValue("LAST_RUN", lastRun);
            param.addValue("CURR_RUN", currRun);
            int insertCount = jdbcTemplate.update(JdbcQuery.INSERT_MERCHANT_TXN, param);
            log.info("Inserted {} records into MERCHANT_TXN", insertCount);
        } catch (Exception ex) {
            log.error("Error during Transaction Data Sync for MERCHANT_TXN : {}", ex);
            throw ex;
        }
    }

    private DataSyncScheduler buildDefaultDataSyncScheduler(String schedulerName){
        return DataSyncScheduler.builder()
                .schedulerName(schedulerName)
                .schedulerLastRun(0)
                .build();
    }

    public int deleteMerchantTransaction(long retentionDaysMillis) {
        log.info("data deleting from MerchantTransaction.");
        MapSqlParameterSource param = new MapSqlParameterSource();
        param.addValue("thresholdDate", retentionDaysMillis);
        return jdbcTemplate.update(JdbcQuery.DELETE_MERCHANT_TXN, param);
    }
}
