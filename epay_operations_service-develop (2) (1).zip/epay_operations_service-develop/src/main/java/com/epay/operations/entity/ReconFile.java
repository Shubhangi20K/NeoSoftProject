package com.epay.operations.entity;

import com.epay.operations.util.enums.ReconStatus;
import com.epay.operations.util.enums.SettlementStatus;
import com.epay.operations.util.enums.Status;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;
import java.util.UUID;

/**
 * Class Name:ReconData<br>
 * Description: Entity class for ReconData<br>
 * Author:@V0000001(Shilpa Kothre)<br>
 * Copyright (c) 2025 [State Bank of India]<br>
 * All right reserved<br>
 * Version:1.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@Entity
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "RECON_FILE")
public class ReconFile extends AuditEntityByDate {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(columnDefinition = "RAW(16)")
    private UUID rfId;
    @Column(columnDefinition = "RAW(16)")
    private UUID configId;
    private String bankCode;
    private String sftpPath;
    @Column(name = "S3_PATH")
    private String s3Path;
    private String ackSftpPath;
    private String fileName;
    private String fileChecksum;
    private Long fileReceivedTime;

    @Enumerated(EnumType.STRING)
    private Status parsingStatus;

    private BigDecimal totalAmount;
    private Integer totalRecords;
    private Integer matchedRecords;
    private BigDecimal matchedAmount;
    private Integer unmatchedRecords;
    private BigDecimal unmatchedAmount;
    private Integer duplicateRecords;
    private BigDecimal duplicateAmount;

    @Enumerated(EnumType.STRING)
    private ReconStatus reconStatus;
    private Long reconTime;

    @Enumerated(EnumType.STRING)
    private SettlementStatus settlementStatus;
    private Long settlementTime;

    private String remark;
}
