package com.epay.operations.service;

import static com.epay.operations.util.DateTimeUtils.DATE_TIME_FORMATTER_ALL;
import static com.epay.operations.util.DateTimeUtils.getCurrentTime;
import static com.epay.operations.util.OperationsConstant.IN_FOLDER;
import static com.epay.operations.util.OperationsConstant.OUT_FOLDER;
import static com.epay.operations.util.OperationsUtil.replacePath;
import static java.lang.String.format;

import com.epay.operations.service.sftp.SftpClientService;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.time.LocalDateTime;

import lombok.RequiredArgsConstructor;
import org.apache.commons.io.FilenameUtils;
import org.springframework.stereotype.Service;

/**
 * Class Name: AckFileService
 * *
 * Description: generate acknowledgement file to sftp
 * *
 * Author:@V0000001(Shilpa Kothre)
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Service
@RequiredArgsConstructor
public class AcknowledgmentService {

    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private final SftpClientService sftpService;

    /**
     * Generates an acknowledgment file
     * @param status   The status string to include.
     */
    public void uploadAckFile(String originalPath, String fileName, String status)  {
        String ackDirPath = replacePath(originalPath, IN_FOLDER, OUT_FOLDER);
        String dateStr = LocalDateTime.now().format(DATE_TIME_FORMATTER_ALL);

        // Full file path
        String ackFileName =format("%s_%s.txt", FilenameUtils.getBaseName(fileName), getCurrentTime());

        // Prepare file content
        StringBuilder contentBuilder = new StringBuilder();
        contentBuilder.append("Filename: ").append(fileName).append("\n");
        contentBuilder.append("Status: ").append(status).append("\n");
        contentBuilder.append("Timestamp: ").append(dateStr).append("\n");

        // Write content to file
        try (ByteArrayOutputStream op = new ByteArrayOutputStream()) {
            op.write(contentBuilder.toString().getBytes());
            sftpService.uploadFile(ackDirPath, ackFileName, op.toByteArray());
            logger.info("File {} process from sftpFolderPath: {} to ack folder : {} with name : {}", fileName, originalPath, ackDirPath, ackFileName);
        } catch (IOException e) {
            logger.error("Error while generating acknowledgement for sftpFolderPath: {}, fileName: {} with error : {}", originalPath, fileName, e.getMessage());
        }
    }

}