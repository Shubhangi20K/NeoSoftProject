package com.epay.operations.dao;

import com.epay.operations.dto.PayoutSchedulerDto;
import com.epay.operations.entity.PayoutScheduler;
import com.epay.operations.mapper.PayoutSchedulerDataMapper;
import com.epay.operations.repository.PayoutScheduleRepository;
import com.epay.operations.util.enums.Status;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.UUID;

/**
 * Class Name:PayoutScheduleDao
 * Description: To fetch and save payout scheduler data
 * Author:Akshaya Sahasranamam
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
@Component
@RequiredArgsConstructor
public class PayoutScheduleDao {

    private final PayoutScheduleRepository payoutScheduleRepository;
    private final PayoutSchedulerDataMapper payoutSchedulerDataMapper;

    public void savePayoutSchedule(UUID rfId, int size) {
        PayoutScheduler payoutScheduler = buildPayoutSchedule(rfId, size);
        payoutScheduleRepository.save(payoutScheduler);
    }

    public void save(PayoutSchedulerDto payoutSchedulerDto) {
        payoutScheduleRepository.save(payoutSchedulerDataMapper.mapToEntity(payoutSchedulerDto));
    }

    private static PayoutScheduler buildPayoutSchedule(UUID rfId, int size) {
        return PayoutScheduler.builder().rfId(rfId).status(Status.PENDING).transactionMatchedCount(size).build();
    }

    public List<PayoutSchedulerDto> getPayoutSchedulerByStatus(List<Status> statusList) {
        List<PayoutScheduler> payoutScheduleList = payoutScheduleRepository.findByStatusIn(statusList);
        return payoutSchedulerDataMapper.mapToDtoList(payoutScheduleList);
    }

}
