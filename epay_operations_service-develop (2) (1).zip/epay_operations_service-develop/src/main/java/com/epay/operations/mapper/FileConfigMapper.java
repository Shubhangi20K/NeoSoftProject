package com.epay.operations.mapper;

import com.epay.operations.dto.admin.FileConfigDto;
import com.epay.operations.model.response.BankConfigFileResponse;
import com.epay.operations.util.OperationsUtil;
import com.sbi.epay.cache.admin.entity.BankFileConfigCache;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;
import java.util.UUID;

/**
 * Class Name: FileConfigMapper <br/>
 * Description: This interface is used to map bank file config details cache and db.<br/>
 * Author: NIRMAL GURJAR<br/>
 * Copyright (c) 2025 [State Bank of India].<br/>
 * All right reserved.<br/>
 * Version:1.0
 */
@Mapper(componentModel = "spring", imports = {OperationsUtil.class, UUID.class})
public interface FileConfigMapper {

    // DB Response → DTO
    @Mapping(target = "headerMapping", expression = "java(OperationsUtil.convertJsonStringToMapSI(bankConfigFileResponse.getHeaderMapping()))")
    @Mapping(target = "valueMapping", expression = "java(OperationsUtil.convertJsonStringToMapSS(bankConfigFileResponse.getValueMapping()))")
    FileConfigDto mapToDto(BankConfigFileResponse bankConfigFileResponse);

    List<FileConfigDto> mapToDto(List<BankConfigFileResponse> bankConfigFileResponses);

    // Cache → DTO
    @Mapping(target = "configId", expression = "java(UUID.fromString(cache.getRfcId()))")
    @Mapping(target = "headerMapping", expression = "java(OperationsUtil.convertJsonStringToMapSI(cache.getHeaderMapping()))")
    @Mapping(target = "valueMapping", expression = "java(OperationsUtil.convertJsonStringToMapSS(cache.getValueMapping()))")
    FileConfigDto mapCacheToDto(BankFileConfigCache cache);

}

