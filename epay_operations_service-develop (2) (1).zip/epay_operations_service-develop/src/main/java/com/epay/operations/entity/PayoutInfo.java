package com.epay.operations.entity;

import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.util.UUID;

@EqualsAndHashCode(callSuper = true)
@Data
@Entity
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "PAYOUT_INFO")
public class PayoutInfo extends AuditEntityByDate {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(columnDefinition = "RAW(16)")
    private UUID piId;
    @Column(columnDefinition = "RAW(16)")
    private UUID neftReportId;
    @Column(columnDefinition = "RAW(16)")
    private UUID aatReportId;
    @Column(name = "TXN_MIS_REPORT_ID", columnDefinition = "RAW(16)")
    private UUID txnMisReportId;
    @Column(name = "MERCHANT_MIS_REPORT_ID", columnDefinition = "RAW(16)")
    private UUID merchantMisReportId;
    @Column(name="REFUND_MIS_REPORT_ID", columnDefinition = "RAW(16)")
    private UUID refundMisReportId;

}
