package com.epay.operations.config;

import com.epay.operations.dto.transaction.MerchantTransactionDto;
import org.apache.spark.sql.Encoder;
import org.apache.spark.sql.Encoders;
import org.apache.spark.sql.SparkSession;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Class Name: SparkConfig
 * Description: The SparkConfig class reads the application configuration for Apache Spark configs and creates it's required beans.
 * configurations to create all clients.
 * Author: V1019620(Bhoopendra Rajput)
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * Version:1.0
 */
@Configuration
public class SparkConfig {
    @Value("${spark.app.name}")
    private String appName;

    @Value("${spark.master}")
    private String master;

    /**
     * Create SparkSession bean in spring context.
     * @return SparkSession
     */
    @Bean
    public SparkSession sparkSession() {
        return SparkSession.builder().appName(appName).master(master).config("spark.ui.enabled", "false").getOrCreate();
    }

    /**
     * Create MerchantOrderPaymentDto Encoder bean in spring context.
     * @return Encoder
     */
    @Bean
    public Encoder<MerchantTransactionDto> getEncoder() {
        return Encoders.bean(MerchantTransactionDto.class);
    }
}
