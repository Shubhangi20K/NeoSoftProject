package com.epay.operations.service.file;

import org.springframework.stereotype.Service;

import java.io.InputStream;

/**
 * Class Name: FileService
 * Description: The FileService interface provides functionalities to interact with AWS S3 for uploading, downloading, and listing files.
 * It supports uploading files as a File, byte array, or MultipartFile, and handles the S3 client operations like put, get, and list objects.
 * It also provides error handling, logging, and custom exception throwing in case of S3 operation failures.
 * Author: Bhoopendra Rajput
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * Version: 1.0
 */
@Service
public interface FileService {

    /**
     * Uploads a file to S3 using byte array content.
     * @param fileName    the name of the file
     * @param fileContent the content of the file as byte array
     * @return the S3 key for the uploaded file
     */
    String uploadFile(String fileName, byte[] fileContent);

    /**
     * Reads file content from S3 and returns it as a ResponseBytes object.
     * @param key the S3 file key
     * @return file content as ResponseBytes
     */
    InputStream readFile(String key);

}