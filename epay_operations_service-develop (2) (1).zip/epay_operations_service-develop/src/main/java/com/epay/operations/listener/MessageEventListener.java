package com.epay.operations.listener;

import com.epay.operations.entity.event.audit.BaseEvent;
import com.epay.operations.repository.event.audit.BufferedRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class MessageEventListener {

    private final BufferedRepository bufferedRepository;

    @EventListener
    @Transactional
    public void sendEvent(BaseEvent eventData) {
        bufferedRepository.buffer(eventData);
    }

}
