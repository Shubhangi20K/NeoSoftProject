package com.epay.operations;

import com.epay.operations.config.audit.SpringSecurityAuditorAware;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.data.domain.AuditorAware;
import org.springframework.data.gemfire.config.annotation.ClientCacheApplication;
import org.springframework.data.gemfire.config.annotation.EnableEntityDefinedRegions;
import org.springframework.data.gemfire.repository.config.EnableGemfireRepositories;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * Class Name: OperationsServiceApplication<br>
 * Description: This class main method is to start the spring boot application. <br>
 * Author: V1019620(Bhoopendra Rajput)<br>
 * Copyright (c) 2025 [State Bank of India]<br>
 * All rights reserved<br>
 * Version:1.0
 */
@SpringBootApplication
@ClientCacheApplication
@EnableEntityDefinedRegions(basePackages = "com.sbi.epay.cache.admin.entity")
@EnableGemfireRepositories(basePackages = "com.epay.operations.repository.cache")
@EnableJpaAuditing(auditorAwareRef = "auditorAware")
@EnableScheduling
@EnableRetry
public class OperationsServiceApplication {

  public static void main(String[] args) {
    SpringApplication.run(OperationsServiceApplication.class, args);
  }

  @Bean
  public AuditorAware<String> auditorAware() {
    return new SpringSecurityAuditorAware();
  }
}
