package com.epay.operations.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor

public class PayoutInfoDto {

    private UUID piId;
    private UUID neftReportId;
    private UUID aatReportId;
    private UUID txnMisReportId;
    private UUID merchantMisReportId;
    private UUID refundMisReportId;

}
