package com.epay.operations.dto.admin;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

/**
 * Class Name: MerchantInfoDto
 * *
 * Description: dto for MerchantInfo which contains merchant information
 * *
 * Author: Akshaya Sahasranamam
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *MerchantInfoDto
 * Version:1.0
 */

@Data
@AllArgsConstructor
@Builder
public class MerchantInfoDto {

    @JsonProperty("mId")
    private String mId;
    private String isActive;
    private String merchantName;
    private String countryCode;
    private String currency;
    private String preferredPayMode;
    private String preferredBank;
    private Long accessTokenExpiryTime;
    private Long transactionTokenExpiryTime;
    private Integer maxAtrnCount;
    private Long orderExpiryTime;
    private String merchantVolVelFlag;
    private String merchantMultiAccountFlag;
    private String numberOfAttemptsApplicable;
    private String numberOfAttempts;
    private String isRefundApplicable;
    private Integer refundWindowDays;
    private String merchantBusinessUrl;
    private String dvpType;
    private String refundAdjustment;

}
