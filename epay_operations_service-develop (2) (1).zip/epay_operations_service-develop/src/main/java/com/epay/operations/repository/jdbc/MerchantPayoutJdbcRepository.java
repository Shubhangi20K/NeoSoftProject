package com.epay.operations.repository.jdbc;

import com.epay.operations.dto.MerchantPayoutDto;
import com.epay.operations.exception.OpsException;
import com.epay.operations.util.DateTimeUtils;
import com.epay.operations.util.OperationsUtil;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.*;

import static com.epay.operations.util.ErrorConstant.FAILED_TO_INSERT_ERROR_CODE;
import static com.epay.operations.util.ErrorConstant.FAILED_TO_INSERT_ERROR_MESSAGE;
import static com.epay.operations.util.query.PayoutProcessingJdbcQuery.INSERT_MERCHANT_PAYOUT;
import static com.epay.operations.util.query.PayoutProcessingJdbcQuery.UPDATE_MERCHANT_PAYOUT;

/**
 * Class Name:MerchantTxnMultiAcctPayoutRepository
 * *
 * Description:
 * *
 * Author:Akshaya Sahasranamam
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
@Repository
@RequiredArgsConstructor
public class MerchantPayoutJdbcRepository {

    private final NamedParameterJdbcTemplate jdbcTemplate;
    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());

    public Map<String, UUID> save(List<MerchantPayoutDto> merchantPayoutList) {
        Map<String, UUID> merchantPayoutIds = new HashMap<>();
        try {
            List<MapSqlParameterSource> parameters = merchantPayoutList.stream().map(merchantPayoutDto -> {
                MapSqlParameterSource param = new MapSqlParameterSource();
                UUID randomId = UUID.randomUUID();
                merchantPayoutIds.put(merchantPayoutDto.getAccountId(), randomId);
                param.addValue("MP_ID", OperationsUtil.uuidToBytes(randomId));
                param.addValue("MERCHANT_ID", merchantPayoutDto.getMId());
                param.addValue("TXN_AMOUNT", merchantPayoutDto.getTransactionAmount());
                param.addValue("BANK_ID", merchantPayoutDto.getBankId());
                param.addValue("ACCOUNT_NUMBER", merchantPayoutDto.getAccountNumber());
                param.addValue("REFUNDED_AMOUNT", merchantPayoutDto.getRefundedAmount());
                param.addValue("REFUND_ADJUSTED", merchantPayoutDto.getRefundedAmount().intValue() > 0 ? 0 : 1);
                param.addValue("PAYOUT_STATUS", merchantPayoutDto.getPayoutStatus().name());
                param.addValue("CREATED_DATE", DateTimeUtils.getCurrentTime());
                param.addValue("ACCOUNT_ID", merchantPayoutDto.getAccountId());
                return param;
            }).toList();

            int[] updateOrderPaymentCounts = jdbcTemplate.batchUpdate(INSERT_MERCHANT_PAYOUT, parameters.toArray(new MapSqlParameterSource[0]));
            log.info("Inserted {} records into MERCHANT_ACCOUNT_PAYOUT", Arrays.stream(updateOrderPaymentCounts).sum());

        } catch (Exception ex) {
            log.error("Error during bulk insert to MERCHANT_PAYOUT", ex);
            throw new OpsException(FAILED_TO_INSERT_ERROR_CODE, FAILED_TO_INSERT_ERROR_MESSAGE);
        }
        return merchantPayoutIds;
    }

    public void updateRefundAdjusted(UUID merchantPayoutId) {
        MapSqlParameterSource param = new MapSqlParameterSource();
        param.addValue("MP_ID", OperationsUtil.uuidToBytes(merchantPayoutId));
        param.addValue("UPDATED_DATE", DateTimeUtils.getCurrentTime());
        int update = jdbcTemplate.update(UPDATE_MERCHANT_PAYOUT, param);
        log.info("updateRefundAdjusted of {} record to true for  payoutId {}", update, merchantPayoutId);
    }
}