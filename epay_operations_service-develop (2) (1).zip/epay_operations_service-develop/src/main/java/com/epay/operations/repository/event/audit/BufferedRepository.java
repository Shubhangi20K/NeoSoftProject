package com.epay.operations.repository.event.audit;

import com.epay.operations.config.OpsConfig;
import com.epay.operations.entity.event.audit.BaseEvent;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.task.TaskExecutor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

@Component
public class BufferedRepository {

    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    private final Map<Class<?>, BlockingQueue<BaseEvent>> bufferEventMap = new ConcurrentHashMap<>();
    private final Map<Class<?>, JpaRepository<BaseEvent, UUID>> repositoryMap = new ConcurrentHashMap<>();

    private final TaskExecutor taskExecutor;
    private final OpsConfig opsConfig;

    public BufferedRepository(@Qualifier("eventTaskExecutor") TaskExecutor taskExecutor, OpsConfig opsConfig) {
        this.taskExecutor = taskExecutor;
        this.opsConfig = opsConfig;
    }

    @SuppressWarnings("unchecked")
    public <T extends BaseEvent> void registerRepository(Class<T> clazz, JpaRepository<T, UUID> repository) {
        bufferEventMap.put(clazz, new LinkedBlockingQueue<>());
        repositoryMap.put(clazz, (JpaRepository<BaseEvent, UUID>) repository);
        taskExecutor.execute(() -> saveAndFlush(clazz));
    }

    public <T extends BaseEvent> void buffer(T event) {
        if(!bufferEventMap.get(event.getClass()).offer(event)){
            log.error("Error while adding event logs, space full error");
        };
    }


    private <T extends BaseEvent> void saveAndFlush(Class<T> clazz) {
        BlockingQueue<BaseEvent> queue = bufferEventMap.get(clazz);
        JpaRepository<BaseEvent, UUID> repository = repositoryMap.get(clazz);
        while (true) {
            try {
                List<BaseEvent> batch = new ArrayList<>();
                BaseEvent first = queue.poll(1, TimeUnit.SECONDS);
                if (ObjectUtils.isNotEmpty(first)) {
                    batch.add(first);
                    queue.drainTo(batch, opsConfig.getEventQueueBatchSize());
                    repository.saveAll(batch);
                }
            } catch (Exception e) {
                log.error("Error in Event Data saveAndFlush for {} : Error :{}", clazz, e.getMessage());
            }
        }
    }
}
