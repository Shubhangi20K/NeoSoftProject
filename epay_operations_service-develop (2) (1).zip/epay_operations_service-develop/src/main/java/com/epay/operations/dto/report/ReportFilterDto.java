package com.epay.operations.dto.report;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.util.List;
import java.util.UUID;

/**
 * Class Name: ReportFiltersDto
 * *
 * Description: Dto Class
 * *
 * Author: Saurabh Mahto(V1018841)
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ReportFilterDto {
    private UUID rfId;
    private List<UUID> mpIdList;
    @JsonProperty("mId")
    private String mId;
    private UUID payoutId;
    private Long toDate;
    private Long fromDate;
}
