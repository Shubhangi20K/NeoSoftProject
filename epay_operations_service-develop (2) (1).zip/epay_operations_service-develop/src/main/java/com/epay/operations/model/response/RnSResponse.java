package com.epay.operations.model.response;

import com.epay.operations.dto.ErrorDto;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import java.util.List;

/**
 * Class Name: RnSResponse
 * Description: Generic RnS response.
 * Author: Gireesh M
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * Version: 1.0
 */
@AllArgsConstructor
@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RnSResponse<T> {
    private Integer status;
    private List<T> data;
    private Long count;
    private Long total;
    private List<ErrorDto> errors;
}