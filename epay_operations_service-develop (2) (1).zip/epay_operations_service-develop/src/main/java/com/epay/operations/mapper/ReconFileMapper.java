package com.epay.operations.mapper;

import com.epay.operations.dto.ReconFileDto;
import com.epay.operations.entity.ReconFile;
import org.mapstruct.Mapper;

/**
 * Class Name: ReconFileSummaryMapper
 * *
 * Description: mapper Class
 * *
 * Author:@V0000001(Shilpa Kothre)
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Mapper(componentModel = "spring")
public interface ReconFileMapper {

    ReconFileDto mapToReconFileSummaryDto(ReconFile reconFile);

    ReconFile mapToEntity(ReconFileDto reconFileDto);
}
