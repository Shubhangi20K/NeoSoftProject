package com.epay.operations.etl.producer;

import com.epay.operations.config.kafka.Topics;
import com.epay.operations.dto.RefundAdjustedDto;
import com.epay.operations.util.enums.InterfaceType;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.AllArgsConstructor;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Component;

import static com.epay.operations.util.EventMessageUtils.buildEventErrorLog;
import static com.epay.operations.util.EventMessageUtils.buildEventSendLog;
import static com.epay.operations.util.OperationsConstant.REFUND_KEY;
import static com.epay.operations.util.OperationsUtil.getKafkaRoutingKey;

/**
 * Class Name:RefundAdjustedPublisher
 * <p>
 * Description: RefundAdjustedPublisher
 * <p>
 * Copyright (c) [2025] [State Bank of India]
 * All rights reserved.
 * <p>
 * Author: Akshaya Sahasranamam
 * Version:1.0
 */
@Component
@AllArgsConstructor
public class RefundAdjustedPublisher {

    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    private final ObjectMapper objectMapper;
    private final KafkaMessagePublisher kafkaMessagePublisher;
    private final Topics topics;
    private final ApplicationEventPublisher publisher;

    /**
     * @param requestType       String
     * @param routingKey        String
     * @param refundAdjustedDto List<String>
     */
    public void publish(String requestType, String routingKey, RefundAdjustedDto refundAdjustedDto) {
        String kafkaRoutingKey = getKafkaRoutingKey(REFUND_KEY, requestType, routingKey);
        try {
            log.info("Refund Adjusted Publisher for requestType : {}, routingKey : {} and value : {}", requestType, routingKey, refundAdjustedDto);
            kafkaMessagePublisher.publish(topics.getRefundAdjustTopic(), kafkaRoutingKey, objectMapper.writeValueAsString(refundAdjustedDto));
            publisher.publishEvent(buildEventSendLog(InterfaceType.OPS_REFUND_ADJUST_DETAIL_TOPIC, topics.getRefundAdjustTopic(), kafkaRoutingKey, objectMapper.writeValueAsString(refundAdjustedDto)));
            log.info("Refund Adjusted published");
        } catch (Exception e) {
            log.error("Error in Refund Adjusted Publisher {}, error: {}", refundAdjustedDto, e.getMessage());
            publisher.publishEvent(buildEventErrorLog(InterfaceType.OPS_REFUND_ADJUST_DETAIL_TOPIC, topics.getRefundAdjustTopic(), kafkaRoutingKey, e.getMessage()));
        }
    }
}

