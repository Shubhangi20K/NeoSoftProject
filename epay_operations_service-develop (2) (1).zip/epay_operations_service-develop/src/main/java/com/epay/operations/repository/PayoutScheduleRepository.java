package com.epay.operations.repository;


import com.epay.operations.entity.PayoutScheduler;
import com.epay.operations.util.enums.Status;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

/**
 * Class Name:PayoutScheduleRepository
 * *
 * Description: Repository interface for PayoutScheduler
 * *
 * Author: Akshaya Sahasranamam
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */

@Repository
public interface PayoutScheduleRepository extends JpaRepository<PayoutScheduler, UUID> {

    List<PayoutScheduler> findByStatusIn(List<Status> status);

}
