package com.epay.operations.util.enums;

import com.epay.operations.exception.OpsException;
import lombok.Getter;
import java.text.MessageFormat;
import java.util.Arrays;
import static com.epay.operations.util.ErrorConstant.INVALID_ERROR_CODE_NO_REASON;
import static com.epay.operations.util.ErrorConstant.INVALID_ERROR_MESSAGE_NO_REASON;

/**
 * enum Name: Status
 * *
 * Description: Status enum for recon file parsing.
 * *
 * Author: V1019285 (NIRMAL GURJAR)
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Getter
public enum Status {

   PENDING,IN_PROCESS,PARTIAL,SUCCESS,FAIL;

    public static Status getStatus(String label) {
        return Arrays.stream(values()).filter(p -> p.name().equalsIgnoreCase(label)).findFirst().orElseThrow(() -> new OpsException(INVALID_ERROR_CODE_NO_REASON, MessageFormat.format(INVALID_ERROR_MESSAGE_NO_REASON, "Parsing Status", label)));
    }
}
