package com.epay.operations.model.response;

import lombok.Data;

import java.util.UUID;

/**
 * Class Name: BankConfigFileResponse
 * *
 * Description:
 * *
 * Author:@V0000001(Shilpa Kothre)
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Data
public class BankConfigFileResponse {
    private UUID configId;
    private String bankCode;
    private String sftpPath;
    private String fileType;
    private String delimiter;
    private Boolean headerPresent;
    private Integer headerRow;
    private Integer dataStartRow;
    private String header;
    private String headerMapping;
    private String dateFormat;
    private String valueMapping;
    private Integer hashRow;
    private String hashHeader;
    private Integer summaryRow;
    private String summaryHeader;
    private Boolean fileEncrypted;
    private String encLevel;
    private String encKey;
}
