package com.epay.operations.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.UUID;

/**
 * Class Name: RefundAdjustedDto
 * *
 * Description: Dto Class
 * *
 * Author:Akshaya Sahasranamam
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class RefundAdjustedDto {

    private List<String> arrnList;
    private UUID payoutId;

}
