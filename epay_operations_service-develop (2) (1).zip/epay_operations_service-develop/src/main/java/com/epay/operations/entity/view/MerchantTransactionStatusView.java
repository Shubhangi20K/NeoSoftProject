package com.epay.operations.entity.view;

import com.epay.operations.util.enums.PayoutStatus;
import com.epay.operations.util.enums.SettlementStatus;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

import java.util.UUID;

/**
 * Class Name:MerchantTransactionStatusView
 * *
 * Description: Entity class for MerchantTransactionStatusView
 * *
 * Author: Akshaya Sahasranamam
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */

@Data
@Entity
@Table(name = "MERCHANT_ORDER_PAYMENT_SETTLEMENT_VIEW")
public class MerchantTransactionStatusView {

    @Id
    private String atrnNum;
    @Column(columnDefinition = "RAW(16)")
    private UUID rfsId;
    private SettlementStatus settlementStatus;
    private PayoutStatus payoutStatus;

}