package com.epay.operations.service;

import com.epay.operations.dto.transaction.MerchantTransactionDto;
import com.epay.operations.dto.spark.ReconFileSummaryDto;
import com.epay.operations.dto.spark.TransactionUnMatchedDto;
import com.epay.operations.repository.spark.SparkDataRepository;
import com.epay.operations.util.query.JdbcQuery;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.apache.spark.sql.*;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

import static java.lang.System.currentTimeMillis;

/**
 * Class Name: SparkService<br/>
 * Description: The SparkService class will perform the operation to perform Apache Spark operation.<br/>
 * Author: V1019620(Bhoopendra Rajput)<br/>
 * Copyright (c) 2025 [State Bank of India]<br/>
 * All rights reserved<br/>
 * Version:1.0
 */
@Service
@RequiredArgsConstructor
public class SparkService {
    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    private final SparkSession sparkSession;

    private final Encoder<MerchantTransactionDto> merchantOrderPayment;
    private final SparkDataRepository sparkDataRepository;

    public String formatMillis(long millis) {
        long hours = millis / (1000 * 60 * 60);
        long minutes = (millis / (1000 * 60)) % 60;
        long seconds = (millis / 1000) % 60;
        long ms = millis % 1000;

        return String.format("%02d:%02d:%02d.%03d", hours, minutes, seconds, ms);
    }

    public ReconFileSummaryDto process() {
        log.info("🚀 POC Application started!");
        long startTime = currentTimeMillis();
        ReconFileSummaryDto reconFileSummaryDto = new ReconFileSummaryDto();
        List<TransactionUnMatchedDto> unMatchedRecords = new ArrayList<>();
        Dataset<MerchantTransactionDto> datasetRowDb = getDbDataSet();
        Dataset<MerchantTransactionDto> datasetRowFile = getFileDataset();
        log.info("Matched");
        reconFileSummaryDto.setFileRecordCount(datasetRowFile.count());
        var matchedWithDB = datasetRowFile.join(datasetRowDb, datasetRowFile.col("atrnNum").equalTo(datasetRowDb.col("atrnNum")), "inner").select(datasetRowFile.col("mid"), datasetRowFile.col("orderRefNumber"), datasetRowFile.col("sbiOrderRefNumber"), datasetRowFile.col("atrnNum"), datasetRowFile.col("debitAmt"));
        log.error("{} time took to calculate matchedWithDB(Spark.JOIN).", formatMillis(currentTimeMillis() - startTime));
        matchedWithDB.show();

        reconFileSummaryDto.setMatchedRecords(matchedWithDB.as(merchantOrderPayment).collectAsList());
        log.info("Unmatched: updated or added records");
        var missMatchedWithDB = datasetRowFile.join(datasetRowDb, datasetRowFile.col("atrnNum").equalTo(datasetRowDb.col("atrnNum")), "leftanti").as(Encoders.bean(MerchantTransactionDto.class));
        missMatchedWithDB.show();
        missMatchedWithDB.collectAsList().forEach(fileRow -> {
            log.info("File Record: {}", fileRow);
//            Dataset<MerchantOrderPayment> fileRowDs = datasetRowDb.filter("atrnNum = " + fileRow.getAtrnNum());
            TransactionUnMatchedDto transactionUnMatchedDto = new TransactionUnMatchedDto();
            transactionUnMatchedDto.setDbMerchantOrderPayment(fileRow);
           /* if (fileRowDs.count() == 0) {
                log.info("New record: {}", fileRow.getAtrnNum());
                transactionUnMatchedDto.setNew(true);
            } else {
                log.info("Updated, DB record: {}", fileRowDs.collectAsList());
            }*/
            unMatchedRecords.add(transactionUnMatchedDto);
        });
        reconFileSummaryDto.setUnMatchedRecords(unMatchedRecords);
        reconFileSummaryDto.setTimeToProcessed(formatMillis(currentTimeMillis() - startTime));
        log.error("{} time took to calculate matchedWithDB(Spark.JOIN).", formatMillis(currentTimeMillis() - startTime));
        return reconFileSummaryDto;
    }

    private Dataset<MerchantTransactionDto> getDbDataSet() {
        long startTime = currentTimeMillis();
        String merchantOrderPaymentQuery = JdbcQuery.getYesterdayQuery("PAYAGGTRANSCTION.MERCHANT_ORDER_PAYMENTS", currentTimeMillis());
        Dataset<Row> datasetRow = sparkDataRepository.readJdbcQuery(merchantOrderPaymentQuery);
        log.error("{} time took to call sparkDataRepository.readJdbcQuery().", formatMillis(currentTimeMillis() - startTime));
        log.error("DB datasetRow count: {}", datasetRow.count());
            /* Dataset<Row> datasetRow = sparkSession.read().option("header", true).option("inferSchema", true)
                .csv("data/employeeDb.csv").cache();*/
        datasetRow.printSchema();
        startTime = currentTimeMillis();
        Dataset<Row> dataset = datasetRow.withColumnRenamed("MERCHANT_ID", "mid").withColumnRenamed("ORDER_REF_NUMBER", "orderRefNumber").withColumnRenamed("SBI_ORDER_REF_NUMBER", "sbiOrderRefNumber").withColumnRenamed("ATRN_NUM", "atrnNum").withColumnRenamed("DEBIT_AMT", "debitAmt");
        log.error("{} time took to call datasetRow.withColumnRenamed().", formatMillis(currentTimeMillis() - startTime));
        dataset.printSchema();
        return dataset.as(merchantOrderPayment);
    }

    private Dataset<MerchantTransactionDto> getFileDataset() {
        long startTime = currentTimeMillis();
        Dataset<Row> merchantOrderPaymentDataset = sparkSession.read().option("header", true).option("inferSchema", true).csv("data/merchantOrderPayment.csv");
        log.error(formatMillis(currentTimeMillis() - startTime) + " time took to call read csv file.");
        merchantOrderPaymentDataset.printSchema();
        Dataset<Row> dataset = merchantOrderPaymentDataset.withColumnRenamed("MID", "mid").withColumnRenamed("ORDER_REF_NUMBER", "orderRefNumber").withColumnRenamed("SBI_ORDER_REF_NUMBER", "sbiOrderRefNumber").withColumnRenamed("ATRN_NUM", "atrnNum").withColumnRenamed("DEBIT_AMT", "debitAmt");
        dataset.printSchema();
        return dataset.as(merchantOrderPayment);
    }
}
