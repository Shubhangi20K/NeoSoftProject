package com.epay.operations.mapper;

import com.epay.operations.dto.ReconFileDetailsDto;
import com.epay.operations.entity.ReconFileDetails;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * Class Name: ReconFileDtlsMapper
 * *
 * Description: mapper Class
 * *
 * Author:V1019285(NIRMAL GURJAR)
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Mapper(componentModel = "spring")
public interface ReconFileDetailsMapper {

    ReconFileDetailsDto mapToDto(ReconFileDetails reconFileDetails);

    List<ReconFileDetailsDto> mapToDtoList(List<ReconFileDetails> reconFileDetailsList);

    ReconFileDetails mapToEntity(ReconFileDetailsDto reconFileDetailsDto);

    List<ReconFileDetails> mapToEntityList(List<ReconFileDetailsDto> reconFileDetailsDtoList);
}
