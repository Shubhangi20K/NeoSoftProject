package com.epay.operations.service;

import com.epay.operations.dao.DataSyncSchedulerDao;
import com.epay.operations.dto.DataSyncSchedulerDto;
import com.epay.operations.util.DateTimeUtils;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.retry.annotation.Retryable;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

/**
 * Class Name:DataTransferService
 * *
 * Description:
 * *
 * Author:SAURABH_MAHTO(V1018841)
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
@Service
@RequiredArgsConstructor
public class DataSyncService {

    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    private final DataSyncSchedulerDao dataSyncSchedulerDao;
    /**
     * Syncing of data from view tables to Operation DB by Scheduler and publishing the ATRN to
     * the Transaction service for updating its status
     */
    @Transactional
    public void syncTransactionData(String schedulerName) {
        log.info("Fetching data from DataSyncScheduler Table");
        DataSyncSchedulerDto dataSyncSchedulerDto = dataSyncSchedulerDao.findBySchedulerName(schedulerName);
        long lastRun = dataSyncSchedulerDto.getSchedulerLastRun();
        long currRun = DateTimeUtils.getCurrentTime();
        log.info("Syncing Transaction Data between {} and {}", lastRun, currRun);
        dataSyncSchedulerDao.saveTransactionDataSync(lastRun, currRun);
        log.info("Transaction Data Syncing Completed");
        dataSyncSchedulerDto.setSchedulerLastRun(currRun);
        dataSyncSchedulerDao.save(dataSyncSchedulerDto);
        log.info("Update {} data for DataSyncScheduler ", schedulerName);
    }

    @Async
    @Retryable(maxAttemptsExpression = "${purge.maxRetry:3}")
    public void purgeMerchantTransactionWithRetry(long retentionDaysMillis) {
        log.info("Attempting to purge MERCHANT_TXN.");
        try {
            purgeMerchantTransaction(retentionDaysMillis);
        } catch (Exception ex) {
            log.error("Error during Data purging for MERCHANT_TXN : {}", ex.getMessage());
            throw ex;
        }
    }

    @Transactional
    public void purgeMerchantTransaction(long retentionDaysMillis) {
        log.info("flushing from MerchantTransaction.");
        int deletedCount = dataSyncSchedulerDao.deleteMerchantTransaction(retentionDaysMillis);
        log.info("Deleted from MerchantTransaction: {}", deletedCount);
    }
}



