package com.epay.operations.dto;

import com.epay.operations.util.enums.ReconStatus;
import com.epay.operations.util.enums.SettlementStatus;
import com.epay.operations.util.enums.Status;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.UUID;

/**
 * Class Name: ReconDataDto
 * *
 * Description: Dto Class
 * *
 * Author:@V0000001(Shilpa Kothre)
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ReconFileDto {

    private UUID rfId;
    private UUID configId;
    private String bankCode;
    private String sftpPath;
    private String s3Path;
    private String ackSftpPath;
    private String fileName;
    private String fileChecksum;
    private Long fileReceivedTime;
    private Status parsingStatus;
    private BigDecimal totalAmount;
    private Integer totalRecords;
    private Integer matchedRecords;
    private BigDecimal matchedAmount;
    private Integer unmatchedRecords;
    private BigDecimal unmatchedAmount;
    private Integer duplicateRecords;
    private BigDecimal duplicateAmount;
    private ReconStatus reconStatus;
    private Long reconTime;
    private SettlementStatus settlementStatus;
    private Long settlementTime;
    private String remark;
    private long createdDate;

}
