package com.epay.operations.service;


import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.UUID;

/**
 * Class Name: ReconErrorRecordProcessService
 * Description: The implementation is for consume  recon error Record data.
 * Author: V0000001(SHILPA KOTHRE)
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * Version:1.0
 */
@Service
@RequiredArgsConstructor
public class ReconStatusFailedService {

    final public ReconFileDtlsService reconFileDtlsService;
    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());

    public void updatedFailedRecord(UUID rfdId, String remark) {
        log.info("Saving ErrorRecordProcess for rfdId: {}", rfdId);
        reconFileDtlsService.updateReconStatusAndRemarkByRfdId(rfdId,remark);
        log.info("Saved ErrorRecordProcess for rfdId: {}", rfdId);
    }
}
