package com.epay.operations.dao;

import com.epay.operations.dto.PayoutInfoDto;
import com.epay.operations.dto.report.ReportRequestDto;
import com.epay.operations.entity.ReportRequest;
import com.epay.operations.exception.OpsException;
import com.epay.operations.mapper.ReportRequestMapper;
import com.epay.operations.repository.ReportRequestRepository;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

import java.text.MessageFormat;
import java.util.List;
import java.util.UUID;

import static com.epay.operations.util.ErrorConstant.NOT_FOUND_ERROR_CODE;
import static com.epay.operations.util.ErrorConstant.NOT_FOUND_ERROR_MESSAGE;
import static com.epay.operations.util.OperationsConstant.ORE_ID;

/**
 * Class Name:ReportRequestDao
 * *
 * Description:
 * *
 * Author:SAURABH_MAHTO(v1018841)
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
@Component
@AllArgsConstructor
public class ReportRequestDao {
    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    private final ReportRequestRepository reportRequestRepository;
    private final MerchantPayoutDao merchantPayoutDao;
    private final PayoutInfoDao payoutInfoDao;
    private final ReportRequestMapper reportRequestMapper;
    private final ReconFileDetailsDao reconFileDetailsDao;

    public ReportRequestDto save(ReportRequestDto reportRequestDto) {
        ReportRequest request = reportRequestRepository.save(reportRequestMapper.mapToEntity(reportRequestDto));
        return reportRequestMapper.mapToDto(request);
    }

    public ReportRequestDto getByReportRequestId(UUID rrId) {
        ReportRequest reportRequest = reportRequestRepository.findById(rrId).orElseThrow(() -> new OpsException(NOT_FOUND_ERROR_CODE, MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, ORE_ID)));
        return reportRequestMapper.mapToDto(reportRequest);
    }

    public void update(ReportRequestDto opsReportRequestDto) {
        reportRequestRepository.save(reportRequestMapper.mapToEntity(opsReportRequestDto));
    }

    public List<UUID> getAllMerchantPayoutForReport() {
        return merchantPayoutDao.getAllMerchantPayoutForReport();
    }

    public void savePayoutInfo(PayoutInfoDto payoutInfo, List<UUID> merchantPayouts) {
        log.info("Report Id is link with PayoutInfo Table with {}", payoutInfo.getPiId());
        payoutInfo = payoutInfoDao.save(payoutInfo);
        merchantPayoutDao.updateMerchantPayoutsByPayoutInfoId(merchantPayouts, payoutInfo.getPiId());
        reconFileDetailsDao.updatePayoutStatusInReconFileDetails(payoutInfo.getPiId());
        log.info("PayoutInfo is linked with MerchantPayout");
    }

}
