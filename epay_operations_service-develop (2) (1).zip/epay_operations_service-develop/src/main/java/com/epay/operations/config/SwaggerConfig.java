package com.epay.operations.config;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.License;
import io.swagger.v3.oas.models.security.SecurityScheme;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.info.BuildProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Map;

import static com.epay.operations.util.OperationsConstant.*;

/**
 * Class Name: SwaggerConfig
 * Description:The SwaggerConfig class configures Swagger for the application, enabling the generation
 * of interactive API documentation. This class is responsible for setting up Swagger's
 * configuration, such as the API title, description, version, and any other relevant metadata
 * to improve the API documentation for developers.
 * Author: Bhoopendra Rajput
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * Version: 1.0
 */
@Configuration
public class SwaggerConfig {
    @Value("${spring.application.name}")
    private String appName;
    @Value("${git.commit.id:unknown}")
    private String gitCommitId;
    @Value("${git.commit.id.abbrev:unknown}")
    private String gitCommitIdAbbr;
    @Value("${git.commit.time:unknown}")
    private String gitCommitTime;
    @Value("${git.branch:unknown}")
    private String gitBranch;

    /**
     * Method Name: createOpenApi
     * Description: This method configures the custom OpenAPI (Swagger) documentation for the application.
     * It uses the `BuildProperties` object to include the application version and Git information
     * (such as commit ID, commit time, and branch) in the API metadata. It also sets the title,
     * description, and contact details for the API documentation.
     *
     * @param buildProperties The build properties that contain the version information of the app
     * @return OpenAPI The configured OpenAPI instance containing metadata for the API documentation
     */
    @Bean
    public OpenAPI createOpenApi(BuildProperties buildProperties) {
    return new OpenAPI()
        .components(
            new Components()
                .addSecuritySchemes(
                    BEARER_AUTH,
                    new SecurityScheme()
                        .type(SecurityScheme.Type.HTTP)
                        .scheme(BEARER)
                        .bearerFormat(JWT)))
        .info(
            new io.swagger.v3.oas.models.info.Info()
                .title(appName)
                .version(String.format("%s-%s",buildProperties.getVersion(), gitCommitIdAbbr))
                .description(String.format("API for %s", appName))
                .contact(new Contact().name("Info").email("info.sbiepay@sbi.co.in"))
                .license(new License().name("SBI ePay").url("https://www.sbiepay.sbi/"))
                .extensions(Map.of(
                        "x-git-commit-id", gitCommitId,
                        "x-git-commit-time", gitCommitTime,
                        "x-git-branch", gitBranch)));
    }
}
