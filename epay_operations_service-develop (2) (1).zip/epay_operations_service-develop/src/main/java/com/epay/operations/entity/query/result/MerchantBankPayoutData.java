package com.epay.operations.entity.query.result;

import java.math.BigDecimal;

/**
 * Class Name:MerchantBankPayoutData
 * *
 * Description: Entity class for MerchantAccountPayout
 * *
 * Author: Akshaya Sahasranamam
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */

public interface MerchantBankPayoutData {
    String getMId();

    BigDecimal getMerchantPayout();

    String getBankId();
}