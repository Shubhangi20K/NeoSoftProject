package com.epay.operations.scheduler;

import com.epay.operations.service.PayoutReportService;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.AllArgsConstructor;
import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;
import org.slf4j.MDC;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.UUID;

import static com.epay.operations.util.OperationsConstant.OPERATION;
import static com.epay.operations.util.OperationsConstant.SCENARIO;
import static org.springframework.kafka.support.KafkaHeaders.CORRELATION_ID;

@Component
@AllArgsConstructor
public class PayoutReportScheduler {

    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());

    private final PayoutReportService payoutReportService;

    @Scheduled(cron = "${scheduler.cron.expression.payout.report}")
    @SchedulerLock(name = "PayoutGenerationCheck")
    public void payoutReportGeneration() {
        log.info("PayoutInitiationScheduler Initiated at {}", System.currentTimeMillis());
        MDC.put(CORRELATION_ID, String.valueOf(UUID.randomUUID()));
        MDC.put(SCENARIO, "payoutReportGeneration");
        MDC.put(OPERATION, "generateReport");
        payoutReportService.reportGenerationRequest();
        log.info(" PayoutInitiationScheduler Completed at {}", System.currentTimeMillis());
    }
}
