package com.epay.operations.util;

import lombok.experimental.UtilityClass;

import java.util.List;

@UtilityClass
public class ReportConstant {

    public static final String PAYOUT = "PAY-OUT/";

    public static final List<String> PAYOUT_HEADER = List.of("MERCHANT_ID", "BANK_IFSC_CODE", "BANK_ACC_NUMBER", "TXN_COUNT", "FINAL_PAYOUT");
}
