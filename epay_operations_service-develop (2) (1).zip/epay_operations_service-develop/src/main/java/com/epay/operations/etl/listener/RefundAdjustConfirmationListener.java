package com.epay.operations.etl.listener;

import com.epay.operations.service.PayoutService;
import com.epay.operations.util.enums.InterfaceType;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.MDC;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import java.util.UUID;

import static com.epay.operations.util.EventMessageUtils.buildEventErrorLog;
import static com.epay.operations.util.EventMessageUtils.buildEventReceivedLog;
import static com.epay.operations.util.OperationsConstant.*;

/**
 * Class Name: ReconFilePathListener
 * Description: The implementation is for consume the s3FilePath from report service.
 * Author: V1018841(Saurabh Mahto)
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * Version:1.0
 */
@Component
@RequiredArgsConstructor
public class RefundAdjustConfirmationListener {
    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    private final PayoutService payoutService;
    private final ApplicationEventPublisher publisher;

    @KafkaListener(topics = "${spring.kafka.topic.refund.adjust.confirmation}")
    public void refundAdjustProcessing(ConsumerRecord<String, String> consumerRecord) {
        log.info("Received Kafka message: {}", consumerRecord);
        MDC.put(CORRELATION, String.valueOf(UUID.randomUUID()));
        MDC.put(SCENARIO, "ReconFilePathListener");
        MDC.put(OPERATION, "reconFilePathProcessing");
        try {
            publisher.publishEvent(buildEventReceivedLog(InterfaceType.OPS_REFUND_ADJUST_DETAIL_TOPIC, consumerRecord));
            payoutService.refundAdjustedByPayoutId(UUID.fromString(consumerRecord.value()));
        } catch (Exception e) {
            publisher.publishEvent(buildEventErrorLog(InterfaceType.OPS_REFUND_ADJUST_DETAIL_TOPIC, consumerRecord, e.getMessage()));
            log.error("Error during reconProcessing kafka listening message[key:{} and value: {}], error: {}", consumerRecord.key(), consumerRecord.value(), e.getMessage());
        }
    }
}
