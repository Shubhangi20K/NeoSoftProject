package com.epay.operations.repository;


import com.epay.operations.entity.ReconFileDetails;
import com.epay.operations.entity.query.result.ReconMatchedTransaction;
import com.epay.operations.entity.query.result.ReconStatusCount;
import com.epay.operations.util.enums.PayoutStatus;
import com.epay.operations.util.enums.ReconStatus;
import com.epay.operations.util.enums.SettlementStatus;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Class Name:ReconDataDetailsRepository
 * *
 * Description: Repository interface for ReconData details
 * *
 * Author: V1019285 (NIRMAL GURJAR)
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */

@Repository
public interface ReconFileDtlsRepository extends JpaRepository<ReconFileDetails, UUID> {

    @Query(value = """
            SELECT
            SUM(CASE WHEN recon_status = 'MATCHED' THEN 1 ELSE 0 END) as matchedCount,
            SUM(CASE WHEN recon_status = 'UNMATCHED' THEN 1 ELSE 0 END) as unmatchedCount,
            SUM(CASE WHEN recon_status = 'DUPLICATE' THEN 1 ELSE 0 END) as duplicateCount
            FROM RECON_FILE_DTLS
            WHERE RF_ID = :rfId
            """, nativeQuery = true)
    ReconStatusCount findReconStatusCountByRfId(@Param("rfId") UUID rfId);


    List<ReconFileDetails> findByRfIdAndReconStatus(UUID rfId, ReconStatus reconStatus);

    List<ReconFileDetails> findByRfId(UUID rfId);

    Optional<ReconFileDetails> findByRfdId(UUID rfdId);

    @Modifying
    @Transactional
    @Query("UPDATE ReconFileDetails rfd SET rfd.settlementStatus = :status, rfd.updatedDate = :updatedDate WHERE rfd.rfId = :rfId and rfd.reconStatus = 'MATCHED'")
    void updateSettlementStatusByRfId(SettlementStatus status, UUID rfId, Long updatedDate);

    @Modifying
    @Transactional
    @Query("UPDATE ReconFileDetails rfd SET rfd.payoutStatus = :status WHERE rfd.rfdId = :rfdId")
    void updatePayoutStatusByRfdId(PayoutStatus status, UUID rfdId);

    @Query(value = """
            SELECT R.RFD_ID as rfdId, R.RF_ID as rfId, R.ATRN_NUM as atrn,R.TXN_AMOUNT as txnAmount,
            R.MERCHANT_ID as mId, COALESCE(MO.MULTI_ACCOUNT,TO_CLOB('')) as multiAccount, COALESCE(MO.TXN_FEE,0) as transactionFee
            FROM RECON_FILE_DTLS R
            LEFT JOIN MERCHANT_TXN MO ON R.ATRN_NUM = MO.ATRN_NUM
            WHERE R.RF_ID = :rfId
            AND R.RECON_STATUS = :reconStatus
            AND R.SETTLEMENT_STATUS = :settlementStatus
            AND R.PAYOUT_STATUS = :payoutStatus
            """, nativeQuery = true)
    List<ReconMatchedTransaction> findByReconSettlementPayoutStatusAndFileId(@Param("rfId") UUID rfId, String reconStatus, String settlementStatus, String payoutStatus);

    @Query(value = """
            SELECT COUNT(*) AS settledCount
            FROM RECON_FILE_DTLS
            WHERE RF_ID = :rfId
            AND RECON_STATUS = 'MATCHED'
            """, nativeQuery = true)
    int countSettledTransaction(@Param("rfId") UUID rfId);

    boolean existsByRfIdAndReconStatus( UUID rfId, ReconStatus status);

}
