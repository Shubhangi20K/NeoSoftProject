package com.epay.operations.dao;

import com.epay.operations.dto.ReconFileDetailsDto;
import com.epay.operations.repository.jdbc.ReconDataJdbcRepository;
import com.epay.operations.repository.spark.SparkDataRepository;
import com.epay.operations.util.enums.ReconStatus;
import com.epay.operations.util.enums.SettlementStatus;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.functions;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static com.epay.operations.util.OperationsConstant.*;
import static com.epay.operations.util.query.JdbcQuery.*;

/**
 * Class Name: ReconUtil
 * *
 * Description: This Util will help to recon service.
 * *
 * Author:Gireesh M
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Component
@RequiredArgsConstructor
public class ReconProcessDao {
    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(ReconProcessDao.class);
    private static final Map<String, String> MAPPING_COLUMNS = Map.of(DEBIT_AMT, PAYMENT_AMOUNT);

    private final SparkDataRepository sparkDataRepository;
    private final ReconFileDetailsDao reconFileDetailsDao;
    private final ReconFileDao reconFileDao;
    private final ReconDataJdbcRepository reconDataJdbcRepository;

    /**
     * This method is used to read and normalise merchant order payments dataset.
     *
     * @return merchant order payments dataset.
     */
    public Dataset<Row> readAndNormalizeTransaction(UUID rfId) {
        String query = buildQueryForTransaction(rfId);
        logger.info("Executing query for : {}", query);
        return normalize(sparkDataRepository.readFromDBWithFilter(query));
    }

    /**
     * This method is used to read and normalise recon file details.
     *
     * @param rfId rfdId.
     * @return recon file details dataset.
     */
    public Dataset<Row> readAndNormalizeRecon(UUID rfId) {
        String query = buildQueryForRecon(rfId);
        logger.info("Executing query for : {}", query);
        return normalizeAndRenameColumns(sparkDataRepository.readFromDBWithFilter(query));
    }

    /**
     * This method is used to normalise the dataset columns.
     *
     * @param dataset required dataset.
     * @return normalised dataset.
     */
    public Dataset<Row> normalize(Dataset<Row> dataset) {
        logger.info("Normalising required data.");
        var columns = Arrays.asList(dataset.columns());
        for (String col : MAPPING_COLUMNS.keySet()) {
            if (columns.contains(col)) {
                dataset = dataset.withColumn(col, functions.trim(dataset.col(col)));
            }
        }
        return dataset;
    }

    /**
     * This method is used to rename the column name.
     *
     * @param dataset required dataset.
     * @return mapped columns dataset
     */
    public Dataset<Row> normalizeAndRenameColumns(Dataset<Row> dataset) {
        logger.info("Renaming column name for the given dataset.");
        var columns = Arrays.asList(dataset.columns());
        for (String col : MAPPING_COLUMNS.keySet()) {
            if (columns.contains(col)) {
                dataset = dataset.withColumn(col, functions.trim(dataset.col(col)));
            }
        }
        for (Map.Entry<String, String> entry : MAPPING_COLUMNS.entrySet()) {
            if (columns.contains(entry.getValue())) {
                dataset = dataset.withColumnRenamed(entry.getValue(), entry.getKey());
            }
        }
        return dataset;
    }

    public List<ReconFileDetailsDto> getAllReconFileData(UUID rfId) {
        return reconFileDetailsDao.getAllReconFileData(rfId);
    }

    public void updateReconRecordsStatus(UUID rfId, Map<String, Dataset<Row>> finalReconRecordsWithStatus) {
        // Step-4.1: Write to staging table.
        logger.info("Step-4.1: Writing recon status for matched to staging table '{}'.", SPARK_RECON_STATUS_STAGE_MATCHED);
        sparkDataRepository.writeToStagingTable(finalReconRecordsWithStatus.get(RECON_STATUS_MATCHED), SPARK_RECON_STATUS_STAGE_MATCHED);

        // Step-4.2: Writing recon status for others to staging table
        logger.info("Step-4.2: Writing recon status for others to staging table '{}'.", SPARK_RECON_STATUS_STAGE_OTHERS);
        sparkDataRepository.writeToStagingTable(finalReconRecordsWithStatus.get(OTHERS), SPARK_RECON_STATUS_STAGE_OTHERS);

        // Step-4.3: Updating recon status and settlement status in main recon_file_dtls table.
        logger.info("Step-4.3: Updating recon status and settlement status in main recon_file_dtls table.");
        sparkDataRepository.updateReconStatusAndSettlementStatusFromStage();


        // Step-4.4: Updating recon status and s in main recon_file_dtls table.
        logger.info("Step-4.4: Updating recon status and s in main recon_file_dtls table.");
        sparkDataRepository.updateReconStatusFromStage();

        // Step-4.5: Clearing staging table after update..
        logger.info("Step-4.5: Clearing staging table after update.");
        sparkDataRepository.clearStageTableByRfId(String.valueOf(rfId));
    }

    public void updateReconStatusById(UUID rfId, ReconStatus reconStatus) {
        reconFileDao.updateReconStatusById(rfId, reconStatus, ReconStatus.FAIL.equals(reconStatus) ? SettlementStatus.FAIL : SettlementStatus.PENDING);
    }

    public void updateReconStatus(ReconStatus status, List<ReconFileDetailsDto> reconFileDetailsDtoList) {
        logger.info("Update the recon with status: {}", status);
        reconDataJdbcRepository.updateReconStatus(reconFileDetailsDtoList ,status);
    }



}
