package com.epay.operations.config.kafka;

import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Class Name: KafkaConsumerSettings
 * *
 * Description: kafka consumer setting.
 * *
 * Author: Gireesh M
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Getter
@Setter
@Component
public class KafkaConsumerSettings {
    @Value("${spring.kafka.bootstrapServers}")
    private String bootstrapServers;

    @Value("${spring.kafka.consumer.groupId}")
    private String groupId;

    @Value("${spring.kafka.consumer.enableAutoCommit}")
    private boolean autoCommitCursor;

    @Value("${spring.kafka.consumer.autoCommitInterval}")
    private int autoCommitCursorIntervalMS;

    @Value("${spring.kafka.consumer.sessionTimeoutMS}")
    private int sessionTimeoutMS;

    @Value("${spring.kafka.consumer.requestTimeoutMS}")
    private String requestTimeoutMS;

    @Value("${spring.kafka.consumer.fetchMaxWaitMS}")
    private String fetchMaxWaitMS;

    @Value("${spring.kafka.consumer.maxPollRecords}")
    private String maxPollRecords;

    @Value("${spring.kafka.consumer.autoOffsetReset}")
    private String offsetReset;

    @Value("${spring.kafka.consumer.keyDeserializer}")
    private String keyDeserializer;

    @Value("${spring.kafka.consumer.valueDeserializer}")
    private String valueDeserializer;

    @Value("${spring.kafka.consumer.retryMaxAttempts}")
    private int retryMaxAttempts;

    @Value("${spring.kafka.consumer.retryBackOffInitialIntervalMS}")
    private int retryBackOffInitialIntervalMS;

    @Value("${spring.kafka.consumer.retryBackOffMaxIntervalMS}")
    private int retryBackOffMaxIntervalMS;

    @Value("${spring.kafka.consumer.numberOfConsumers}")
    private Integer numberOfConsumers;
}
