package com.epay.operations.dao;

import com.epay.operations.dto.transaction.MerchantTransactionDto;
import com.epay.operations.mapper.MerchantTransactionMapper;
import com.epay.operations.repository.MerchantTransactionRepository;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Class Name:MerchantOrderPaymentDao
 * *
 * Description:
 * *
 * Author:SAURABH_MAHTO(v1018841)
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
@Component
@RequiredArgsConstructor
public class MerchantTransactionDao {

    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());

    private final MerchantTransactionRepository merchantTransactionRepository;
    private final MerchantTransactionMapper merchantTransactionMapper;
    private final NamedParameterJdbcTemplate jdbcTemplate;

    public List<MerchantTransactionDto> getMerchantTxn(List<String> atrnNum) {
        return merchantTransactionMapper.toPaymentDtoList(merchantTransactionRepository.findByAtrnNumIn(atrnNum));
    }
}
