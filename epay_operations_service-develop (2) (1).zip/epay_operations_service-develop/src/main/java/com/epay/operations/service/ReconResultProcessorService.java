package com.epay.operations.service;

import com.epay.operations.dao.PayoutScheduleDao;
import com.epay.operations.dao.ReconFileDao;
import com.epay.operations.dao.ReconFileDetailsDao;
import com.epay.operations.dto.ReconFileDetailsDto;
import com.epay.operations.dto.ReconFileDto;
import com.epay.operations.etl.producer.ReconDuplicateRecordPublisher;
import com.epay.operations.etl.producer.ReconMatchedRecordPublisher;
import com.epay.operations.etl.producer.ReconUnMatchedRecordPublisher;
import com.epay.operations.exception.OpsException;
import com.epay.operations.util.ErrorConstant;
import com.epay.operations.util.enums.ReconStatus;
import com.epay.operations.util.enums.Report;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.jetbrains.annotations.NotNull;
import org.springframework.stereotype.Service;

import java.text.MessageFormat;
import java.util.List;
import java.util.UUID;

import static com.epay.operations.util.OperationsConstant.IN_FOLDER;
import static com.epay.operations.util.OperationsConstant.OUT_FOLDER;
import static com.epay.operations.util.OperationsUtil.replacePath;

/**
 * Class Name:ReconResultProcessorService
 * *
 * Description:
 * *
 * Author:SAURABH_MAHTO(V1018841)
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
@Service
@RequiredArgsConstructor
public class ReconResultProcessorService {
    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());

    private final ObjectMapper objectMapper;
    private final ReconMatchedRecordPublisher reconMatchPublisher;
    private final ReconUnMatchedRecordPublisher reconUnMatchPublisher;
    private final ReconDuplicateRecordPublisher reconDuplicatePublisher;
    private final ReconFileDetailsDao reconFileDetailsDao;
    private final ReconFileDao reconFileDao;
    private final PayoutScheduleDao payoutScheduleDao;
    private final PayoutReportService payoutReportService;

    private static @NotNull List<?> getPublishedMessage(List<ReconFileDetailsDto> reconDataDetails, ReconStatus reconStatus) {
        if (ReconStatus.DUPLICATE.equals(reconStatus)) {
            return reconDataDetails;
        }
        return reconDataDetails.stream().map(e -> e.getAtrnNum() + ":" + e.getBankRefNumber() + ":" + e.getRfId() + ":" + e.getRfdId()).toList();
    }

    /**
     * This method is used to publish the recon processed data.
     *
     * @param rfId recon file summary id.
     */
    public void publishReconProcessedData(UUID rfId) {
        log.info("Publishing recon processed data.");
        List<ReconFileDetailsDto> matched = reconFileDetailsDao.getReconFileDataByRfsIdAndReconStatus(rfId, ReconStatus.MATCHED);
        publishReconDataStatusWise(matched, ReconStatus.MATCHED);

        List<ReconFileDetailsDto> unmatched = reconFileDetailsDao.getReconFileDataByRfsIdAndReconStatus(rfId, ReconStatus.UNMATCHED);
        publishReconDataStatusWise(unmatched, ReconStatus.UNMATCHED);

        List<ReconFileDetailsDto> duplicate = reconFileDetailsDao.getReconFileDataByRfsIdAndReconStatus(rfId, ReconStatus.DUPLICATE);
        publishReconDataStatusWise(duplicate, ReconStatus.DUPLICATE);

        reconFileDao.updateReconFile(rfId, matched, unmatched, duplicate);
        payoutScheduleDao.savePayoutSchedule(rfId, matched.size());

        log.info("Generate Bad Report for rf_id:- {}",rfId);
        if(!unmatched.isEmpty() || !duplicate.isEmpty()) generateBadReport(rfId);
    }

    private void publishReconDataStatusWise(List<ReconFileDetailsDto> reconDataDetails, ReconStatus reconStatus) {
        log.info("Publishing list of ATRN at  :- {} for reconStatus : {}", System.currentTimeMillis(), reconStatus);
        List<?> publishedMessage = getPublishedMessage(reconDataDetails, reconStatus);
        for (Object object : publishedMessage) {
            try {
                String message = objectMapper.writeValueAsString(object);
                switch (reconStatus) {
                    case MATCHED ->
                            reconMatchPublisher.publish(reconStatus.name(), String.valueOf(UUID.randomUUID()), object.toString());
                    case UNMATCHED ->
                            reconUnMatchPublisher.publish(reconStatus.name(), String.valueOf(UUID.randomUUID()), object.toString());
                    case DUPLICATE ->
                            reconDuplicatePublisher.publish(reconStatus.name(), String.valueOf(UUID.randomUUID()), message);
                    default ->
                            throw new OpsException(ErrorConstant.INVALID_ERROR_CODE_NO_REASON, MessageFormat.format(ErrorConstant.INVALID_ERROR_MESSAGE, reconStatus));
                }
            } catch (JsonProcessingException e) {
                log.error("Error in publishing of Recon Data Details of value {}, error: {}", object, e.getMessage());
            }
        }
        log.info("Publishing finished list of ATRN at  :- {} for reconStatus : {}", System.currentTimeMillis(), reconStatus);
    }

    /**
     * To generate a report for Unmatched and Duplicate report.
     * @param rfId UUID file Id
     */
    private  void generateBadReport(UUID rfId){
        ReconFileDto reconFileDto= reconFileDao.findByReconFileId(rfId);
        String SftpPath = replacePath(reconFileDto.getSftpPath(), IN_FOLDER, OUT_FOLDER);
        payoutReportService.badReportRequest(rfId, Report.BAD_RECORD,SftpPath);
    }

}
