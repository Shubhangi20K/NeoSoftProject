package com.epay.operations.util.parser;

import com.opencsv.CSVParser;
import com.opencsv.CSVParserBuilder;
import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;
import com.opencsv.exceptions.CsvException;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.experimental.UtilityClass;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Collections;
import java.util.List;

/**
 * Class Name: CsvParser
 * *
 * Description: Read Csv file data and store in database
 * *
 * Author:@V0000001(Shilpa Kothre)
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@UtilityClass
public class CsvParser {

    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(CsvParser.class);

    /**
     * Read file and return all row list, row is cell string array.
     *
     * @param fileKey String
     * @return List of row
     */
    public List<String[]> parseFile(InputStream inputStream, String fileKey, String delimiter) {
        CSVParser csvParser = new CSVParserBuilder().withSeparator(delimiter.charAt(0)).build();
        try (InputStreamReader reader = new InputStreamReader(inputStream);
             CSVReader csvReader = new CSVReaderBuilder(reader).withCSVParser(csvParser).build()) {
            return csvReader.readAll();
        } catch (IOException | CsvException e) {
            logger.debug("Reading csv file failed for filePath: {}", fileKey);
        }
        return Collections.emptyList();
    }
}
