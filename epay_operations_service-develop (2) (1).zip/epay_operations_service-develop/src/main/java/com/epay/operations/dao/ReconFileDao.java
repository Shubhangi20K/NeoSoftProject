package com.epay.operations.dao;

import com.epay.operations.dto.ReconFileDetailsDto;
import com.epay.operations.dto.ReconFileDto;
import com.epay.operations.entity.ReconFile;
import com.epay.operations.exception.OpsException;
import com.epay.operations.mapper.ReconFileMapper;
import com.epay.operations.repository.ReconFileRepository;
import com.epay.operations.repository.jdbc.ReconDataJdbcRepository;
import com.epay.operations.util.DateTimeUtils;
import com.epay.operations.util.enums.PayoutStatus;
import com.epay.operations.util.enums.ReconStatus;
import com.epay.operations.util.enums.SettlementStatus;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.text.MessageFormat;
import java.util.List;
import java.util.UUID;

import static com.epay.operations.util.ErrorConstant.NOT_FOUND_ERROR_CODE;
import static com.epay.operations.util.ErrorConstant.NOT_FOUND_ERROR_MESSAGE;

/**
 * Class Name:ReconFileSummaryDao
 * *
 * Description:
 * *
 * Author:NIRMAL GURJAR
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
@Component
@RequiredArgsConstructor
public class ReconFileDao {

    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private final ReconFileRepository reconFileRepository;
    private final ReconDataJdbcRepository reconDataJdbcRepository;
    private final ReconFileMapper reconFileMapper;

    public ReconFileDto findByReconFileId(UUID rfId) {
        logger.info("Finding Recon File for id: {}", rfId);
        ReconFile reconFile = reconFileRepository.findById(rfId).orElseThrow(() -> new OpsException(NOT_FOUND_ERROR_CODE, "Recon File Not Found"));
        return reconFileMapper.mapToReconFileSummaryDto(reconFile);
    }

    public ReconFileDto save(ReconFileDto reconFileDto) {
        logger.info("Saving ReconFile for file: {}", reconFileDto.getFileName());
        return reconFileMapper.mapToReconFileSummaryDto(reconFileRepository.save(reconFileMapper.mapToEntity(reconFileDto)));
    }

    public boolean isExistByFileName(String fileName) {
        return reconFileRepository.existsByFileNameAndCurrentDate(fileName, DateTimeUtils.getStartOfDayMillis(), DateTimeUtils.getEndOfDayMillis());
    }

    public boolean isExistByFileChecksum(String fileChecksum) {
        return reconFileRepository.existsByFileChecksumAndCurrentDate(fileChecksum, DateTimeUtils.getStartOfDayMillis(), DateTimeUtils.getEndOfDayMillis());
    }

    /**
     * This method is used to find the recon file summary by parsing status and recon status.
     */
    public void updateReconStatusById(UUID reconFileId, ReconStatus reconStatus, SettlementStatus settlementStatus) {
        logger.info("Fetch Recon File Summary of reconFileId: {}", reconFileId);
        int count = reconFileRepository.updateFileSummaryReconStatusByIdAndParsingStatus(reconFileId, reconStatus, settlementStatus);
        if (count <= 0) {
            throw new OpsException(NOT_FOUND_ERROR_CODE, MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, "Correct Recon file Info"));
        }
    }


    public void updateSettlementStatus(UUID rfId, SettlementStatus settlementStatus) {
        reconFileRepository.updateSettlementStatus(rfId, settlementStatus, DateTimeUtils.getCurrentTime());
    }

    public void updatePayoutStatusOfReconData(UUID rfId, String mId, PayoutStatus payoutStatus, String remark) {
        logger.info("Update the payout status {} in file details table against rfId {} and mId {}", payoutStatus, rfId, mId);
        reconDataJdbcRepository.updatePayoutStatusOfReconData(rfId, mId, payoutStatus, remark);
    }

    public void updateReconFile(UUID reconFileId, List<ReconFileDetailsDto> matched, List<ReconFileDetailsDto> unmatched, List<ReconFileDetailsDto> duplicate) {
        logger.info("Count updating into recon summary table.");

        ReconFile reconFile = reconFileRepository.findById(reconFileId).orElseThrow(() -> new OpsException(NOT_FOUND_ERROR_CODE, MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, "Correct Recon file Info")));
        reconFile.setReconStatus(ReconStatus.SUCCESS);
        reconFile.setMatchedRecords(matched.size());
        reconFile.setUnmatchedRecords(unmatched.size());
        reconFile.setDuplicateRecords(duplicate.size());
        reconFile.setMatchedAmount(matched.stream().map(ReconFileDetailsDto::getTransactionAmount).reduce(BigDecimal.ZERO, BigDecimal::add));
        reconFile.setUnmatchedAmount(unmatched.stream().map(ReconFileDetailsDto::getTransactionAmount).reduce(BigDecimal.ZERO, BigDecimal::add));
        reconFile.setDuplicateAmount(duplicate.stream().map(ReconFileDetailsDto::getTransactionAmount).reduce(BigDecimal.ZERO, BigDecimal::add));
        reconFile.setReconTime(DateTimeUtils.getCurrentTime());

        reconFileRepository.save(reconFile);
        logger.info("Recon file summary count updated successfully.");
    }

}