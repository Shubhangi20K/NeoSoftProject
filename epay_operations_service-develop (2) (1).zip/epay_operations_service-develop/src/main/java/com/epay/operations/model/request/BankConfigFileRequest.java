package com.epay.operations.model.request;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Class Name: BankConfigFileRequest
 * *
 * Description:
 * *
 * Author:@V0000001(Shilpa Kothre)
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class BankConfigFileRequest {

    private String bankCode;
    private String sftpPath;
    private String fileType;

}
