package com.epay.operations.scheduler;

import com.epay.operations.service.PayoutInitiationService;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.AllArgsConstructor;
import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;
import org.slf4j.MDC;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.UUID;

import static com.epay.operations.util.OperationsConstant.OPERATION;
import static com.epay.operations.util.OperationsConstant.SCENARIO;
import static org.springframework.kafka.support.KafkaHeaders.CORRELATION_ID;

/**
 * Class Name: PayoutInitiationScheduler
 * Description: Scheduler to check and initiate payout data population
 * Author:Akshaya Sahasranamam
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Component
@AllArgsConstructor
public class PayoutInitiationScheduler {

    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());

    private final PayoutInitiationService payoutInitiationService;

    @Scheduled(cron = "${scheduler.cron.expression.payout.generation.check}")
    @SchedulerLock(name = "PayoutGenerationCheck")
    public void isPayoutReadyForGeneration() {
        log.info("PayoutInitiationScheduler Initiated at {}", System.currentTimeMillis());
        MDC.put(CORRELATION_ID, String.valueOf(UUID.randomUUID()));
        MDC.put(SCENARIO, "PayoutGenerationCheck");
        MDC.put(OPERATION, "isPayoutReadyForGeneration");
        payoutInitiationService.isPayoutReadyForGeneration();
        log.info(" PayoutInitiationScheduler Completed at {}", System.currentTimeMillis());
    }

}
