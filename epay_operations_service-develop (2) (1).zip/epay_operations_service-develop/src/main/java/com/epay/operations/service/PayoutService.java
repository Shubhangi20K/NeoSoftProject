package com.epay.operations.service;

import com.epay.operations.dao.*;
import com.epay.operations.dto.*;
import com.epay.operations.dto.admin.BankAccountInfoDto;
import com.epay.operations.dto.admin.MerchantBankAccountsDto;
import com.epay.operations.dto.admin.MerchantInfoDto;
import com.epay.operations.entity.query.result.ReconMatchedTransaction;
import com.epay.operations.entity.view.MerchantRefundView;
import com.epay.operations.etl.producer.RefundAdjustedPublisher;
import com.epay.operations.exception.OpsException;
import com.epay.operations.util.OperationsConstant;
import com.epay.operations.util.OperationsUtil;
import com.epay.operations.util.enums.PayoutStatus;
import com.epay.operations.util.enums.ReconStatus;
import com.epay.operations.util.enums.Report;
import com.epay.operations.util.enums.SettlementStatus;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.retry.annotation.Retryable;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.text.MessageFormat;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.epay.operations.util.ErrorConstant.*;
import static com.epay.operations.util.OperationsConstant.*;
import static com.epay.operations.util.OperationsUtil.replacePath;

/**
 * Class Name: PayoutService
 * <p>Description: payout data population account wise.</p>
 *
 * @author : Akshaya Sahasranamam
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * Version:1.0
 */

@Service
@RequiredArgsConstructor
public class PayoutService {

    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    private final ObjectMapper objectMapper;
    private final ReconFileDao reconFileDao;
    private final AdminDao adminDao;
    private final MerchantTransactionPayoutDao merchantTransactionPayoutDao;
    private final MerchantPayoutDao merchantPayoutDao;
    private final ReconFileDetailsDao reconDataDetailsDao;
    private final RefundAdjustedPublisher refundAdjustedPublisher;
    private final PayoutTransactionMappingDao payoutTransactionMappingDao;
    private final PayoutReportService payoutReportService;


    /**
     * initiate payout data population process
     *
     * @param rfId rfId
     */
    public void initiatePayout(UUID rfId) {
        log.info("initiateMerchantTransactionPayout for rfId {}", rfId);
        //Step1: fetch Matched Records for payout Generation
        List<ReconMatchedTransaction> reconMatchedTransactions = reconDataDetailsDao.findByReconSettlementPayoutStatusAndFileId(rfId, ReconStatus.MATCHED, SettlementStatus.SETTLED, PayoutStatus.PENDING);
        //Step2: initiate payout process for eligible List Rf Id wise
        saveMerchantTransactionPayout(rfId, reconMatchedTransactions);
        log.info("Save MerchantTransactionPayout for rfId {}", rfId);
        log.info("Generate Fail Report For rfId: {}",rfId);
        if(reconDataDetailsDao.checkFailReconStatusExits(rfId)) generateFailReport(rfId);
    }

    /**
     * update the refund adjusted flag against mpId
     */
    public void refundAdjustedByPayoutId(UUID payoutId) {
        merchantPayoutDao.updateRefundAdjusted(payoutId);
    }

    /**
     * populate Merchant Transaction Payout
     *
     * @param rfId                        rfId
     * @param reconMatchedTransactionList matched record list
     */
    private void saveMerchantTransactionPayout(UUID rfId, List<ReconMatchedTransaction> reconMatchedTransactionList) {
        log.info("Payout Generation process mid wise initiated");
        Map<String, List<ReconMatchedTransaction>> reconMatchedRecordsMIdWise = reconMatchedTransactionList.stream().collect(Collectors.groupingBy(ReconMatchedTransaction::getMId));

        // Fetch bank account details
        List<String> mIds = reconMatchedRecordsMIdWise.keySet().stream().toList();
        Map<String, MerchantBankAccountsDto> merchantBankAccount = getMerchantsBankAccountInfo(mIds);
        Map<String, String> merchantInfo = getMerchantInfo(mIds);

        reconMatchedRecordsMIdWise.forEach((mId, reconMatchedTransactions) -> {
            log.info("Save MerchantTransactionPayout for MId : {}", mId);
            List<MerchantTransactionPayoutDto> merchantTransactionPayout = saveMerchantTransactionPayout(merchantBankAccount.get(mId), reconMatchedTransactions, rfId);
            log.info("Save MerchantTransactionPayout for MId : {}", mId);

            if (CollectionUtils.isNotEmpty(merchantTransactionPayout)) {
                Map<String, BigDecimal> accountWiseMerchantPayout = merchantTransactionPayout.stream().collect(Collectors.groupingBy(MerchantTransactionPayoutDto::getAccountId, Collectors.mapping(dto -> dto.getTransactionPayoutAmount().subtract(dto.getTransactionFee()), Collectors.reducing(BigDecimal.ZERO, BigDecimal::add))));
                Map<String, MerchantRefundDto> merchantAccountRefund = IS_REFUND_TO_BE_ADJUSTED.equalsIgnoreCase(merchantInfo.get(mId)) ? getMerchantRefundByAccountId(mId, accountWiseMerchantPayout, merchantBankAccount.get(mId).getPrimaryAccount()) : new HashMap<>();
                saveMerchantPayout(rfId, merchantTransactionPayout, merchantAccountRefund);
            }
            reconFileDao.updatePayoutStatusOfReconData(rfId, mId, PayoutStatus.READY_FOR_PAYOUT, StringUtils.EMPTY);
        });
        log.info("Payout Generation Process mId wise completed");
    }

    /**
     * save the merchant wise payout details
     *
     * @param merchantTransactionPayout merchant transaction payout details
     * @param refundObject              refund details
     * @param rfId                      file Id
     */
    private void saveMerchantPayout(UUID rfId, List<MerchantTransactionPayoutDto> merchantTransactionPayout, Map<String, MerchantRefundDto> refundObject) {
        Map<String, List<String>> refundArrns = new HashMap<>();
        Map<String, MerchantPayoutDto> merchantPayoutDtoMap = new HashMap<>();
        log.info("Save MerchantPayout");
        Map<String, List<String>> atrnListAgainstAccountId = buildMerchantPayoutAndRefundArrn(merchantTransactionPayout, refundObject, merchantPayoutDtoMap, refundArrns);
        log.info("Save MerchantPayout of merchantPayoutDtoMap : {} and refundArrns : {}", merchantPayoutDtoMap, refundArrns);
        Map<String, UUID> payoutIds = merchantPayoutDao.save(merchantPayoutDtoMap.keySet().stream().map(merchantPayoutDtoMap::get).toList());
        publishRefundAdjusted(payoutIds, refundArrns);
        populatePayoutTransactionMapping(rfId, atrnListAgainstAccountId, payoutIds);
    }

    /**
     * frame merchant payout and refund adjusted details
     *
     * @param merchantTransactionPayout merchantTxnPayout
     * @param refundArrns               refund arrns to be adjusted
     * @param merchantPayoutDtoMap      merchant payout dto
     * @param refundObject              refund details
     */
    private static Map<String, List<String>> buildMerchantPayoutAndRefundArrn(List<MerchantTransactionPayoutDto> merchantTransactionPayout, Map<String, MerchantRefundDto> refundObject, Map<String, MerchantPayoutDto> merchantPayoutDtoMap, Map<String, List<String>> refundArrns) {
        Map<String, List<String>> atrnListAgainstAccount = new HashMap<>();
        merchantTransactionPayout.forEach(merchantTransactionPayoutDto -> {
            atrnListAgainstAccount.computeIfAbsent(merchantTransactionPayoutDto.getAccountId(), k -> new ArrayList<>()).add(merchantTransactionPayoutDto.getAtrnNum());
            MerchantRefundDto merchantRefundDto = refundObject.get(merchantTransactionPayoutDto.getAccountId());
            if (merchantPayoutDtoMap.containsKey(merchantTransactionPayoutDto.getAccountId())) {
                MerchantPayoutDto merchantPayoutDto = merchantPayoutDtoMap.get(merchantTransactionPayoutDto.getAccountId());
                merchantPayoutDto.setTransactionAmount(merchantPayoutDto.getTransactionAmount().add(merchantTransactionPayoutDto.getTransactionPayoutAmount()));
            } else {
                MerchantPayoutDto merchantPayoutDto = buildMerchantPayoutDto(merchantTransactionPayoutDto);
                merchantPayoutDtoMap.put(merchantTransactionPayoutDto.getAccountId(), merchantPayoutDto);
                if (Objects.nonNull(merchantRefundDto)) {
                    refundArrns.put(merchantTransactionPayoutDto.getAccountId(), merchantRefundDto.getArrnList());
                    merchantPayoutDto.setRefundedAmount(merchantRefundDto.getRefundAmount());
                }
            }
        });
        return atrnListAgainstAccount;
    }

    /**
     * Fetch Bank Account Details
     *
     * @param mIdList mId List
     */
    private Map<String, MerchantBankAccountsDto> getMerchantsBankAccountInfo(List<String> mIdList) {
        log.info("Fetching Bank Details For mId: {}", mIdList);
        List<MerchantBankAccountsDto> merchantBankAccountsDtoList = adminDao.getMerchantBankAccountInfo(mIdList);
        return merchantBankAccountsDtoList.stream().collect(Collectors.toMap(MerchantBankAccountsDto::getMId, Function.identity()));
    }

    /**
     * Fetch Merchant Info Details
     *
     * @param mIdList mId List
     */
    private Map<String, String> getMerchantInfo(List<String> mIdList) {
        log.info("Fetching Merchant Info For mId: {}", mIdList);
        List<MerchantInfoDto> merchantInfoDtoList = adminDao.getMerchantInfo(mIdList);
        return merchantInfoDtoList.stream().collect(Collectors.toMap(MerchantInfoDto::getMId, MerchantInfoDto::getRefundAdjustment));
    }

    /**
     * Save payout details in merchant txn multi account payout
     *
     * @param reconMatchedTransactionList recon matched records
     */
    private List<MerchantTransactionPayoutDto> saveMerchantTransactionPayout(MerchantBankAccountsDto merchantAccountDetailsDto, List<ReconMatchedTransaction> reconMatchedTransactionList, UUID rfId) {
        log.info("Txn payout calculation against the account number is initiated");
        List<MerchantTransactionPayoutDto> merchantTransactionPayoutList = new ArrayList<>();
        if (ObjectUtils.isEmpty(merchantAccountDetailsDto.getPrimaryAccount())) {
            log.error("Primary Account Details not found for mId: {}", merchantAccountDetailsDto.getMId());
            reconFileDao.updatePayoutStatusOfReconData(rfId, merchantAccountDetailsDto.getMId(), PayoutStatus.PENDING, MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, "Primary Account"));
        } else {
            // Iterate list and calculate the payout against account
            reconMatchedTransactionList.forEach(matchedTransaction -> {
                String multiAccount = OperationsUtil.clobToString(matchedTransaction.getMultiAccount());
                if (StringUtils.isEmpty(multiAccount)) {
                    MerchantTransactionPayoutDto merchantTransactionPayoutDto = saveMerchantTransactionPayout(matchedTransaction, merchantAccountDetailsDto.getMId(), merchantAccountDetailsDto.getPrimaryAccount());
                    merchantTransactionPayoutList.add(merchantTransactionPayoutDto);
                } else {
                    List<MerchantTransactionPayoutDto> merchantTransactionPayoutDtos = buildMerchantTransactionPayoutDto(matchedTransaction, merchantAccountDetailsDto, multiAccount);
                    merchantTransactionPayoutList.addAll(merchantTransactionPayoutDtos);
                }
            });
            merchantTransactionPayoutDao.save(merchantTransactionPayoutList);
        }
        log.info("Txn payout calculation against the account number is completed");
        return merchantTransactionPayoutList;
    }

    /**
     * publish the adjusted refunds account wise
     */
    private void publishRefundAdjusted(Map<String, UUID> payoutIds, Map<String, List<String>> refundArrns) {
        log.info("Publish Refund Adjusted event for  payoutId: {} of refundArrns : {}", payoutIds, refundArrns);
        payoutIds.keySet().stream().filter(accountId -> CollectionUtils.isNotEmpty(refundArrns.get(accountId))).forEach(accountId -> {
            RefundAdjustedDto refundAdjusted = RefundAdjustedDto.builder().arrnList(refundArrns.get(accountId)).payoutId(payoutIds.get(accountId)).build();
            refundAdjustedPublisher.publish(OperationsConstant.REFUND_KEY, String.valueOf(payoutIds.get(accountId)), refundAdjusted);
        });
    }

    private static MerchantPayoutDto buildMerchantPayoutDto(MerchantTransactionPayoutDto merchantTransactionPayoutDto) {
        return MerchantPayoutDto.builder().bankId(merchantTransactionPayoutDto.getBankId()).accountId(merchantTransactionPayoutDto.getAccountId()).accountNumber(merchantTransactionPayoutDto.getAccountNumber()).payoutStatus(PayoutStatus.READY_FOR_PAYOUT).mId(merchantTransactionPayoutDto.getMId()).transactionAmount(merchantTransactionPayoutDto.getTransactionPayoutAmount()).refundedAmount(BigDecimal.ZERO).build();
    }

    private MerchantTransactionPayoutDto saveMerchantTransactionPayout(ReconMatchedTransaction matchedRecordDto, String mId, BankAccountInfoDto bankAccountInfoDto) {
        return MerchantTransactionPayoutDto.builder().mId(mId).transactionPayoutAmount(matchedRecordDto.getTxnAmount()).bankId(bankAccountInfoDto.getBankId()).accountNumber(bankAccountInfoDto.getAccountNumber()).accountId(bankAccountInfoDto.getAccountId()).atrnNum(matchedRecordDto.getAtrn()).rfId(OperationsUtil.bytesToUUID(matchedRecordDto.getRfId())).transactionFee(matchedRecordDto.getTransactionFee()).build();
    }

    /**
     * Calculate payout for multi account
     *
     * @param matchedTransaction        merchant txn payout dto
     * @param merchantAccountDetailsDto dto
     */
    private List<MerchantTransactionPayoutDto> buildMerchantTransactionPayoutDto(ReconMatchedTransaction matchedTransaction, MerchantBankAccountsDto merchantAccountDetailsDto, String multiAccount) {
        Optional<List<MerchantMultiAccountTransactionDto>> merchantTransactionAccountWise = buildMerchantMultiAccountTransactionDto(multiAccount);
        if (merchantTransactionAccountWise.isPresent()) {
            Map<String, BankAccountInfoDto> bankNickNameWise = merchantAccountDetailsDto.getSecondaryAccount().stream().collect(Collectors.toMap(BankAccountInfoDto::getAccountNickName, Function.identity()));
            return merchantTransactionAccountWise.get().stream().map(order -> saveMerchantTransactionPayout(merchantAccountDetailsDto, bankNickNameWise.get(order.getAccountIdentifier()), matchedTransaction, order.getAmount())).toList();
        }
        return List.of(saveMerchantTransactionPayout(matchedTransaction, merchantAccountDetailsDto.getMId(), merchantAccountDetailsDto.getPrimaryAccount()));
    }

    /**
     * frame dto for merchant txn multi acct payout
     *
     * @param merchantAccountDetailsDto dto
     * @param accountDetail             bank account details dto
     * @param matchedRecordDto          merchant txn payout dto
     * @param payout                    calculated payout
     */
    private MerchantTransactionPayoutDto saveMerchantTransactionPayout(MerchantBankAccountsDto merchantAccountDetailsDto, BankAccountInfoDto accountDetail, ReconMatchedTransaction matchedRecordDto, BigDecimal payout) {
        return MerchantTransactionPayoutDto.builder().mId(merchantAccountDetailsDto.getMId()).transactionPayoutAmount(payout).bankId(accountDetail.getBankId()).accountNumber(accountDetail.getAccountNumber()).accountId(accountDetail.getAccountId()).atrnNum(matchedRecordDto.getAtrn()).rfId(OperationsUtil.bytesToUUID(matchedRecordDto.getRfId())).transactionFee(matchedRecordDto.getTransactionFee()).build();
    }

    private Optional<List<MerchantMultiAccountTransactionDto>> buildMerchantMultiAccountTransactionDto(String multiAccount) {
        try {
            return Optional.of(objectMapper.readValue(multiAccount, new TypeReference<>() {
            }));
        } catch (JsonProcessingException e) {
            log.error(INVALID_ERROR_CODE_NO_REASON, MessageFormat.format(INVALID_ERROR_MESSAGE, "Merchant Order"));
        }
        return Optional.empty();
    }

    /**
     * fetch the refund list based on account id wise
     *
     * @param mId                       merchantId
     * @param accountWiseMerchantPayout account wise payout details
     * @param primaryAccountDetail      primary account details
     */
    private Map<String, MerchantRefundDto> getMerchantRefundByAccountId(String mId, Map<String, BigDecimal> accountWiseMerchantPayout, BankAccountInfoDto primaryAccountDetail) {
        Map<String, MerchantRefundDto> merchantRefundByAccountId = new HashMap<>();
        List<MerchantRefundView> merchantRefunds = merchantTransactionPayoutDao.getMerchantRefundInfo(mId);
        for (MerchantRefundView refundToBeAdjusted : merchantRefunds) {
            checkAccountId(primaryAccountDetail, refundToBeAdjusted);
            BigDecimal remainingPayout = accountWiseMerchantPayout.getOrDefault(refundToBeAdjusted.getAccountId(), BigDecimal.ZERO);
            if (remainingPayout.compareTo(refundToBeAdjusted.getRefundAmount()) > 0 && StringUtils.isNotEmpty(refundToBeAdjusted.getArrnNum())) {
                setMerchantRefundAccountWise(refundToBeAdjusted, merchantRefundByAccountId);
                accountWiseMerchantPayout.put(refundToBeAdjusted.getAccountId(), remainingPayout.subtract(refundToBeAdjusted.getRefundAmount()));
            }
        }
        return merchantRefundByAccountId;
    }

    private static void checkAccountId(BankAccountInfoDto primaryAccountDetail, MerchantRefundView refundToBeAdjusted) {
        if (StringUtils.isEmpty(refundToBeAdjusted.getAccountId()))
            refundToBeAdjusted.setAccountId(primaryAccountDetail.getAccountId());
    }

    private static void setMerchantRefundAccountWise(MerchantRefundView refundToBeAdjusted, Map<String, MerchantRefundDto> merchantRefundByAccountId) {
        if (merchantRefundByAccountId.containsKey(refundToBeAdjusted.getAccountId())) {
            MerchantRefundDto merchantRefundDto = merchantRefundByAccountId.get(refundToBeAdjusted.getAccountId());
            merchantRefundDto.setRefundAmount(merchantRefundDto.getRefundAmount().add(refundToBeAdjusted.getRefundAmount()));
            merchantRefundDto.getArrnList().add(refundToBeAdjusted.getArrnNum());
            merchantRefundByAccountId.put(refundToBeAdjusted.getAccountId(), merchantRefundDto);
        } else {
            List<String> arrnList = new ArrayList<>();
            arrnList.add(refundToBeAdjusted.getArrnNum());
            merchantRefundByAccountId.put(refundToBeAdjusted.getAccountId(), MerchantRefundDto.builder().refundAmount(refundToBeAdjusted.getRefundAmount()).arrnList(arrnList).build());
        }
    }

    private void populatePayoutTransactionMapping(UUID rfId, Map<String, List<String>> atrnListAgainstAccountId, Map<String, UUID> mpIdAccountWise) {
        List<PayoutTransactionMappingDto> payoutTransactionMappingDtoList = new ArrayList<>();
        for (Map.Entry<String, List<String>> atrnAgainstAccountId : atrnListAgainstAccountId.entrySet()) {
            for (String atrn : atrnAgainstAccountId.getValue()) {
                payoutTransactionMappingDtoList.add(PayoutTransactionMappingDto.builder().atrnNum(atrn).payoutInfoId(mpIdAccountWise.get(atrnAgainstAccountId.getKey())).rfId(rfId).build());
            }
        }
        payoutTransactionMappingDao.savePayoutTransactionMapping(payoutTransactionMappingDtoList);
    }

    @Async
    @Retryable(maxAttemptsExpression = "${purge.maxRetry:3}")
    public void purgeMerchantTransactionPayoutWithRetry(long retentionDaysMillis) {
        log.info("Attempting to flush MerchantTransactionPayout.");
        try {
            purgeMerchantTransactionPayout(retentionDaysMillis);
        } catch (Exception ex) {
            log.error("Error during Data purging for MERCHANT_TXN_PAYOUT : {}", ex.getMessage());
            throw ex;
        }
    }

    @Transactional
    public void purgeMerchantTransactionPayout(long retentionDaysMillis) {
        log.info("Data insertion started in merchant txn payout history.");
        int insertCount = merchantTransactionPayoutDao.insertMerchantTxnPayoutHistory(retentionDaysMillis);
        log.info("Inserted into history: {}", insertCount);
        int deletedCount = merchantTransactionPayoutDao.deleteMerchantTxnPayout(retentionDaysMillis);
        log.info("Deleted from ReconDataDetails: {}", deletedCount);

        if (insertCount != deletedCount) {
            log.error(MISMATCH_ERROR_MESSAGE, insertCount, deletedCount);
            throw new OpsException(MISMATCH_ERROR_CODE, MessageFormat.format(MISMATCH_ERROR_MESSAGE, insertCount, deletedCount));
        }
    }

    /**
     * To generate a report for Unmatched and Duplicate report.
     * @param rfId UUID file Id
     */
    private  void generateFailReport(UUID rfId){
        ReconFileDto reconFileDto= reconFileDao.findByReconFileId(rfId);
        String SftpPath = replacePath(reconFileDto.getSftpPath(), IN_FOLDER, OUT_FOLDER);
        payoutReportService.badReportRequest(rfId, Report.FAILED_REPORT,SftpPath);
    }
}
