package com.epay.operations.dto.admin;

import com.epay.operations.util.enums.ReconFileType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.Map;
import java.util.UUID;

/**
 * Class Name: ConfigFileDto
 * *
 * Description: Dto Class
 * *
 * Author:@V0000001(Shilpa Kothre)
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class FileConfigDto {

    private UUID configId;
    private String bankCode;
    private String sftpPath;
    private ReconFileType fileType;
    private String delimiter;
    private Boolean headerPresent;
    private Integer headerRow;
    private int dataStartRow;
    private String header;
    private Map<String, Integer> headerMapping;
    private String dateFormat;
    private Map<String, String> valueMapping;
    private Integer hashRow;
    private String hashHeader;
    private Integer summaryRow;
    private String summaryHeader;
    private Boolean fileEncrypted;
    private String encLevel;
    private String encKey;

}