package com.epay.operations.util;

import com.epay.operations.exception.OpsException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import jakarta.validation.constraints.NotNull;
import lombok.experimental.UtilityClass;
import org.apache.commons.lang3.StringUtils;

import java.io.File;
import java.io.Reader;
import java.io.StringWriter;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.ByteBuffer;
import java.sql.Clob;
import java.text.MessageFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Collections;
import java.util.Map;
import java.util.UUID;

import static com.epay.operations.util.ErrorConstant.GENERIC_ERROR_CODE;
import static com.epay.operations.util.OperationsConstant.EXTERNAL_SERVICE;
import static com.epay.operations.util.OperationsConstant.LOCAL;

/**
 * Class Name: CommonUtil
 * *
 * Description: Common Utility methods
 * *
 * Author:@V0000001(Shilpa Kothre)
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@UtilityClass
public class OperationsUtil {
    private final LoggerUtility log = LoggerFactoryUtility.getLogger(OperationsUtil.class);
    private static final ObjectMapper mapper = new ObjectMapper();

    /**
     * @param fileName String
     * @return String
     */
    public static String getAbsolutePath(String fileName) {
        return new File(fileName).getAbsolutePath();
    }

    public static Map<String, Integer> convertJsonStringToMapSI(String jsonString) {
        if (jsonString == null || jsonString.trim().isEmpty()) {
            return Collections.emptyMap();
        }

        try {
            return mapper.readValue(jsonString, new TypeReference<>() {
            });
        } catch (JsonProcessingException e) {
            throw new OpsException(GENERIC_ERROR_CODE, ErrorConstant.GENERIC_ERROR_MESSAGE);
        }
    }

    public static Map<String, String> convertJsonStringToMapSS(String jsonString) {
        if (jsonString == null || jsonString.trim().isEmpty()) {
            return Collections.emptyMap();
        }
        try {
            return mapper.readValue(jsonString, new TypeReference<>() {
            });
        } catch (JsonProcessingException e) {
            throw new OpsException(ErrorConstant.GENERIC_ERROR_CODE, ErrorConstant.GENERIC_ERROR_MESSAGE);
        }
    }

    public static String verifyAndUpdateDate(String sftpPath) {
        return sftpPath.replace("$$DATE$$", LocalDate.now().format(DateTimeFormatter.ofPattern("ddMMyyyy")));
    }

    public static String replacePath(String sftpPath, String subString, String replacement) {
        boolean containsSubstring = sftpPath.contains(subString);
        String modifiedString = null;
        if (containsSubstring) {
            modifiedString = sftpPath.replace(subString, replacement);
        }
        return modifiedString;
    }

    /**
     * Return service name from the given baseURL
     *
     * @return String
     */
    public static String getServiceName(@NotNull String baseURL) {
        String[] urlToken = baseURL.split("/");
        return urlToken.length > 1 ? urlToken[urlToken.length - 2].substring(0, 1).toUpperCase() + urlToken[urlToken.length - 2].substring(1) : EXTERNAL_SERVICE;
    }

    /**
     * @param key         String
     * @param requestType String
     * @param routingKey  String
     * @return String
     */
    public static String getKafkaRoutingKey(String key, String requestType, String routingKey) {
        return MessageFormat.format("{0}.{1}.{2}", key, requestType, routingKey);
    }

    /**
     * Check the given profile is local profile or not.
     *
     * @param profile String
     * @return boolean
     */
    public static boolean isLocalProfile(String profile) {
        return StringUtils.equalsIgnoreCase(LOCAL, profile);
    }

    public static BigDecimal getPercentageValue(BigDecimal number, BigDecimal percent) {
        return number.multiply(percent).divide(new BigDecimal("100"), RoundingMode.HALF_UP);
    }

    public static BigDecimal getPercentage(BigDecimal number, BigDecimal total) {
        BigDecimal fractionalValue = number.divide(total, 2, RoundingMode.HALF_UP);
        return fractionalValue.multiply(new BigDecimal("100"));
    }

    public static UUID bytesToUUID(byte[] bytes) {
        if (bytes == null || bytes.length != 16) {
            return null;
        }
        ByteBuffer bb = ByteBuffer.wrap(bytes);
        long high = bb.getLong();
        long low = bb.getLong();
        return new UUID(high, low);
    }

    public static byte[] uuidToBytes(UUID uuid) {
        ByteBuffer bb = ByteBuffer.wrap(new byte[16]);
        bb.putLong(uuid.getMostSignificantBits());
        bb.putLong(uuid.getLeastSignificantBits());
        return bb.array();
    }

    public static String clobToString(Clob clob) {
        if (clob == null) return StringUtils.EMPTY;
        try (Reader reader = clob.getCharacterStream();
             StringWriter writer = new StringWriter()) {

            char[] buffer = new char[2048];
            int len;
            while ((len = reader.read(buffer)) != -1) {
                writer.write(buffer, 0, len);
            }
            return writer.toString();
        } catch (Exception e) {
            log.error("Failed to convert CLOB to String, {}", e);
        }
        return StringUtils.EMPTY;
    }


    public long getRetentionDays(int retentionDays){
        return Instant.now().minus(retentionDays, ChronoUnit.DAYS).toEpochMilli();
    }
}
