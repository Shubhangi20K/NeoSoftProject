package com.epay.operations.dao;


import com.epay.operations.repository.MerchantTransactionStatusRepository;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.UUID;

/**
 * Class Name:MerchantTransactionStatusDao
 * Description: MerchantTransactionStatusDao
 * Author:Akshaya Sahasranamam
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
@Component
@AllArgsConstructor
public class MerchantTransactionStatusDao {

    private final MerchantTransactionStatusRepository merchantTransactionStatusRepository;

    public int countSettledTransaction(UUID rfId) {
        return merchantTransactionStatusRepository.countSettledTransaction(rfId);
    }

}
