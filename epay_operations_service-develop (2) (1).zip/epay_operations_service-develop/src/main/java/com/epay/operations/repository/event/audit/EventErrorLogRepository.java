package com.epay.operations.repository.event.audit;

import com.epay.operations.entity.event.audit.EventErrorLog;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface EventErrorLogRepository extends JpaRepository<EventErrorLog, UUID> {
}
