package com.epay.operations.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;

/**
 * Class Name: MerchantRefundDtoŌ
 * *
 * Description: Dto Class
 * *
 * Author:Akshaya Sahasranamam
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class MerchantRefundDto {

    private String mId;
    private List<String> arrnList;
    private BigDecimal refundAmount;

}
