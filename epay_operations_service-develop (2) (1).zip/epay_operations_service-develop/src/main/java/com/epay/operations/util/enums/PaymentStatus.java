package com.epay.operations.util.enums;

public enum PaymentStatus {
  BOOKED,
  PAYMENT_INITIATION_START,
  SUCCESS,
  FAILED,
  PENDING,
  EXPIRED
}
