package com.epay.operations.repository;

import com.epay.operations.entity.MerchantTransactionPayout;
import com.epay.operations.entity.query.result.MerchantBankPayoutData;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface MerchantTransactionPayoutRepository extends JpaRepository<MerchantTransactionPayout, UUID> {

    @Query(value = """
            SELECT MERCHANT_ID as mId,BANK_ID as bankId,
            SUM(TXN_PAYOUT_AMOUNT) AS merchantPayout
            FROM MERCHANT_TXN_PAYOUT
            WHERE PAYOUT_STATUS = 'READY_FOR_PAYOUT'
            GROUP BY MERCHANT_ID,BANK_ID
            """, nativeQuery = true)
    List<MerchantBankPayoutData> findMerchantBankPayoutData();

}
