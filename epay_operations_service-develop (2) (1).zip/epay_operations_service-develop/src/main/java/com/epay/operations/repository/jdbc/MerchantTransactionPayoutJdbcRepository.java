package com.epay.operations.repository.jdbc;

import com.epay.operations.dto.MerchantTransactionPayoutDto;
import com.epay.operations.exception.OpsException;
import com.epay.operations.util.DateTimeUtils;
import com.epay.operations.util.OperationsUtil;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import static com.epay.operations.util.ErrorConstant.FAILED_TO_INSERT_ERROR_CODE;
import static com.epay.operations.util.ErrorConstant.FAILED_TO_INSERT_ERROR_MESSAGE;
import static com.epay.operations.util.query.PayoutProcessingJdbcQuery.INSERT_MERCHANT_TXN_PAYOUT;

/**
 * Class Name:MerchantTxnMultiAcctPayoutRepository
 * *
 * Description:
 * *
 * Author:Akshaya Sahasranamam
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
@Repository
@RequiredArgsConstructor
public class MerchantTransactionPayoutJdbcRepository {

    private final NamedParameterJdbcTemplate jdbcTemplate;
    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());


    public void save(List<MerchantTransactionPayoutDto> merchantTxnPayoutDtoList) throws OpsException {
        try {
            MapSqlParameterSource[] parameters = merchantTxnPayoutDtoList.stream().map(merchantTxnPayoutDto -> {
                MapSqlParameterSource param = new MapSqlParameterSource();
                param.addValue("MTP_ID", OperationsUtil.uuidToBytes(UUID.randomUUID()));
                param.addValue("RF_ID", OperationsUtil.uuidToBytes(merchantTxnPayoutDto.getRfId()));
                param.addValue("ATRN_NUM", merchantTxnPayoutDto.getAtrnNum());
                param.addValue("MERCHANT_ID", merchantTxnPayoutDto.getMId());
                param.addValue("TXN_PAYOUT_AMOUNT", merchantTxnPayoutDto.getTransactionPayoutAmount());
                param.addValue("BANK_ID", merchantTxnPayoutDto.getBankId());
                param.addValue("CREATED_DATE", DateTimeUtils.getCurrentTime());
                param.addValue("UPDATED_DATE", DateTimeUtils.getCurrentTime());
                param.addValue("ACCOUNT_NUMBER", merchantTxnPayoutDto.getAccountNumber());
                param.addValue("ACCOUNT_ID", merchantTxnPayoutDto.getAccountId());
                param.addValue("TXN_FEE", merchantTxnPayoutDto.getTransactionFee());
                return param;
            }).toList().toArray(MapSqlParameterSource[]::new);

            log.info("Inserting into {}", INSERT_MERCHANT_TXN_PAYOUT);
            int[] updateOrderPaymentCounts = jdbcTemplate.batchUpdate(INSERT_MERCHANT_TXN_PAYOUT, parameters);
            log.info("Inserted {} records into MERCHANT_TXN_MULTI_ACC_PAYOUT", Arrays.stream(updateOrderPaymentCounts).sum());

        } catch (Exception ex) {
            log.error("Error during bulk insert to MERCHANT_TXN_MULTI_ACC_PAYOUT", ex.getMessage());
            throw new OpsException(FAILED_TO_INSERT_ERROR_CODE, FAILED_TO_INSERT_ERROR_MESSAGE);
        }
    }

}