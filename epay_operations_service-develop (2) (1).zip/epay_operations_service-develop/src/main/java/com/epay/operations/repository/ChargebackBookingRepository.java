package com.epay.operations.repository;

import org.springframework.stereotype.Repository;

/**
 * Class Name:ChargebackBookingRepository
 * *
 * Description: Repository interface for ChargebackBooking details
 * *
 * Author: Akshaya Sahasranamam
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
@Repository
public interface ChargebackBookingRepository {
}
