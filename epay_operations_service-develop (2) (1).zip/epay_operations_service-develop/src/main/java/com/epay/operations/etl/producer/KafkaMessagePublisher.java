package com.epay.operations.etl.producer;

import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

/**
 * Class Name: KafkaProducer
 * *
 * Description: The parent producer for Recon service.
 * *
 * Author:@V0000001(Shilpa Kothre)
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Component
@RequiredArgsConstructor
public class KafkaMessagePublisher {
    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    private final KafkaTemplate<String, String> kafkaTemplate;

    /**
     * Publishing string message on transaction topic(s).
     *
     * @param topic   String
     * @param key     String
     * @param message String
     */
    public void publish(String topic, String key, String message) {
        try {
            kafkaTemplate.send(topic, key, message);
        } catch (Exception e) {
            log.debug("Issue in message publishing to kafka topic: {} , key : {} and  message : {}", topic, key, message);
        }
    }
}