package com.epay.operations.mapper;

import com.epay.operations.dto.DataSyncSchedulerDto;
import com.epay.operations.entity.DataSyncScheduler;
import org.mapstruct.Mapper;


@Mapper(componentModel = "spring")
public interface DataSyncSchedulerMapper {

    DataSyncScheduler mapToEntity(DataSyncSchedulerDto dataSyncSchedulerDto);

    DataSyncSchedulerDto entityToDto(DataSyncScheduler dataSyncScheduler);
}
