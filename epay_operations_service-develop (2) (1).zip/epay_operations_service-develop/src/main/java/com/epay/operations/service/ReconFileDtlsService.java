package com.epay.operations.service;


import com.epay.operations.config.OpsConfig;
import com.epay.operations.dao.ReconFileDetailsDao;
import com.epay.operations.entity.ReconFileDetails;
import com.epay.operations.exception.OpsException;
import com.epay.operations.repository.ReconFileDtlsRepository;
import com.epay.operations.util.enums.PayoutStatus;
import com.epay.operations.util.enums.ReconStatus;
import com.epay.operations.util.enums.SettlementStatus;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.retry.annotation.Retryable;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.text.MessageFormat;
import java.util.UUID;

import static com.epay.operations.util.ErrorConstant.*;

/**
 * Class Name:ReconDataDetailsService
 * Description: Methods related to file dls.
 * Author:@V0000001(Shilpa Kothre)
 * Copyright (c) 2024 [State Bank of India]
 * All right reserved<br>
 * Version:1.0
 */
@Service
@RequiredArgsConstructor
public class ReconFileDtlsService {

    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    private final ReconFileDtlsRepository reconFileDtlsRepository;
    private final ReconFileDetailsDao reconFileDetailsDao;

    public void updateReconStatusAndRemarkByRfdId(UUID rfdId, String Remark) {
        log.info("Updating ReconDataDetails  for rfdId: {}", rfdId);
        ReconFileDetails reconFileDetails = reconFileDtlsRepository.findByRfdId(rfdId)
                .orElseThrow(() -> new OpsException(NOT_FOUND_ERROR_CODE, MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, "Rfd Id")));
        reconFileDetails.setReconStatus(ReconStatus.FAIL);
        reconFileDetails.setRemark(Remark);
        reconFileDetails.setSettlementStatus(SettlementStatus.FAIL);
        reconFileDetails.setPayoutStatus(PayoutStatus.FAIL);
        reconFileDtlsRepository.save(reconFileDetails);
        log.info("Updated ReconDataDetails for rfdId: {}", rfdId);
    }

    @Async
    @Retryable(maxAttemptsExpression = "${purge.maxRetry:3}")
    public void purgeReconFileDetailsWithRetry(long retentionDaysMillis) {
        log.info("Attempting to purge Recon file details.");
        try {
            purgeReconFileDetails(retentionDaysMillis);
        } catch (Exception ex) {
            log.error("Error during Data purging for RECON_FILE_DTLS : {}", ex.getMessage());
            throw ex;
        }
    }

    @Transactional
    public void purgeReconFileDetails(long retentionDaysMillis) {

        log.info("Data insertion started in Recon file details.");
        int insertCount = reconFileDetailsDao.insertReconFileDetailsHistory(retentionDaysMillis);
        log.info("Inserted into history: {}", insertCount);
        int deletedCount = reconFileDetailsDao.deleteReconFileDetails(retentionDaysMillis);
        log.info("Deleted from ReconDataDetails: {}", deletedCount);

        if (insertCount != deletedCount) {
            log.error(MISMATCH_ERROR_MESSAGE, insertCount, deletedCount);
            throw new OpsException(MISMATCH_ERROR_CODE, MessageFormat.format(MISMATCH_ERROR_MESSAGE, insertCount, deletedCount));
        }
    }

}
