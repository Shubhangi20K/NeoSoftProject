package com.epay.operations.mapper;

import com.epay.operations.dto.transaction.MerchantTransactionDto;
import com.epay.operations.entity.view.MerchantTransaction;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(builder = @Builder(disableBuilder = true), componentModel = "spring")
public interface MerchantTransactionMapper {


    MerchantTransactionDto toPaymentDto(MerchantTransaction merchantTransaction);

    List<MerchantTransactionDto> toPaymentDtoList(List<MerchantTransaction> merchantTransactions);
}
