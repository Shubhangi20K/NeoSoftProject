package com.epay.operations.config.kafka;

import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Class Name: KafkaProducerSettings
 * *
 * Description: kafka topic setting.
 * *
 * Author:@V0000001(Shilpa Kothre)
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Getter
@Setter
@Component
public class KafkaProducerSettings {
    @Value("${spring.kafka.bootstrapServers}")
    private String bootstrapServers;

    @Value("${spring.kafka.producer.acks}")
    private String acks;

    @Value("${spring.kafka.producer.retries}")
    private int retries;

    @Value("${spring.kafka.producer.batchSize}")
    private int batchSize;

    @Value("${spring.kafka.producer.lingerMs}")
    private int lingerMs;

    @Value("${spring.kafka.producer.bufferMemory}")
    private long bufferMemory;

    @Value("${spring.kafka.properties.security.protocol:}")
    private String securityProtocol;

    @Value("${spring.kafka.properties.ssl.truststore.location:}")
    private String trustLocation;

    @Value("${spring.kafka.properties.ssl.truststore.password:}")
    private String trustPassword;

    @Value("${spring.kafka.properties.ssl.truststore.type:}")
    private String trustType;

    @Value("${spring.kafka.properties.ssl.keystore.location:}")
    private String keyLocation;

    @Value("${spring.kafka.properties.ssl.keystore.password:}")
    private String keyPassword;

    @Value("${spring.kafka.properties.ssl.keystore.type:}")
    private String keyType;

    @Value("${transaction.kafka.sslConfig.provided:false}")
    private boolean sslConfigProvided;
}
