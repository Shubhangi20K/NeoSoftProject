package com.epay.operations.service;

import com.epay.operations.dao.MerchantTransactionDao;
import com.epay.operations.dao.ReconFileDao;
import com.epay.operations.dao.ReconProcessDao;
import com.epay.operations.dto.ReconFileDetailsDto;
import com.epay.operations.dto.ReconFileDto;
import com.epay.operations.dto.ReconRecordStatusDto;
import com.epay.operations.dto.transaction.MerchantTransactionDto;
import com.epay.operations.util.enums.ReconStatus;
import com.epay.operations.util.enums.Report;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Service;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.epay.operations.util.OperationsConstant.*;
import static com.epay.operations.util.OperationsUtil.replacePath;
import static com.epay.operations.util.query.JdbcQuery.MERCHANT_TRANSACTION;


/**
 * Class Name:JavaReconciliationService
 * *
 * Description:
 * *
 * Author:SAURABH_MAHTO(V1018841)
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
@Service
@RequiredArgsConstructor
public class JavaReconciliationService {
    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());

    private final MerchantTransactionDao merchantTransactionDao;
    private final ReconProcessDao reconProcessDao;
    private final ReconResultProcessorService reconResultProcessorService;

    public void reconProcessing(UUID rfId) {
        // Step-1: Fetch recon file details using rfId.
        logger.info("Step-1: Fetching recon file details for rfId: {}", rfId);
        Map<String, List<ReconFileDetailsDto>> reconFileDetailsMap = reconProcessDao.getAllReconFileData(rfId).stream().collect(Collectors.groupingBy(ReconFileDetailsDto::getAtrnNum));

        // Step-2: Fetch transaction data.
        logger.info("Step-2: Fetching transaction data from table: {}", MERCHANT_TRANSACTION);
        Map<String, MerchantTransactionDto> merchantTransactionByAtrns = getMerchantPaymentsByAtrns(reconFileDetailsMap.keySet());

        // Step-3: Classify the data into matched, duplicate, and unmatched.
        logger.info("Step-3: Classifying recon data.");
        ReconRecordStatusDto reconRecordStatusDto = findMatchedUnmatchedAndDuplicateReconRecords(reconFileDetailsMap, merchantTransactionByAtrns);

        // Step-4: Update Recon Status.
        logger.info("Step-4: Update Recon Status.");
        updateReconStatuses(reconRecordStatusDto);

        // Step-5 Publish process data into kafka
        logger.info("Step-5: Publish recon processed data into kafka.");
        reconResultProcessorService.publishReconProcessedData(rfId);
    }

    @Transactional
    private Map<String, MerchantTransactionDto> getMerchantPaymentsByAtrns(Set<String> atrnNum) {
        logger.info("Fetching matched ATRNs data from MerchantOrderPayment");
        List<String> atrns = atrnNum.stream().toList();
        List<MerchantTransactionDto> payments = new ArrayList<>();
        for (int i = 0; i < atrns.size(); i += IN_CLAUSE_MAX_SIZE) {
            int end = Math.min(i + IN_CLAUSE_MAX_SIZE, atrns.size());
            payments.addAll(merchantTransactionDao.getMerchantTxn(atrns.subList(i, end)));
        }
        return payments.stream().collect(Collectors.toMap(MerchantTransactionDto::getAtrnNum, Function.identity(), (existing, replacement) -> {
            logger.warn("Duplicate ATRN detected: {}", existing.getAtrnNum());
            return existing;
        }));
    }

    private ReconRecordStatusDto findMatchedUnmatchedAndDuplicateReconRecords(Map<String, List<ReconFileDetailsDto>> reconPaymentMap, Map<String, MerchantTransactionDto> marchantTxnMap) {
        ReconRecordStatusDto result = new ReconRecordStatusDto();
        reconPaymentMap.forEach((atrn, reconList) -> {
            if (marchantTxnMap.containsKey((atrn))) {
                processReconData(reconList, marchantTxnMap.get(atrn), result);
            } else {
                result.addUnmatched(reconList.stream().peek(x -> x.setRemark(ATRN_MISMATCH_WITH_TXN_DATA)).toList());
            }
        });
        return result;
    }

    private void processReconData(List<ReconFileDetailsDto> reconFileDtlsDtos, MerchantTransactionDto payment, ReconRecordStatusDto result) {
        if (CollectionUtils.isNotEmpty(reconFileDtlsDtos)) {
            boolean isDuplicate = false;
            for (ReconFileDetailsDto reconFileDtlsDto : reconFileDtlsDtos) {
                if (isDuplicate) {
                    reconFileDtlsDto.setRemark(DUPLICATE_ATRN);
                    result.addDuplicate(reconFileDtlsDto);
                } else if (reconFileDtlsDto.getTransactionAmount().compareTo(payment.getTransactionAmount()) == 0) {
                    result.addMatched(reconFileDtlsDto);
                    isDuplicate = true;
                } else {
                    reconFileDtlsDto.setRemark(AMOUNT_MISMATCH_WITH_TXN_ATRN);
                    result.addUnmatched(List.of(reconFileDtlsDto));
                    isDuplicate = true;
                }
            }
        }
    }

    private void updateReconStatuses(ReconRecordStatusDto result) {
        batchUpdateStatus(result.getMatched(), ReconStatus.MATCHED);
        batchUpdateStatus(result.getUnmatched(), ReconStatus.UNMATCHED);
        batchUpdateStatus(result.getDuplicate(), ReconStatus.DUPLICATE);
    }

    /**
     * * Updating Recon Status in batch.
     * *
     * * @param list   of ReconDataDetails
     * * @param status Recon_Status
     */

    private void batchUpdateStatus(List<ReconFileDetailsDto> list, ReconStatus status) {
        List<ReconFileDetailsDto> reconFileDetailsDtoList;
        for (int reconFileIndex = 0; reconFileIndex < list.size(); reconFileIndex += IN_CLAUSE_MAX_SIZE) {
            int end = Math.min(reconFileIndex  + IN_CLAUSE_MAX_SIZE, list.size());
            reconFileDetailsDtoList = list.subList(reconFileIndex, end);
            reconProcessDao.updateReconStatus(status,reconFileDetailsDtoList);
        }
    }



}
