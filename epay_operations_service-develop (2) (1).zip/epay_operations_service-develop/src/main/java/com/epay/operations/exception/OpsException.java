package com.epay.operations.exception;

import com.epay.operations.dto.ErrorDto;
import java.util.List;
import lombok.*;

/**
 * Class Name: RnSException
 * *
 * Description: This class defines a custom runtime exception specific to the RnS module of the project.
 * It extends the 'RuntimeException' class to provide custom exception handling for reporting-related errors.
 * The exception can be thrown when there are issues during report generation, validation, or other reporting processes.
 * The class uses Lombok annotations to automatically generate getter, setter, equals, hashCode, builder, and constructor methods.
 * Author: Bhoopendra Rajput
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@EqualsAndHashCode(callSuper = true)
@Builder
@AllArgsConstructor
@Getter
public class OpsException extends RuntimeException {
    private final String errorCode;
    private final String errorMessage;
    private final List<ErrorDto> errorMessages;

    /**
     * Parametrized constructor taking errorCode and errorMessage
     * @param errorCode String
     * @param errorMessage String
     */
    public OpsException(String errorCode, String errorMessage) {
        super(errorMessage);
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
        this.errorMessages = null;
    }

    /**
     * Parametrized constructor taking List of ErrorDTO
     * @param errorMessages List<ErrorDto>
     */
    public OpsException(List<ErrorDto> errorMessages) {
        this.errorMessages = errorMessages;
        this.errorCode = null;
        this.errorMessage = null;
    }

}