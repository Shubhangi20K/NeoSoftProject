package com.epay.operations.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

@Configuration
public class TaskExecutorConfig {

    @Value("${queue.batch.size.event}")
    private int eventQueueBatchSize;

    @Bean(name="eventTaskExecutor")
    public TaskExecutor eventTaskExecutor(){
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(5);
        executor.setMaxPoolSize(10);
        executor.setQueueCapacity(eventQueueBatchSize);
        executor.setThreadNamePrefix("eventTaskExecutor");
        executor.initialize();
        return executor;
    }
}
