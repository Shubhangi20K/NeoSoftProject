package com.epay.operations.util.parser;

import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.experimental.UtilityClass;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

/**
 * Class Name: TxtParser
 * *
 * Description:
 * *
 * Author:@V10000025(Sagar Rathod)
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@UtilityClass
public class TxtParser {

    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(TxtParser.class);

    public List<String[]> parseFile(InputStream inputStream, String fileKey, String delimiter) {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream))) {
            return reader.lines().map(line -> line.split(Pattern.quote(delimiter))).collect(Collectors.toCollection(ArrayList::new));
        } catch (Exception e) {
            logger.error("Reading TXT file failed for filePath: {}", fileKey);
        }
        return Collections.emptyList();
    }
}