package com.epay.operations.util.file.generator;


import com.epay.operations.dto.ReportFileDto;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.StringEscapeUtils;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.stream.Collectors;

import static com.epay.operations.util.DateTimeUtils.getCurrentTimeSting;


/**
 * Class Name: CSVGenerator
 * *
 * Description:Class for generating and downloading CSV files for reports.
 * *
 * Author: Gireesh M
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class CSVGenerator {

    private static final LoggerUtility log = LoggerFactoryUtility.getLogger(CSVGenerator.class);

    /**
     * Generates a CSV file from the provided data and saves it to the file system.
     *
     * @param reportName - Name of the report
     * @param headerName - List of CSV headers
     * @param objects    - Data to populate the CSV
     * @return - Generated CSV file
     */
    protected static ReportFileDto csvFileGenerator(String reportName, List<String> headerName, List<List<Object>> objects) {
        log.info("Started csv file generator for reportName : {}, mId {}, headerName: {},  objects.size: {}", reportName, headerName, CollectionUtils.size(objects));
        String fileName = getFileName(reportName);
        String csvContent = generateCSV(headerName, objects);
        return ReportFileDto.builder().name(fileName).content(csvContent.getBytes(StandardCharsets.UTF_8)).build();
    }

    /**
     * Constructs the file name for the CSV file based on the report name and merchant ID.
     *
     * @param reportName - Name of the report
     * @return - Generated file name
     */
    private static String getFileName(String reportName) {
        return StringEscapeUtils.escapeJava(reportName + "_" + getCurrentTimeSting() + ".csv");
    }

    /**
     * Generates the CSV content as a string.
     *
     * @param headers - List of headers for the CSV
     * @param objects - List of data rows for the CSV
     * @return - CSV content as a string
     */
    private static String generateCSV(List<String> headers, List<List<Object>> objects) {
        StringBuilder csvContent = new StringBuilder();
        csvContent.append(String.join(",", headers)).append("\n");
        for (List<Object> rowData : objects) {
            String row = rowData.stream()
                    .map(data -> ObjectUtils.isNotEmpty(data) ? data.toString() : StringUtils.EMPTY)
                    .collect(Collectors.joining(","));
            csvContent.append(row).append("\n");
        }
        return csvContent.toString();
    }

}
