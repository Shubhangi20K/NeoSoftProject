package com.epay.operations.dao;

import com.epay.operations.dto.MerchantPayoutDto;
import com.epay.operations.repository.MerchantPayoutRepository;
import com.epay.operations.repository.jdbc.MerchantPayoutJdbcRepository;
import com.epay.operations.util.DateTimeUtils;
import com.epay.operations.util.enums.PayoutStatus;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Class Name:MerchantPayoutDao
 * *
 * Description:
 * *
 * Author:Akshaya Sahasranamam
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
@Component
@RequiredArgsConstructor
public class MerchantPayoutDao {

    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());

    private final MerchantPayoutJdbcRepository merchantPayoutJdbcRepository;
    private final MerchantPayoutRepository merchantPayoutRepository;

    public Map<String, UUID> save(List<MerchantPayoutDto> merchantPayoutDtoList) {
        log.info("Saving Merchant Account Payout Details");
        return merchantPayoutJdbcRepository.save(merchantPayoutDtoList);
    }

    public void updateRefundAdjusted(UUID merchantPayoutId) {
        log.info("Received updateRefundAdjusted for merchantPayoutId {}", merchantPayoutId);
        merchantPayoutJdbcRepository.updateRefundAdjusted(merchantPayoutId);
    }

    public List<UUID> getAllMerchantPayoutForReport() {
        return merchantPayoutRepository.findByRefundedAdjustTrueAndPayoutStatus(PayoutStatus.READY_FOR_PAYOUT);
    }

    public void updateMerchantPayoutsByPayoutInfoId(List<UUID> merchantPayoutIds, UUID payoutInfoId) {
        merchantPayoutRepository.updateMerchantPayoutsByPayoutInfoId(merchantPayoutIds, payoutInfoId, DateTimeUtils.getCurrentTime());
    }
}
