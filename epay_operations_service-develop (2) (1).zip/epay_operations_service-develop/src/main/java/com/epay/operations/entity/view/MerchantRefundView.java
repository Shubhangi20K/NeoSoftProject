package com.epay.operations.entity.view;


import com.epay.operations.util.enums.SettlementStatus;
import com.epay.operations.util.enums.TransactionRefundStatus;
import jakarta.persistence.*;
import lombok.Data;

import java.math.BigDecimal;
import java.util.UUID;

@Data
@Entity
@Table(name = "MERCHANT_REFUND_VIEW")
public class MerchantRefundView {

    @Id
    private String arrnNum;

    @Column(name = "MERCHANT_ID")
    private String mId;

    private String atrnNum;

    private String accountId;

    private BigDecimal refundAmount;

    @Enumerated(EnumType.STRING)
    private SettlementStatus settlementStatus;

    @Enumerated(EnumType.STRING)
    private TransactionRefundStatus refundStatus;

    @Column(columnDefinition = "RAW(16)")
    private UUID mpId;

    private String refundAdjusted;
}
