package com.epay.operations.util.parser;

import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.experimental.UtilityClass;
import org.apache.poi.ss.usermodel.*;

import java.io.InputStream;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;

/**
 * Class Name: ExcelParser
 * *
 * Description:
 * *
 * Author:@V10000025(Sagar Rathod)
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@UtilityClass
public class ExcelParser {

    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(ExcelParser.class);

    /**
     * Handles parsing TXT, XLS, and XLSX files.
     *
     * @param fileKey - Path to file on S3
     * @return List<String [ ]>
     */
    public List<String[]> parseFile(InputStream inputStream, String fileKey) {
        logger.info("Starting Parsing Excel File: {}", fileKey);
        DataFormatter dataFormatter = new DataFormatter();
        try (Workbook workbook = WorkbookFactory.create(inputStream)) {
            Sheet sheet = workbook.getSheetAt(0);
            List<String[]> rows = new LinkedList<>();
            for (Row row : sheet) {
                List<String> cellValues = new LinkedList<>();
                logger.info("Converting the different cell value type into string: {}", fileKey);
                for (Cell cell : row) {
                    cellValues.add(dataFormatter.formatCellValue(cell));
                }
                rows.add(cellValues.toArray(new String[0]));
            }
            logger.info("Parsing Excel file completed: {}", fileKey);
            return rows;
        } catch (Exception e) {
            logger.error("Parsing Excel file failed for fileKey: {}", fileKey, e);
        }
        return Collections.emptyList();
    }
}
