package com.epay.operations.scheduler;

import com.epay.operations.service.DataSyncService;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;
import org.slf4j.MDC;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.UUID;

import static com.epay.operations.util.OperationsConstant.*;

/**
 * Class Name: DataSyncScheduler
 * *
 * Description: Scheduler to sync the data from view to table
 * *
 * Author:Saurabh Mahto(v1018841)
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Component
@RequiredArgsConstructor
public class DataSyncScheduler {
    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private final DataSyncService dataSyncService;

    @Scheduled(cron = "${scheduler.cron.expression.transaction.data.sync}")
    @SchedulerLock(name ="TransactionDataSync")
    public void syncTransactionData() {
        MDC.put(CORRELATION, String.valueOf(UUID.randomUUID()));
        MDC.put(SCENARIO, "TransactionDataSync");
        MDC.put(OPERATION, "syncTransactionData");
        long startTime = Instant.now().toEpochMilli();
        logger.info("TransactionDataSync Scheduler job- start time: {}", startTime);
        dataSyncService.syncTransactionData("TRANSACTION_DATA_SYNC");
    }

}
