package com.epay.operations.repository.spark;

import com.epay.operations.config.JdbcConfig;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SaveMode;
import org.apache.spark.sql.SparkSession;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.Properties;

/**
 * Class Name: SparkDataRepository
 * *
 * Description: This class handles all incoming requests related to invoice management and provides appropriate responses.
 * It interacts with the InvoiceService to process and retrieve invoice data as required by the client
 * *
 * Author: Bhoopendra Rajput
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Service
@RequiredArgsConstructor
public class SparkDataRepository {

    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());

    private final SparkSession sparkSession;
    private final JdbcConfig jdbcConfig;
    private final JdbcTemplate jdbcTemplate;

    @Value("${spring.datasource.url}")
    private String jdbcUrl;

    @Value("${spring.datasource.username}")
    private String jdbcUserName;

    @Value("${spring.datasource.password}")
    private String jdbcPassword;

    @Value("${spring.datasource.driver-class-name}")
    private String jdbcDriver;

    /**
     * This method is used to read data from jdbc by query.
     *
     * @param query String.
     * @return dataset.
     */
    public Dataset<Row> readJdbcQuery(String query) {
        try {
            return sparkSession.read()
                    .option("header", true)
                    .option("inferSchema", true)
                    .jdbc(jdbcConfig.getJdbcUrl(), query, jdbcConfig.getJdbcProperties());
        } catch (Exception ex) {
            logger.error("Error while reading jdbc query : {}", query, ex);
            throw new RuntimeException(ex.getMessage());
        }
    }

    /**
     * This method is used to read data from jdbc by query and filter.
     *
     * @param query table name.
     * @return dataset.
     */
    public Dataset<Row> readFromDBWithFilter(String query) {

        return sparkSession.read()
                .format("jdbc")
                .option("url", jdbcConfig.getJdbcUrl())
                .option("driver", jdbcDriver)
                .option("dbtable", query)
                .option("user", jdbcUserName)
                .option("password", jdbcPassword)
                .load();
    }

    /**
     * This method is used to write data into recon status stage table.
     *
     * @param dataset   dataset
     * @param tableName table name.
     */
    public void writeToStagingTable(Dataset<Row> dataset, String tableName) {
        logger.info("Inserting into recon status stage.");
        Properties connectionProperties = new Properties();
        connectionProperties.put("user", jdbcUserName);
        connectionProperties.put("password", jdbcPassword);
        connectionProperties.put("driver", jdbcDriver);

        dataset.write()
                .mode(SaveMode.Append)
                .jdbc(jdbcUrl, tableName, connectionProperties);
        logger.info("Insertion completed.");
    }

    /**
     * This method is used to update recon status from stage table.
     */
    public void updateReconStatusFromStage() {
        String mergeSql = """
                    MERGE INTO RECON_FILE_DTLS tgt
                    USING SPARK_RECON_STATUS_STAGE_OTHERS src
                    ON (tgt.RFD_ID = src.RFD_ID)
                    WHEN MATCHED THEN
                      UPDATE SET tgt.RECON_STATUS = src.RECON_STATUS
                """;

        jdbcTemplate.update(mergeSql);
    }

    /**
     * This method is used to write recon status and settlement status on stage
     */
    public void updateReconStatusAndSettlementStatusFromStage() {
        String mergeMatched = """
                    MERGE INTO RECON_FILE_DTLS tgt
                    USING SPARK_RECON_STATUS_STAGE_MATCHED src
                    ON (tgt.RFD_ID = src.RFD_ID)
                    WHEN MATCHED THEN
                      UPDATE SET tgt.RECON_STATUS = src.RECON_STATUS,
                                 tgt.SETTLEMENT_STATUS = src.SETTLEMENT_STATUS
                """;
        jdbcTemplate.update(mergeMatched);
    }

    /**
     * This method deletes data from RECON_STATUS_STAGE table by rfId.
     *
     * @param rfId the identifier to delete records by
     */
    public void clearStageTableByRfId(String rfId) {
        jdbcTemplate.update("DELETE FROM SPARK_RECON_STATUS_STAGE_MATCHED WHERE RF_ID = ?", rfId);
        jdbcTemplate.update("DELETE FROM SPARK_RECON_STATUS_STAGE_OTHERS WHERE RF_ID = ?", rfId);
    }

}
