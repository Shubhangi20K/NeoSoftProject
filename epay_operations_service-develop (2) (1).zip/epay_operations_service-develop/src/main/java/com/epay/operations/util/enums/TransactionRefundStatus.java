package com.epay.operations.util.enums;

import com.epay.operations.exception.OpsException;

import java.text.MessageFormat;
import java.util.Arrays;

import static com.epay.operations.util.ErrorConstant.INVALID_ERROR_CODE_NO_REASON;
import static com.epay.operations.util.ErrorConstant.INVALID_ERROR_MESSAGE;
import static com.epay.operations.util.OperationsConstant.TRANSACTION_REFUND_STATUS;


/**
 * Copyright (c) [2024] [State Bank of India]
 * All rights reserved.
 * <p>
 * Author:NIRMAL GURJAR
 * <p>
 * Version:1.0
 */
public enum TransactionRefundStatus {

    FULL_REFUND_BOOKED, PARTIAL_REFUND_BOOKED, CANCELLATION_BOOKED, REFUND_BOOKED;

    public static TransactionRefundStatus getTransactionRefundStatus(String transactionRefundStatus) {
        return Arrays.stream(values()).filter(p -> p.name().equalsIgnoreCase(transactionRefundStatus)).findFirst().orElseThrow(() -> new OpsException(INVALID_ERROR_CODE_NO_REASON,  MessageFormat.format(INVALID_ERROR_MESSAGE, TRANSACTION_REFUND_STATUS)));
    }
}
