package com.epay.operations.service;

import com.epay.operations.config.OpsConfig;
import com.epay.operations.dao.ReconProcessDao;
import com.epay.operations.util.enums.ReconStatus;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.UUID;

import static com.epay.operations.util.OperationsConstant.SPARK;

@Service
@RequiredArgsConstructor
public class ReconProcessingService {

    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private final SparkReconProcessingService sparkReconProcessingService;
    private final JavaReconciliationService javaReconciliationService;
    private final OpsConfig opsConfig;
    private final ReconProcessDao reconProcessDao;

    public void performReconciliation(UUID rfId) {
        long startTime = Instant.now().toEpochMilli();
        logger.info("Recon process job of file {} - start time: {}", rfId, startTime);
        try {
            logger.info("Step-0: Updating Recon Status for rfId: {}", rfId, "and Start Recon Processing.");
            reconProcessDao.updateReconStatusById(rfId, ReconStatus.IN_PROCESS);
            if (SPARK.equalsIgnoreCase(opsConfig.getReconProcessRunnerMode())) {
                logger.info("Running Recon process by SPARK");
                sparkReconProcessingService.reconProcessing(rfId);
            } else {
                logger.info("Running Recon process by JAVA");
                javaReconciliationService.reconProcessing(rfId);
            }
        } catch (Exception ex) {
            logger.error("Error during recon process for rfId {}: {}", rfId, ex.getMessage(), ex);
            reconProcessDao.updateReconStatusById(rfId, ReconStatus.FAIL);
        }
        logger.info("Recon process job of file {} - total execution time: {}", rfId, Instant.now().toEpochMilli() - startTime);
    }
}
