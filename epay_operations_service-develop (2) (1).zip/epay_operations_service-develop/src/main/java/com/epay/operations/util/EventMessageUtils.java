package com.epay.operations.util;

import com.epay.operations.entity.event.audit.EventErrorLog;
import com.epay.operations.entity.event.audit.EventReceivedLog;
import com.epay.operations.entity.event.audit.EventSendLog;
import com.epay.operations.util.enums.InterfaceType;
import lombok.experimental.UtilityClass;
import org.apache.kafka.clients.consumer.ConsumerRecord;

@UtilityClass
public class EventMessageUtils {


    public static EventReceivedLog buildEventReceivedLog(InterfaceType interfaceType, ConsumerRecord<String, String> consumerRecord) {
        return EventReceivedLog.builder().interfaceType(interfaceType).topic(consumerRecord.topic()).routingKey(consumerRecord.key()).message(consumerRecord.value()).build();
    }

    public static EventSendLog buildEventSendLog(InterfaceType interfaceType, String topic, String key, String message) {
        return EventSendLog.builder().interfaceType(interfaceType).topic(topic).routingKey(key).message(message).build();
    }

    public static EventErrorLog buildEventErrorLog(InterfaceType interfaceType, ConsumerRecord<String, String> consumerRecord, String message) {
        return EventErrorLog.builder().interfaceType(interfaceType).topic(consumerRecord.topic()).routingKey(consumerRecord.key()).message(message).build();
    }

    public static EventErrorLog buildEventErrorLog(InterfaceType interfaceType, String topic, String key, String message) {
        return EventErrorLog.builder().interfaceType(interfaceType).topic(topic).routingKey(key).message(message).build();
    }
}
