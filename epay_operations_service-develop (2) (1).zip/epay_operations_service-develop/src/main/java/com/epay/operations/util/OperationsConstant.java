package com.epay.operations.util;

import lombok.experimental.UtilityClass;

/**
 * Class Name: RnSConstant
 * *
 * Description: rns constants
 * *
 * Author:@V0000001(Shilpa Kothre)
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@UtilityClass
public class OperationsConstant {
    public static final String BEARER_AUTH = "BearerAuth";
    public static final String JWT = "JWT";
    //TODO: Will replace following 5 constants from auth-service constants.
    public static final String BEARER = "bearer";
    public static final String X_CORRELATION_ID = "X-Correlation-Id";
    public static final String CORRELATION = "correlation";
    public static final String SCENARIO = "scenario";
    public static final String OPERATION = "operation";
    public static final String COMMON_FILE_REGEX = "^(.+?)(\\.[^.]*$|$)";
    public static final String FILE_SUCCESS_STATUS = "published Successfully";
    public static final String FILE_FAIL_STATUS = "File Validation fails";
    public static final String IN_FOLDER = "IN";
    public static final String OUT_FOLDER = "OUT";
    public static final long FILE_MAX_LENGTH = 1024 * 1024 * 10L;
    public static final int FILE_NAME_MAX_LENGTH = 50;
    public static final String FILE_SUMMARY_ROUTING_KEY = "reconFileSummaryId";
    public static final String FILE_PROCESSING_ROUTING_REQUEST = "ReconFileProcessing";

    public static final String PAYOUT_KEY = "payout";
    public static final String REFUND_KEY = "refund";
    public static final String PAYOUT_TYPE = "payout";
    public static final String TRANSACTION_REFUND_STATUS = "Transaction Refund Status";
    public static final String SPARK = "SPARK";
    public static final String IS_REFUND_TO_BE_ADJUSTED = "Y";

    //Recon File Parsing Constant
    public static final String ATRN_PARSING_KEY = "atrn";
    public static final String PAYMENT_AMOUNT_PARSING_KEY = "paymentamount";
    public static final String BANK_REF_NUMBER_PARSING_KEY = "bankrefnumber";

    //Recon process
    public static final String RFD_ID = "RFD_ID";
    public static final String RF_ID = "RF_ID";
    public static final String ATRN_NUM = "ATRN_NUM";
    public static final String MATCHED_ATRN = "MATCHED_ATRN";
    public static final String DEBIT_AMT = "TXN_AMOUNT";
    public static final String PAYMENT_AMOUNT = "TXN_AMOUNT";
    public static final String EXACT_MATCH = "exactMatch";
    public static final String MATCH_RANK = "match_rank";

    public static final String RECON_STATUS = "RECON_STATUS";
    public static final String SETTLEMENT_STATUS = "SETTLEMENT_STATUS";
    public static final String RECON_STATUS_MATCHED = "MATCHED";
    public static final String RECON_STATUS_UNMATCHED = "UNMATCHED";
    public static final String RECON_STATUS_DUPLICATE = "DUPLICATE";
    public static final String SETTLEMENT_STATUS_SETTLED = "SETTLED";
    public static final String OTHERS = "OTHERS";

    public static final String FILE_SEPARATOR = "/";
    public static final String S3_FILE_NAME_FORMAT = "%s-%s";
    public static final String LOCAL = "Local";
    public static final String EXTERNAL_SERVICE = "External service";


    public static final String ATRN_MATCHED = "isAtrnMatched";
    public static final String ORE_ID = "ORE_ID";

    public static final int IN_CLAUSE_MAX_SIZE = 1000;
    public static final String ATRN_MISMATCH_WITH_TXN_DATA = "ATRN mismatch with txn data";
    public static final String AMOUNT_MISMATCH_WITH_TXN_ATRN = "Amount mismatch with txn ATRN";
    public static final String DUPLICATE_ATRN = "Duplicate ATRN";
    public static final String FAIL = "FAIL";
}