package com.epay.operations.entity;

import com.epay.operations.util.enums.PayoutStatus;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;
import java.util.UUID;

/**
 * Class Name:MerchantPayout
 * *
 * Description: Entity class for MerchantPayout
 * *
 * Author: Akshaya Sahasranamam
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@Entity
@Table(name = "MERCHANT_PAYOUT")
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
public class MerchantPayout extends AuditEntityByDate {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(columnDefinition = "RAW(16)")
    private UUID mpId;

    @Column(name = "PI_ID", columnDefinition = "RAW(16)")
    private UUID payoutInfoId;

    @Column(name = "MERCHANT_ID")
    private String mId;
    @Column(name = "TXN_AMT")
    private BigDecimal transactionAmount;
    private BigDecimal refundedAmount;
    private String bankId;
    private String accountNumber;
    @Enumerated(EnumType.STRING)
    private PayoutStatus payoutStatus;
    private boolean refundAdjusted;
    private String accountId;

}
