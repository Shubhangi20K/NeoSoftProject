package com.epay.operations.util.enums;

import com.epay.operations.exception.OpsException;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.text.MessageFormat;
import java.util.Arrays;

import static com.epay.operations.util.ErrorConstant.INVALID_ERROR_CODE_NO_REASON;
import static com.epay.operations.util.ErrorConstant.INVALID_ERROR_MESSAGE_NO_REASON;

/**
 * Enum Name: ReconFileType
 * *
 * Description: Scheduler to ingested sftp file
 * *
 * Author:@V0000001(Shilpa Kothre)
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */

@Getter
@AllArgsConstructor
public enum ReconFileType {
    CSV("csv"),
    TXT("txt"),
    XLS("xls"),
    XLSX("xlsx") ;

    private final String label;

    public static ReconFileType getFileType(String fileType) {
        return Arrays.stream(values()).filter(p -> p.name().equalsIgnoreCase(fileType)).findFirst().orElseThrow(() -> new OpsException(INVALID_ERROR_CODE_NO_REASON, MessageFormat.format(INVALID_ERROR_MESSAGE_NO_REASON, "fileType", fileType)));
    }
}
