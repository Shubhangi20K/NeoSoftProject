package com.epay.operations.entity.query.result;

import java.math.BigDecimal;
import java.sql.Clob;

/**
 * Class Name:ReconMatchRecordsDto
 * *
 * Description: Dto class
 * *
 * Author: Akshaya Sahasranamam
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */

public interface ReconMatchedTransaction {

    byte[] getRfId();

    byte[] getRfdId();

    String getAtrn();

    BigDecimal getTxnAmount();

    String getMId();

    Clob getMultiAccount();

    BigDecimal getTransactionFee();

}