package com.epay.operations.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

/**
 * Class Name: ErrorDto
 * Description: This class represents a standardized error response object that is used across the application
 * for all failed responses. It includes properties for error code and error message, which can be returned
 * in the response body when an error occurs. The class is annotated with `@Data` to generate getter, setter,
 * equals, hashCode, and toString methods, `@Builder` to allow easy construction of instances, and
 * `@JsonInclude` to exclude null values from the JSON representation.
 * Author: Bhoopendra Rajput
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * Version: 1.0
 */
@Data
@Builder
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ErrorDto {
    private String errorCode;
    private String errorMessage;
}