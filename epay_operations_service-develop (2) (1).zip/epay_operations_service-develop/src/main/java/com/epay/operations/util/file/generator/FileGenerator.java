package com.epay.operations.util.file.generator;


import com.epay.operations.dto.ReportFileDto;
import com.epay.operations.util.enums.ReconFileType;
import com.epay.operations.util.enums.Report;
import com.epay.operations.util.file.model.CSVFileModel;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

/**
 * Class Name: FileGenerator
 * *
 * Description: The FileGenerator class is responsible for generating files in different formats (CSV)
 * based on the provided report and data. It can either generate the file for local saving
 * or initiate a download for the user via HTTP response.
 * *
 * Author: Gireesh M
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */

@Component
@RequiredArgsConstructor
public class FileGenerator {
    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());

    /**
     * This method generates a file in the requested format and returns it as a File object.
     * The file is generated based on the provided report data.
     *
     * @param reportFormat The format of the report (CSV, XLS, or PDF).
     * @param report       The report details containing the report name and template name.
     * @param fileModel    The file model containing the report data.
     * @return A File object representing the generated report.
     */
    public ReportFileDto generateFile(ReconFileType reportFormat, Report report, CSVFileModel fileModel) {
        logger.info("Generating file for report format: {}, report: {}", reportFormat, report.getName());
        return CSVGenerator.csvFileGenerator(report.getName(), fileModel.getHeaders(), fileModel.getFileData());

    }
}
