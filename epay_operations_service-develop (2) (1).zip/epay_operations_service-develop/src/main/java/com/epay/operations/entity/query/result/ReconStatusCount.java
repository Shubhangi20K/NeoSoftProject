package com.epay.operations.entity.query.result;

/**
 * Class Name: ReconStatusCountProjection
 * *
 * Description: This interface is used to map the recon status count.
 * *
 * Author:Gireesh M
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
public interface ReconStatusCount {
    Integer getDuplicateCount();
    Integer getMatchedCount();
    Integer getUnmatchedCount();
}
