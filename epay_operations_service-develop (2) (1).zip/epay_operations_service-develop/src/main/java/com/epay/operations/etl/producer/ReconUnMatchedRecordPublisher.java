package com.epay.operations.etl.producer;

import com.epay.operations.config.kafka.Topics;
import com.epay.operations.util.enums.InterfaceType;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Component;

import static com.epay.operations.util.EventMessageUtils.buildEventErrorLog;
import static com.epay.operations.util.EventMessageUtils.buildEventSendLog;
import static com.epay.operations.util.OperationsUtil.getKafkaRoutingKey;

/**
 * Class Name: ReconUnMatchedRecordPublisher<br>
 * Description: The parent producer for Recon service.<br>
 * Author:@V1018841(SAURABH MAHTO)<br>
 * Copyright (c) 2025 [State Bank of India]<br>
 * All rights reserved<br>
 * Version:1.0<br>
 */
@Component
@RequiredArgsConstructor
public class ReconUnMatchedRecordPublisher {

    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    private final KafkaMessagePublisher kafkaMessagePublisher;
    private final Topics topics;
    private final ApplicationEventPublisher publisher;

    /**
     * @param requestType          String
     * @param routingKey           String
     * @param unMatchedTransaction String
     */
    public void publish(String requestType, String routingKey, String unMatchedTransaction) {
        String kafkaRoutingKey = getKafkaRoutingKey(requestType, requestType, routingKey);
        try {
            log.debug("unMatchedTransaction for requestType : {}, routingKey : {} and value : {}", requestType, routingKey, unMatchedTransaction);
            kafkaMessagePublisher.publish(topics.getReconUnmatchedRecordTopic(), kafkaRoutingKey, unMatchedTransaction);
            publisher.publishEvent(buildEventSendLog(InterfaceType.OPS_RECON_RECORD_UNMATCHED_TOPIC, topics.getReconUnmatchedRecordTopic(), kafkaRoutingKey, unMatchedTransaction));
            log.debug("Transaction UnMatch Record has been published");
        } catch (Exception e) {
            publisher.publishEvent(buildEventErrorLog(InterfaceType.OPS_RECON_RECORD_UNMATCHED_TOPIC, topics.getReconUnmatchedRecordTopic(), kafkaRoutingKey, e.getMessage()));
            log.error("Error in Transaction unmatchedTransaction {} publish", unMatchedTransaction, e.getMessage());
        }
    }
}
