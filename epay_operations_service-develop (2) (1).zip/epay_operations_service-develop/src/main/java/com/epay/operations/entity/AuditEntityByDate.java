package com.epay.operations.entity;

import jakarta.persistence.EntityListeners;
import jakarta.persistence.MappedSuperclass;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.experimental.SuperBuilder;
import org.hibernate.envers.Audited;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.io.Serializable;

/**
 * Class Name: AuditEntityByDate
 * <p>
 * Description:
 * This class provides a base implementation for auditing entities based on date information.
 * It automatically tracks the creation and last modification timestamps of an entity.
 * <p>
 * Author: V1018344
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved.
 * <p>
 * Version: 1.0
 */

@Getter
@Setter
@MappedSuperclass
@SuperBuilder
@Audited
@AllArgsConstructor
@NoArgsConstructor
@EntityListeners(AuditingEntityListener.class)
public class AuditEntityByDate implements Serializable {

    @CreatedDate
    private Long createdDate;

    @LastModifiedDate
    private Long updatedDate;

}
