package com.epay.operations.dao;

import com.epay.operations.config.OpsConfig;
import com.epay.operations.dto.ReconFileDetailsDto;
import com.epay.operations.entity.ReconFileDetails;
import com.epay.operations.entity.query.result.ReconMatchedTransaction;
import com.epay.operations.entity.query.result.ReconStatusCount;
import com.epay.operations.entity.view.MerchantTransaction;
import com.epay.operations.mapper.ReconFileDetailsMapper;
import com.epay.operations.repository.MerchantTransactionRepository;
import com.epay.operations.repository.ReconFileDtlsRepository;
import com.epay.operations.repository.jdbc.ReconDataJdbcRepository;
import com.epay.operations.util.DateTimeUtils;
import com.epay.operations.util.enums.PayoutStatus;
import com.epay.operations.util.enums.ReconStatus;
import com.epay.operations.util.enums.SettlementStatus;
import com.epay.operations.util.query.JdbcQuery;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

import static com.epay.operations.util.OperationsConstant.IN_CLAUSE_MAX_SIZE;

/**
 * Class Name:ReconFileDetailsDao
 * *
 * Description:
 * *
 * Author:NIRMAL GURJAR
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
@Component
@RequiredArgsConstructor
public class ReconFileDetailsDao {


    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    private final ReconFileDtlsRepository reconFileDtlsRepository;
    private final ReconFileDetailsMapper reconFileDetailsMapper;
    private final ReconDataJdbcRepository reconDataJdbcRepository;
    private final MerchantTransactionRepository merchantTransactionRepository;
    private final OpsConfig opsConfig;
    private final NamedParameterJdbcTemplate jdbcTemplate;

    public void save(List<ReconFileDetailsDto> reconFileDetailsDtoList) {
        List<ReconFileDetails> reconFileDetailsList = reconFileDetailsMapper.mapToEntityList(reconFileDetailsDtoList);
        mapMerchantIdWithAtrn(reconFileDetailsList);
        for (int i = 0; i < reconFileDetailsList.size(); i += opsConfig.getJdbcInsertBatchSize()) {
            int end = Math.min(i + opsConfig.getJdbcInsertBatchSize(), reconFileDetailsList.size());
            reconDataJdbcRepository.saveListOfReconFileDtls(reconFileDetailsList.subList(i, end));
        }
    }

    public List<ReconMatchedTransaction> findByReconSettlementPayoutStatusAndFileId(UUID rfId, ReconStatus reconStatus, SettlementStatus settlementStatus, PayoutStatus payoutStatus) {
        return reconFileDtlsRepository.findByReconSettlementPayoutStatusAndFileId(rfId, reconStatus.name(), settlementStatus.name(), payoutStatus.name());
    }

    public int getSettledCount(UUID rfId) {
        log.info("Fetch Settled Count From Recon File Details for rfId:{} ", rfId);
        return reconFileDtlsRepository.countSettledTransaction(rfId);
    }

    public List<ReconFileDetailsDto> getAllReconFileData(UUID rfId) {
        return reconFileDetailsMapper.mapToDtoList(reconFileDtlsRepository.findByRfId(rfId));
    }

    public ReconStatusCount getReconStatusCount(UUID rfdId) {
        return reconFileDtlsRepository.findReconStatusCountByRfId(rfdId);
    }

    public List<ReconFileDetailsDto> getReconFileDataByRfsIdAndReconStatus(UUID rfsId, ReconStatus reconStatus) {
        return reconFileDetailsMapper.mapToDtoList(reconFileDtlsRepository.findByRfIdAndReconStatus(rfsId, reconStatus));
    }

    @Transactional
    private void mapMerchantIdWithAtrn(List<ReconFileDetails> reconFileDetailsList) {
        log.info("mapping mId with atrn");
        List<String> atrns = reconFileDetailsList.stream().map(ReconFileDetails::getAtrnNum).toList();
        List<MerchantTransaction> merchantOrderPayments = new ArrayList<>();
        for (int i = 0; i < atrns.size(); i += IN_CLAUSE_MAX_SIZE) {
            int end = Math.min(i + IN_CLAUSE_MAX_SIZE, atrns.size());
            merchantOrderPayments.addAll(merchantTransactionRepository.findByAtrnNumIn(atrns.subList(i, end)));
        }
        Map<String, String> mIds = merchantOrderPayments.stream().collect(Collectors.toMap(MerchantTransaction::getAtrnNum, MerchantTransaction::getMId, (a, b) -> b));
        reconFileDetailsList.forEach(reconFileDtls -> reconFileDtls.setMId(mIds.get(reconFileDtls.getAtrnNum())));
    }

    public void updatePayoutStatusInReconFileDetails(UUID piId) {
        log.info("Update the payout status in file details table against piId {}", piId);
        reconDataJdbcRepository.updatePayoutStatusInReconFileDetails(piId);
    }

    public void updateSettlementStatusAgainstRfId(SettlementStatus settlementStatus, UUID rfId) {
        log.info("Update the Settlement Status in file details for rfId: {} as status: {}", rfId, settlementStatus);
        reconFileDtlsRepository.updateSettlementStatusByRfId(settlementStatus, rfId, DateTimeUtils.getCurrentTime());
    }

    public int insertReconFileDetailsHistory(long retentionDaysMillis) {
        log.info("data inserting in ReconFileDetailsHistory.");
        MapSqlParameterSource param = new MapSqlParameterSource();
        param.addValue("thresholdDate", retentionDaysMillis);
        return jdbcTemplate.update(JdbcQuery.INSERT_RECON_FILE_DTLS_HISTORY, param);
    }

    public int deleteReconFileDetails(long retentionDaysMillis) {
        log.info("data deleting from ReconFileDetails.");
        MapSqlParameterSource param = new MapSqlParameterSource();
        param.addValue("thresholdDate", retentionDaysMillis);
        return jdbcTemplate.update(JdbcQuery.DELETE_RECON_FILE_DTLS, param);
    }

    public boolean checkFailReconStatusExits(UUID rfId){
      return reconFileDtlsRepository.existsByRfIdAndReconStatus(rfId, ReconStatus.FAIL);
    }
}
