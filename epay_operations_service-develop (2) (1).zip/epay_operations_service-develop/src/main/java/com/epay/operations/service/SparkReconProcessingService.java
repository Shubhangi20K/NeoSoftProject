package com.epay.operations.service;

import com.epay.operations.dao.ReconProcessDao;
import com.epay.operations.util.enums.Status;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.expressions.Window;
import org.apache.spark.sql.expressions.WindowSpec;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import static com.epay.operations.util.query.JdbcQuery.MERCHANT_TRANSACTION;
import static com.epay.operations.util.OperationsConstant.*;
import static org.apache.spark.sql.functions.*;

/**
 * Class Name: TransactionReconProcessingService<br/>
 * Description: This Service will compare and process the recon file details from the respective table data.<br/>
 * Author:Gireesh M<br/>
 * Copyright (c) 2025 [State Bank of India]<br/>
 * All rights reserved<br/>
 * Version:1.0<br/>
 */
@Service
@RequiredArgsConstructor
public class SparkReconProcessingService {
    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());

    private final ReconResultProcessorService reconResultProcessorService;
    private final ReconProcessDao reconProcessDao;

    /**
     * This method is used to process and find the matched, unmatched and duplicate data from recon file
     * with respect to transaction data.
     */
    public void reconProcessing(UUID rfId) {
        // Step-1: Fetch transaction data.
        logger.info("Step-1: Fetching transaction data from table: {}", MERCHANT_TRANSACTION);
        Dataset<Row> transactionDataset = reconProcessDao.readAndNormalizeTransaction(rfId);

        // Step-2: Fetch recon file details using rfId.
        logger.info("Step-2: Fetching recon file details for rfId: {}", rfId);
        Dataset<Row> reconFileDataset = reconProcessDao.readAndNormalizeRecon(rfId);

        // Step-3: Classify the data into matched, duplicate, and unmatched.
        logger.info("Step-3: Classifying recon data.");
        Map<String, Dataset<Row>> finalReconRecordsWithStatus = findMatchedUnmatchedAndDuplicateReconRecords(transactionDataset, reconFileDataset, rfId);

        // Step-4: Update Recon Status.
        logger.info("Step-4: Update Recon Status.");
        reconProcessDao.updateReconRecordsStatus(rfId, finalReconRecordsWithStatus);

        // Step-6 Publish process data into kafka
        logger.info("Step-5: Publish recon processed data into kafka.");
        reconResultProcessorService.publishReconProcessedData(rfId);

    }

    /**
     * This method is used to find the matched, unmatched and duplicate data.
     *
     * @param reconFileDataset   recon file dtls dataset.
     * @param transactionDataset transaction dataset.
     * @return Map of matched, unmatched and duplicate data set.
     */
    private Map<String, Dataset<Row>> findMatchedUnmatchedAndDuplicateReconRecords(Dataset<Row> transactionDataset, Dataset<Row> reconFileDataset, UUID reconFileId) {
        logger.info("Starting classification of recon data...");
        final String reconFieldFormat = "recon.%s";
        final String txnFieldFormat = "txn.%s";
        // Step 3.1: Apply aliasing
        Dataset<Row> recon = reconFileDataset.alias("recon");
        Dataset<Row> txn = transactionDataset.alias("txn");

        // Step 3.1.1: Apply row_number to tag first match per (ATRN_NUM, DEBIT_AMT, RFD_ID)
        logger.info("Step-3.1: Apply row_number to tag first match per (ATRN_NUM, DEBIT_AMT, RFD_ID)");
        WindowSpec matchWindow = Window.partitionBy(reconFieldFormat.formatted(ATRN_NUM), reconFieldFormat.formatted(DEBIT_AMT)).orderBy(reconFieldFormat.formatted(RFD_ID)); // can use any ordering

        // Step 3.2: Perform left_outer join on ATRN_NUM + DEBIT_AMT
        logger.info("Step-3.2: Performing join between recon and transaction data.");
        Dataset<Row> joined = recon.join(txn, col(reconFieldFormat.formatted(ATRN_NUM)).equalTo(col(txnFieldFormat.formatted(ATRN_NUM))).and(col(reconFieldFormat.formatted(DEBIT_AMT)).equalTo(col(txnFieldFormat.formatted(DEBIT_AMT)))), "left_outer").withColumn(EXACT_MATCH, when(col(txnFieldFormat.formatted(ATRN_NUM)).isNotNull(), lit(1)).otherwise(lit(0))).withColumn(MATCH_RANK, when(col(EXACT_MATCH).equalTo(1), row_number().over(matchWindow)));

        // Step 3.3: Find distinct matched ATRN_NUM
        logger.info("Step-3.3: Find distinct matched ATRN_NUM.");
        Dataset<Row> matchedAtrns = joined.filter(col(MATCH_RANK).equalTo(1)).select(col(reconFieldFormat.formatted(ATRN_NUM)).alias(MATCHED_ATRN)).distinct();

        // Step 3.4: Re-join matched ATRN_NUM to mark duplicates (same ATRN_NUM, different DEBIT_AMT)
        logger.info("Step-3.4: Re-join matched ATRN_NUM to mark duplicates");
        Dataset<Row> withMatchedFlag = joined.join(matchedAtrns, col(reconFieldFormat.formatted(ATRN_NUM)).equalTo(col(MATCHED_ATRN)), "left_outer").withColumn(ATRN_MATCHED, col(MATCHED_ATRN).isNotNull());

        // Step 3.5: Apply classification logic
        logger.info("Step-3.5: Applying classification logic to tag rows with status.");
        Dataset<Row> finalStatus = withMatchedFlag.withColumn(RECON_STATUS, when(col(EXACT_MATCH).equalTo(1).and(col(MATCH_RANK).equalTo(1)), lit(RECON_STATUS_MATCHED)).when(col(EXACT_MATCH).equalTo(1).and(col(MATCH_RANK).gt(1)), lit(RECON_STATUS_DUPLICATE)).when(col(EXACT_MATCH).equalTo(0).and(col(ATRN_MATCHED).equalTo(true)), lit(RECON_STATUS_DUPLICATE)).otherwise(lit(RECON_STATUS_UNMATCHED)));

        // Step 3.6: Filter Dataset for the matched,unmatched and duplicate Recon Data
        logger.info("Step-3.6: Filter Dataset for the matched,unmatched and duplicate Recon Data");
        Dataset<Row> matched = finalStatus
                .filter(col(RECON_STATUS).equalTo(RECON_STATUS_MATCHED))
                .withColumn(RECON_STATUS, lit(RECON_STATUS_MATCHED))
                .withColumn(SETTLEMENT_STATUS,
                        when(col(SETTLEMENT_STATUS).isNull()
                                        .or(col(SETTLEMENT_STATUS).equalTo(Status.PENDING.name())),
                                lit(SETTLEMENT_STATUS_SETTLED)))
                .withColumn(RF_ID, lit(String.valueOf(reconFileId)))
                .select(RFD_ID, RECON_STATUS, SETTLEMENT_STATUS, RF_ID);

        Dataset<Row> unmatchedOrDuplicate = finalStatus
                .filter(col(RECON_STATUS).isin(RECON_STATUS_UNMATCHED, RECON_STATUS_DUPLICATE))
                .withColumn(RF_ID, lit(String.valueOf(reconFileId)))
                .select(RFD_ID, RECON_STATUS, RF_ID);

        // Step 3.7: Return as Map data.
        Map<String, Dataset<Row>> result = new HashMap<>();
        result.put(RECON_STATUS_MATCHED, matched);
        result.put(OTHERS, unmatchedOrDuplicate);

        return result;
    }

}