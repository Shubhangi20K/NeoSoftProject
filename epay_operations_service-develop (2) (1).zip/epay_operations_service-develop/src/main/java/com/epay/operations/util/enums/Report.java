package com.epay.operations.util.enums;

import com.epay.operations.exception.OpsException;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

import java.text.MessageFormat;
import java.util.Arrays;

import static com.epay.operations.util.ErrorConstant.INVALID_ERROR_CODE_NO_REASON;
import static com.epay.operations.util.ErrorConstant.INVALID_ERROR_MESSAGE;


/**
 * Name: Report
 * Description: Represents different types of reports that can be generated (e.g., MerchantOrder, Settlements, etc.).
 * *
 * Author: Gireesh M
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Getter
@RequiredArgsConstructor
public enum Report {

    PAYOUT("PAYOUT", "report"),
    TRANSACTION_MIS("TRANSACTION_MIS","report"),
    SETTLEMENT_FILE("SETTLEMENT_FILE","report"),
    TRANSACTION_WISE_PAYOUT_MIS("TRANSACTION_WISE_PAYOUT_MIS","report"),
    TRANSACTION_WISE_REFUND_MIS("TRANSACTION_WISE_REFUND_MIS", "report"),
    MERCHANT_WISE_PAYOUT_MIS("MERCHANT_WISE_PAYOUT_MIS","report"),
    SBIEPAY_AGG_BANKSTMT_REPORT("SBIEPAY_AGG_BANKSTMT_REPORT", "report"),
    AAT_PAYOUT("AAT_PAYOUT","report"),
    NEFT_PAYOUT("NEFT_PAYOUT","report"),
    BAD_RECORD("BAD_RECORD","report"),
    FAILED_REPORT("FAILED_REPORT","report");


    private final String name;
    private final String templateName;


    /**
     * Returns the Report enum corresponding to the provided name (case-insensitive).
     *
     * @param name The name of the report.
     * @return Corresponding Report enum.
     */
    public static Report getName(String name) {
        return Arrays.stream(values()).filter(rt -> rt.name().equalsIgnoreCase(name)).findFirst().orElseThrow(() -> new OpsException(INVALID_ERROR_CODE_NO_REASON, MessageFormat.format(INVALID_ERROR_MESSAGE, "Report")));
    }

}