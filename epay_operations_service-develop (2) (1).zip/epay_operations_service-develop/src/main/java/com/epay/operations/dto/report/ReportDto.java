package com.epay.operations.dto.report;

import com.epay.operations.util.enums.Report;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;

import java.util.UUID;

/**
 * Class Name: ReportFiltersDto
 * *
 * Description: Dto Class
 * *
 * Author: Saurabh Mahto(V1018841)
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ReportDto {

    private Report reportType;
    private UUID rrId;
    private ReportFilterDto reportFilter;
}
