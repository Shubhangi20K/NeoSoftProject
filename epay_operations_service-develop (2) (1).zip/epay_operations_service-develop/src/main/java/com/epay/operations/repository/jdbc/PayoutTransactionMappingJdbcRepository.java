package com.epay.operations.repository.jdbc;

import com.epay.operations.dto.PayoutTransactionMappingDto;
import com.epay.operations.exception.OpsException;
import com.epay.operations.util.OperationsUtil;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.Arrays;
import java.util.List;
import java.util.UUID;

import static com.epay.operations.util.ErrorConstant.FAILED_TO_INSERT_ERROR_CODE;
import static com.epay.operations.util.ErrorConstant.FAILED_TO_INSERT_ERROR_MESSAGE;
import static com.epay.operations.util.query.PayoutProcessingJdbcQuery.INSERT_PAYOUT_TXN_MAPPING;

/**
 * Class Name:PayoutTransactionMappingJdbcRepository
 * *
 * Description:
 * *
 * Author:Akshaya Sahasranamam
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
@Repository
@RequiredArgsConstructor
public class PayoutTransactionMappingJdbcRepository {

    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    private final NamedParameterJdbcTemplate jdbcTemplate;

    public void savePayoutTransactionMapping(List<PayoutTransactionMappingDto> payoutTransactionMappingDtoList) {
        log.info("Saving Payout Txn Mapping for RfsId:{} ", payoutTransactionMappingDtoList.getFirst().getRfId());
        try {
            List<MapSqlParameterSource> paramsList = payoutTransactionMappingDtoList.stream()
                    .map(dto -> {
                        MapSqlParameterSource params = new MapSqlParameterSource();
                        params.addValue("PTM_ID", OperationsUtil.uuidToBytes(UUID.randomUUID()));
                        params.addValue("MP_ID", OperationsUtil.uuidToBytes(dto.getPayoutInfoId()));
                        params.addValue("RF_ID", OperationsUtil.uuidToBytes(dto.getRfId()));
                        params.addValue("ATRN_NUM", dto.getAtrnNum());
                        return params;
                    })
                    .toList();
            int[] updatedCount = jdbcTemplate.batchUpdate(INSERT_PAYOUT_TXN_MAPPING, paramsList.toArray(new MapSqlParameterSource[0]));
            log.info("Inserted {} records into Payout Txn Mapping", Arrays.stream(updatedCount).sum());

        } catch (Exception ex) {
            log.error("Error during bulk insert to Payout Txn Mapping ", ex.getMessage());
            throw new OpsException(FAILED_TO_INSERT_ERROR_CODE, FAILED_TO_INSERT_ERROR_MESSAGE);
        }
    }

}


