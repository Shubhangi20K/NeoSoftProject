package com.epay.operations.service;

import com.epay.operations.config.OpsConfig;
import com.epay.operations.dao.MerchantTransactionStatusDao;
import com.epay.operations.dao.PayoutScheduleDao;
import com.epay.operations.dao.ReconFileDao;
import com.epay.operations.dao.ReconFileDetailsDao;
import com.epay.operations.dto.PayoutSchedulerDto;
import com.epay.operations.etl.producer.PayoutPublisher;
import com.epay.operations.util.DateTimeUtils;
import com.epay.operations.util.enums.SettlementStatus;
import com.epay.operations.util.enums.Status;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

import static com.epay.operations.util.OperationsConstant.PAYOUT_TYPE;
import static com.epay.operations.util.enums.Status.*;

@Service
@AllArgsConstructor
public class PayoutInitiationService {

    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());

    private final PayoutScheduleDao payoutScheduleDao;
    private final MerchantTransactionStatusDao merchantTransactionStatusDao;
    private final ReconFileDao reconFileDao;
    private final PayoutPublisher payoutPublisher;
    private final OpsConfig opsConfig;
    private final ReconFileDetailsDao reconFileDetailsDao;

    /**
     * validate and  publish event to trigger payout process
     */
    public void isPayoutReadyForGeneration() {
        log.info("Validation for Payout Generation initiated");
        //Step1: fetch pending data to initiate payout process
        List<PayoutSchedulerDto> payoutSchedulerDTOs = payoutScheduleDao.getPayoutSchedulerByStatus(List.of(PENDING, PARTIAL));
        //Step2: validate and publish the eligible rfId
        checkAndInitiatePayoutProcessing(payoutSchedulerDTOs);
        log.info("Payout Generation initiation completed");
    }

    /**
     * Fetch Pending payout details and initiate the payout processing
     */
    private void checkAndInitiatePayoutProcessing(List<PayoutSchedulerDto> payoutSchedulerDTOs) {
        log.info("Check the pending/partial rfId List and initiate payout process");
        for (PayoutSchedulerDto data : payoutSchedulerDTOs) {
            long timeDiff = opsConfig.getInterval() - DateTimeUtils.getDiffInMinutes(data.getCreatedDate());
            log.info("Transaction creationDate : {} and timeDiff : {} with current time for rfId: {}", data.getCreatedDate(), timeDiff, data.getRfId());
            if (timeDiff > 0 && data.getTransactionMatchedCount() > 0) {
                if (isReadyForPayoutGeneration(data.getRfId())) {
                    updatePayoutSchedule(data, SUCCESS);
                    payoutPublisher.publish(PAYOUT_TYPE, String.valueOf(data.getRfId()), data.getRfId());
                }
            } else {
                updatePayoutSchedule(data, FAIL);
            }
        }
    }

    private void updatePayoutSchedule(PayoutSchedulerDto data, Status status) {
        data.setStatus(status);
        payoutScheduleDao.save(data);
        reconFileDao.updateSettlementStatus(data.getRfId(), SUCCESS.equals(status) ? SettlementStatus.SETTLED : SettlementStatus.FAIL);
        reconFileDetailsDao.updateSettlementStatusAgainstRfId(SUCCESS.equals(status) ? SettlementStatus.SETTLED : SettlementStatus.FAIL, data.getRfId());
    }

    private boolean isReadyForPayoutGeneration(UUID rfId) {
        int matchedCount = merchantTransactionStatusDao.countSettledTransaction(rfId);
        int toBeMatchedCount = reconFileDetailsDao.getSettledCount(rfId);
        log.info("Transaction currentMatchedCount : {} and toBeMatchedCount : {} for rfId: {}", matchedCount, toBeMatchedCount, rfId);
        return matchedCount == toBeMatchedCount;
    }

}
