package com.epay.operations.repository.jdbc;

import com.epay.operations.dto.ReconFileDetailsDto;
import com.epay.operations.entity.ReconFileDetails;
import com.epay.operations.util.DateTimeUtils;
import com.epay.operations.util.OperationsUtil;
import com.epay.operations.util.enums.PayoutStatus;
import com.epay.operations.util.enums.ReconStatus;
import com.epay.operations.util.enums.SettlementStatus;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

import static com.epay.operations.util.query.JdbcQuery.*;
import static com.epay.operations.util.query.PayoutProcessingJdbcQuery.UPDATE_PAYOUT_STATUS_IN_FILE_DETAILS_AGAINST_MID;
import static com.epay.operations.util.query.PayoutProcessingJdbcQuery.UPDATE_PAYOUT_STATUS_IN_RECON_FILE_DETAILS;

/**
 * Class Name:ReconDataDetailsRepository
 * *
 * Description:
 * *
 * Author:SAURABH_MAHTO(V1018841)
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
@Repository
@RequiredArgsConstructor
public class ReconDataJdbcRepository {

    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    private final NamedParameterJdbcTemplate jdbcTemplate;

    /**
     * This will update the ReconStatus
     *
     * @param status      String
     * @param reconFileDetailsList List of ReconFileDetailsDto
     */
    @Transactional
    public void updateReconStatus(List<ReconFileDetailsDto> reconFileDetailsList, ReconStatus status) {
        log.info("Updating {} status.", status);
        MapSqlParameterSource[] batchParams = new MapSqlParameterSource[reconFileDetailsList.size()];
        for (int reconFileIndex  = 0; reconFileIndex  < reconFileDetailsList.size(); reconFileIndex ++) {
            UUID rfdId = reconFileDetailsList.get(reconFileIndex ).getRfdId();
            String currentRemark = reconFileDetailsList.get(reconFileIndex ).getRemark();
            MapSqlParameterSource params = new MapSqlParameterSource();
            params.addValue("updatedDate", DateTimeUtils.getCurrentTime());
            params.addValue("status", status.name());
            params.addValue("remark", currentRemark);
            params.addValue("rfdId", rfdId.toString().replace("-", "").toUpperCase());
            params.addValue("settlementStatus", ReconStatus.MATCHED.equals(status) ? SettlementStatus.PENDING.name() : SettlementStatus.FAIL.name());
            params.addValue("payoutStatus", ReconStatus.MATCHED.equals(status) ? PayoutStatus.PENDING.name() : PayoutStatus.FAIL.name());
            batchParams[reconFileIndex ] = params;
        }
        jdbcTemplate.batchUpdate(UPDATE_RECON_STATUS, batchParams);
    }

    public void updatePayoutStatusOfReconData(UUID rfId, String mId, PayoutStatus status, String remark) {
        log.info("Updating payout status {} in File Details against rfId {} and mId {}", status, rfId, mId);
        MapSqlParameterSource param = new MapSqlParameterSource();
        param.addValue("MERCHANT_ID", mId);
        param.addValue("RF_ID", String.valueOf(rfId));
        param.addValue("PAYOUT_STATUS", status.name());
        param.addValue("REMARK", remark);
        jdbcTemplate.update(UPDATE_PAYOUT_STATUS_IN_FILE_DETAILS_AGAINST_MID, param);
    }

    @Transactional
    public void saveListOfReconFileDtls(List<ReconFileDetails> reconFileDetailsList) {
        List<MapSqlParameterSource> paramsList = reconFileDetailsList.stream()
                .map(dto -> {
                    MapSqlParameterSource params = new MapSqlParameterSource();
                    params.addValue("rfdId", OperationsUtil.uuidToBytes(UUID.randomUUID()));
                    params.addValue("rfId", OperationsUtil.uuidToBytes(dto.getRfId()));
                    params.addValue("atrnNum", dto.getAtrnNum());
                    params.addValue("mId", dto.getMId());
                    params.addValue("transactionAmount", dto.getTransactionAmount());
                    params.addValue("rowNumber", dto.getRowNumber());
                    params.addValue("bankRefNumber", dto.getBankRefNumber());
                    params.addValue("remark", dto.getRemark());
                    params.addValue("createdDate", DateTimeUtils.getCurrentTime());
                    return params;
                })
                .toList();
        jdbcTemplate.batchUpdate(INSERT_RECON_FILE_DTLS, paramsList.toArray(new MapSqlParameterSource[0]));
    }

    public void updatePayoutStatusInReconFileDetails(UUID piId) {
        log.info("Updating payout status in File Details against piId {}", piId);
        MapSqlParameterSource param = new MapSqlParameterSource();
        param.addValue("PI_ID", OperationsUtil.uuidToBytes(piId));
        jdbcTemplate.update(UPDATE_PAYOUT_STATUS_IN_RECON_FILE_DETAILS, param);
    }

}


