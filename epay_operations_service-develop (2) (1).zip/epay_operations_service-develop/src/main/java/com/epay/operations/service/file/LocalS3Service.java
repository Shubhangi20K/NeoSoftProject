package com.epay.operations.service.file;

import com.epay.operations.exception.OpsException;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import org.apache.commons.io.FileUtils;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

import java.io.*;

import static com.epay.operations.util.ErrorConstant.GENERIC_ERROR_CODE;
import static com.epay.operations.util.ErrorConstant.GENERIC_ERROR_MESSAGE;

/**
 * Class Name: LocalS3Service
 * Description: The LocalS3Service class provides functionalities to interact with local file storage for uploading, downloading, and listing files.
 * It supports uploading files as a File, byte array, or MultipartFile, and handles the S3 client operations like put, get, and list objects.
 * It also provides error handling, logging, and custom exception throwing in case of file storage operation failures.
 * Author: Bhoopendra Rajput
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * Version: 1.0
 */
@Service
@Profile("local")
public class LocalS3Service implements FileService {
    private static final String ROOT_DIR = "S3_Files";
    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());


    @Override
    public String uploadFile(String fileName, byte[] fileContent) {
        File file = new File(ROOT_DIR, fileName);
        try {
            FileUtils.writeByteArrayToFile(file, fileContent, false);
        } catch (IOException e) {
            log.error("Failed to read file from local storage: {} with error: {}", file.getAbsoluteFile(), e.getMessage());
            throw new OpsException(GENERIC_ERROR_CODE, GENERIC_ERROR_MESSAGE);
        }
        return file.getAbsolutePath();
    }

    @Override
    public InputStream readFile(String key) {
        try {
            return FileUtils.openInputStream(new File(key));
        } catch (IOException e) {
            log.error("Failed to read file from local storage: {} with error: {}", key, e.getMessage());
            throw new OpsException(GENERIC_ERROR_CODE, GENERIC_ERROR_MESSAGE);
        }
    }
}
