package com.epay.operations.repository;

import com.epay.operations.entity.view.MerchantRefundView;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MerchantRefundRepository extends JpaRepository<MerchantRefundView, String> {

    @Query("FROM MerchantRefundView WHERE refundStatus IN ('CANCELLATION_BOOKED','REFUND_BOOKED') AND settlementStatus = 'SETTLED' AND mpId IS NULL AND (refundAdjusted IS NULL OR refundAdjusted = 'N') AND mId = :mId")
    List<MerchantRefundView> findMerchantRefundByMId(String mId);
}
