package com.epay.operations.mapper;

import com.epay.operations.dto.PayoutInfoDto;
import com.epay.operations.entity.PayoutInfo;
import org.mapstruct.Mapper;

/**
 * Class Name: PayoutInfoMapper
 * *
 * Description: mapper Class
 * *
 * Author:Saurabh Mahto
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Mapper(componentModel = "spring")
public interface PayoutInfoMapper {

    PayoutInfo mapToEntity(PayoutInfoDto payoutInfoDto);

    PayoutInfoDto mapToDto(PayoutInfo payoutInfo);
}
