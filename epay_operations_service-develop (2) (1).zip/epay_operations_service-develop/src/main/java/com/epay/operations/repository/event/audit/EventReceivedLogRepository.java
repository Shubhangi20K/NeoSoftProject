package com.epay.operations.repository.event.audit;

import com.epay.operations.entity.event.audit.EventReceivedLog;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface EventReceivedLogRepository extends JpaRepository<EventReceivedLog, UUID> {
}
