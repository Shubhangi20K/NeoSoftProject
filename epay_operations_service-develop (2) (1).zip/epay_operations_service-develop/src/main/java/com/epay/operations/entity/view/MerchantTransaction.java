package com.epay.operations.entity.view;

import jakarta.persistence.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;
@Data
@Entity
@Table(name = "MERCHANT_TXN")
@EqualsAndHashCode
public class MerchantTransaction {

    @Id
    private String atrnNum;

    @Column(name = "MERCHANT_ID")
    private String mId;

    @Column(name = "TXN_AMOUNT")
    private BigDecimal transactionAmount;

    @Lob
    private String multiAccount;
}
