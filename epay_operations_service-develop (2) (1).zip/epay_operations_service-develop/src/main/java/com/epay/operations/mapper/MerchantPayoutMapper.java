package com.epay.operations.mapper;

import org.mapstruct.Mapper;

/**
 * Class Name: MerchantAccountPayoutMapper
 * *
 * Description: mapper Class
 * *
 * Author:Gireesh M
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Mapper(componentModel = "spring")
public interface MerchantPayoutMapper {


}
