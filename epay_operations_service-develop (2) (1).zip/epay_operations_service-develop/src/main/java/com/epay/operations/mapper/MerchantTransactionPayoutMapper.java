package com.epay.operations.mapper;

import com.epay.operations.dto.MerchantTransactionPayoutDto;
import com.epay.operations.entity.MerchantTransactionPayout;
import org.mapstruct.Mapper;

/**
 * Class Name: MerchantTxnMultiAccPayoutMapper
 * *
 * Description: mapper Class
 * *
 * Author:Akshaya Sahasranamam
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Mapper(componentModel = "spring")
public interface MerchantTransactionPayoutMapper {

    MerchantTransactionPayout mapToEntity(MerchantTransactionPayoutDto merchantTxnMultiAccPayout);

}
