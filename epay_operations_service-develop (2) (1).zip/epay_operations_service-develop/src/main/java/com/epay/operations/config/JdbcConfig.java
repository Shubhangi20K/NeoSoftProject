package com.epay.operations.config;

import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Properties;

/**
 * Class Name: JdbcConfig<br>
 * Description: The JdbcConfig class reads the application configuration for Apache Spark JDBC
 * connection and creates it's required beans.<br>
 * Author: V1019620(Bhoopendra Rajput)<br>
 * Copyright (c) 2025 [State Bank of India] All rights reserved<br>
 * Version:1.0
 */
@Configuration
public class JdbcConfig {
  @Getter
  @Value("${spring.datasource.url}")
  private String jdbcUrl;

  @Value("${spring.datasource.username}")
  private String jdbcUserName;

  @Value("${spring.datasource.password}")
  private String jdbcPassword;

  @Value("${spring.datasource.driver-class-name}")
  private String jdbcDriver;

  @Bean
  public Properties getJdbcProperties() {
    Properties props = new Properties();
    props.put("user", jdbcUserName);
    props.put("password", jdbcPassword);
    props.put("driver", jdbcDriver);
    return props;
  }
}
