package com.epay.operations.etl.listener;

import com.epay.operations.service.PayoutService;
import com.epay.operations.util.enums.InterfaceType;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.MDC;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import java.util.UUID;

import static com.epay.operations.util.EventMessageUtils.buildEventErrorLog;
import static com.epay.operations.util.EventMessageUtils.buildEventReceivedLog;
import static com.epay.operations.util.OperationsConstant.*;

/**
 * Class Name: PayoutInitiateListener
 * Description: The implementation is for consume the payout initiation
 * Author: Akshaya Sahasranamam
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * Version:1.0
 */
@Component
@RequiredArgsConstructor
public class PayoutListener {

    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    private final PayoutService payoutService;
    private final ApplicationEventPublisher publisher;

    @KafkaListener(topics = "${spring.kafka.topic.payout}")
    public void initiatePayout(ConsumerRecord<String, String> consumerRecord) {
        log.info("Received Kafka message for initiatePayout for rfId: {}", consumerRecord.value());
        MDC.put(CORRELATION, String.valueOf(UUID.randomUUID()));
        MDC.put(SCENARIO, "PayoutService");
        MDC.put(OPERATION, "initiatePayout");
        try {
            publisher.publishEvent(buildEventReceivedLog(InterfaceType.OPS_PAYOUT_TOPIC, consumerRecord));
            payoutService.initiatePayout(UUID.fromString(consumerRecord.value()));
        } catch (Exception e) {
            publisher.publishEvent(buildEventErrorLog(InterfaceType.OPS_PAYOUT_TOPIC, consumerRecord, e.getMessage()));
            log.error("Error during initiatePayout kafka listening message[key:{} and value: {}], error: {}", consumerRecord.key(), consumerRecord.value(), e.getMessage());
        }
    }
}
