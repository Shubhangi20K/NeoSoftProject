package com.epay.operations.service;

import com.epay.operations.dao.FileConfigDao;
import com.epay.operations.dao.ReconFileDao;
import com.epay.operations.dto.ReconFileDto;
import com.epay.operations.dto.admin.FileConfigDto;
import com.epay.operations.etl.producer.ReconFileProcessingPublisher;
import com.epay.operations.exception.OpsException;
import com.epay.operations.service.file.FileService;
import com.epay.operations.service.sftp.SftpClientService;
import com.epay.operations.util.enums.ReconStatus;
import com.epay.operations.util.enums.SettlementStatus;
import com.epay.operations.util.enums.Status;
import com.epay.operations.util.file.FileUtil;
import com.epay.operations.validator.SftpReconFileValidator;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.InputStream;
import java.util.List;

import static com.epay.operations.util.DateTimeUtils.getCurrentTime;
import static com.epay.operations.util.OperationsConstant.*;
import static com.epay.operations.util.OperationsUtil.verifyAndUpdateDate;

/**
 * Class Name: SftpFileReaderService
 * *
 * Description: This Service will transfer file from sftp to s3 bucket.
 * *
 * Author:@V0000001(Shilpa Kothre)
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Service
@RequiredArgsConstructor
public class SftpFileReaderService {

    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());

    private final SftpReconFileValidator sftpReconFileValidator;
    private final SftpClientService sftpService;
    private final AcknowledgmentService acknowledgmentService;
    private final FileService fileService;
    private final FileConfigDao fileConfigDao;
    private final ReconFileDao reconFileDao;
    private final ReconFileProcessingPublisher reconFileSummaryPublisher;

    /**
     * This method will fetch all bank rns config from admin service or cache, and transfer the files.
     */
    public void readSftpReconFiles() {
        logger.info("Fetching all configuration from admin service and processing each file");
        fileConfigDao.loadAllFileConfig().forEach(this::readSftpReconFile);
    }

    private void readSftpReconFile(FileConfigDto fileConfigDto) {
        logger.info("Processing file of bankCode {}", fileConfigDto.getBankCode());

        String sftpPath = verifyAndUpdateDate(fileConfigDto.getSftpPath());
        logger.info("Processing file from  sftpPath {}", sftpPath);

        if (sftpService.isDirExists(sftpPath)) {
            fileConfigDto.setSftpPath(sftpPath);
            processSftpReconFile(fileConfigDto);
        } else {
            logger.info("Creating SFTP directory with path {}", sftpPath);
            sftpService.createDir(sftpPath);
        }

    }

    /**
     * @param fileConfigDto FileConfigDto
     */
    private void processSftpReconFile(FileConfigDto fileConfigDto) {
        logger.info("Getting list of sftp files bank wise file from sftp folder path: {}", fileConfigDto.getSftpPath());
        List<String> files = sftpService.listFiles(fileConfigDto.getSftpPath());
        if (CollectionUtils.isNotEmpty(files)) {
            logger.info("No of files fetched : {}", files.size());
            for (String filePath : files) {
                String fileStatus = FILE_SUCCESS_STATUS;
                String checkSum = StringUtils.EMPTY;
                String s3Path = StringUtils.EMPTY;
                File file = new File(filePath);
                try (InputStream inputStream = sftpService.readFile(filePath)) {
                    logger.info("Validating file {}", file.getName());
                    sftpReconFileValidator.validateFile(fileConfigDto, file);
                    byte[] fileData = inputStream.readAllBytes();
                    logger.info("Calculating file {} checksum", file.getName());
                    checkSum = FileUtil.calculateChecksum(fileData);
                    if (StringUtils.isNotEmpty(checkSum)) {
                        sftpReconFileValidator.validateFileWithCheckSum(checkSum);
                    }
                    logger.info("Uploading file {} on S3 bucket", file.getName());
                    s3Path = fileService.uploadFile(file.getName(), fileData);
                    logger.info("File [{}] moved to S3 path {}.", file.getName(), s3Path);
                    ReconFileDto reconFileSummaryDto = reconFileDao.save(buildReconFileSummaryDto(fileConfigDto, file.getName(), checkSum, "File validated successfully", s3Path, Status.PENDING));
                    reconFileSummaryPublisher.publish(FILE_PROCESSING_ROUTING_REQUEST, String.valueOf(reconFileSummaryDto.getRfId()), String.valueOf(reconFileSummaryDto.getRfId()));
                } catch (OpsException e) {
                    fileStatus = FILE_FAIL_STATUS;
                    reconFileDao.save(buildReconFileSummaryDto(fileConfigDto, (file.getName().length() > FILE_NAME_MAX_LENGTH ? file.getName().substring(0, FILE_NAME_MAX_LENGTH) : file.getName()), checkSum, e.getErrorMessage(), s3Path, Status.FAIL));
                    logger.error("Error in processSftpReconFilesBankWise : {}", e.getErrorMessage());
                } catch (Exception e) {
                    fileStatus = Status.FAIL.name();
                    reconFileDao.save(buildReconFileSummaryDto(fileConfigDto, (file.getName().length() > FILE_NAME_MAX_LENGTH ? file.getName().substring(0, FILE_NAME_MAX_LENGTH) : file.getName()), checkSum, e.getMessage(), s3Path, Status.FAIL));
                    logger.error("Error in processSftpReconFilesBankWise : {}", e.getMessage());
                }
                acknowledgmentService.uploadAckFile(fileConfigDto.getSftpPath(), file.getName(), fileStatus);
                sftpService.removeFile(filePath);
            }
        } else {
            logger.info("No files found in sftp path : {}", fileConfigDto.getSftpPath());
        }
    }


    /**
     * @param fileName      String
     * @param s3Path        String
     * @param fileConfigDto FileConfigDto
     * @param checksum      String
     * @return ReconDataDto
     */
    private ReconFileDto buildReconFileSummaryDto(FileConfigDto fileConfigDto, String fileName, String checksum, String remark, String s3Path, Status parsingStatus) {
        return ReconFileDto.builder().configId(fileConfigDto.getConfigId()).bankCode(fileConfigDto.getBankCode()).fileName(fileName).fileChecksum(checksum).remark(remark).sftpPath(fileConfigDto.getSftpPath()).s3Path(s3Path).fileReceivedTime(getCurrentTime()).parsingStatus(parsingStatus).reconStatus(Status.FAIL.equals(parsingStatus) ? ReconStatus.FAIL : ReconStatus.PENDING).settlementStatus(Status.FAIL.equals(parsingStatus) ? SettlementStatus.FAIL : SettlementStatus.PENDING).build();
    }


}