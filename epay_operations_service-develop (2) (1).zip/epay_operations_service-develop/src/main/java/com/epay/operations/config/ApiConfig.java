package com.epay.operations.config;

import static com.epay.operations.util.OperationsUtil.isLocalProfile;

import com.epay.operations.externalservice.AdminServicesClient;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Class Name: ApiConfig
 * Description: The ApiConfig class reads the application configuration for all APIs and sets up the necessary
 * configurations to create all clients.
 * Author: Gireesh M
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * Version:1.0
 */
@Configuration
@RequiredArgsConstructor
@Getter
public class ApiConfig {

    @Value("${external.api.services.base.path.admin}")
    private String adminServicesBasePath;
    @Value("${security.cors.origin}")
    private String corsOrigin;
    @Value("${spring.profiles.active}")
    private String springProfile;

    /**
     * @return AdminServicesClient
     */
    @Bean
    public AdminServicesClient constructAdminServicesClient() {
        return new AdminServicesClient(adminServicesBasePath, corsOrigin, isLocalProfile(springProfile));
    }
}
