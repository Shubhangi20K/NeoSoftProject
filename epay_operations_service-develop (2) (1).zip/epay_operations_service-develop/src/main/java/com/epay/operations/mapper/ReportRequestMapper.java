package com.epay.operations.mapper;

import com.epay.operations.dto.report.ReportFilterDto;
import com.epay.operations.dto.report.ReportRequestDto;
import com.epay.operations.entity.ReportRequest;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

/**
 * Class Name: OpsReportRequestMapper
 * *
 * Description: mapper Class
 * *
 * Author:Saurabh Mahto
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Mapper(componentModel = "spring", imports = ObjectMapper.class)
public interface ReportRequestMapper {

    @Mapping(target = "reportFilter", source = "reportFilter", qualifiedByName = "serializeGenerateReport")
    ReportRequest mapToEntity(ReportRequestDto dto);

    @Mapping(target = "reportFilter", source = "reportFilter", qualifiedByName = "deserializeGenerateReport")
    ReportRequestDto mapToDto(ReportRequest reportRequest);

    @Named("serializeGenerateReport")
    default String serializeGenerateReport(ReportFilterDto reportFilterDto) {
        try {
            return new ObjectMapper().writeValueAsString(reportFilterDto);
        } catch (JsonProcessingException e) {
            return null;
        }
    }

    @Named("deserializeGenerateReport")
    default ReportFilterDto deserializeGenerateReport(String reportFilterStr) {
        try {
            return new ObjectMapper().readValue(reportFilterStr, ReportFilterDto.class);
        } catch (JsonProcessingException e) {
            return null;
        }
    }

}
