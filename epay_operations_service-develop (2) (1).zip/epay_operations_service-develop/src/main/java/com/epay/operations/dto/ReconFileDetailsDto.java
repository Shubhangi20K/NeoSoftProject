package com.epay.operations.dto;

import com.epay.operations.util.enums.PayoutStatus;
import com.epay.operations.util.enums.ReconStatus;
import com.epay.operations.util.enums.SettlementStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.UUID;

/**
 * Class Name: ReconDataDto
 * *
 * Description: Dto Class
 * *
 * Author:@V0000001(Shilpa Kothre)
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ReconFileDetailsDto {

    private UUID rfdId;
    private UUID rfId;
    private int rowNumber;
    private String mId;
    private String atrnNum;
    private BigDecimal transactionAmount;
    private String bankRefNumber;
    private ReconStatus reconStatus;
    private SettlementStatus settlementStatus;
    private PayoutStatus payoutStatus;
    private String remark;

}
