package com.epay.operations.dao;

import com.epay.operations.config.OpsConfig;
import com.epay.operations.dto.MerchantTransactionPayoutDto;
import com.epay.operations.entity.view.MerchantRefundView;
import com.epay.operations.repository.MerchantRefundRepository;
import com.epay.operations.repository.jdbc.MerchantTransactionPayoutJdbcRepository;
import com.epay.operations.util.query.JdbcQuery;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.jetbrains.annotations.NotNull;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Class Name:MerchantTransactionPayoutDao
 * *
 * Description:
 * *
 * Author:Akshaya Sahasranamam
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
@Component
@RequiredArgsConstructor
public class MerchantTransactionPayoutDao {

    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());

    private final MerchantTransactionPayoutJdbcRepository merchantTransactionRepository;
    private final MerchantRefundRepository merchantRefundRepository;
    private final OpsConfig opsConfig;
    private final NamedParameterJdbcTemplate jdbcTemplate;

    public void save(List<MerchantTransactionPayoutDto> merchantTxnPayoutDtoList) {
        log.info("Insert into Merchant Txn Payout");
        for (int i = 0; i < merchantTxnPayoutDtoList.size(); i += opsConfig.getJdbcInsertBatchSize()) {
            int end = Math.min(i + opsConfig.getJdbcInsertBatchSize(), merchantTxnPayoutDtoList.size());
            merchantTransactionRepository.save(merchantTxnPayoutDtoList.subList(i, end));
        }
    }

    public @NotNull List<MerchantRefundView> getMerchantRefundInfo(String mId) {
        return merchantRefundRepository.findMerchantRefundByMId(mId);
    }

    @Transactional
    public void flushMerchantTransactionPayout(long retentionDaysMillis) {
        log.info("Data insertion started in merchant txn payout history.");
        try {
            MapSqlParameterSource param = new MapSqlParameterSource();
            param.addValue("thresholdDate", retentionDaysMillis);
            int insertCount = jdbcTemplate.update(JdbcQuery.INSERT_MERCHANT_TXN_PAYOUT_HISTORY, param);
            log.info("Inserted into history: {}", insertCount);
            int deletedCount = jdbcTemplate.update(JdbcQuery.DELETE_MERCHANT_TXN_PAYOUT, param);
            log.info("Deleted from merchantTxnPayout: {}", deletedCount);
        } catch (Exception ex) {
            log.error("Error during Data flushing for MERCHANT_TXN_PAYOUT : {}", ex.getMessage());
            throw ex;
        }
    }

    public int insertMerchantTxnPayoutHistory(long retentionDaysMillis) {
        log.info("data inserting in MerchantTxnPayoutHistory.");
        MapSqlParameterSource param = new MapSqlParameterSource();
        param.addValue("thresholdDate", retentionDaysMillis);
        return jdbcTemplate.update(JdbcQuery.INSERT_MERCHANT_TXN_PAYOUT_HISTORY, param);
    }

    public int deleteMerchantTxnPayout(long retentionDaysMillis) {
        log.info("data deleting from ReconFileDetails.");
        MapSqlParameterSource param = new MapSqlParameterSource();
        param.addValue("thresholdDate", retentionDaysMillis);
        return jdbcTemplate.update(JdbcQuery.DELETE_MERCHANT_TXN_PAYOUT, param);
    }
}
