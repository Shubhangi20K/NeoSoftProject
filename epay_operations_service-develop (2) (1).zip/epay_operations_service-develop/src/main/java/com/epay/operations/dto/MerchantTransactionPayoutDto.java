package com.epay.operations.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.UUID;

/**
 * Class Name:MerchantTransactionPayoutDto
 * *
 * Description: Entity class for MerchantTransactionPayoutDto
 * *
 * Author: Akshaya Sahasranamam
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class MerchantTransactionPayoutDto {

    private UUID mtpId;
    private UUID rfId;
    private String mId;
    private BigDecimal transactionPayoutAmount;
    private String bankId;
    private String atrnNum;
    private String accountNumber;
    private long createdDate;
    private long updatedDate;
    private String accountId;
    private BigDecimal transactionFee;

}
