package com.epay.operations.exception;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

/**
 * Class Name: SftpClientException
 * *
 * Description: This class defines a custom runtime exception specific to the SFTP module of the project.
 * It extends the 'RuntimeException' class to provide custom exception handling for SFTP errors.
 * <p>
 * Author: Gireesh M
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Getter
@Setter
@RequiredArgsConstructor
public class SftpClientException extends RuntimeException {
    private final String errorCode;
    private final String errorMessage;
}
