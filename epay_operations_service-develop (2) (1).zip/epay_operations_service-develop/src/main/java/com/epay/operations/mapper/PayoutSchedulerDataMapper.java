package com.epay.operations.mapper;

import com.epay.operations.dto.PayoutSchedulerDto;
import com.epay.operations.entity.PayoutScheduler;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * Class Name: PayoutSchedulerDataMapper
 * *
 * Description: mapper Class
 * *
 * Author:Akshaya Sahasranamam
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Mapper(componentModel = "spring")
public interface PayoutSchedulerDataMapper {

    PayoutScheduler mapToEntity(PayoutSchedulerDto payoutSchedulerDataDto);

    List<PayoutSchedulerDto> mapToDtoList(List<PayoutScheduler> payoutData);

}
