package com.epay.operations.repository;


import com.epay.operations.entity.view.MerchantTransactionStatusView;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.UUID;

/**
 * Class Name:MerchantTransactionStatusRepository
 * *
 * Description: Repository interface for Merchant Order payment
 * *
 * Author: Akshaya Sahasranamam
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */

@Repository
public interface MerchantTransactionStatusRepository extends JpaRepository<MerchantTransactionStatusView, UUID> {

    @Query(value = """
            SELECT COUNT(*) AS settledCount
            FROM MERCHANT_ORDER_PAYMENT_SETTLEMENT_VIEW
            WHERE RF_ID = :rfId
            """, nativeQuery = true)
    int countSettledTransaction(@Param("rfId") UUID rfId);

}
