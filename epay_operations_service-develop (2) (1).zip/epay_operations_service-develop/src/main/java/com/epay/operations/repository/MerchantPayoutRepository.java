package com.epay.operations.repository;

import com.epay.operations.entity.MerchantPayout;
import com.epay.operations.util.enums.PayoutStatus;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface MerchantPayoutRepository extends JpaRepository<MerchantPayout, UUID> {

    @Query("SELECT m.mpId FROM MerchantPayout m WHERE m.refundAdjusted = true and m.payoutStatus = :payoutStatus")
    List<UUID> findByRefundedAdjustTrueAndPayoutStatus(@Param("payoutStatus") PayoutStatus payoutStatus);

    @Modifying
    @Transactional
    @Query("UPDATE MerchantPayout m SET m.payoutInfoId = :pIId, m.payoutStatus = 'SUCCESS', m.updatedDate = :updatedDate WHERE m.mpId IN :mpIdList")
    void updateMerchantPayoutsByPayoutInfoId(@Param("mpIdList") List<UUID> mpIdList, @Param("pIId") UUID payoutInfoId, @Param("updatedDate") Long updatedDate);
}
