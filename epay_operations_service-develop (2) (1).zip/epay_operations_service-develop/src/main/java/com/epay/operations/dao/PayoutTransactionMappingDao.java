package com.epay.operations.dao;

import com.epay.operations.config.OpsConfig;
import com.epay.operations.dto.PayoutTransactionMappingDto;
import com.epay.operations.repository.jdbc.PayoutTransactionMappingJdbcRepository;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Class Name:PayoutTransactionMappingDao
 * Description: To store the details of mapping between payout account wise and rfId
 * Author:Akshaya Sahasranamam
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
@Component
@RequiredArgsConstructor
public class PayoutTransactionMappingDao {

    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());

    private final PayoutTransactionMappingJdbcRepository payoutTransactionMappingJdbcRepository;
    private final OpsConfig opsConfig;

    public void savePayoutTransactionMapping(List<PayoutTransactionMappingDto> payoutTransactionMappingDtoList) {
        log.info("Saving payout mapping details");
        for (int i = 0; i < payoutTransactionMappingDtoList.size(); i += opsConfig.getJdbcInsertBatchSize()) {
            int end = Math.min(i + opsConfig.getJdbcInsertBatchSize(), payoutTransactionMappingDtoList.size());
            payoutTransactionMappingJdbcRepository.savePayoutTransactionMapping((payoutTransactionMappingDtoList.subList(i, end)));
        }
    }


}
