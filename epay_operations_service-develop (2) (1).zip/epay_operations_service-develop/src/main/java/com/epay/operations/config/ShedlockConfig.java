package com.epay.operations.config;

import javax.sql.DataSource;
import net.javacrumbs.shedlock.core.LockProvider;
import net.javacrumbs.shedlock.provider.jdbctemplate.JdbcTemplateLockProvider;
import net.javacrumbs.shedlock.spring.annotation.EnableSchedulerLock;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

/**
 * Class Name: ShedlockConfig<br>
 * Description: The ShedlockConfig class reads the application configuration for scheduler shedlock
 * and creates it's required beans.<br>
 * Author: V1019620(Bhoopendra Rajput)<br>
 * Copyright (c) 2025 [State Bank of India]<br>
 * All rights reserved<br>
 * Version:1.0
 */
@Configuration
@EnableSchedulerLock(defaultLockAtMostFor = "PT10M")
public class ShedlockConfig {
   
    /**
     * @param dataSource DataSource
     * @return LockProvider Shedlock
     */
    @Bean
    public LockProvider createShedLockProvider(DataSource dataSource) {
        return new JdbcTemplateLockProvider(JdbcTemplateLockProvider.Configuration.builder()
                .withJdbcTemplate(new JdbcTemplate(dataSource))
                .usingDbTime()
                .build());
    }
}