package com.epay.operations.repository;

import com.epay.operations.entity.PayoutInfo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.UUID;
/**
 * Class Name:PayoutInfoRepository
 * *
 * Description: Repository interface for Payout info
 * *
 * Author: Saurabh mahto(V1018841)
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
@Repository
public interface PayoutInfoRepository extends JpaRepository<PayoutInfo, UUID> {

}
