package com.epay.operations.util;

import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.experimental.UtilityClass;
import org.apache.commons.lang3.time.DateUtils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;

/**
 * Class Name:DateTimeUtils
 * *
 * Description: This class is used for time formatting
 * *
 * Author:V1014352
 * <p>
 * Copyright (c) 2024 [State Bank of india]
 * All right reserved
 * *
 * Version:1.0
 */
@UtilityClass
public final class DateTimeUtils {

    public static final String DDMMYY = "dd/MM/yyyy";
    public static final DateFormat FORMATTER_DD_MM_YYYY = new SimpleDateFormat(DDMMYY);
    public static final DateTimeFormatter DATE_TIME_FORMATTER_ALL = DateTimeFormatter.ofPattern("dd-MM-yyyy hh:mm:ss.nnn a");
    public static final String DD_MM_YYYY = "dd-MM-yyyy";
    public static final String HH_MM_SS = "hh-mm-ss";
    private static final LoggerUtility logger = LoggerFactoryUtility.getLogger(DateTimeUtils.class);

    /**
     * Checks whether the provided expiry time has passed.
     *
     * @param expiryTime The expiry time to check, in milliseconds.
     * @return `true` if the `expiryTime` is in the past, otherwise `false`.
     */
    public static boolean isPastDate(Long expiryTime) {
        logger.info("Checking if the expiry time {} has passed.", expiryTime);
        return expiryTime < getCurrentTime();
    }

    /**
     * Adds the specified number of minutes to the current system time and returns the resulting time in milliseconds.
     *
     * @param minute The number of minutes to add to the current time.
     * @return The resulting time in milliseconds after adding the specified number of minutes.
     */
    public static Long addMinutes(int minute) {
        logger.info("Adding {} minutes to the current time.", minute);
        return DateUtils.addMinutes(new Date(), minute).getTime();
    }

    /**
     * Retrieves end of the day millis i.e. millis at time 23:59:59 for current date.
     */
    public static long endOfDayMillis() {
        logger.info("Fetching end of day millis");
        return LocalDate.now().atTime(LocalTime.MAX).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
    }

    /**
     * Calculates the number of days between two time millis
     */
    public static int calculateDaysBetween(long millis1, long millis2) {
        logger.info("Calculating days between millis");
        return (int) (Math.abs(millis1 - millis2) / (1000 * 60 * 60 * 24));
    }

    /**
     * Converts the given milliseconds into a formatted date string.
     *
     * @param milliSeconds the time in milliseconds
     * @param format       the date format to be used
     * @return the formatted date as a string
     */
    public static String getDate(Long milliSeconds, DateFormat format) {
        logger.debug("Converting milliseconds {} to formatted date string", milliSeconds);
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(milliSeconds);
        return format.format(calendar.getTime());
    }

    public static long convertToMillis(String dateStr, String dateFormat) {
        try {
            return new SimpleDateFormat(dateFormat).parse(dateStr).getTime();
        } catch (ParseException e) {
            logger.error("Error while Converting dateStr : {} to time millis", dateStr);
            return 0L;
        }
    }

    /**
     * Retrieves the current system time in milliseconds.
     *
     * @return millis in Long
     */
    public static Long getCurrentTime() {
        return System.currentTimeMillis();
    }

    /**
     * Get yesterday date string.
     *
     * @return string date
     */
    public String getYesterdayDate() {
        return LocalDate.now().minusDays(1).format(DateTimeFormatter.ofPattern("ddMMyyyy"));
    }

    public static long getStartOfDayMillis() {
        return LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli();
    }

    public static long getEndOfDayMillis() {
        return LocalDate.now().plusDays(1).atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli() - 1;
    }


    /**
     * Give the time difference in minutes
     */
    public static long getDiffInMinutes(long givenTime) {
        logger.info("Fetching time difference");
        return (System.currentTimeMillis() - givenTime) / (60 * 1000);
    }

    /**
     * This method is used to get current date format
     *
     * @return String e.g : 11_07_2025
     */
    public static String getCurrentDateString() {
        return LocalDateTime.now().format(DateTimeFormatter.ofPattern(DD_MM_YYYY));
    }

    /**
     * This method is used to get current time format
     *
     * @return String e.g : 11-07-33
     */
    public static String getCurrentTimeSting() {
        return LocalDateTime.now().format(DateTimeFormatter.ofPattern(HH_MM_SS));
    }

    /**
     * This method is used to get current date in given format
     *
     * @return String of given date format
     */
    public static String getCurrentDateString(String format) {
        return LocalDateTime.now().format(DateTimeFormatter.ofPattern(format));
    }

    /**
     * validate given time is within interval
     *
     * @return boolean true/false
     */
    public static boolean checkTimeWithInLimit(long interval, long timeDiff) {
        return interval - timeDiff >= 0;
    }

}
