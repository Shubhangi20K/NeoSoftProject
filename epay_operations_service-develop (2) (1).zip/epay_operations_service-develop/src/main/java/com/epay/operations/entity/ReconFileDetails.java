package com.epay.operations.entity;


import com.epay.operations.util.enums.PayoutStatus;
import com.epay.operations.util.enums.ReconStatus;
import com.epay.operations.util.enums.SettlementStatus;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;
import java.util.UUID;

/**
 * Class Name:ReconFileData<br>
 * Description:<br>
 * Author:@V0000001(Shilpa Kothre)<br>
 * Copyright (c) 2024 [State Bank of India]<br>
 * All right reserved<br>
 * Version:1.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@Entity
@SuperBuilder
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "RECON_FILE_DTLS")
public class ReconFileDetails extends AuditEntityByDate {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(columnDefinition = "RAW(16)")
    private UUID rfdId;
    @Column(columnDefinition = "RAW(16)")
    private UUID rfId;
    private int rowNumber;

    @Column(name = "MERCHANT_ID")
    private String mId;

    private String atrnNum;

    @Column(name = "TXN_AMOUNT")
    private BigDecimal transactionAmount;
    private String bankRefNumber;

    @Enumerated(EnumType.STRING)
    private PayoutStatus payoutStatus;

    @Enumerated(EnumType.STRING)
    @Column(insertable = false)
    private ReconStatus reconStatus;

    @Enumerated(EnumType.STRING)
    @Column(insertable = false)
    private SettlementStatus settlementStatus;

    private String remark;
}


