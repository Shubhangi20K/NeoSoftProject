package com.epay.operations.client;

import com.epay.operations.exception.OpsException;
import com.epay.operations.model.response.RnSResponse;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import io.netty.handler.ssl.SslContextBuilder;
import io.netty.handler.ssl.util.InsecureTrustManagerFactory;
import lombok.Getter;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.MDC;
import org.springframework.core.NestedRuntimeException;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.netty.http.client.HttpClient;

import java.net.URI;
import java.text.MessageFormat;

import static com.epay.operations.util.ErrorConstant.*;
import static com.epay.operations.util.OperationsConstant.CORRELATION;
import static com.epay.operations.util.OperationsConstant.X_CORRELATION_ID;
import static com.epay.operations.util.OperationsUtil.getServiceName;
import static java.util.Objects.nonNull;
import static org.apache.commons.lang3.StringUtils.EMPTY;

/**
 * Class Name: ApiClient
 * *
 * Description: ApiClient is parent class for all other service client.
 * <p>
 * Author: @V1019436 (Gireesh M)
 * Version: 1.0
 * <p>
 * Copyright (c) [2025] [State Bank of India]
 * All rights reserved.
 */
@Getter
public class ApiClient {
    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private final String baseUrl;
    private final WebClient webClient;

    /**
     * Constructor to initialize the ApiClient with the provided base URL. It also sets up the
     * WebClient instance with the base URL for making HTTP requests.
     * In local if we have other than local host service url (e.g <a href="https://dev.epay.sbi/api/admin">dev.epay.sbi</a>) then we need to handle PKIX error.
     *
     * @param baseUrl    The base URL for the API client
     * @param corsOrigin String
     */
    public ApiClient(String baseUrl, String corsOrigin, boolean isLocalProfile) {
        this.baseUrl = baseUrl;
        if (isLocalProfile) {
            this.webClient =
                    WebClient.builder()
                            .baseUrl(baseUrl)
                            .defaultHeader(HttpHeaders.ORIGIN, corsOrigin)
                            .clientConnector(new ReactorClientHttpConnector(HttpClient.create()
                                    .secure(t -> t.sslContext(SslContextBuilder.forClient()
                                            .trustManager(InsecureTrustManagerFactory.INSTANCE)))))
                            .build();
        } else {
            this.webClient =
                    WebClient.builder()
                            .baseUrl(baseUrl)
                            .defaultHeader(HttpHeaders.ORIGIN, corsOrigin)
                            .build();
        }
    }

    /**
     * Prepare HTTP headers for making API requests. This includes setting the content type, accept
     * type, and adding correlation ID from MDC.
     *
     * @return The HTTP headers prepared for the request
     */
    protected HttpHeaders prepareHttpHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);
        headers.add(X_CORRELATION_ID, MDC.get(CORRELATION));
        return headers;
    }

    /**
     * @param urlPath       String
     * @param requestBody   T
     * @param typeReference R
     * @param <T>           T
     * @param <R>           R
     * @return RnSResponse
     */
    protected <T, R> RnSResponse<R> post(String urlPath, T requestBody, ParameterizedTypeReference<RnSResponse<R>> typeReference) {
        try {
            URI uri = URI.create(getBaseUrl() + urlPath);
            logger.info("POST call URI: {}", uri);
            logger.debug("Request body: {}", requestBody);
            RnSResponse<R> rnsResponse =
                    getWebClient()
                            .post()
                            .uri(uri)
                            .headers(httpHeaders -> httpHeaders.addAll(prepareHttpHeaders()))
                            .bodyValue(requestBody)
                            .exchangeToMono(response -> response.bodyToMono(typeReference))
                            .block();
            return validateResponse(rnsResponse);
        } catch (NestedRuntimeException e) {
            logger.error(LOG_EXCEPTION, e.getMessage());
            throw new OpsException(EXTERNAL_SERVICE_ERROR_CODE, MessageFormat.format(EXTERNAL_SERVICE_ERROR_MESSAGE, getServiceName(getBaseUrl())));
        }
    }

    /**
     * Overloaded method of post to call API without request body.
     *
     * @return RnSResponse
     */
    protected <R> RnSResponse<R> post(String urlPath, ParameterizedTypeReference<RnSResponse<R>> typeReference) {
        return post(urlPath, EMPTY, typeReference);
    }

    /**
     * @param urlPath       String
     * @param typeReference T
     * @return RnSResponse
     */
    protected <T> RnSResponse<T> get(String urlPath, ParameterizedTypeReference<RnSResponse<T>> typeReference) {
        try {
            URI uri = URI.create(getBaseUrl() + urlPath);
            logger.info("Get call URI: {}", uri);
            RnSResponse<T> rnsResponse =
                    getWebClient()
                            .get()
                            .uri(uri)
                            .headers(httpHeaders -> httpHeaders.addAll(prepareHttpHeaders()))
                            .exchangeToMono(response -> response.bodyToMono(typeReference))
                            .block();
            return validateResponse(rnsResponse);
        } catch (NestedRuntimeException e) {
            logger.error(LOG_EXCEPTION, e.getMessage());
            throw new OpsException(EXTERNAL_SERVICE_ERROR_CODE, MessageFormat.format(EXTERNAL_SERVICE_ERROR_MESSAGE, getServiceName(getBaseUrl())));
        }
    }

    /**
     * @param response MerchantResponse
     * @param <T>      T
     */
    private <T> RnSResponse<T> validateResponse(RnSResponse<T> response) {
        if (nonNull(response) && RESPONSE_FAILURE == response.getStatus() && CollectionUtils.isNotEmpty(response.getErrors())) {
            logger.error("{} has sent errors: {}", getServiceName(getBaseUrl()), response.getErrors());
            throw new OpsException(response.getErrors());
        }
        return response;
    }

}