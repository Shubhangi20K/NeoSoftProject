package com.epay.operations.validator;


import com.epay.operations.dao.ReconFileDao;
import com.epay.operations.dto.admin.FileConfigDto;
import com.epay.operations.exception.OpsException;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.apache.commons.io.FilenameUtils;
import org.springframework.stereotype.Component;

import java.io.File;
import java.util.regex.Pattern;

import static com.epay.operations.util.ErrorConstant.*;
import static com.epay.operations.util.OperationsConstant.*;

/**
 * Class Name: SftpFileReaderService
 * *
 * Description: This Service will transfer file from sftp to s3 bucket.
 * *
 * Author:@V0000001(Shilpa Kothre)
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Component
@RequiredArgsConstructor
public class SftpReconFileValidator {
    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private final ReconFileDao reconFileDao;

    public void validateFile(FileConfigDto filesConfig, File file) {
        validateFileType(file, filesConfig);
        validateFileNameLength(file);
        validateFileRegex(file);
        validateFileSize(file);
        duplicateFileCheckWithName(file);
    }

    private void validateFileNameLength(File file) {
        if (file.getName().length()>FILE_NAME_MAX_LENGTH) {
            logger.error("File Name Should not Exceed more than 50 words {}", file.getName().length());
            throw new OpsException(FILE_NAME_SIZE_ERROR_CODE, FILE_NAME_SIZE_ERROR_MESSAGE);
        }
    }

    public void validateFileWithCheckSum(String checksum) {
        logger.info("Validating file checksum {}", checksum);
        boolean isExist = reconFileDao.isExistByFileChecksum(checksum);
        if (isExist) {
            logger.error("Duplicate file with checksum {}", checksum);
            throw new OpsException(FILE_CHECKSUM_ERROR_CODE, FILE_CHECKSUM_ERROR_MESSAGE);
        }
    }

    private void validateFileSize(File file) {
        logger.info("Validating file {} size", file.getName());
        if (FILE_MAX_LENGTH < file.length()) {
            logger.error("Invalid file {} size", file.getName());
            throw new OpsException(FILE_SIZE_ERROR_CODE,FILE_SIZE_ERROR_MESSAGE);
        }
    }

    private void validateFileType(File file, FileConfigDto filesConfig) {
        logger.info("Validating file {} type", file.getName());
        if (!filesConfig.getFileType().getLabel().equalsIgnoreCase(FilenameUtils.getExtension(file.getName()))) {
            logger.error("Invalid file {} type", file.getName());
            throw new OpsException(FILE_TYPE_ERROR_CODE, FILE_TYPE_ERROR_MESSAGE);
        }
    }

    private void validateFileRegex(File file) {
        logger.info("Validating file {} regex", file.getName());
        if (!Pattern.compile(COMMON_FILE_REGEX).matcher(FilenameUtils.getBaseName(file.getName())).matches()) {
            logger.error("Invalid file {} regex", file.getName());
            throw new OpsException(FILE_NAME_ERROR_CODE, FILE_NAME_ERROR_MESSAGE);
        }
    }

    private void duplicateFileCheckWithName(File file) {
        logger.info("Validating duplicate file {} check with name", file.getName());
        boolean isExist = reconFileDao.isExistByFileName(file.getName());
        if (isExist) {
            logger.error("Found duplicate file {}", file.getName());
            throw new OpsException(FILE_NAME_DUPLICATE_ERROR_CODE,FILE_NAME_DUPLICATE_ERROR_MESSAGE);
        }
    }

}
