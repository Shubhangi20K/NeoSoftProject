package com.epay.operations.dto.admin;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class BankAccountInfoDto {

    private String bankId;
    private String accountId;
    private String accountNumber;
    private String accountNickName;

}
