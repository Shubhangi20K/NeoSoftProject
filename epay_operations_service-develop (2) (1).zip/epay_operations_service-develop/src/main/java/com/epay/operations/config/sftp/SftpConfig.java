package com.epay.operations.config.sftp;

import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.file.remote.session.CachingSessionFactory;
import org.springframework.integration.sftp.session.DefaultSftpSessionFactory;

/**
 * Class Name: SftpConfig<br>
 * Description: This Service will provide methods to connect sftp.<br>
 * Author:@V0000001(Shilpa Kothre)<br>
 * Copyright (c) 2025 [State Bank of India] All rights reserved<br>
 * Version:1.0
 */
@Configuration
@RequiredArgsConstructor
@Getter
public class SftpConfig {

    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());

    @Value("${sftp.host}")
    private String host;

    @Value("${sftp.port}")
    private int port;

    @Value("${sftp.username}")
    private String username;

    @Value("${sftp.password}")
    private String password;

    @Value("${sftp.remote.directory}")
    private String remoteDirectory;

    @Value("${sftp.session.timeout:10000}")//10 second2
    private int sessionTimeout;

    @Value("${sftp.session.cacheSize:10}")//10 sessions
    private int sessionCacheSize;

    @Bean
    public CachingSessionFactory<?> sftpSessionFactory(){

        DefaultSftpSessionFactory factory = new DefaultSftpSessionFactory(true);
        factory.setHost(host);
        factory.setPort(port);
        factory.setUser(username);
        factory.setPassword(password);
        factory.setAllowUnknownKeys(true);

        CachingSessionFactory<?> cachingSessionFactory = new CachingSessionFactory<>(factory, sessionCacheSize);
        cachingSessionFactory.setSessionWaitTimeout(sessionTimeout);
        return cachingSessionFactory;
    }

}
