package com.epay.operations.externalservice;

import com.epay.operations.client.ApiClient;
import com.epay.operations.dto.admin.MerchantBankAccountsDto;
import com.epay.operations.dto.admin.MerchantInfoDto;
import com.epay.operations.model.response.BankConfigFileResponse;
import com.epay.operations.model.response.RnSResponse;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import org.springframework.core.ParameterizedTypeReference;

import java.util.List;

/**
 * Class Name: AdminServicesClient
 * Description: AdminServicesClient to call all the admin-service endpoint which are required in recon.
 * Author: Gireesh M
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * Version: 1.0
 */
public class AdminServicesClient extends ApiClient {

    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    public static final String BANK_FILE_CONFIG_ENDPOINT = "/rns/";
    public static final String MERCHANT_BANK_ACCOUNT_DETAILS_ENDPOINT = "/merchant/bankdetails/";
    public static final String MERCHANT_INFO_DETAILS_ENDPOINT = "/merchant/info";

    /**
     * Constructor to initialize AdminServicesClient with the base URL.
     *
     * @param baseUrl    API base URL
     * @param corsOrigin String
     */
    public AdminServicesClient(String baseUrl, String corsOrigin, boolean isLocalProfile) {
        super(baseUrl, corsOrigin, isLocalProfile);
    }

    /**
     * @param configId String
     * @return RnSResponse of BankConfigFileResponse
     */
    public RnSResponse<BankConfigFileResponse> getBankConfigurationDetailsById(String configId) {
        logger.info("Retrieving bank recon config for config id:{}", configId);
        return post(BANK_FILE_CONFIG_ENDPOINT + configId, new ParameterizedTypeReference<>() {
        });
    }

    /**
     * @return RnSResponse of BankConfigFileResponse
     */
    public RnSResponse<BankConfigFileResponse> loadAllBankFilesConfiguration() {
        logger.info("Retrieving all bank recon config data");
        return post(BANK_FILE_CONFIG_ENDPOINT, new ParameterizedTypeReference<>() {
        });
    }

    public RnSResponse<MerchantBankAccountsDto> getMerchantBankAccountDetails(List<String> mIdList) {
        logger.info("Retrieving Merchant Bank Account Details");
        return post(MERCHANT_BANK_ACCOUNT_DETAILS_ENDPOINT, mIdList, new ParameterizedTypeReference<>() {
        });
    }

    public RnSResponse<MerchantInfoDto> getMerchantInfo(List<String> mIdList) {
        logger.info("Retrieving Merchant Info Details");
        return post(MERCHANT_INFO_DETAILS_ENDPOINT, mIdList, new ParameterizedTypeReference<>() {
        });
    }
}
