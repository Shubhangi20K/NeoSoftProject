package com.epay.operations.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DataSyncSchedulerDto {

    private UUID dssId;
    private String schedulerName;
    private long schedulerLastRun;
    private Long createdDate;
}
