package com.epay.operations.util;

import lombok.experimental.UtilityClass;

/**
 * Class Name: ErrorConstant
 *
 * <p>Description: Define all error constants in this class.
 *
 * <p>Author: Gireesh M
 *
 * <p>Copyright (c) 2025 [State Bank of India] All rights reserved * Version:1.0
 */
@UtilityClass
public class ErrorConstant {

  public static final int RESPONSE_SUCCESS = 1;
  public static final int RESPONSE_FAILURE = 0;

  public static final String NOT_FOUND_ERROR_CODE = "6003";
  public static final String NOT_FOUND_ERROR_MESSAGE = "{0} was not found.";

  public static final String GENERIC_ERROR_CODE = "6006";
  public static final String GENERIC_ERROR_MESSAGE = "An unexpected error occurred.";

  public static final String FILE_CONFIG_DETAILS_ERROR_CODE = "6001";
  public static final String FILE_CONFIG_DETAILS_ERROR_MESSAGE = "Bank file configuration data not found for bankId {0}.";

  public static final String SFTP_ERROR_CODE = "6003";
  public static final String SFTP_ERROR_MESSAGE = "{0}";

  public static final String INVALID_ERROR_CODE_NO_REASON = "6012";
  public static final String INVALID_ERROR_MESSAGE_NO_REASON = "{0} ''{1}'' is invalid.";
  public static final String INVALID_ERROR_MESSAGE = "{0} is invalid";

  public static final String FAILED_TO_INSERT_ERROR_CODE = "6013";
  public static final String FAILED_TO_INSERT_ERROR_MESSAGE = "Failed to insert data.";

  public static final String EXTERNAL_SERVICE_ERROR_CODE = "6101";
  public static final String EXTERNAL_SERVICE_ERROR_MESSAGE = "{0} service is currently unavailable. Please try again later.";

  public static final String EXTERNAL_SERVICE_4XX_ERROR_CODE = "6106";
  public static final String EXTERNAL_SERVICE_4XX_ERROR_MESSAGE = "Something went wrong while connecting {0} Service. Please try again.";

  public static final String LOG_EXCEPTION = "Got exception {}";
  public static final String JSON_PARSING_ERROR_IN_MULTI_ACCOUNT = "Json Parsing Error in Multi Account";

  public static final String FILE_NAME_SIZE_ERROR_CODE = "6014";
  public static final String FILE_NAME_SIZE_ERROR_MESSAGE = "File Name Should not Exceed more than 50 characters";

  public static final String FILE_SIZE_ERROR_CODE ="6015";
  public static final String FILE_SIZE_ERROR_MESSAGE = "Invalid file size";

  public static final String FILE_TYPE_ERROR_CODE ="6016";
  public static final String FILE_TYPE_ERROR_MESSAGE =  "Invalid file type";

  public static final String FILE_NAME_ERROR_CODE = "6017";
  public static final String FILE_NAME_ERROR_MESSAGE =   "Invalid file name";

  public static final String FILE_NAME_DUPLICATE_ERROR_CODE ="6018";
  public static final String FILE_NAME_DUPLICATE_ERROR_MESSAGE =   "Duplicate file name";

  public static final String FILE_CHECKSUM_ERROR_CODE ="6019";
  public static final String FILE_CHECKSUM_ERROR_MESSAGE =  "Duplicate file with checksum";

  public static final String MISMATCH_ERROR_CODE ="6020";
  public static final String MISMATCH_ERROR_MESSAGE =  "Mismatch in counts: inserted {}, deleted {}.";





}
