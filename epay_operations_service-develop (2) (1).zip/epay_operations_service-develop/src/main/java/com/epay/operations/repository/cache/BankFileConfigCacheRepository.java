package com.epay.operations.repository.cache;

import com.sbi.epay.cache.admin.entity.BankFileConfigCache;
import org.jetbrains.annotations.NotNull;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Class Name: BankFileConfigCacheRepository.
 * *
 * Description: Repository for Bank file config cache details.
 * *
 * Author: Gireesh M.
 * <p>
 * Copyright (c) 2025 [State Bank of India].
 * All rights reserved.
 * *
 * Version:1.0
 */
@Repository
public interface BankFileConfigCacheRepository extends CrudRepository<BankFileConfigCache, String> {

     @NotNull List<BankFileConfigCache> findAll();
}
