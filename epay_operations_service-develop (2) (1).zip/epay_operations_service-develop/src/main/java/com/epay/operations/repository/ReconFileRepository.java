package com.epay.operations.repository;


import com.epay.operations.entity.ReconFile;
import com.epay.operations.util.enums.ReconStatus;
import com.epay.operations.util.enums.SettlementStatus;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.UUID;

/**
 * Class Name:ReconDataJdbcRepository
 * *
 * Description: Repository interface for ReconData
 * *
 * Author:@V0000001(Shilpa Kothre)
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */

@Repository
public interface ReconFileRepository extends JpaRepository<ReconFile, UUID> {

    @Modifying
    @Transactional
    @Query("UPDATE ReconFile rf SET rf.reconStatus = :reconStatus, rf.settlementStatus = :settlementStatus WHERE rf.id = :rfId")
    int updateFileSummaryReconStatusByIdAndParsingStatus(UUID rfId, ReconStatus reconStatus, SettlementStatus settlementStatus);

    @Query("Select COUNT(rf) > 0 from ReconFile rf where rf.fileName = :fileName AND rf.fileReceivedTime BETWEEN :startTime AND :endTime")
    boolean existsByFileNameAndCurrentDate(@Param("fileName") String fileName, @Param("startTime") long startTime, @Param("endTime") long endTime);

    @Query("Select COUNT(rf) > 0 from ReconFile rf where rf.fileChecksum = :fileChecksum AND rf.fileReceivedTime BETWEEN :startTime AND :endTime")
    boolean existsByFileChecksumAndCurrentDate(@Param("fileChecksum") String fileChecksum, @Param("startTime") long startTime, @Param("endTime") long endTime);

    @Modifying
    @Transactional
    @Query("UPDATE ReconFile rf SET rf.settlementStatus = :settlementStatus, rf.settlementTime = :settlementTime WHERE rf.id = :rfId")
    void updateSettlementStatus(UUID rfId, SettlementStatus settlementStatus, Long settlementTime);

}
