package com.epay.operations.dto.spark;

import com.epay.operations.dto.transaction.MerchantTransactionDto;
import lombok.Data;

import java.util.List;

/**
 * Class Name: ReconFileSummaryDto
 * Description: Dto class to send API spark result response.
 * Author: V1019620(Bhoopendra Rajput)
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * Version:1.0
 */
@Data
public class ReconFileSummaryDto {
    private List<MerchantTransactionDto> matchedRecords;
    private List<TransactionUnMatchedDto> unMatchedRecords;
    private long fileRecordCount;
    private String timeToProcessed;
}
