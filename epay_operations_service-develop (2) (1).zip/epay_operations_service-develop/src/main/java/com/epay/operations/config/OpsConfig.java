package com.epay.operations.config;

import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

/**
 * Class Name: OpsConfig<br>
 * Description: The OpsConfig class reads the application configuration.<br>
 * Author: V1019620(Bhoopendra Rajput)<br>
 * Copyright (c) 2025 [State Bank of India]<br>
 * All rights reserved<br>
 * Version:1.0
 */
@Configuration
@Getter
public class OpsConfig {

    @Value("${secret.key}")
    private String secretKey;

    @Value("${secret.salt}")
    private String salt;

    @Value("${recon.process.runner.mode:SPARK}")
    private String reconProcessRunnerMode;

    @Value("${payout.generation.time.interval}")
    private long interval;

    @Value("${jdbc.insert.batchSize:1000}")
    private int jdbcInsertBatchSize;

    @Value("${queue.batch.size.event}")
    private int eventQueueBatchSize;

    @Value("${purge.retentionDays}")
    private int purgeRetentionDays;
}
