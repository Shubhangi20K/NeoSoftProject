package com.epay.operations.etl.producer;

import com.epay.operations.config.kafka.Topics;
import com.epay.operations.util.enums.InterfaceType;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Component;

import static com.epay.operations.util.EventMessageUtils.buildEventErrorLog;
import static com.epay.operations.util.EventMessageUtils.buildEventSendLog;
import static com.epay.operations.util.OperationsConstant.FILE_SUMMARY_ROUTING_KEY;
import static com.epay.operations.util.OperationsUtil.getKafkaRoutingKey;

/**
 * Class Name: ReconFileProcessingPublisher <br>
 * Description: Kafka Service will publish ReconFileSummaryId <br>
 * Author:@V0000001(Shilpa Kothre)<br>
 * Copyright (c) 2025 [State Bank of India]<br>
 * All rights reserved<br>
 * Version:1.0
 */
@Component
@RequiredArgsConstructor
public class ReconFileProcessingPublisher {

    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    private final KafkaMessagePublisher kafkaMessagePublisher;
    private final Topics topics;
    private final ApplicationEventPublisher publisher;

    /**
     * @param requestType        String
     * @param routingKey         String
     * @param reconFileSummaryId UUID
     */
    public void publish(String requestType, String routingKey, String reconFileSummaryId) {
        String kafkaRoutingKey = getKafkaRoutingKey(requestType, FILE_SUMMARY_ROUTING_KEY, routingKey);
        try {
            log.debug("ReconFileProcessingPublisher for requestType : {}, routingKey : {} and value : {}", requestType, routingKey, reconFileSummaryId);
            kafkaMessagePublisher.publish(topics.getReconFileTopic(), kafkaRoutingKey, reconFileSummaryId);
            publisher.publishEvent(buildEventSendLog(InterfaceType.OPS_RECON_FILE_TOPIC, topics.getReconFileTopic(), kafkaRoutingKey, reconFileSummaryId));
            log.debug("ReconFileProcessing has been published");
        } catch (Exception e) {
            log.error("Error in ReconFileProcessing , reconFileSummaryId {}", reconFileSummaryId, e.getMessage());
            publisher.publishEvent(buildEventErrorLog(InterfaceType.OPS_RECON_FILE_TOPIC, topics.getReconFileTopic(), kafkaRoutingKey, e.getMessage()));
        }
    }
}
