package com.epay.operations;

import org.junit.jupiter.api.Test;

//@SpringBootTest
class OperationsServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
