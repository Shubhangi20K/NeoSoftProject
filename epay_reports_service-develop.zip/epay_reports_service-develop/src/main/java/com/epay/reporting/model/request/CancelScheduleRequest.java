package com.epay.reporting.model.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Class Name: CancelScheduleRequest
 * Description: This class represents a request body for cancel scheduler
 * Author: Subhra
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * Version: 1.0
 */
@AllArgsConstructor
@Data
@Builder
@NoArgsConstructor
public class CancelScheduleRequest {
    private String remarks;
}
