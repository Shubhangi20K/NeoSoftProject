package com.epay.reporting.util;

import lombok.experimental.UtilityClass;

/**
 * Class Name: ErrorConstants
 * <p>
 * Description: Define all error constants in this class.
 * <p>
 * Author: Bhoopendra Rajput
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@UtilityClass
public class ErrorConstants {

    public static final String REQUIRED_ERROR_CODE = "5001";
    public static final String REQUIRED_ERROR_MESSAGE = "{0} is required.";//for Validator
    public static final String HIBERNATOR_REQUIRED_ERROR_MESSAGE = " is required.";//for @NotBlank validation

    public static final String INVALID_ERROR_CODE = "5002";
    public static final String INVALID_ERROR_MESSAGE = "{0} is invalid. Reason: {1}";

    public static final String NOT_FOUND_ERROR_CODE = "5003";
    public static final String NOT_FOUND_ERROR_MESSAGE = "{0} was not found.";

    public static final String FIXED_LENGTH_ERROR_CODE = "5005";
    public static final String FIXED_LENGTH_ERROR_MESSAGE = "The fixed length required for {0} is {1}.";

    public static final String GENERIC_ERROR_CODE = "5006";
    public static final String GENERIC_ERROR_MESSAGE = "An unexpected error occurred while processing your request.";

    public static final String EXCEED_LENGTH_ERROR_CODE = "5007";
    public static final String EXCEED_LENGTH_ERROR_MESSAGE = "The maximum allowed length for {0} is {1}.";

    public static final String WHITESPACE_ERROR_CODE = "5010";
    public static final String WHITESPACE_ERROR_MESSAGE = "{0} contains leading or trailing spaces. Please provide a valid value.";

    public static final String JSON_ERROR_CODE = "5011";
    public static final String JSON_ERROR_MESSAGE = "Invalid JSON data provided in {0}.";

    public static final String INVALID_ENUM_ERROR_CODE = "5012";
    public static final String INVALID_ENUM_ERROR_MESSAGE = "{0} is invalid."; //we're using this in where we're sending enum as values


    public static final String DATE_FORMAT_ERROR_CODE = "5201";
    public static final String DATE_FORMAT_ERROR_MESSAGE = "Please ensure the date format is: {0} (e.g., Jan-2025) and that both month and year are valid.";

    public static final String FILE_GENERATION_ERROR_CODE = "5202";
    public static final String FILE_GENERATION_ERROR_MESSAGE = "Error in {0} Generation, {1}.";

    public static final String REPORT_NOT_AVAILABLE_CODE = "5203";
    public static final String REPORT_NOT_AVAILABLE_MESSAGE = "Report is not available to download.";

    public static final String GENERATION_ERROR_CODE = "5205";
    public static final String GENERATION_ERROR_MESSAGE = "Failed to generate {0}.";

    public static final String MID = "mId";
    public static final String FILE_PATH = "filePath";
    public static final String SCHEDULE_EXECUTION_DATE = "scheduleExecutionDate";
    public static final String YEAR = "year";
    public static final String MONTH = "month";
    public static final String REPORT = "report";
    public static final String FORMAT = "format";
    public static final String DURATION_FROM_DATE = "durationFromDate";
    public static final String DURATION_TO_DATE = "durationToDate";
    public static final String FREQUENCY = "frequency";
    public static final String REPORT_MONTHS = "reportMonth";
    public static final String CURRENT_DATE = "currentDate";
    public static final String PREVIOUS_DATE = "previousDate";
    public static final String FROM_DATE = "fromDate";
    public static final String TO_DATE = "toDate";
    public static final String START_DATE = "startDate";
    public static final String END_DATE = "endDate";
    public static final String CURR_DATE = "currDate";
    public static final String FIRST = "first";
    public static final String OFFSET = "offset";
    public static final String SCHEDULE_EXECUTION_TIME = "scheduleExecutionTime";
    public static final String REPORT_DURATION = "reportDuration";
    public static final String REQUEST_ID = "requestId";
    public static final String DATA = "Data";

    //report scheduler management error message
    public static final String SCHEDULE_REQUEST_ID = "schedule request id";

    public static final String NO_RECORD_FOUND = "No record found for the selection.";
    public static final String INVALID_FORMAT = "format is incorrect.";

    public static final String INVALID_YEAR_MESSAGE = "Year must be in 1900 and the current year.";
    public static final String INVALID_MONTH_MESSAGE = "requested month must not be in future.";
    public static final String FUTURE_DATE_ERROR = "future date is not allowed.";
    public static final String INCORRECT_FORMAT = "Format is incorrect";
    public static final String PAST_DATE_12M_ERROR = "past date more than 12 months is not allowed";
    public static final String FROM_TO_DATE_ERROR = "from date can not be more than to date";
    public static final String DATE_DIFF_1M_ERROR = "difference between from and to date more than 1 month is not allowed";

    public static final String ALLOWED_DIGIT_REGEX = "^\\d+$";
    public static final String ALLOWED_ALPHABET_REGEX = "^(?! )[A-Za-z  .-]+(?<! )$";
    public static final String ALPHA_NO_SPACE_REGEX = "^[A-Za-z]+$";
    public static final String CAPS_NO_SPACE_REGEX = "^[A-Z]+$";
    public static final String ALLOWED_SUMMARY_DATE_REGEX = "^(0[1-9]|[12][0-9]|3[01])-(0[1-9]|1[0-2])-(19|20)\\d\\d$";
    public static final String ALLOWED_DATE_REGEX = "^(0[1-9]|[12][0-9]|3[01])-[a-zA-Z]{3}-(19|20)\\d\\d$";
    public static final String MONTH_FORMAT_REGEX_DD_MMM_YYYY = "^(0[1-9]|[12][0-9]|3[01])-(?i)(JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|OCT|NOV|DEC)-\\d{4}$";
    public static final String ALPHANUMERIC_NO_SPACE_REGEX = "^[a-zA-Z0-9]+$";
    public static final String MID_REGEX = "[0-9]+$";
    public static final String SCHEDULE_EXECUTION_TIME_REGEX = "^(0[1-9]|1[0-2]):[0-5][0-9] [AP]M$";
    public static final String NO_SPACE_INBETWEEN_STRING ="^[\\S]+$";
    public static final String UUID_FORMAT_REGEX = "^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$";


    public static final String DATE_FORMAT = "MMM-yyyy";

    public static final int ZERO = 0;
    public static final int ONE = 1;
    public static final int MONTH_DEFF_LENGTH =2;
    public static final int MID_LENGTH = 7;
    public static final int FORMAT_LENGTH = 4;
    public static final int ALLOWED_SUMMARY_DATE_LENGTH = 10;
    public static final int ALLOWED_DATE_LENGTH = 11;
    public static final int ALLOWED_FREQUENCY_LENGTH = 8;
    public static final int REMARK_MAX_LENGTH = 100;
    public static final int SCHEDULE_EXECUTION_DATE_MAX_VALUE = 28;
    public static final int SCHEDULE_EXECUTION_DATE_LENGTH = 2;
    public static final int SCHEDULE_EXECUTION_TIME_LENGTH = 8;
    public static final int INVALID_YEAR = 1900;
    public static final int MAX_FILE_PATH_LENGTH = 200;
    public static final int MAX_UUID_ID_LENGTH = 36;

    public static final int MILLIS_LENGTH = 13;
    public static final String EXTERNAL_SERVICE_ERROR_CODE = "5013";
    public static final String EXTERNAL_SERVICE_ERROR_MESSAGE = "Something went wrong while connecting {0} Service. Please try again";
    public static final String EXTERNAL_MESSAGE ="external";
    public static final String THREE_MONTH_DIFF_ERROR = "difference between from and to date more than 3 month is not allowed.";
    public static final String FROM_DATE_YEAR_DIFF_ERROR = "From date cannot be more than {0} year older than today";
    public static final String TO_DATE_DIFF_ERROR = "toDate must be greater than or equal to from date";
}