package com.epay.reporting.mapper;

import com.epay.reporting.entity.view.OrderReport;
import org.apache.commons.lang3.StringUtils;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;

import java.util.List;

import static org.thymeleaf.util.ObjectUtils.nullSafe;

@Mapper(builder = @Builder(disableBuilder = true), componentModel = "spring")
public interface OrderMapper {
    default List<Object> mapToList(OrderReport orderReport) {
        return List.of(
                nullSafe(orderReport.getTransactionDate(), StringUtils.EMPTY),
                nullSafe(orderReport.getMerchantOrderNumber(), StringUtils.EMPTY),
                nullSafe(orderReport.getCustomerId(), StringUtils.EMPTY),
                nullSafe(orderReport.getTransactionCurrency(), StringUtils.EMPTY),
                nullSafe(orderReport.getOrderAmount(), StringUtils.EMPTY),
                nullSafe(orderReport.getSbiOrderRefNumber(), StringUtils.EMPTY),
                nullSafe(orderReport.getStatus(), StringUtils.EMPTY),
                nullSafe(orderReport.getAttempts(), StringUtils.EMPTY));
    }
}
