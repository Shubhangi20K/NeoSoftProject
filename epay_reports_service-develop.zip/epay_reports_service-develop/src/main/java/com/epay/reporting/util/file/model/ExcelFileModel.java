package com.epay.reporting.util.file.model;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;
/**
 * Class Name: ExcelFileModel
 * *
 * Description: This class represents the model for an Excel file, holding the headers and the data
 * for the Excel file. It extends the FileModel class, providing common properties for files.
 * Lombok annotations are used to simplify getter/setter and other methods generation.
 * *
 * Author: Bhoopendra Rajput
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Builder
@Data
@EqualsAndHashCode(callSuper = true)
public class ExcelFileModel extends FileModel {
    /**
     * The headers of the Excel file.
     */
    private List<String> headers;

    /**
     * The data of the Excel file, represented as a list of rows, where each row is a list of objects.
     */
    private List<List<Object>> fileData;
    
}
