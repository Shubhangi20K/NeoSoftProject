package com.epay.reporting.service;

import com.epay.reporting.dao.ReportMasterDao;
import com.epay.reporting.dto.ReportMasterDto;
import com.epay.reporting.model.response.ReportingResponse;
import com.epay.reporting.util.ReportingConstant;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Class Name: ReportMasterService
 * *
 * Description:This service class contains the business logic for handling report master data. It interacts with the data access
 * layer (ReportMasterDao) to fetch, save, and manage report master-related operations such as fetching report names,
 * report details, and other business-specific logic related to report masters.
 * Author: V1018344
 * Copyright (c) 2025 [State Bank of India]
 * ALl rights reserved
 * *
 * Version: 1.0
 */

@Service
@RequiredArgsConstructor
public class ReportMasterService {

    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private final ReportMasterDao reportMasterDao;



    /**
     * Retrieves a list of all available report names.
     * This method fetches a list of report names from the report master and returns them in a response object.
     * It is used to fetch the names of all the reports that are available in the system.
     * @return ReportingResponse<String> A response containing the list of all report names.
     *         The response includes the data (list of report names) and other metadata such as the status.
     */
    public ReportingResponse<ReportMasterDto> getAllReportNames() {
        logger.info("Service providing ReportList ");
        List<ReportMasterDto> reportMasterList = reportMasterDao.getAllReportNames();
        logger.info("Report names : {}", reportMasterList);
        return ReportingResponse.<ReportMasterDto>builder().data(reportMasterList).count((long) reportMasterList.size()).status(ReportingConstant.RESPONSE_SUCCESS).build();
    }
}