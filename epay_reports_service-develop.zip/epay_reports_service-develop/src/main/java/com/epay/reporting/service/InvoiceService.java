package com.epay.reporting.service;

import com.epay.reporting.dao.InvoiceDao;
import com.epay.reporting.exception.ReportingException;
import com.epay.reporting.exception.ValidationException;
import com.epay.reporting.model.response.ReportingResponse;
import com.epay.reporting.util.ErrorConstants;
import com.epay.reporting.util.ReportingConstant;
import com.epay.reporting.util.enums.Report;
import com.epay.reporting.util.enums.ReportFormat;
import com.epay.reporting.util.file.model.FileModel;
import com.epay.reporting.util.file.model.PdfFileModel;
import com.epay.reporting.validator.InvoiceValidator;
import com.epay.reporting.validator.MIdValidator;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Service;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static com.epay.reporting.util.ErrorConstants.*;

/**
 * Class Name: InvoiceService
 * *
 * Description: To define business logic for all the Invoice request.
 * Description: This service defines the business logic for handling all invoice-related requests. It interacts
 * with the `InvoiceDao` for data access, the `FileGeneratorService` for file creation, and `MIdValidator` to
 * validate merchant IDs. It processes the necessary logic for generating, managing, and validating invoices,
 * providing the core functionality of the invoice management system.
 * Author: Bhoopendra Rajput
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Service
@RequiredArgsConstructor
public class InvoiceService {
    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    private final InvoiceDao invoiceDao;
    private final FileGeneratorService fileGeneratorService;
    private final MIdValidator mIdValidator;
    private final InvoiceValidator invoiceValidator;

    /**
     * Validate the request, generate pdf file content and set it for downloading.
     *
     * @param mId        String
     * @param reportMonths String
     * @param response   HttpServletResponse
     */
    public ReportingResponse<String> generateMerchantFeesInvoice(String mId, List<String> reportMonths, HttpServletResponse response) {
        try {
            log.info("Received Fees invoice generation for mId {}, reportMonths {}", mId, reportMonths);
            invoiceValidator.validateRequestMonths(reportMonths);
            mIdValidator.validateActiveMId(mId);
            List<Map<String, Object>> feesInvoiceData = invoiceDao.getFeesInvoiceData(mId, reportMonths);
            if(CollectionUtils.isNotEmpty(feesInvoiceData)) {
                if (feesInvoiceData.size() > 1) {
                    List<FileModel> fileModels = getFileModels(feesInvoiceData);
                    fileGeneratorService.generateZipFile(response, ReportFormat.PDF, Report.FEES_INVOICE, mId, fileModels);
                } else {
                    FileModel fileModel = PdfFileModel.builder().fileData(feesInvoiceData.getFirst()).build();
                    fileGeneratorService.downloadFile(response, ReportFormat.PDF, Report.FEES_INVOICE, mId, fileModel);
                }
                return ReportingResponse.<String>builder().status(ReportingConstant.RESPONSE_SUCCESS).build();
            }
            throw new ReportingException(NOT_FOUND_ERROR_CODE, MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, DATA));
        } catch (ValidationException e){
            log.error("Failed to generate PDF for MID {} and Report: {} during Validation. Error : {}", mId, reportMonths, e.getErrorMessages());
            throw e;
        } catch (ReportingException e){
            log.error("Failed to generate PDF for MID {} and Report: {}, at file generation. Error : {}", mId, reportMonths, e.getErrorMessages());
            throw e;
        } catch (Exception e) {
            log.error("Failed to generate PDF for MID {} and Report: {}. Error : {}", mId, reportMonths, e.getMessage());
            throw new ReportingException(ErrorConstants.GENERATION_ERROR_CODE, MessageFormat.format(ErrorConstants.GENERATION_ERROR_MESSAGE, reportMonths));
        }
    }

    /**
     * Validate the request, generate pdf file content and set it for downloading.
     *
     * @param mId        String
     * @param reportMonths String
     * @param response   HttpServletResponse
     */
    public ReportingResponse<String> generateMerchantGstInvoice(String mId, List<String> reportMonths, HttpServletResponse response) {
        try {
            log.info("Fetching GST Invoice Data for mId: {} and reportMonths: {}", mId, reportMonths);
            mIdValidator.validateActiveMId(mId);
            invoiceValidator.validateRequestMonths(reportMonths);
            List<Map<String, Object>> gstInvoiceData = invoiceDao.getGstInvoiceData(mId, reportMonths);
            if (CollectionUtils.isNotEmpty(gstInvoiceData)) {
                log.info("Fetched {} records for GST Invoice", gstInvoiceData.size());
                buildReport(mId, reportMonths, gstInvoiceData, response);
            } else {
                log.info("No GST Invoice Data found for MID: {} and reportMonths: {}", mId, reportMonths);
                throw new ReportingException(NOT_FOUND_ERROR_CODE, MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, DATA));
            }
        } catch (ValidationException e) {
            log.error("Validation error while generating GST Invoice for MID: {} and reportMonths: {}. Error: {}", mId, reportMonths, e.getMessage());
            throw e;
        } catch (ReportingException e){
            log.error("Failed to generate GST Invoice MID {} and Report: {}, at file generation. Error : {}", mId, reportMonths, e.getErrorMessages());
            throw e;
        } catch (Exception e) {
            log.error("Unexpected error while generating GST Invoice for MID: {} and reportMonths: {}. Error: {}", mId, reportMonths, e.getMessage());
            throw new ReportingException(ErrorConstants.GENERATION_ERROR_CODE, "Error generating GST invoice report.");
        }
        return ReportingResponse.<String>builder().data(List.of("Success")).status(ReportingConstant.RESPONSE_SUCCESS).build();
    }


    private void buildReport(String mId, List<String> reportMonths, List<Map<String, Object>> gstInvoiceData, HttpServletResponse response) {
        log.info("Building GST Invoice Report for MID: {} and Report months: {}", mId, reportMonths);
        List<FileModel> fileModels = new ArrayList<>();
        if( gstInvoiceData.size() > 1) {
            for (Map<String, Object> csvData : gstInvoiceData) {
                FileModel fileModel = buildFileModel(csvData);
                fileModels.add(fileModel);
            }
            fileGeneratorService.generateZipFile(response, ReportFormat.CSV, Report.GST_INVOICE, mId, fileModels);
        } else {
            FileModel fileModel = buildFileModel(gstInvoiceData.getFirst());
            fileGeneratorService.downloadFile(response, ReportFormat.CSV, Report.GST_INVOICE, mId, fileModel);
        }

    }
    /**
     * Converts a list of fees invoice data into a list of file models.
     * This method processes the provided fees invoice data, creates a `FileModel` for each set of invoice data,
     * and sets the appropriate report month based on the data. The file models can be used for further file
     * generation, such as creating PDF reports.
     * @param feesInvoiceData A list of maps containing the fees invoice data. Each map represents a set of invoice data.
     * @return A list of `FileModel` objects that represent the processed fees invoice data, ready for file generation.
     */
    private static List<FileModel> getFileModels(List<Map<String, Object>> feesInvoiceData) {
        List<FileModel> fileModels = new ArrayList<>();
        for (Map<String, Object> feesData : feesInvoiceData) {
            FileModel fileModel = PdfFileModel.builder().fileData(feesData).build();
            fileModel.setReportMonth((String) feesData.get("report"));
            fileModels.add(fileModel);
        }
        return fileModels;
    }

    /**
     * Converts gst invoice data into a file model.
     * @param csvData A map containing the gst invoice data.
     * @return A `FileModel` object that represent the processed gst invoice data, ready for file generation.
     */
    private FileModel buildFileModel(Map<String, Object> csvData) {
        Map<String, Object> dataMap = (Map<String, Object>) csvData.get("map");
        List<String> gstHeaders = (List<String>) dataMap.get("headers");
        List<List<Object>> fileData = (List<List<Object>>) dataMap.get("rows");
        String reportMonth = (String) csvData.get("report"); // Extract the month
        FileModel fileModel = null;
        if (CollectionUtils.isNotEmpty(fileData)) {
             fileModel = fileGeneratorService.buildFileModel(
                    ReportFormat.CSV, gstHeaders, fileData, Map.of("headers", gstHeaders, "rows", fileData)
            );
            fileModel.setReportMonth(reportMonth);
        }
        return fileModel;
    }

}
