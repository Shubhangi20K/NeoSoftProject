package com.epay.reporting.util.queries;

import lombok.experimental.UtilityClass;

/**
 * Class Name: TransactionDashboardQueries
 * *
 * Description: This class contains SQL queries related to the transaction dashboard
 * *
 * Author: Bhoopendra Rajput
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@UtilityClass
public class TransactionDashboardQueries {

    public static final String JDBC_DAILY_TRANSACTION_TRENDS =  """
            WITH T as(SELECT trunc(sysdate) - level+1 as dt from dual connect by level <=12),
            result as(SELECT TRANSACTION_DATE as transactionDate,
            TOTAL_SUCCESS_AMOUNT as successAmount, SUCCESS_COUNT as successCount
            FROM VIEW_TRANSACTION_DAILY_REPORT
            WHERE MID = :mId
            and transaction_date between trunc(sysdate)-12 and sysdate           \s
            )
            select t.dt as transactionDate, nvl(result.successamount,0) as successAmount,nvl(result.successcount,0) as successCount
            from T left join result on T.dt = result.transactiondate
            order by 1 desc
            """;

    public static final String JDBC_MONTHLY_TRANSACTION_TRENDS =  "SELECT TO_CHAR(TO_DATE(TRANSACTION_DATE, 'DD-MM-YY'), 'Mon-YYYY') as transactionDate,"+
            " SUM(TOTAL_SUCCESS_AMOUNT) as successAmount, SUM(SUCCESS_COUNT) as successCount"+
            " from VIEW_TRANSACTION_DAILY_REPORT"+
            " where MID = :mId"+
            " GROUP By TO_CHAR(TO_DATE(TRANSACTION_DATE, 'DD-MM-YY'), 'Mon-YYYY'),"+
            " TRUNC(TO_DATE(TRANSACTION_DATE, 'DD-MM-YY'), 'MM')"+
            " Order By TRUNC(TO_DATE(TRANSACTION_DATE, 'DD-MM-YY'), 'MM') desc"+
            " Fetch FIRST 12 ROWS only";

    public static final String JDBC_DAILY_RECENT_TRANSACTION =  """ 
            SELECT SUM(TOTAL_TRANSACTION_COUNT) AS totalTransactionCount,
            SUM(TOTAL_ORDER_AMOUNT) AS totalOrderAmount,
            SUM(TOTAL_REFUND_AMOUNT) AS totalRefundAmount,
            SUM(TOTAL_TAX_AMOUNT) AS totalTaxAmount,
            SUM(TOTAL_NET_SETTLEMENT_AMOUNT) AS totalNetSettlementAmount,
            SUM(TOTAL_SETTLED_AMOUNT) AS totalSettledAmount,
            SUM(TOTAL_PENDING_SETTLEMENT_AMOUNT) AS totalPendingSettlementAmount,
            TO_CHAR(TRUNC(TRANSACTION_DATE), 'DD-MM-YYYY') AS transactionDate
            FROM VIEW_TRANSACTION_DASHBOARD_REPORT
            WHERE MID = :mId
            AND TRANSACTION_DATE BETWEEN :fromDate AND :toDate
            GROUP BY TRUNC(TRANSACTION_DATE) ORDER BY TRUNC(TRANSACTION_DATE) DESC
            OFFSET :offset ROWS FETCH FIRST :first ROWS ONLY
            """;

    public static final String JDBC_DAILY_RECENT_TRANSACTION_COUNT = """
                SELECT count(*) as record_count FROM VIEW_TRANSACTION_DASHBOARD_REPORT
                WHERE MID = :mId AND TRANSACTION_DATE BETWEEN :fromDate AND :toDate
            """;

    public static final String JDBC_MONTHLY_RECENT_TRANSACTION =  """
            SELECT SUM(TOTAL_TRANSACTION_COUNT) AS totalTransactionCount,
            SUM(TOTAL_ORDER_AMOUNT) AS totalOrderAmount,
            SUM(TOTAL_REFUND_AMOUNT) AS totalRefundAmount,
            SUM(TOTAL_TAX_AMOUNT) AS totalTaxAmount,
            SUM(TOTAL_NET_SETTLEMENT_AMOUNT) AS totalNetSettlementAmount,
            SUM(TOTAL_PENDING_SETTLEMENT_AMOUNT) AS totalPendingSettlementAmount,
            TO_CHAR(TRANSACTION_DATE, 'Mon-YYYY') as transactionDate
            from VIEW_TRANSACTION_DASHBOARD_REPORT
            where MID = :mId
            AND TRANSACTION_DATE BETWEEN :fromDate AND :toDate
            GROUP By TO_CHAR(TRANSACTION_DATE, 'Mon-YYYY') Order By transactionDate desc
            OFFSET :offset ROWS FETCH FIRST :first ROWS ONLY
            """;

    public static final String JDBC_MONTHLY_RECENT_TRANSACTION_COUNT = """
                SELECT count(DISTINCT TO_CHAR(TRANSACTION_DATE, 'Mon-YYYY')) as record_count FROM
                VIEW_TRANSACTION_DASHBOARD_REPORT
                WHERE MID = :mId AND TRANSACTION_DATE BETWEEN :fromDate AND :toDate
            """;

    public static final String JDBC_CURRENT_TRANSACTION_SUMMARY = "SELECT SUM(TOTAL_TRANSACTION_COUNT) AS totalTransactionCount," +
            " SUM(TOTAL_ORDER_AMOUNT + TOTAL_TAX_AMOUNT - TOTAL_REFUND_AMOUNT) AS totalAmount," +
            " TO_CHAR(TRANSACTION_DATE, 'DD MON YYYY') AS transactionDate" +
            " FROM VIEW_TRANSACTION_DASHBOARD_REPORT" +
            " WHERE MID = :mId" +
            " AND TRUNC(TRANSACTION_DATE) = TO_DATE(:currentDate, 'DD/MM/YYYY')" +
            " GROUP BY TRANSACTION_DATE";

    public static final String JDBC_CURRENT_PAST_SETTLEMENT = """
            WITH result AS (
               SELECT
                (
                    SELECT total_net_settlement_amount FROM view_transaction_dashboard_report
                    WHERE mid = :mId AND transaction_date = TO_DATE(:currentDate, 'DD/MM/YYYY')
                ) AS todaysettlement,
                (
                    SELECT total_settled_amount FROM view_transaction_dashboard_report
                    WHERE mid = :mId AND transaction_date = TO_DATE(:previousDate, 'DD/MM/YYYY')
                ) AS pastsettlement
                FROM dual dl
            )
            SELECT * FROM result res WHERE
            res.todaysettlement IS NOT NULL OR res.pastsettlement IS NOT NULL
            """;

    public static final String JDBC_CURRENT_REFUND_SUMMARY = "SELECT SUM(REFUND_COUNT) AS refundCount," +
            " SUM(TOTAL_AVAILABLE_AMT) AS totalAvailableAmt," +
            " SUM(TOTAL_REFUND_AMT) AS totalRefundAmt," +
            " TO_CHAR(CREATED_DATE, 'DD MON YYYY') AS createdDate" +
            " FROM VIEW_REFUND_DASHBOARD_SUMMARY" +
            " WHERE MERCHANT_ID = :mId" +
            " AND TRUNC(CREATED_DATE) = TO_DATE(:currDate, 'DD/MM/YYYY')" +
            " GROUP BY CREATED_DATE";

    public static final String JDBC_TRANSACTION_PAYMODE = """
            SELECT TO_CHAR(TO_DATE(TRANSACTION_DATE, 'DD-MM-YY'), 'Mon-YYYY') as transactionDate,
            PAYMODE_CODE as paymodeCode, sum(SUCCESS_COUNT) as totalSuccessCount, sum(FAIL_COUNT)as totalFailCount,
            round(sum(SUCCESS_COUNT)/(sum(SUCCESS_COUNT)+sum(FAIL_COUNT)) * 100, 2) as successPercentage
            FROM VIEW_TRANSACTION_PAYMODE_DAILY_REPORT
            WHERE MID = :mId AND PAYMODE_CODE is NOT NULL AND
            TRANSACTION_DATE BETWEEN TO_DATE(:startDate, 'DD-MM-YYYY') AND TO_DATE(:endDate, 'DD-MM-YYYY')
            GROUP BY TO_CHAR(TO_DATE(TRANSACTION_DATE, 'DD-MM-YY'), 'Mon-YYYY'), PAYMODE_CODE
            Order By transactionDate desc
            """;

    public static final String JDBC_TRANSACTION_SUMMARY = """
            SELECT SUM(SUCCESS_COUNT) as totalSuccessCount, sum(FAIL_COUNT) as totalFailureCount,
            round(sum(SUCCESS_COUNT)/(sum(SUCCESS_COUNT)+sum(FAIL_COUNT)) * 100, 2) as successPercentage,
            round(sum(FAIL_COUNT)/(sum(SUCCESS_COUNT)+sum(FAIL_COUNT)) * 100, 2) as failPercentage
            FROM VIEW_TRANSACTION_DAILY_REPORT
            WHERE MID = :mId AND TRANSACTION_DATE BETWEEN TO_DATE(:startDate, 'DD-MM-YYYY') AND TO_DATE(:endDate, 'DD-MM-YYYY')
            """;

    public static final String JDBC_TRANSACTION_FAILURE_DETAILS = """ 
            SELECT 
            FAILURE_REASON as failureReason, sum(FAIL_COUNT) as failureCount FROM VIEW_TRANSACTION_DAILY_FAILURE_REPORT
            WHERE MID = :mId AND FAILURE_REASON is NOT NULL AND 
            TRANSACTION_DATE BETWEEN TO_DATE(:startDate, 'DD-MM-YYYY') AND TO_DATE(:endDate, 'DD-MM-YYYY') 
                         GROUP BY FAILURE_REASON
                         Order By failureReason desc""";


}