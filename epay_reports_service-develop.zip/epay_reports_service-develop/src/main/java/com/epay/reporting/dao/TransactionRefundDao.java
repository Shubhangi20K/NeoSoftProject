package com.epay.reporting.dao;

import com.epay.reporting.entity.view.TransactionWiseRefundFormat;
import com.epay.reporting.mapper.TransactionRefundMapper;
import com.epay.reporting.repository.view.TransactionRefundRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class TransactionRefundDao {

    private final TransactionRefundRepository transactionRefundRepository;
    private final TransactionRefundMapper transactionRefundMapper;

    public List<List<Object>> getTransactionRefundData(List<UUID> mpId) {
        List<TransactionWiseRefundFormat> transactionWiseRefundFormats = transactionRefundRepository.fetchTransactionRefund(mpId);
        return transactionWiseRefundFormats.stream().map(transactionRefundMapper::mapToList).collect(Collectors.toList());
    }
}
