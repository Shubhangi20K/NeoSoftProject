package com.epay.reporting.entity.view;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.math.BigDecimal;
import java.util.Date;

/**
 * Class Name: TransactionMIS
 * *
 * Description: This class is used to hold and represent the TransactionMis report data.
 * Author: Saurabh Mahto
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TransactionMIS {
    private String mId;
    private String merchantName;
    private Character merchantCategory;
    private String orderRefNumber;
    private String atrnNum;
    private Long instructionDateandTime;
    private  String currencyCode;
    private BigDecimal orderAmount;
    private BigDecimal totalFeeAbs;
    private String gstNumber;
    private Integer gatewayPostingAmount;
    private BigDecimal amountSettled;
    private BigDecimal availableRefundAmount;
    private String payMode;
    private String channelBank;
    private String gatewayTraceNumber;
    private String transactionStatus;
    private String remark;
    private String accessMedium;
    private String merchantRiskCategory;
    private String payProcId;
    private String payProcType;
    private String merchantAuthorize;
    private Long merchantAuthorizeDate;
    private String autoSettlement;
    private String bearableEntity;
    private String cin;
    private String failReason;
    private BigDecimal merchantFeeBearableAbs;
    private BigDecimal merchantGstBearableAbs;
    private BigDecimal customerFeeBearableAbs;
    private BigDecimal customerGstBearableAbs;
    private String sbuStatusDescription;
    private Date paymentSuccessDate;

}
