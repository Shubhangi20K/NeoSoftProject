package com.epay.reporting.dao;

import com.epay.reporting.entity.view.ReconFileDtls;
import com.epay.reporting.mapper.ReconFileDtlsMapper;
import com.epay.reporting.repository.view.ReconFileDtlsRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
/**
 * Class Name: TransactionMISDao
 * *
 * Class for accessing Operation-related data.
 * *
 * Author: Saurabh mahto(v1018841)
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */

@Service
@RequiredArgsConstructor
public class ReconFileDtlsDao {
    private final ReconFileDtlsRepository reconFileDtlsRepository;
    private final ReconFileDtlsMapper reconFileDtlsMapper;
    public List<List<Object>> getBadRecord(UUID rfId){
        List<ReconFileDtls> reconFileDtls= reconFileDtlsRepository.getReconFileDtls(rfId);
        return reconFileDtls.stream().map(reconFileDtlsMapper::mapToList).collect(Collectors.toList());
    }

    public List<List<Object>> getFailedReport(UUID rfId){
        List<ReconFileDtls> reconFileDtls= reconFileDtlsRepository.getFailedReconFileDtls(rfId);
        return reconFileDtls.stream().map(reconFileDtlsMapper::mapToList).collect(Collectors.toList());
    }
}
