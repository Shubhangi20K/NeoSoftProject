package com.epay.reporting.dao;

import com.epay.reporting.dto.ReportMasterDto;
import com.epay.reporting.entity.ReportMaster;
import com.epay.reporting.exception.ReportingException;
import com.epay.reporting.mapper.ReportMasterMapper;
import com.epay.reporting.repository.ReportMasterRepository;
import com.epay.reporting.util.ErrorConstants;
import com.epay.reporting.util.enums.Report;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.text.MessageFormat;
import java.util.List;
import java.util.UUID;

/**
 * Class Name: ReportMasterDao
 * Description: Data access layer for managing and fetching report master data such as report names and IDs.
 * Provides methods for retrieving all available reports, fetching report IDs by name, and fetching report names by ID.
 * Author: V1018344
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * Version: 1.0
 */
@Component
@RequiredArgsConstructor
public class ReportMasterDao {

    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());

    private final ReportMasterRepository reportMasterRepository;
    private final ReportMasterMapper reportMasterMapper;


    /**
     * Method Name: getAllReportNames
     * Description: Fetches a list of all available report names.
     * Logs the process of fetching the report list and returns a list of ReportMasterDto.
     * @return List<ReportMasterDto> - List of ReportMasterDto objects representing all reports.
     */
    public List<ReportMasterDto> getAllReportNames() {
        log.info("Fetching all available report names.");
        return reportMasterMapper.mapEntityListToDtoList(reportMasterRepository.findAll());
    }


    /**
     * Method Name: getReportIdByName
     * Description: Fetches the report ID based on the provided report name. If the report is not found, an exception is thrown.
     * Logs the process of fetching the report ID and handles potential errors.
     * @param name - The name of the report.
     * @return UUID - The unique ID of the report.
     * @throws ReportingException - If the report is not found.
     */
    public UUID getReportIdByName(Report name){
        log.info("Fetching report ID for report name: {}", name);
        ReportMaster reportMaster = reportMasterRepository.findByName(name).orElseThrow(() ->
                new ReportingException(ErrorConstants.NOT_FOUND_ERROR_CODE, MessageFormat.format(ErrorConstants.NOT_FOUND_ERROR_MESSAGE, "report")));
        log.info("Found report ID: {}", reportMaster.getId());
        return reportMaster.getId();
    }

    /**
     * Method Name: getReportNameById
     * Description: Fetches the report name based on the provided report ID. If the report is not found, an exception is thrown.
     * Logs the process of fetching the report name and handles potential errors.
     * @param reportId - The unique ID of the report.
     * @return Report - The name of the report.
     * @throws ReportingException - If the report is not found.
     */
    public Report getReportNameById(UUID reportId){
        log.info("Fetching report name for report ID: {}", reportId);
        ReportMaster reportMaster = reportMasterRepository.findById(reportId).orElseThrow(() ->
                new ReportingException(ErrorConstants.NOT_FOUND_ERROR_CODE, MessageFormat.format(ErrorConstants.NOT_FOUND_ERROR_MESSAGE, "Report")));
        log.info("Found report name: {}", reportMaster.getName());
        return reportMaster.getName();
    }

}
