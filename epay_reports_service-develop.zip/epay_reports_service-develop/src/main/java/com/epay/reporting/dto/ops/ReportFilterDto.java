package com.epay.reporting.dto.ops;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.UUID;
/**
 * Class Name: ReportFilterDto
 * Description: This class serves as a Data Transfer Object (DTO) for managing report-related details within
 * the application.
 * Author: Saurabh Mahto(V1018841)
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * Version:1.0
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ReportFilterDto {
    private UUID rfId;
    private List<UUID> mpIdList;
    @JsonProperty("mId")
    private String mId;
    private UUID payoutId;
    private Long toDate;
    private Long fromDate;
}
