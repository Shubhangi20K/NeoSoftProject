package com.epay.reporting.mapper;
import com.epay.reporting.dto.ReportMasterDto;
import com.epay.reporting.entity.ReportMaster;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;

import java.util.List;

/**
 * Class Name: ReportMasterMapper
 * Description:This interface provides the mapping logic for converting between different data transfer objects (DTOs),
 * requests, responses, and entities related to the Report Schedule Management module.
 * It uses MapStruct annotations to automatically generate implementation classes for the mapping functions.
 * The interface includes custom mappings for fields such as report, format, and frequency, converting string values
 * into specific enum types (Report, ReportFormat, and Frequency).
 * It also handles mapping timestamps and other attributes between entities and DTOs.
 * Author: V1018344
 * Copyright (c) 2025 [State Bank of India]
 * ALl rights reserved
 * *
 * Version: 1.0
 */

@Mapper(builder = @Builder(disableBuilder = true), componentModel = "spring")
public interface ReportMasterMapper {

    List<ReportMasterDto> mapEntityListToDtoList(List<ReportMaster> report);

}
