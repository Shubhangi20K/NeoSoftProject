package com.epay.reporting.model.response;


import com.epay.reporting.util.enums.Report;
import com.epay.reporting.util.enums.ReportFormat;
import com.epay.reporting.util.enums.ReportStatus;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

@AllArgsConstructor
@Getter
@Setter
@ToString
@Builder
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ReportManagementResponse {

    private Report report;
    private String mId;
    private Long durationFromDate;
    private Long durationToDate;
    private ReportFormat format;
    private ReportStatus status;
    private String filePath;
    private String remarks;
    private Long requestStateTime;
    private Long executionTime;
}
