package com.epay.reporting.repository.view;

import com.epay.reporting.entity.view.RefundSummaryReport;
import com.epay.reporting.exception.ReportingException;
import com.epay.reporting.util.DateTimeUtils;
import com.epay.reporting.util.queries.TransactionDashboardQueries;
import lombok.RequiredArgsConstructor;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.text.MessageFormat;
import java.util.List;

import static com.epay.reporting.util.ErrorConstants.*;
import static com.epay.reporting.util.ReportingConstant.MID;
import static com.epay.reporting.util.ReportingConstant.REFUND;

@Repository
@RequiredArgsConstructor
public class RefundSummaryRepository {

    private final NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    /**
     * Fetches Refund data for a given merchant ID for current date.
     *
     * @param mId the merchant ID
     * @return a list of RefundSummaryReport objects representing the Refund summary
     */
    public List<RefundSummaryReport> getRefundSummaryForCurrentDate(String mId) {
        try {
            MapSqlParameterSource parameters = new MapSqlParameterSource();
            parameters.addValue(MID, mId);
            parameters.addValue(CURR_DATE, DateTimeUtils.getDate(DateTimeUtils.getCurrentTimeInMills(), DateTimeUtils.FORMATTER_DD_MM_YYYY));
            return namedParameterJdbcTemplate.query(TransactionDashboardQueries.JDBC_CURRENT_REFUND_SUMMARY, parameters, new BeanPropertyRowMapper<>(RefundSummaryReport.class));
        } catch (EmptyResultDataAccessException e) {
            throw new ReportingException(NOT_FOUND_ERROR_CODE, MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, REFUND));
        }
    }
}
