package com.epay.reporting.entity.view;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SettlementSummaryReport {

    private BigDecimal todaySettlement;
    @Builder.Default
    private BigDecimal pastSettlement = BigDecimal.valueOf(0.00);
}
