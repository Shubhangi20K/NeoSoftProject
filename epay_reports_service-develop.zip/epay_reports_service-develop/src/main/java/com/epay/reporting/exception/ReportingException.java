package com.epay.reporting.exception;

import com.epay.reporting.dto.ErrorDto;
import lombok.*;

import java.util.List;

/**
 * Class Name: ReportingException
 * *
 * Description: This class defines a custom runtime exception specific to the reporting module of the project.
 * It extends the `RuntimeException` class to provide custom exception handling for reporting-related errors.
 * The exception can be thrown when there are issues during report generation, validation, or other reporting processes.
 * The class uses Lombok annotations to automatically generate getter, setter, equals, hashCode, builder, and constructor methods.
 * Author: Bhoopendra Rajput
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@NoArgsConstructor
@Builder
@AllArgsConstructor
public class ReportingException extends RuntimeException {
    private String errorCode;
    private String errorMessage;
    private List<ErrorDto> errorMessages;

    /**
     * Parametrized constructor taking errorcode and errorMessage
     * @param errorCode String
     * @param errorMessage String
     */
    public ReportingException(String errorCode, String errorMessage) {
        super(errorMessage);
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
    }

    /**
     * Parametrized constructor taking List of ErrorDTO
     * @param errorMessages List<ErrorDto>
     */
    public ReportingException(List<ErrorDto> errorMessages) {
        this.errorMessages = errorMessages;
    }

}
