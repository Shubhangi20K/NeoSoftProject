package com.epay.reporting.util.enums;
import com.epay.reporting.exception.ReportingException;
import com.epay.reporting.util.ErrorConstants;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

import java.text.MessageFormat;
import java.util.Arrays;

/**
 * Name: ReportStatus
 * Description: Represents the various statuses a report can have (e.g., to be generated, generated, generation started, generation failed).
 * *
 * Author: Bhoopendra Rajput
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Getter
@RequiredArgsConstructor
public enum ReportStatus {
    TO_BE_GENERATE("TO BE GENERATE"), GENERATED("GENERATED"), GENERATION_STARTED("GENERATION STARTED"), GENERATION_FAILED("GENERATION FAILED");
    private final String name;
    public static ReportStatus getName(String name) {
        return Arrays.stream(values()).filter(rt -> rt.name().equalsIgnoreCase(name)).findFirst().orElseThrow(() -> new ReportingException(ErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(ErrorConstants.INVALID_ERROR_MESSAGE, "ReportStatus", "Valid ReportStatus are " + Arrays.toString(ReportStatus.values()))));
    }
}
