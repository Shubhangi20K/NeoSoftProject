package com.epay.reporting.util.enums;


/**
 * Class Name: InterfaceType
 * Description:
 * Copyright (c) [2025] [State Bank of India]
 * All rights reserved.
 * Author:@V0000001(Shilpa Kothre)
 * Version:1.0
 */
public enum InterfaceType {

    REPORT_RECON_REQUEST_TOPIC,
    REPORT_RECON_CONFIRMATION_TOPIC,

    REPORT_GENERATION_TOPIC,
    REPORT_ALERT_GENERATION_TOPIC,
    REPORT_TOPIC,


}