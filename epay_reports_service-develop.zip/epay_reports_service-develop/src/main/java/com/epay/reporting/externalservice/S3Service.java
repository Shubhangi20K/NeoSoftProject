package com.epay.reporting.externalservice;

import com.epay.reporting.config.aws.S3Config;
import com.epay.reporting.exception.ReportingException;
import com.epay.reporting.util.ErrorConstants;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import software.amazon.awssdk.core.ResponseInputStream;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.*;

import java.io.File;
import java.io.IOException;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

/**
 * Class Name: S3Service
 * Description: The S3Service class provides functionalities to interact with AWS S3 for uploading, downloading, and listing files.
 * It supports uploading files as a File, byte array, or MultipartFile, and handles the S3 client operations like put, get, and list objects.
 * It also provides error handling, logging, and custom exception throwing in case of S3 operation failures.
 * Author: Bhoopendra Rajput
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * Version: 1.0
 */
@RequiredArgsConstructor
@Service
public class S3Service {
    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    private final S3Config s3Config;
    private final S3Client s3Client;

    /**
     * Uploads a file to S3 using the provided File object.
     * @param file the file to upload
     * @return the S3 key for the uploaded file
     */
    private String uploadFile(File file, boolean isMerchantReport) {
        String key = System.currentTimeMillis() + "-" + file.getName();
        String bucket = isMerchantReport ? s3Config.getReportBucket() : s3Config.getOpsBucket();
        log.info("Uploading file [{}] to bucket: {}", key, bucket);
        try {
            PutObjectRequest objectRequest = PutObjectRequest.builder().bucket(bucket).key(file.getName()).build();
            s3Client.putObject(objectRequest, RequestBody.fromFile(file));
            return key;
        } catch (S3Exception e) {
            log.error("S3 - Failed to upload file:{} on s3 with error:{}", key, e.getMessage());
            throw new ReportingException(ErrorConstants.GENERIC_ERROR_CODE, e.getMessage());
        }
    }

    /**
     * Uploads a file to S3 using byte array content.
     * @param fileName the name of the file
     * @param fileContent the content of the file as byte array
     * @return the S3 key for the uploaded file
     */
    public String uploadFile(String fileName, byte[] fileContent,boolean isMerchantReport) {
        String key = System.currentTimeMillis() + "-" + fileName;
        String bucket = isMerchantReport ? s3Config.getReportBucket() : s3Config.getOpsBucket();
        log.info("Uploading file [{}] to bucket: {}", key, bucket);
        try {
            PutObjectRequest objectRequest = PutObjectRequest.builder().bucket(bucket).key(key).build();
            s3Client.putObject(objectRequest, RequestBody.fromBytes(fileContent));
            return key;
        } catch (S3Exception e) {
            log.error("S3 - Failed to upload file:{} on s3 with error:{}", key, e.getMessage());
            throw new ReportingException(ErrorConstants.GENERIC_ERROR_CODE, e.getMessage());
        }
    }

    /**
     *
     * @param file MultipartFile
     * @return
     */
    public String uploadFile(MultipartFile file,boolean isMerchantReport) {
        String key = System.currentTimeMillis() + "-" + file.getName();
        String bucket = isMerchantReport ? s3Config.getReportBucket() : s3Config.getOpsBucket();
        log.info("Uploading file [{}] to bucket: {}", key, bucket);
        try {
            PutObjectRequest objectRequest = PutObjectRequest.builder()
                    .bucket(s3Config.getReportBucket())
                    .key(key)
                    .contentType(file.getContentType())
                    .contentLength(file.getSize())
                    .build();
            PutObjectResponse putObjectResponse= s3Client.putObject(objectRequest, RequestBody.fromInputStream(file.getInputStream(), file.getSize()));
            log.info("putObjectResponse: {}", putObjectResponse);
            return key;
        } catch (S3Exception | IOException e) {
            log.error("S3 - Failed to upload file:{} on s3 with error:{}", key, e.getMessage());
            throw new ReportingException(ErrorConstants.GENERIC_ERROR_CODE, e.getMessage());
        }
    }

    /**
     * Download file content to HttpServletRepose.
     * @param response HttpServletResponse
     * @param fileName String
     */
    public void downloadFile(HttpServletResponse response, String fileName) {
        try {
            GetObjectRequest getObjectRequest = GetObjectRequest.builder().bucket(s3Config.getReportBucket()).key(fileName).build();
            ResponseInputStream<GetObjectResponse> object = s3Client.getObject(getObjectRequest);
            object.transferTo(response.getOutputStream());
            response.getOutputStream().close();
        } catch (S3Exception | IOException e) {
            log.error("S3 - Failed to read file:{} from s3 with error: {}", fileName, e.getMessage());
            Object[] messageArgs = {fileName};
            throw new ReportingException(ErrorConstants.NOT_FOUND_ERROR_CODE, MessageFormat.format(ErrorConstants.NOT_FOUND_ERROR_MESSAGE, messageArgs));
        }
    }

    /**
     * Return list of S3 uploaded file keys.
     * @return List
     */
    public List<String> listObjects() {
        List<String> fileList = new ArrayList<>();
        try {
            ListObjectsV2Request listObjectsV2Request = ListObjectsV2Request.builder()
                    .bucket(s3Config.getReportBucket())
                    .build();
            log.info("s3Client : {}", s3Client);
            log.info("listObjectsV2Request :{}", listObjectsV2Request);
            ListObjectsV2Response listObjectsV2Response = s3Client.listObjectsV2(listObjectsV2Request);

            listObjectsV2Response.contents().forEach(s3Object -> {
                log.info("Object Key :{}", s3Object.key());
                fileList.add(s3Object.toString());
            });
        } catch (S3Exception e) {
            log.info("S3 - Failed to get list object from s3 with error: {}", e.getMessage());
            throw new ReportingException(ErrorConstants.GENERIC_ERROR_CODE, e.getMessage());
        }
        return fileList;
    }
}