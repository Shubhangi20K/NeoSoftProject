package com.epay.reporting.service;

import com.epay.reporting.externalservice.MerchantServiceClient;
import com.epay.reporting.model.response.ReportingResponse;
import com.epay.reporting.util.ReportingConstant;
import com.sbi.epay.authentication.model.EPayPrincipal;
import com.sbi.epay.authentication.service.AuthenticationUserService;
import com.sbi.epay.authentication.util.EPayAuthenticationConstant;
import com.sbi.epay.authentication.util.enums.TokenType;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.util.Optional;

/**
 * Class Name: SecurityService
 * *
 * Description: This service class handles user authentication and token validation
 * for the merchant system. It interacts with the `MerchantServiceClient` to validate
 * merchant users and tokens. It implements the `AuthenticationUserService` interface
 * to load users based on their credentials and check the validity of their tokens.
 * It also provides logging functionality to track the flow of the authentication process.
 * *
 * Author: Bhoopendra Rajput
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Service
@RequiredArgsConstructor
public class SecurityService implements AuthenticationUserService {
    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    private final MerchantServiceClient merchantServiceClient;

    /**
     * Method Name: loadUserByUserName
     * <p>
     * Description: This method extracts the username and token type from the provided
     * `userNameWithTokenType` string, validates the merchant user using the `merchantServiceClient`,
     * and returns an `EPayPrincipal` object if the validation is successful. It logs the
     * process for debugging and traceability. If validation fails, an empty `Optional` is returned.
     *
     * @param userNameWithTokenType String - A string that contains the username and token type,
     *                              separated by a predefined delimiter.
     * @return Optional<EPayPrincipal> - An `Optional` containing the `EPayPrincipal` if the user is valid,
     * or an empty `Optional` if the user is invalid.
     */
    @Override
    public Optional<EPayPrincipal> loadUserByUserName(String userNameWithTokenType) {
        log.info("Attempting to load user by username and token type: {}", userNameWithTokenType);

        String[] users = userNameWithTokenType.split(EPayAuthenticationConstant.JOINER);
        if (users.length > 0 && StringUtils.isNotEmpty(users[1]) && TokenType.USER.equals(TokenType.valueOf(users[1]))) {
            log.info("Token type is USER. Validating merchant user: {}", users[0]);
            ReportingResponse<String> response = merchantServiceClient.validateMerchantUser(users[0]);
            if (response.getStatus() == ReportingConstant.RESPONSE_SUCCESS && CollectionUtils.isEmpty(response.getErrors())) {
                log.info("Merchant user validation successful for: {}", users[0]);
                EPayPrincipal authenticateEntity = new EPayPrincipal();
                authenticateEntity.setAuthenticationId(users[0]);
                return Optional.of(authenticateEntity);
            }
        }
        return Optional.empty();
    }


    /**
     * Method Name: isTokenInValid
     * <p>
     * Description: This method checks if the provided token is valid based on the token type.
     * It validates the token type, and if it is a USER token, it calls the `merchantServiceClient`
     * to validate the token. If the token is invalid, it returns true; otherwise, it returns false.
     * It logs the process for better traceability and debugging.
     *
     * @param token     String - The token to be validated.
     * @param tokenType String - The type of the token (e.g., USER).
     * @return boolean - Returns `true` if the token is invalid, `false` if the token is valid.
     */
    @Override
    public boolean isTokenInValid(String token, String tokenType) {
        log.info("Checking token validity for token: {} and tokenType: {}", token, tokenType);
        if (StringUtils.isNotEmpty(tokenType) && TokenType.USER.equals(TokenType.valueOf(tokenType))) {
            log.info("Token type is USER. Validating merchant token: {}", token);
            ReportingResponse<String> response = merchantServiceClient.validateMerchantToken(token);
            return !ObjectUtils.isNotEmpty(response) || response.getStatus() != ReportingConstant.RESPONSE_SUCCESS || !CollectionUtils.isEmpty(response.getErrors());
        }
        log.warn("Invalid token type: {}", tokenType);
        return true;
    }
}
