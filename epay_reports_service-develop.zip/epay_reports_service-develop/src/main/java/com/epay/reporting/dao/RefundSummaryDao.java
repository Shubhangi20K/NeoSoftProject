package com.epay.reporting.dao;

import com.epay.reporting.entity.view.RefundSummaryReport;
import com.epay.reporting.repository.view.RefundSummaryRepository;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class RefundSummaryDao {

    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    private final RefundSummaryRepository refundSummaryRepository;

    /**
     * Fetches refund summary for a given merchant ID for current date.
     * @param mId - Merchant ID
     * @return List of refund summary data
     */
    public List<RefundSummaryReport> getDailyRefundSummary(String mId) {
        log.info("Fetching refund summary data for MerchantId: {}", mId);
        return refundSummaryRepository.getRefundSummaryForCurrentDate(mId);
    }
}
