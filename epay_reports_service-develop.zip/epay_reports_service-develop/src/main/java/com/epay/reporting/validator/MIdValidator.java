package com.epay.reporting.validator;

import com.epay.reporting.exception.ValidationException;
import com.epay.reporting.externalservice.MerchantServiceClient;
import com.epay.reporting.model.response.ReportingResponse;
import com.epay.reporting.util.ReportingConstant;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.ArrayList;

import static com.epay.reporting.util.ErrorConstants.*;

/**
 * Class Name: MIdValidator
 * *
 * Description: The MIdValidator class is responsible for validating merchant IDs (MId) to ensure they have the correct access or are active.
 * It interacts with the MerchantServiceClient to validate MIds and throws a ValidationException if any validation fails.
 * *
 * Author: Bhoopendra Rajput
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Component
@RequiredArgsConstructor
public class MIdValidator extends BaseValidator {
    private static final LoggerUtility log = LoggerFactoryUtility.getLogger(MIdValidator.class);
    private final MerchantServiceClient merchantServiceClient;

    /**
     * Validates that the provided Merchant ID (MId) has valid value, and it is active.
     * @param mId - The Merchant ID to validate.
     * @throws ValidationException if the Merchant ID is not active or if the validation fails.
     */
    public void validateActiveMId(String mId) {
        validateMIdValue(mId);
        ReportingResponse<String> response = merchantServiceClient.validateActiveMIdAccess(mId);
        if (ReportingConstant.RESPONSE_FAILURE == response.getStatus()) {
            log.error("Failed to validate active MId '{}'. Errors: {}", mId, response.getErrors());
            throw new ValidationException(response.getErrors());
        }
    }

    /**
     * Validates a report management request by checking mandatory fields and their values.
     * Also validates the MId by merchant-service.
     * @param mId The request containing mId.
     * @throws ValidationException if any validation fails.
     */
    public void validateMid(String mId) {
        log.debug("Request Validation start for {}", mId);
        errorDtoList = new ArrayList<>();
        validateMIdValue(mId);
        validateMIdAccess(mId);
        log.debug("Request Validation end for {}", mId);
    }

    /**
     * Validates that the provided Merchant ID (MId) has access.
     *
     * @param mId - The Merchant ID to validate.
     * @throws ValidationException if the Merchant ID does not have access or if the validation fails.
     */
    public void validateMIdAccess(String mId) {
        validateMIdValue(mId);
        ReportingResponse<String> response = merchantServiceClient.validateMIdAccess(mId);
        if (ReportingConstant.RESPONSE_FAILURE == response.getStatus()) {
            log.error("Failed to validate MId '{}'. Errors: {}", mId, response.getErrors());
            throw new ValidationException(response.getErrors());
        }
    }

    /**
     * Validates a report management request by their values.
     * Also validates the MId.
     *
     * @param mId The request containing mId.
     * @throws ValidationException if any validation fails.
     */
    public void validateMIdValue(String mId) {
        errorDtoList = new ArrayList<>();
        checkMandatoryField(mId, MID);
        throwIfErrors();
        checkForLeadingTrailingAndSingleSpace(mId, MID);
        throwIfErrors();
        validateFixedFieldLength(mId, MID_LENGTH, MID);
        throwIfErrors();
        validateFieldWithRegex(mId, MID_REGEX, MID, INVALID_ERROR_MESSAGE, INVALID_FORMAT);
        throwIfErrors();
    }

}