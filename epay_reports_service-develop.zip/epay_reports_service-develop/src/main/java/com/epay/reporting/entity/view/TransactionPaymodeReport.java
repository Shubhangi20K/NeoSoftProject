package com.epay.reporting.entity.view;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * Class Name: TransactionPaymodeReport
 * Description: This class is used to hold and represent the data related to the payment modes
 * used in transactions. It includes information such as the type of payment mode (e.g., credit card,
 * debit card, online transfer), transaction details, payment status, and other relevant attributes
 * necessary for generating reports about the distribution and performance of various payment methods
 * within the system. This class serves as a data transfer object (DTO) for processing and presenting
 * payment mode data in the reporting context.
 * Author: Ranu Jain
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * Version: 1.0
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TransactionPaymodeReport {

    private String paymodeCode;
    private Long totalSuccessCount;
    private Long totalFailCount;
    private Double successPercentage;
    private String transactionDate;
}
