package com.epay.reporting.mapper;

import com.epay.reporting.entity.view.RefundReport;
import org.apache.commons.lang3.StringUtils;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;

import java.math.BigDecimal;
import java.util.List;

import static org.thymeleaf.util.ObjectUtils.nullSafe;

@Mapper(builder = @Builder(disableBuilder = true), componentModel = "spring")
public interface RefundMapper {
    default List<Object> mapToList(RefundReport refundReport) {
        return List.of(nullSafe(refundReport.getMerchantOrderID(), StringUtils.EMPTY), nullSafe(refundReport.getSbiEPayOrderID(), StringUtils.EMPTY), nullSafe(refundReport.getMerchantPostingAmount(), BigDecimal.ZERO), nullSafe(refundReport.getGatewayPostingAmount(), BigDecimal.ZERO), nullSafe(refundReport.getAtrn(), StringUtils.EMPTY), nullSafe(refundReport.getTransactionStatus(), StringUtils.EMPTY), nullSafe(refundReport.getTransactionSuccessDateAndTime(), StringUtils.EMPTY), nullSafe(refundReport.getArrn(), StringUtils.EMPTY), nullSafe(refundReport.getRefundType(), StringUtils.EMPTY), nullSafe(refundReport.getRefundCurrency(), StringUtils.EMPTY), nullSafe(refundReport.getRefundAmount(), BigDecimal.ZERO), nullSafe(refundReport.getRefundBookingDate(), StringUtils.EMPTY), nullSafe(refundReport.getRefundProcessedDate(), StringUtils.EMPTY), nullSafe(refundReport.getRefundStatus(), StringUtils.EMPTY), nullSafe(refundReport.getPaymentGateway(), StringUtils.EMPTY), nullSafe(refundReport.getPaymentMode(), StringUtils.EMPTY), nullSafe(refundReport.getAmountRefunded(), BigDecimal.ZERO), nullSafe(refundReport.getFurtherRefundAllowed(), BigDecimal.ZERO), nullSafe(refundReport.getPendingAmountforRefund(), BigDecimal.ZERO), nullSafe(refundReport.getRemark(), StringUtils.EMPTY));
    }
}
