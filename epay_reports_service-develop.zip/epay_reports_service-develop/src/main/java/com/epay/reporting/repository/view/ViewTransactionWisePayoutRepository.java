package com.epay.reporting.repository.view;


import com.epay.reporting.entity.view.TransactionWisePayoutFormat;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

import static com.epay.reporting.util.queries.ReconQueries.GET_TRANSACTION_WISE_PAYOUT;

/**
 * Class Name: ViewTransactionWisePayoutRepository
 * *
 * Description: This class is responsible for interacting with the database to retrieve Transaction wise payout records .
 * Author: Saurabh mahto(V1018841)
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * Version:1.0
 */

@Repository
@RequiredArgsConstructor
public class ViewTransactionWisePayoutRepository {
    private final NamedParameterJdbcTemplate jdbcTemplate;

    public List<TransactionWisePayoutFormat> fetchTransactionMerchantPayouts(List<UUID> mpId) {
        List<String> mpIdString = mpId.stream().map(id -> id.toString().replace("-", "").toUpperCase()).toList();
        MapSqlParameterSource params = new MapSqlParameterSource();
        params.addValue("mpId", mpIdString);
        return jdbcTemplate.query(GET_TRANSACTION_WISE_PAYOUT, params, new BeanPropertyRowMapper<>(TransactionWisePayoutFormat.class));
    }
}
