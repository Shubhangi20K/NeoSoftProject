package com.epay.reporting.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;
/**
 * Class Name: ReportResponseDto
 * Description: This class serves as a Data Transfer Object (DTO) for managing report-related details within
 * the application.
 * Author: Saurabh Mahto(V1018841)
 *  <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * Version:1.0
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ReportResponseDto {
    private UUID rrId;
    private String s3FilePath;
}
