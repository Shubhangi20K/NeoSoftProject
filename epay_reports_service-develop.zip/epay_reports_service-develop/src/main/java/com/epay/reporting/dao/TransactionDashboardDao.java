package com.epay.reporting.dao;

import com.epay.reporting.entity.view.RecentTransactionReport;
import com.epay.reporting.entity.view.TransactionFailureSummaryReport;
import com.epay.reporting.entity.view.TransactionPaymodeReport;
import com.epay.reporting.entity.view.TransactionSummaryReport;
import com.epay.reporting.model.request.RecentTransactionRequest;
import com.epay.reporting.model.request.TransactionPayModeRequest;
import com.epay.reporting.model.request.TransactionSummaryRequest;
import com.epay.reporting.repository.view.TransactionDashboardRepository;
import com.epay.reporting.util.enums.Frequency;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Class Name: TransactionDashboardDao
 * *
 * Class for accessing transaction dashboard-related data, such as trends, paymode reports, and failure summaries.
 * *
 * Author: Bhoopendra Rajput
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Component
@RequiredArgsConstructor
public class TransactionDashboardDao {
    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    private final TransactionDashboardRepository transactionDashboardRepository;

    /**
     * Fetches transaction trends (daily, weekly, or monthly) for a given merchant ID and frequency.
     * @param mId - Merchant ID
     * @param frequency - Frequency of the trends
     * @return List of transaction trend data
     */
    public List<TransactionSummaryReport> getTransactionTrends(String mId, Frequency frequency) {
        log.info("Fetching transaction trends for merchant ID: {} with frequency: {}", mId, frequency);
        return transactionDashboardRepository.getTransactionDailyTrendsByMidAndFrequency(mId, frequency);
    }

    /**
     * Fetches recent transaction (daily, or monthly) for a given merchant ID, frequency and time period.
     * @param mId - Merchant ID
     * @return List of recent transaction data
     */
    public Page<RecentTransactionReport> getRecentTransactionSummary(String mId, RecentTransactionRequest recentTransactionRequest, Pageable pageable) {
        log.info("Fetching recent transaction details for merchant ID: {} with frequency: {}", mId, recentTransactionRequest);
        if (Frequency.MONTHLY.name().equalsIgnoreCase(recentTransactionRequest.getFrequency())) {
            return transactionDashboardRepository.getRecentTransactionSummaryMonthly(mId, recentTransactionRequest, pageable);
        } else {
            return transactionDashboardRepository.getRecentTransactionSummaryDaily(mId, recentTransactionRequest, pageable);
        }
    }

    /**
     * Retrieves a transaction pay mode report for a merchant within a specified date range.
     * @param mId - Merchant ID
     * @param transactionPayModeRequest - Request containing date range
     * @return List of pay mode details
     */
    public List<TransactionPaymodeReport> getTransactionPayModeReport(String mId, TransactionPayModeRequest transactionPayModeRequest) {
        log.info("Fetching transaction pay mode report for merchant ID: {} from {} to {}", mId, transactionPayModeRequest.getFromDate(), transactionPayModeRequest.getToDate());
        return transactionDashboardRepository.getTransactionPayModeReport(mId, transactionPayModeRequest.getFromDate(), transactionPayModeRequest.getToDate());
    }

    /**
     * Fetches the transaction summary report for a given merchant ID and date range, including failure percentages.
     * @param mId - Merchant ID
     * @param transactionSummaryRequest - Request containing date range
     * @return Transaction summary report with failure details
     */
    public List<TransactionSummaryReport> getTransactionSummaryReport(String mId, TransactionSummaryRequest transactionSummaryRequest) {
        log.info("Fetching transaction summary report for merchant ID: {} from {} to {}", mId, transactionSummaryRequest.getFromDate(), transactionSummaryRequest.getToDate());
        List<TransactionSummaryReport> transactionSummaryReports = new ArrayList<>();
        Optional<TransactionSummaryReport> transactionSummaryDataOptional = transactionDashboardRepository.getTransactionSummaryReport(mId, transactionSummaryRequest.getFromDate(), transactionSummaryRequest.getToDate());
        transactionSummaryDataOptional.ifPresentOrElse(transactionSummaryReport -> {
            List<TransactionFailureSummaryReport> transactionDailyFailures = transactionDashboardRepository.getTransactionFailureSummaryReport(mId, transactionSummaryRequest.getFromDate(), transactionSummaryRequest.getToDate());
            transactionDailyFailures.forEach(transactionDailyFailure -> transactionDailyFailure.setFailurePercentage(BigDecimal.valueOf((transactionDailyFailure.getFailureCount() * 100) / transactionSummaryReport.getTotalFailureCount()).setScale(2, RoundingMode.HALF_UP).doubleValue()));
            transactionSummaryReport.setTransactionDailyFailure(transactionDailyFailures);
            log.info("Transaction summary report for merchant ID: {} fetched successfully.", mId);
            transactionSummaryReports.add(transactionSummaryReport);
        }, () -> log.info("No transaction summary record found for mId: {}, fromDate: {} and toDate: {}", mId, transactionSummaryRequest.getFromDate(), transactionSummaryRequest.getToDate()));
        return transactionSummaryReports;
    }
}
