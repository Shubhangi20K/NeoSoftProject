package com.epay.reporting.config;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

/**
 * Class Name: ReportingConfig
 * Description: The ReportingConfig class reads the required application properties and defines custom beans
 * for the reporting functionality. It ensures that the application is properly configured to
 * handle reporting tasks, such as setting up data sources or other reporting-related beans.
 * Author: Bhoopendra Rajput
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * Version:1.0
 */
@Data
@Configuration
public class ReportingConfig {

    @Value("${scheduled.report.execution.window:30}")
    private int reportScheduleExecutionWindow;

    @Value("${transaction.report.page.size}")
    private int reportPageSize;

}