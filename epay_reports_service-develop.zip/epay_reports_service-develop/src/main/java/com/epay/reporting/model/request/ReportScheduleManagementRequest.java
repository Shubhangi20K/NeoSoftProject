package com.epay.reporting.model.request;


import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotBlank;
import lombok.*;

import static com.epay.reporting.util.ErrorConstants.HIBERNATOR_REQUIRED_ERROR_MESSAGE;

/**
 * Class Name: ReportScheduleManagementRequest
 * Description: This class represents a request for managing scheduled reports. It contains details about the
 * report to be scheduled, including the report name, merchant ID, frequency, format, and the time for execution.
 * Author: Bhoopendra Rajput
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * Version: 1.0
 */
@AllArgsConstructor
@Getter
@Setter
@ToString
@Builder
@NoArgsConstructor
public class ReportScheduleManagementRequest {

    @NotBlank(message = HIBERNATOR_REQUIRED_ERROR_MESSAGE)
    private String report;
    @NotBlank(message = HIBERNATOR_REQUIRED_ERROR_MESSAGE)
    @JsonProperty("mId")
    private String mId;
    @NotBlank(message = HIBERNATOR_REQUIRED_ERROR_MESSAGE)
    private String frequency;
    @NotBlank(message = HIBERNATOR_REQUIRED_ERROR_MESSAGE)
    private String format;
    @NotBlank(message = HIBERNATOR_REQUIRED_ERROR_MESSAGE)
    private String scheduleExecutionTime;
    @NotBlank(message = HIBERNATOR_REQUIRED_ERROR_MESSAGE)
    private String scheduleExecutionDate;
    @NotBlank(message = HIBERNATOR_REQUIRED_ERROR_MESSAGE)
    private String reportDuration;
}
