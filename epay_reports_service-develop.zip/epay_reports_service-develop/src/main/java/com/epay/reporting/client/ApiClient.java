package com.epay.reporting.client;

import com.epay.reporting.exception.ReportingException;
import com.epay.reporting.exception.ValidationException;
import com.epay.reporting.model.response.ReportingResponse;
import com.epay.reporting.util.EPayIdentityUtil;
import com.epay.reporting.util.ReportingConstant;
import com.sbi.epay.authentication.util.EPayAuthenticationConstant;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import io.netty.handler.ssl.SslContextBuilder;
import io.netty.handler.ssl.util.InsecureTrustManagerFactory;
import lombok.RequiredArgsConstructor;
import org.slf4j.MDC;
import org.springframework.core.NestedRuntimeException;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.UnsupportedMediaTypeException;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientRequestException;
import reactor.netty.http.client.HttpClient;

import java.net.URI;
import java.text.MessageFormat;

import static com.epay.reporting.util.ErrorConstants.*;
import static com.sbi.epay.authentication.util.EPayAuthenticationConstant.BEARER;
import static com.sbi.epay.authentication.util.EPayAuthenticationConstant.X_CORRELATION_ID;
import org.springframework.util.CollectionUtils;

/**
 * Class Name: ApiClient
 * Description:The ApiClient class is responsible for interacting with external APIs using WebClient.
 * It provides methods to configure and send HTTP requests to a specified base URL.
 * Author: Bhoopendra Rajput
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * Version: 1.0
 */
@RequiredArgsConstructor
public class ApiClient {
    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private final String baseUrl;
    private final WebClient webClient;

    /**
     * Constructor to initialize the ApiClient with the provided base URL.
     * It also sets up the WebClient instance with the base URL for making HTTP requests.
     *
     * @param baseUrl The base URL for the API client
     */
    public ApiClient(String baseUrl) {
        this.baseUrl = baseUrl;
        this.webClient = WebClient.builder().clientConnector(new ReactorClientHttpConnector(HttpClient.create().secure(t -> t.sslContext(SslContextBuilder.forClient().trustManager(InsecureTrustManagerFactory.INSTANCE))))).baseUrl(baseUrl).build();
    }

    protected String getBaseUrl() {
        return baseUrl;
    }

    protected WebClient getWebClient() {
        return webClient;
    }

    /**
     * Prepare HTTP headers for making API requests.
     * This includes setting the content type, accept type, and adding correlation ID from MDC.
     *
     * @return The HTTP headers prepared for the request
     */
    protected HttpHeaders prepareHttpHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);
        headers.add(X_CORRELATION_ID, MDC.get(EPayAuthenticationConstant.CORRELATION_ID));
        return headers;
    }

    /**
     *
     * @param urlPath String
     * @param requestBody T
     * @param typeReference  ParameterizedTypeReference
     * @return ReportingResponse
     * @param <T> requestBody T
     * @param <R> ReportingResponse<T>
     */
    protected <T, R> ReportingResponse<R> post(String urlPath, T requestBody, ParameterizedTypeReference<ReportingResponse<R>> typeReference) {
        try {
            URI uri = URI.create(getBaseUrl() + urlPath);
            logger.info("Calling uri: {}", uri);
            logger.debug("Request body: {}", requestBody);
            ReportingResponse<R> ReportingResponse = getWebClient()
                    .post()
                    .uri(uri)
                    .headers(httpHeaders -> httpHeaders.addAll(prepareHttpHeaders()))
                    .bodyValue(requestBody)
                    .exchangeToMono(response -> response.bodyToMono(typeReference)).block();
            validateResponse(ReportingResponse);
            return ReportingResponse;
        } catch (NestedRuntimeException e) {
            throw new ReportingException(EXTERNAL_SERVICE_ERROR_CODE, MessageFormat.format(EXTERNAL_SERVICE_ERROR_MESSAGE, getServiceName()));
        }
    }

    /**
     * @param urlPath       String
     * @param typeReference ParameterizedTypeReference
     * @param <T>           ReportingResponse<T>
     * @return ReportingResponse<T>
     */
    protected <T> ReportingResponse<T> get(String urlPath, ParameterizedTypeReference<ReportingResponse<T>> typeReference) {
        URI uri = URI.create(getBaseUrl() + urlPath);
        logger.info("Calling uri: {}", uri);
        return getWebClient()
                .get()
                .uri(uri)
                .headers(httpHeaders -> httpHeaders.addAll(prepareHttpHeaders()))
                .exchangeToMono(response -> response.bodyToMono(typeReference)).block();

    }

    /**
     * @param urlPath       String
     * @param token         String
     * @param typeReference ParameterizedTypeReference
     * @param <T>           ReportingResponse<T>
     * @return ReportingResponse
     */
    protected <T> ReportingResponse<T> get(String urlPath, String token, ParameterizedTypeReference<ReportingResponse<T>> typeReference) {
        try {
            URI uri = URI.create(getBaseUrl() + urlPath);
            logger.info("Calling uri: {}", uri);
            HttpHeaders headers = prepareHttpHeaders();
            headers.set(HttpHeaders.AUTHORIZATION, BEARER + token);
            return getWebClient()
                    .get()
                    .uri(uri)
                    .headers(httpHeaders -> httpHeaders.addAll(headers))
                    .exchangeToMono(response -> response.bodyToMono(typeReference)).block();
        } catch (NestedRuntimeException e) {
            throw new ReportingException(EXTERNAL_SERVICE_ERROR_CODE, MessageFormat.format(EXTERNAL_SERVICE_ERROR_MESSAGE, getServiceName()));
        }
    }

    private <T> void validateResponse(ReportingResponse<T> response) {
        if (response != null && ReportingConstant.RESPONSE_FAILURE == response.getStatus() && !CollectionUtils.isEmpty(response.getErrors())) {
            throw new ValidationException(response.getErrors());
        }
    }

    private String getServiceName() {
        String urlToken[] = getBaseUrl().split("/");
        return urlToken.length > 1 ? urlToken[urlToken.length - 2]:EXTERNAL_MESSAGE;
    }

}