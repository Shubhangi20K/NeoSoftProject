package com.epay.reporting.service;

import com.epay.reporting.exception.ReportingException;
import com.epay.reporting.util.ErrorConstants;
import com.epay.reporting.util.enums.ReportFormat;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.MessageFormat;

import static com.epay.reporting.util.ReportUtils.setHeader;

/**
 * Class Name: FileDownloadService
 * Description: This service defines the logic for downloading files. It handles the processes of preparing,
 * streaming, and sending files in response to a client’s request. The service ensures efficient file download
 * handling with buffer management and proper error logging.
 * Author: Bhoopendra Rajput
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * Version:1.0
 */
@Service
@RequiredArgsConstructor
public class FileDownloadService {
    private static final int DEFAULT_BUFFER_SIZE = 8192;
    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());

    /**
     * Building content type and setting file in response.
     *
     * @param httpResponse HttpServletResponse
     * @param reportFormat ReportFormat
     * @param filePath     String
     */
    public void downloadFile(HttpServletResponse httpResponse, ReportFormat reportFormat, String filePath) {
        log.info("Started downloadFile for Report : {}, filePath: {}", reportFormat, filePath);
        String contentType = switch (reportFormat) {
            case CSV -> "text/csv";
            case XLSX -> "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
            case PDF -> MediaType.APPLICATION_PDF_VALUE;
            case TXT -> "text/plain";
        };
        setFileResponse(httpResponse, contentType, filePath);
    }

    /**
     *
     * @param filePath String
     * @return InputStream
     */
    protected InputStream getFileContent(String filePath) {
        log.info("Started getFileContent for filePath: {}", filePath);
        try {
            return new FileInputStream(filePath);
        } catch (IOException e) {
            log.error("Unable to read file {}", filePath, e);
            throw new ReportingException(ErrorConstants.NOT_FOUND_ERROR_CODE, MessageFormat.format(ErrorConstants.NOT_FOUND_ERROR_MESSAGE, filePath));
        }
    }

    /**
     * Setting file name, content type and content in http servlet response.
     *
     * @param response    HttpServletResponse
     * @param contentType String
     * @param filePath    String
     */
    protected void setFileResponse(HttpServletResponse response, String contentType, String filePath) {
        // Write the file content to the response output stream
        log.info("Started setFileResponse for contentType: {}, fileName: {}", contentType, filePath);

        try (InputStream inputStream = new FileInputStream(filePath); ServletOutputStream outputStream = response.getOutputStream()) {
            String fileName = FilenameUtils.getName(filePath);
            setHeader(response, contentType, fileName);
            long length = IOUtils.copy(inputStream, outputStream, DEFAULT_BUFFER_SIZE);
            if (length <= Integer.MAX_VALUE) {
                response.setContentLength((int) length);
            } else {
                response.addHeader("Content-Length", Long.toString(length));
            }
        } catch (IOException e) {
            log.error("Error in setting file content in response", e);
            throw new ReportingException(ErrorConstants.GENERIC_ERROR_CODE, MessageFormat.format(ErrorConstants.GENERATION_ERROR_MESSAGE, filePath));
        }
    }

}
