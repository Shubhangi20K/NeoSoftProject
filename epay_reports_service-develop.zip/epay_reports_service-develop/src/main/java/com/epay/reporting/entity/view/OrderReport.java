package com.epay.reporting.entity.view;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

/**
 * Class Name: OrderReport
 * *
 * Description: This class is used to hold and represent order report data. It contains information related to customer orders,
 * such as order ID, order details, transaction amounts, status, and any other relevant attributes necessary for generating
 * and processing order reports. The class serves as a Data Transfer Object (DTO) used for organizing and presenting order
 * data within the system, typically for analysis, reporting, or business insights.
 * Author: Bhoopendra Rajput
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OrderReport {
    private String transactionDate;
    private String merchantOrderNumber;
    private String customerId;
    private String transactionCurrency;
    private BigDecimal orderAmount;
    private String sbiOrderRefNumber;
    private String status;
    private Integer attempts;
    private String mId;
}