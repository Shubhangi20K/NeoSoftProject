package com.epay.reporting.entity;

import com.epay.reporting.util.enums.ReportFormat;
import com.epay.reporting.util.enums.ReportStatus;
import jakarta.persistence.*;
import lombok.*;

import java.util.UUID;

/**
 * Class Name: ReportManagement
 * Description:This class represents an entity for managing reports. It extends the AuditEntity class, inheriting
 * auditing fields such as createdBy, updatedBy, and timestamps for creation and last modification.
 * The class is annotated with @Entity to denote it as a JPA entity and is mapped to the "REPORT_MANAGEMENT"
 * table in the database. It uses Lombok annotations for boilerplate code generation like equals, hashCode,
 * getters, setters, constructors, and the builder pattern.
 * Author: V1018344
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * Version: 1.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Builder
@Table(name = "REPORT_MANAGEMENT")
public class ReportManagement extends AuditEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "ID", nullable = false, updatable = false, unique = true)
    private UUID id;

    private UUID reportId;

    @Column(name="MID")
    private String mId;

    private Long durationFromDate;
    private Long durationToDate;
    @Enumerated(EnumType.STRING)
    private ReportFormat format;
    @Enumerated(EnumType.STRING)
    private ReportStatus status;
    private String filePath;
    private String remarks;
    private UUID scheduledId;

}