package com.epay.reporting.repository.event.audit;

import com.epay.reporting.entity.event.audit.EventReceivedLog;
import org.springframework.data.repository.CrudRepository;
import java.util.UUID;

/**
 * Class Name: EventReceivedLogRepository
 * Description: interface for  event receive logs data persistence and retrieval in a database.
 * Copyright (c) [2025] [State Bank of India]
 * All rights reserved.
 * Author:@V0000001(Shilpa Kothre)
 * Version:1.0
 */
public interface EventReceivedLogRepository extends CrudRepository<EventReceivedLog, UUID> {
}
