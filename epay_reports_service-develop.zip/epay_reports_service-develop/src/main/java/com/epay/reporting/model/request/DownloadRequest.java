package com.epay.reporting.model.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

import static com.epay.reporting.util.ErrorConstants.HIBERNATOR_REQUIRED_ERROR_MESSAGE;

/**
 * Class Name: DownloadRequest
 * Description: This class serves as a Data Transfer Object (DTO) used to request the download of a report file.
 * It contains the necessary information (file path) to locate and download the requested report.
 * Author: Bhoopendra Rajput
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Data
public class DownloadRequest {
    @NotBlank(message = HIBERNATOR_REQUIRED_ERROR_MESSAGE)
    private String filePath;
}