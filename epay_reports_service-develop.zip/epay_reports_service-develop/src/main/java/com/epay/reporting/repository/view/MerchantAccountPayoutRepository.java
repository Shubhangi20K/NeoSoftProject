package com.epay.reporting.repository.view;



import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.UUID;

import static com.epay.reporting.util.ReportingConstant.PAYOUT_DETAILS;
import static com.epay.reporting.util.queries.ReconQueries.*;
/**
 * Class Name: MerchantAccountPayoutRepository
 * *
 * Description: This class is responsible for interacting with the database to retrieve invoice records related to Payout.
 * It specifically contains methods for querying merchant fees invoices based on the payout Id.
 * Author: Saurabh mahto(V1018841
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * Version:1.0
 */
@Repository
@RequiredArgsConstructor
public class MerchantAccountPayoutRepository {
    private final NamedParameterJdbcTemplate jdbcTemplate;


    public List<String> fetchAatMerchantPayout(List<UUID> listMpId){
        List<String> mpIdString=listMpId.stream().map(id -> id.toString().replace("-","").toUpperCase()).toList();
        MapSqlParameterSource params = new MapSqlParameterSource();
        params.addValue("mpId", mpIdString);
        return jdbcTemplate.query(AAT_MERCHANT_ACCOUNT_PAYOUT, params,(rs, rowNum) -> rs.getString(1));
    }

    public List<String> fetchNeftMerchantPayout(List<UUID> listMpId) {
        List<String> mpIdString=listMpId.stream().map(id -> id.toString().replace("-","").toUpperCase()).toList();
        MapSqlParameterSource params = new MapSqlParameterSource();
        params.addValue("mpId", mpIdString);
        return jdbcTemplate.query(NEFT_MERCHANT_ACCOUNT_PAYOUT,params,((rs, rowNum) -> rs.getString(1)));
    }

}
