package com.epay.reporting.util;

import static com.epay.reporting.util.ErrorConstants.ONE;
import static com.epay.reporting.util.ErrorConstants.ZERO;
import static java.time.format.DateTimeFormatter.ofPattern;

import com.epay.reporting.util.enums.Frequency;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.stream.Stream;
import lombok.experimental.UtilityClass;
import org.apache.commons.lang3.time.DateUtils;
import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.format.DateTimeFormat;

/**
 * Class Name: DateTimeUtils
 * *
 * Description: This utility class provides various methods for handling date and time operations,
 * such as formatting, calculating future and past dates based on frequency, and getting the current time in milliseconds.
 * The methods support functionalities like adding minutes to a date, converting milliseconds to date strings,
 * and calculating dates based on frequencies such as daily, monthly, or yearly.
 * *
 * Author: Bhoopendra Rajput
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@UtilityClass
public class DateTimeUtils {
    private static final LoggerUtility log = LoggerFactoryUtility.getLogger(DateTimeUtils.class);
    public static final String DDMMYY = "dd/MM/yyyy";
    public static final DateFormat FORMATTER_DD_MM_YYYY = new SimpleDateFormat(DDMMYY);
    public static final DateTimeFormatter FORMATTER_MMM_YYYY = ofPattern("MMM-yyyy", Locale.ENGLISH);
    public static final DateTimeFormatter FORMATTER_MONTH_YEAR = ofPattern("MMMM-yyyy", Locale.ENGLISH);
    public static final DateTimeFormatter FORMATTER_DD_MMM_YYYY = ofPattern("dd-MMM-yyyy", Locale.ENGLISH);
    public static final DateTimeFormatter FORMATTER_DD_MM_YY_HH_MM_SS = ofPattern("ddMMyyHHmmss", Locale.ENGLISH);
    public static final DateTimeFormatter FORMATTER_TIME_HH_MM = ofPattern("h:mm a", Locale.ENGLISH);
    public static final ZoneId ZONE_ID_INDIA = ZoneId.of("Asia/Kolkata");
    public static final DateTimeZone DT_ZONE_ID_INDIA = DateTimeZone.forID("Asia/Kolkata");
    /**
     * Returns the current system time in milliseconds.
     *
     * @return the current time in milliseconds
     */
    public static Long getCurrentTimeInMills() {
        log.debug("Fetching current time in milliseconds");
        return System.currentTimeMillis();
    }

    /**
     * Adds the specified number of minutes to the current time.
     *
     * @param minute the number of minutes to add
     * @return the new time in milliseconds after adding the specified minutes
     */
    public static Long addMinutes(int minute) {
        log.debug("Adding {} minutes to the current time", minute);
        return DateUtils.addMinutes(new Date(), minute).getTime();
    }

    public static Long deductHourFromNow(int hour) {return DateTime.now().minusHours(hour).getMillis();}

    /**
     * Converts the given milliseconds into a formatted date string.
     *
     * @param milliSeconds the time in milliseconds
     * @param format the date format to be used
     * @return the formatted date as a string
     */
    public static String getDate(Long milliSeconds, DateFormat format) {
        log.debug("Converting milliseconds {} to formatted date string", milliSeconds);
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(milliSeconds);
        return format.format(calendar.getTime());
    }

    public static String getCurrentDate(java.time.format.DateTimeFormatter format){
        return Stream.of(LocalDate.now())
                .map(date -> date.format(format))
                .findFirst()
                .orElse("Date not available");
    }

    public static Long calculateNextExecutionTime(Frequency frequency, String time, String generationDate) {
        DateTime currentDateTime = new DateTime(DT_ZONE_ID_INDIA);

        var timeFormatter = DateTimeFormat.forPattern("h:mm a");
        DateTime parsedTime = timeFormatter.parseDateTime(time);

        DateTime nextDate;
        switch (frequency) {
          case Frequency.DAILY -> nextDate = currentDateTime.plusDays(ONE);
          case Frequency.MONTHLY -> {
            int day = Integer.parseInt(generationDate);
            DateTime nextMonth = currentDateTime.plusMonths(ONE);
            int maxDay = nextMonth.dayOfMonth().getMaximumValue();
            nextDate = nextMonth.withDayOfMonth(Math.min(day, maxDay));
          }
          default -> throw new IllegalArgumentException("Invalid frequency: " + frequency);
        }

        return nextDate.withHourOfDay(parsedTime.getHourOfDay())
                .withMinuteOfHour(parsedTime.getMinuteOfHour())
                .withSecondOfMinute(ZERO)
                .withMillisOfSecond(ZERO)
                .getMillis();
    }

    public static Long getCurrentDateWithTime(String time) {
        DateTime currentDateTime = new DateTime(DT_ZONE_ID_INDIA);
        DateTime parsedTime = DateTimeFormat.forPattern("h:mm a").parseDateTime(time);
        return currentDateTime.withHourOfDay(parsedTime.getHourOfDay())
                .withMinuteOfHour(parsedTime.getMinuteOfHour())
                .withSecondOfMinute(ZERO)
                .withMillisOfSecond(ZERO)
                .getMillis();
    }

    /**
     * Calculates the number of days between two time millis
     */
    public static int calculateDaysBetween(long millis1, long millis2) {
        log.info("Calculating days between millis");
        return (int) (Math.abs(millis1 - millis2) / (1000 * 60 * 60 * 24));
    }

    public static Long getNextDayStartInMillis() {
        return LocalDate.now()
                .plusDays(1)
                .atStartOfDay()
                .atZone(ZoneId.systemDefault())
                .toInstant()
                .toEpochMilli();
    }

    /**
     * Retrieves end of the day millis i.e. millis at time 23:59:59 for current date.
     */
    public static long endOfDayMillis() {
        log.info("Fetching end of day millis");
        return LocalDate.now().atTime(LocalTime.MAX).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
    }
}
