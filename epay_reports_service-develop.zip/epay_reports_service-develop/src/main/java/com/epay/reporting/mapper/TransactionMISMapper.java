package com.epay.reporting.mapper;

import com.epay.reporting.entity.view.TransactionMIS;
import org.apache.commons.lang3.StringUtils;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;

import java.math.BigDecimal;
import java.util.List;

import static org.thymeleaf.util.ObjectUtils.nullSafe;

@Mapper(builder = @Builder(disableBuilder = true), componentModel = "spring")
public interface TransactionMISMapper {

    default List<Object> mapToList(TransactionMIS transactionMIS){
        return List.of(
                nullSafe(transactionMIS.getMId(), StringUtils.EMPTY),
                nullSafe(transactionMIS.getMerchantName(), StringUtils.EMPTY),
                nullSafe(transactionMIS.getMerchantCategory(), StringUtils.EMPTY),
                nullSafe(transactionMIS.getOrderRefNumber(), StringUtils.EMPTY),
                nullSafe(transactionMIS.getAtrnNum(), StringUtils.EMPTY),
                nullSafe(transactionMIS.getInstructionDateandTime(), 0L),
                nullSafe(transactionMIS.getCurrencyCode(), StringUtils.EMPTY),
                nullSafe(transactionMIS.getOrderAmount(), BigDecimal.ZERO),
                nullSafe(transactionMIS.getTotalFeeAbs(), BigDecimal.ZERO),
                nullSafe(transactionMIS.getGstNumber(), StringUtils.EMPTY),
                nullSafe(transactionMIS.getGatewayPostingAmount(), 0),
                nullSafe(transactionMIS.getAmountSettled(), BigDecimal.ZERO),
                nullSafe(transactionMIS.getAvailableRefundAmount(), BigDecimal.ZERO),
                nullSafe(transactionMIS.getPayMode(), StringUtils.EMPTY),
                nullSafe(transactionMIS.getChannelBank(), StringUtils.EMPTY),
                nullSafe(transactionMIS.getGatewayTraceNumber(), StringUtils.EMPTY),
                nullSafe(transactionMIS.getTransactionStatus(), StringUtils.EMPTY),
                nullSafe(transactionMIS.getRemark(), StringUtils.EMPTY),
                nullSafe(transactionMIS.getMerchantRiskCategory(), StringUtils.EMPTY),
                nullSafe(transactionMIS.getAccessMedium(), StringUtils.EMPTY),
                nullSafe(transactionMIS.getPayProcId(), StringUtils.EMPTY),
                nullSafe(transactionMIS.getPayProcType(), StringUtils.EMPTY),
                nullSafe(transactionMIS.getMerchantAuthorize(), StringUtils.EMPTY),
                nullSafe(transactionMIS.getMerchantAuthorizeDate(), 0L),
                nullSafe(transactionMIS.getAutoSettlement(), StringUtils.EMPTY),
                nullSafe(transactionMIS.getBearableEntity(), StringUtils.EMPTY),
                nullSafe(transactionMIS.getCin(), StringUtils.EMPTY),
                nullSafe(transactionMIS.getFailReason(), StringUtils.EMPTY),
                nullSafe(transactionMIS.getMerchantFeeBearableAbs(), BigDecimal.ZERO),
                nullSafe(transactionMIS.getMerchantGstBearableAbs(), BigDecimal.ZERO),
                nullSafe(transactionMIS.getCustomerFeeBearableAbs(), BigDecimal.ZERO),
                nullSafe(transactionMIS.getCustomerGstBearableAbs(), BigDecimal.ZERO),
                nullSafe(transactionMIS.getSbuStatusDescription(), StringUtils.EMPTY),
                nullSafe(transactionMIS.getPaymentSuccessDate(), StringUtils.EMPTY)
        );
    }
}
