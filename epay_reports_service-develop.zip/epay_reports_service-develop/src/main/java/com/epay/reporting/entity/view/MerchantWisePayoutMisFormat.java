package com.epay.reporting.entity.view;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MerchantWisePayoutMisFormat {

    private String mId;
    private String merchantName;
    private BigDecimal transactionAmount;
    private String transactionCurrency;
    private BigDecimal settlementAmount;
    private String settlementCurrency;
    private BigDecimal commissionPayable;
    private BigDecimal gst;
    private BigDecimal payoutAmount;
    private BigDecimal refundAdjusted;
    private BigDecimal tdrOnRefundAmount;
    private BigDecimal gstOnRefundAmount;
    private BigDecimal netRefundAmount;
    private BigDecimal netPayoutAmount;
    private String payoutDate;
    private Integer transactionCount;

}
