package com.epay.reporting.controller;

import com.epay.reporting.model.request.DownloadRequest;
import com.epay.reporting.model.request.ReportManagementRequest;
import com.epay.reporting.model.response.ReportManagementResponse;
import com.epay.reporting.model.response.ReportingResponse;
import com.epay.reporting.service.ReportManagementService;
import com.epay.reporting.util.ReportingConstant;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.web.bind.annotation.*;

/**
 * Class Name: ReportManagementController
 * *
 * Description: This class defines all the endpoints related to report management, providing functionalities for handling
 * report generation, retrieval, and processing. It interacts with the ReportManagementService to execute report-related tasks.
 * Author: Bhoopendra Rajput
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@RestController
@RequiredArgsConstructor
@RequestMapping("/report/management")
public class ReportManagementController {

    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    private final ReportManagementService reportManagementService;

    /**
     * Generate Report Management request and saves it for processing.
     *
     * @param reportManagementRequest The request body containing the details of the report to be generated.
     * @return ReportingResponse A response indicating the status of the report generation request.
     */
    @PostMapping
    @Operation(summary = "Generate/Create Report generation request")
    public ReportingResponse<String> saveReportManagement(@Valid @RequestBody ReportManagementRequest reportManagementRequest) {
        log.info("save ReportManagement request {}", reportManagementRequest);
        return reportManagementService.save(reportManagementRequest);
    }

    /**
     * Searches and retrieves all ReportManagementRequest based on the provided filters and pagination.
     *
     * @param reportManagementRequest The request body containing the criteria to filter report management requests.
     * @param pageable Pagination information, including page size and sort direction, used to retrieve results.
     * @return ReportingResponse<ReportManagementResponse> A response containing a paginated list of ReportManagementRequest results.
     */
    @PostMapping("/search")
    @Operation(summary = "Search/GetAll request for getting ReportManagementRequest")
    public ReportingResponse<ReportManagementResponse> searchReportManagement(@RequestBody ReportManagementRequest reportManagementRequest, @PageableDefault(size = ReportingConstant.PAGE_SIZE, sort = "createdAt", direction = Sort.Direction.DESC) Pageable pageable) {
        log.info("getReportRequests invoked for {} and pageable {}", reportManagementRequest, pageable);
        return reportManagementService.searchAndGetReportManagement(reportManagementRequest, pageable);
    }


    /**
     * Downloads the generated report for the given merchant ID (MID) and specified download request.
     * This method is invoked to handle the report download process. It takes the merchant ID and the download request
     * to retrieve and send the report as a response to the client. The file path and other download-related parameters
     * are logged for tracking purposes.
     *
     * @param httpResponse The HTTP response object used to send the report file to the client.
     * @param mId The merchant ID (MID) for which the report is to be downloaded.
     * @param downloadRequest The request body containing the details needed to identify and download the report, such as file path or report type.
     */
    @PostMapping("/download/{mId}")
    @Operation(summary = "Download generated report")
    public void downloadReport(HttpServletResponse httpResponse, @PathVariable String mId, @Valid @RequestBody DownloadRequest downloadRequest) {
        log.info("Invoked download report for file path :{} & MID: {}", downloadRequest, mId);
        reportManagementService.downloadReport(httpResponse, mId, downloadRequest);
    }
}
