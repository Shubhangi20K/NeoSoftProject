package com.epay.reporting.entity.view;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Class Name: Refund Report
 * *
 * Description: This class is used to hold and represent the refund report data.
 * It contains information related to refunds, such as refund amount, transaction details,
 * refund status, and other relevant attributes necessary for generating refund-related reports.
 * This class acts as a data transfer object (DTO) for processing and presenting refund data within the system.
 * Author: Bhoopendra Rajput
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RefundReport {

    private String merchantOrderID;
    private String sbiEPayOrderID;
    private String merchantPostingAmount;
    private String gatewayPostingAmount;
    private String atrn;
    private String transactionStatus;
    private String transactionSuccessDateAndTime;
    private String arrn;
    private String refundType;
    private String refundCurrency;
    private String refundAmount;
    private String refundBookingDate;
    private String refundProcessedDate;
    private String refundStatus;
    private String paymentGateway;
    private String paymentMode;
    private String amountRefunded;
    private String furtherRefundAllowed;
    private String pendingAmountforRefund;
    private String remark;
}
