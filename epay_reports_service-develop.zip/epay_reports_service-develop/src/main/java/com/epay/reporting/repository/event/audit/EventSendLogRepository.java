package com.epay.reporting.repository.event.audit;

import com.epay.reporting.entity.event.audit.EventSendLog;
import org.springframework.data.repository.CrudRepository;
import java.util.UUID;

/**
 * Class Name: EventSendLogRepository
 * Description: interface for  event send logs data persistence and retrieval in a database.
 * Copyright (c) [2025] [State Bank of India]
 * All rights reserved.
 * Author:@V0000001(Shilpa Kothre)
 * Version:1.0
 */
public interface EventSendLogRepository extends CrudRepository<EventSendLog, UUID> {
}
