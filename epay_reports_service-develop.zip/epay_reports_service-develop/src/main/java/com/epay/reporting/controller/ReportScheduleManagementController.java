package com.epay.reporting.controller;

import com.epay.reporting.model.request.CancelScheduleRequest;
import com.epay.reporting.model.request.ReportScheduleManagementRequest;
import com.epay.reporting.model.request.ReportScheduleManagementSearchRequest;
import com.epay.reporting.model.request.ReportScheduleManagementUpdateRequest;
import com.epay.reporting.model.response.ReportScheduleManagementResponse;
import com.epay.reporting.model.response.ReportingResponse;
import com.epay.reporting.service.ReportScheduleManagementService;
import com.epay.reporting.util.ReportingConstant;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

/**
 * Class Name: ReportScheduleManagementController
 * Description: This class defines the endpoints for managing the scheduling of reports. It interacts with the
 * ReportScheduleManagementService to handle tasks like scheduling, executing, and managing report-related schedules.
 * Author: Ranu Jain
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * Version: 1.0
 */
@RestController
@RequiredArgsConstructor
@RequestMapping("/report/schedule/management")
public class ReportScheduleManagementController {

    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    private final ReportScheduleManagementService reportSchedulerManagementService;

    /**
     * Saves a new report scheduler management request for generating or creating a report scheduler.
     *
     * @param reportScheduleManagementRequest The request body containing the details of the report scheduler to be created.
     * @return ReportingResponse<String> A response indicating the status of the report scheduler creation.
     */
    @PostMapping
    @Operation(summary = "Generate/Create Report scheduler request")
    public ReportingResponse<String> saveSchedulerManagement(@Valid @RequestBody ReportScheduleManagementRequest reportScheduleManagementRequest) {
        log.info("save schedulerManagement request {}", reportScheduleManagementRequest);
        return reportSchedulerManagementService.save(reportScheduleManagementRequest);
    }

    /**
     * Searches and retrieves all report schedule management requests based on the provided search criteria and pagination.
     *
     * @param searchRequest The request body containing the criteria to filter report schedule management results.
     * @param pageable Pagination information, including page size and sort direction, used to retrieve results.
     * @return ReportingResponse<ReportScheduleManagementResponse> A response containing a paginated list of report schedule management results.
     */
    @PostMapping("/search")
    @Operation(summary = "Search/GetAll request for getting ReportScheduleManagement")
    public ReportingResponse<ReportScheduleManagementResponse> searchScheduleManagement(@Valid @RequestBody ReportScheduleManagementSearchRequest searchRequest, @PageableDefault(size = ReportingConstant.PAGE_SIZE, sort = "createdAt", direction = Sort.Direction.DESC) Pageable pageable) {
        log.info("search searchRequest for {} and pageable {}", searchRequest, pageable);
        return reportSchedulerManagementService.searchAndGetAll(searchRequest, pageable);
    }

    /**
     * Updates an existing report schedule management entry based on the provided ID and update request.
     *
     * @param id The unique identifier of the schedule management entry to be updated.
     * @param ReportScheduleManagementUpdateRequest The request body containing the updated details for the schedule management.
     * @return ReportingResponse<String> A response indicating the status of the schedule management update.
     */
    @PostMapping("/update/{id}")
    @Operation(summary = "Update Schedule Management", description = "Updates a schedule management entry based on the provided ID and update request.")
    public ReportingResponse<String> updateScheduleManagement(@PathVariable String id, @RequestBody ReportScheduleManagementUpdateRequest ReportScheduleManagementUpdateRequest) {
        log.info("Started updateScheduleManagement for ID: {}, Request: {}", id, ReportScheduleManagementUpdateRequest);
        return reportSchedulerManagementService.updateScheduleManagement(id, ReportScheduleManagementUpdateRequest);
    }

    /**
     * Cancels a report schedule management entry based on the provided ID.
     *
     * @param id The unique identifier of the schedule management entry to be canceled.
     * @return ReportingResponse<String> A response indicating the status of the cancellation operation.
     */
    @PostMapping("/cancel/{id}")
    @Operation(summary = "Cancel Schedule Management", description = "Cancel a schedule management entry based on the provided ID.")
    public ReportingResponse<String> cancelScheduler(@PathVariable String id, @RequestBody CancelScheduleRequest cancelScheduleRequest) {
        log.info("cancel scheduler for ID: {}", id);
        return reportSchedulerManagementService.cancelScheduler(id, cancelScheduleRequest);
    }
}
