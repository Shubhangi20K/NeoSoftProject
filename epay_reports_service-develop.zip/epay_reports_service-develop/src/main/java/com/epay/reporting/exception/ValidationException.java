package com.epay.reporting.exception;

import com.epay.reporting.dto.ErrorDto;
import lombok.Getter;

import java.util.List;

/**
 * Class Name: ValidationException
 * *
 * Description: This class defines a custom runtime exception specifically for handling validation errors in the application.
 * It extends `RuntimeException` and is used to signal issues that arise when input data or business logic validation fails.
 * This exception can be thrown to indicate that certain conditions were not met during validation checks,
 * such as invalid input or incorrect parameters.
 * Author: Bhoopendra Rajput
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * Version:1.0
 */
@Getter
public class ValidationException extends RuntimeException {

    private String errorCode;
    private String errorMessage;
    private List<ErrorDto> errorMessages;

    /**
     * Parametrized constructor taking error code and errorMessage
     * @param errorCode String
     * @param errorMessage String
     */
    public ValidationException(String errorCode, String errorMessage) {
        super(errorMessage);
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
    }

    /**
     * Parametrized constructor taking List of ErrorDTO
     * @param errorMessages List
     */
    public ValidationException(List<ErrorDto> errorMessages) {
        this.errorMessages = errorMessages;
    }

}
