package com.epay.reporting.dao;

import com.epay.reporting.dto.ReportManagementDto;
import com.epay.reporting.dto.ops.ReportFilterDto;
import com.epay.reporting.repository.view.MerchantAccountPayoutRepository;
import com.epay.reporting.util.enums.ReportFormat;
import com.epay.reporting.util.enums.ReportStatus;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.UUID;

@Component
@RequiredArgsConstructor
public class OpsReportDao {

    private final ReportManagementDao reportManagementDao;
    private final TransactionMISDao transactionMISDao;
    private final TransactionMerchantPayoutDao transactionMerchantPayoutDao;
    private final SBIAccountPayoutDao sbiAccountPayoutDao;
    private final MerchantAccountPayoutRepository merchantAccountPayoutRepository;
    private final MerchantPayoutDao merchantPayoutDao;
    private final TransactionRefundDao transactionRefundDao;
    private final ReconFileDtlsDao reconFileDtlsDao;

    public List<List<Object>> getTransactionMISByMID(ReportFilterDto reportFilterDto){
        return transactionMISDao.getTransactionMISByMID(reportFilterDto.getMId());
    }

    public List<List<Object>> getTransactionMerchantPayouts(ReportFilterDto reportFilterDto){
        return transactionMerchantPayoutDao.getTransactionMerchantPayouts(reportFilterDto.getMpIdList());
    }

    public List<List<Object>> getSBIAccountPayouts(ReportFilterDto reportFilterDto){
        return sbiAccountPayoutDao.getSBIAccountPayouts(reportFilterDto.getMId());
    }

    public List<String> getAATMerchantAccountPayoutDao(ReportFilterDto reportFilterDto) {
        return merchantAccountPayoutRepository.fetchAatMerchantPayout(reportFilterDto.getMpIdList());
    }

    public List<String> getNEFTMerchantAccountPayoutDao(ReportFilterDto reportFilterDto) {
        return merchantAccountPayoutRepository.fetchNeftMerchantPayout(reportFilterDto.getMpIdList());
    }

    public List<List<Object>> getTransactionRefundData(ReportFilterDto reportFilterDto) {
        return transactionRefundDao.getTransactionRefundData(reportFilterDto.getMpIdList());
    }

    public List<List<Object>> getMerchantPayoutData(ReportFilterDto reportFilterDto) {
        return merchantPayoutDao.getMerchantPayoutData(reportFilterDto.getMpIdList());
    }

    public void saveReport(UUID rrId, ReportFormat reportFormat, String filePath){
        ReportManagementDto reportDto = ReportManagementDto.builder().reportId(rrId).durationFromDate(0L).mId("0000000").durationToDate(0L).format(reportFormat).status(ReportStatus.GENERATED).remarks("Report request from operation service").filePath(filePath).build();
        reportManagementDao.saveReport(reportDto);
    }

    public List<List<Object>> getBadRecordDetails(ReportFilterDto reportFilterDto){
        return reconFileDtlsDao.getBadRecord(reportFilterDto.getRfId());
    }

    public List<List<Object>> getFailedReportDetails(ReportFilterDto reportFilterDto){
        return reconFileDtlsDao.getFailedReport(reportFilterDto.getRfId());
    }

}
