package com.epay.reporting.service;

import com.epay.reporting.dao.ReportScheduleManagementDao;
import com.epay.reporting.dto.ReportScheduleManagementDto;
import com.epay.reporting.mapper.ReportScheduleManagementMapper;
import com.epay.reporting.model.request.CancelScheduleRequest;
import com.epay.reporting.model.request.ReportScheduleManagementRequest;
import com.epay.reporting.model.request.ReportScheduleManagementSearchRequest;
import com.epay.reporting.model.request.ReportScheduleManagementUpdateRequest;
import com.epay.reporting.model.response.ReportScheduleManagementResponse;
import com.epay.reporting.model.response.ReportingResponse;
import com.epay.reporting.util.ReportingConstant;
import com.epay.reporting.validator.ReportScheduleManagementValidator;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

import static com.epay.reporting.util.ReportingConstant.RESPONSE_SUCCESS;

/**
 * Class Name: ReportScheduleManagementService
 * *
 * Description:This service class contains the business logic for managing report schedules. It interacts with the data access
 * layer (ReportScheduleManagementDao) to perform operations related to report schedule management such as
 * scheduling reports, updating, and canceling scheduled reports. The service also validates the inputs using
 * ReportScheduleManagementValidator and maps entities to DTOs using ReportScheduleManagementMapper.
 * *
 * Author: Subhra Goswami
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Service
@RequiredArgsConstructor
public class ReportScheduleManagementService {

    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());

    private final ReportScheduleManagementDao reportScheduleManagementDao;
    private final ReportScheduleManagementMapper mapper;
    private final ReportScheduleManagementValidator validator;

    /**
     * Searches and retrieves all report schedule management records based on the provided search criteria and pagination.
     * This method validates the search request, retrieves a paginated list of report schedule management records from the
     * data access layer, and maps the data to a response format.
     *
     * @param searchRequest The search criteria for retrieving the report schedule management records.
     * @param pageable      The pagination information (page size, sorting, etc.).
     * @return ReportingResponse<ReportScheduleManagementResponse> The response containing the list of report schedule
     * management records and pagination metadata.
     * The response includes the data (list of records), count of the records in the current page, and total records.
     */
    public ReportingResponse<ReportScheduleManagementResponse> searchAndGetAll(ReportScheduleManagementSearchRequest searchRequest, Pageable pageable) {
        validator.validateRequest(searchRequest);
        log.info("Search and get all Report Schedule Management Request {}", searchRequest);
        Page<ReportScheduleManagementDto> reportManagementDTOs = reportScheduleManagementDao.searchAndGetAll(searchRequest, pageable);
        List<ReportScheduleManagementResponse> reportManagementResponses = mapper.mapDtoListToResponseList(reportManagementDTOs.getContent());
        log.info("Returning list of Report Schedule Management {}", reportManagementResponses);
        return ReportingResponse.<ReportScheduleManagementResponse>builder().data(reportManagementResponses).count(reportManagementDTOs.stream().count()).total(reportManagementDTOs.getTotalElements()).status(RESPONSE_SUCCESS).build();
    }

    /**
     * Saves a new report schedule management request.
     * This method validates the provided schedule management request, saves it to the database, and returns a response indicating
     * successful receipt of the request.
     *
     * @param reportScheduleManagementRequest The request containing details for the report schedule to be saved.
     * @return ReportingResponse<String> A response confirming that the schedule management request has been received and saved successfully.
     */
    public ReportingResponse<String> save(ReportScheduleManagementRequest reportScheduleManagementRequest) {
        log.info("Saving Report Schedule Management for mId: {}, Request: {}", reportScheduleManagementRequest.getMId(), reportScheduleManagementRequest);
        validator.validateRequest(reportScheduleManagementRequest);
        reportScheduleManagementDao.save(mapper.mapRequestToDto(reportScheduleManagementRequest));
        return ReportingResponse.<String>builder().data(List.of("ScheduleManagement Request received successfully.")).status(RESPONSE_SUCCESS).build();
    }

    /**
     * Executes the scheduled report generation tasks.
     * This method triggers the execution of reports based on the existing schedule in the system. It is typically called to
     * process the scheduled reports based on their defined time intervals.
     */
    public void executeReportBySchedule() {
        log.info("Started executeReportBySchedule");
        reportScheduleManagementDao.executeReportBySchedule();
    }

    /**
     * Updates a schedule management entry in the database.
     *
     * @param id      UUID ID of the schedule management entry to be updated.
     * @param request ReportScheduleManagementUpdateRequest Update request containing new details.
     */
    public ReportingResponse<String> updateScheduleManagement(String id, ReportScheduleManagementUpdateRequest request) {
        validator.validateUpdateRequest(id,request);
        log.info("Started updating schedule management entry for ID: {}, Request: {}", id, request);
        reportScheduleManagementDao.update(id, request);
        return ReportingResponse.<String>builder().status(RESPONSE_SUCCESS).data(List.of(ReportingConstant.UPDATED_SUCCESSFULLY)).build();
    }

    /**
     * Cancel a schedule management entry based on the provided ID.
     *
     * @param id UUID ID of the schedule management entry to be updated.
     */
    public ReportingResponse<String> cancelScheduler(String id, CancelScheduleRequest cancelScheduleRequest) {
        validator.validateCancelScheduleRequest(id,cancelScheduleRequest);
        reportScheduleManagementDao.cancelScheduler(UUID.fromString(id), cancelScheduleRequest);
        log.info("scheduler cancelled for ID: {}", id);
        return ReportingResponse.<String>builder().status(RESPONSE_SUCCESS).data(List.of(ReportingConstant.SCHEDULER_CANCELED)).build();
    }
}
