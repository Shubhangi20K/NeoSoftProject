package com.epay.reporting.repository.view;

import com.epay.reporting.entity.view.*;
import com.epay.reporting.exception.ReportingException;
import com.epay.reporting.model.request.RecentTransactionRequest;
import com.epay.reporting.util.ErrorConstants;
import com.epay.reporting.util.enums.Frequency;
import com.epay.reporting.util.queries.TransactionDashboardQueries;
import lombok.RequiredArgsConstructor;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.util.List;
import java.util.Optional;

import static com.epay.reporting.util.ErrorConstants.*;
import static com.epay.reporting.util.ReportingConstant.*;
import static com.epay.reporting.util.ReportingConstant.MID;
import static com.epay.reporting.util.queries.TransactionDashboardQueries.*;


/**
 * Class Name: TransactionDashboardRepository
 * Description: This class is responsible for querying the database and retrieving various transaction-related reports,
 * including daily, monthly, and yearly transaction trends, transaction pay mode details, transaction summary reports,
 * and failure summaries. The repository uses `NamedParameterJdbcTemplate` for database interaction, and custom report
 * objects are populated through result set mapping.
 * Author: Subhra Goswami
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * Version: 1.0
 */
@Repository
@RequiredArgsConstructor
public class TransactionDashboardRepository {

    private final NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    /**
     * Retrieves daily, monthly, or yearly transaction trends for a given merchant ID.
     *
     * @param mId       the merchant ID to filter the transaction trends by
     * @param frequency the frequency of the transaction trend report (daily, monthly, or yearly)
     * @return a list of TransactionSummaryReport objects representing the transaction trends
     */
    public List<TransactionSummaryReport> getTransactionDailyTrendsByMidAndFrequency(String mId, Frequency frequency) {
        try {
            String sql = TransactionDashboardQueries.JDBC_DAILY_TRANSACTION_TRENDS;
            if (Frequency.MONTHLY.equals(frequency)) {
                sql = TransactionDashboardQueries.JDBC_MONTHLY_TRANSACTION_TRENDS;
            }
            SqlParameterSource parameters = new MapSqlParameterSource("mId", mId);
            return namedParameterJdbcTemplate.query(sql, parameters, (rs, rowNum) -> setTransactionSuccessDailyReport(rs));
        } catch (EmptyResultDataAccessException e) {
            throw new ReportingException(ErrorConstants.NOT_FOUND_ERROR_CODE, MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, "Transaction"));
        }
    }

    /**
     * Retrieves daily, or monthly recent transactions for a given merchant ID.
     *
     * @param mId the merchant ID to filter the transaction trends by
     * @return a list of RecentTransactionReport objects representing the recent transaction
     */
    private Page<RecentTransactionReport> getRecentTransactionSummary(String mId, RecentTransactionRequest recentTransactionRequest, Pageable pageable, String selectSQL, String countSQL) {
        try {
            MapSqlParameterSource parameters = new MapSqlParameterSource();
            parameters.addValue(MID, mId);
            parameters.addValue(FROM_DATE, recentTransactionRequest.getFromDate());
            parameters.addValue(TO_DATE, recentTransactionRequest.getToDate());
            parameters.addValue(FIRST, pageable.getPageSize());
            parameters.addValue(OFFSET, pageable.getPageNumber() * pageable.getPageSize());
            Long totalCount = namedParameterJdbcTemplate.queryForObject(countSQL, parameters, Long.class);
            return new PageImpl<>(namedParameterJdbcTemplate.query(selectSQL, parameters, new BeanPropertyRowMapper<>(RecentTransactionReport.class)), pageable, totalCount != null ? totalCount : 0);
        } catch (EmptyResultDataAccessException e) {
            throw new ReportingException(NOT_FOUND_ERROR_CODE, MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, TRANSACTION));
        }
    }

    /**
     * Retrieves daily recent transactions for a given merchant ID.
     * @param mId String
     * @param recentTransactionRequest RecentTransactionRequest
     * @param pageable Pageable
     * @return Page of RecentTransactionReport
     */
    public Page<RecentTransactionReport> getRecentTransactionSummaryDaily(String mId, RecentTransactionRequest recentTransactionRequest, Pageable pageable) {
        return getRecentTransactionSummary(mId, recentTransactionRequest, pageable, JDBC_DAILY_RECENT_TRANSACTION, JDBC_DAILY_RECENT_TRANSACTION_COUNT);
    }

    /**
     * Retrieves monthly recent transactions for a given merchant ID.
     * @param mId String
     * @param recentTransactionRequest RecentTransactionRequest
     * @param pageable Pageable
     * @return Page of RecentTransactionReport
     */
    public Page<RecentTransactionReport> getRecentTransactionSummaryMonthly(String mId, RecentTransactionRequest recentTransactionRequest, Pageable pageable) {
        return getRecentTransactionSummary(mId, recentTransactionRequest, pageable, JDBC_MONTHLY_RECENT_TRANSACTION, JDBC_MONTHLY_RECENT_TRANSACTION_COUNT);
    }
    /**
     * Retrieves the transaction pay mode report for a given merchant ID and date range.
     *
     * @param mId       the merchant ID to filter the transaction pay mode report by
     * @param startDate the start date for the report range
     * @param endDate   the end date for the report range
     * @return a list of TransactionPaymodeReport objects representing the transaction pay mode details
     */
    public List<TransactionPaymodeReport> getTransactionPayModeReport(String mId, String startDate, String endDate) {
        MapSqlParameterSource parameters = new MapSqlParameterSource();
        parameters.addValue(MID, mId);
        parameters.addValue(START_DATE, startDate);
        parameters.addValue(END_DATE, endDate);
        try {
            return namedParameterJdbcTemplate.query(TransactionDashboardQueries.JDBC_TRANSACTION_PAYMODE, parameters, new BeanPropertyRowMapper<>(TransactionPaymodeReport.class));
        } catch (EmptyResultDataAccessException e) {
            throw new ReportingException(NOT_FOUND_ERROR_CODE, MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, TRANSACTION));
        }
    }

    /**
     * Retrieves the transaction summary report for a given merchant ID and date range.
     *
     * @param mId       the merchant ID to filter the transaction summary report by
     * @param startDate the start date for the report range
     * @param endDate   the end date for the report range
     * @return a TransactionSummaryReport object representing the transaction summary
     */
    public Optional<TransactionSummaryReport> getTransactionSummaryReport(String mId, String startDate, String endDate) {
        MapSqlParameterSource parameters = new MapSqlParameterSource();
        parameters.addValue(MID, mId);
        parameters.addValue(START_DATE, startDate);
        parameters.addValue(END_DATE, endDate);
        try {
            return Optional.ofNullable(namedParameterJdbcTemplate.queryForObject(TransactionDashboardQueries.JDBC_TRANSACTION_SUMMARY, parameters, new BeanPropertyRowMapper<>(TransactionSummaryReport.class)));
        } catch (EmptyResultDataAccessException e) {
            return Optional.empty();
        }
    }

    /**
     * Retrieves the transaction failure summary report for a given merchant ID and date range.
     *
     * @param mId       the merchant ID to filter the failure summary report by
     * @param startDate the start date for the report range
     * @param endDate   the end date for the report range
     * @return a list of TransactionFailureSummaryReport objects representing transaction failure details
     */
    public List<TransactionFailureSummaryReport> getTransactionFailureSummaryReport(String mId, String startDate, String endDate) {
        MapSqlParameterSource parameters = new MapSqlParameterSource();
        parameters.addValue(MID, mId);
        parameters.addValue(START_DATE, startDate);
        parameters.addValue(END_DATE, endDate);
        try {
            return namedParameterJdbcTemplate.query(TransactionDashboardQueries.JDBC_TRANSACTION_FAILURE_DETAILS, parameters, new BeanPropertyRowMapper<>(TransactionFailureSummaryReport.class));
        } catch (EmptyResultDataAccessException e) {
            throw new ReportingException(NOT_FOUND_ERROR_CODE, MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, TRANSACTION));
        }
    }

    /**
     * @param rs ResultSet
     * @return TransactionSummaryReport
     * @throws SQLException while db call
     */
    private TransactionSummaryReport setTransactionSuccessDailyReport(ResultSet rs) throws SQLException {
        return TransactionSummaryReport.builder().totalSuccessCount(rs.getLong("successCount")).totalSuccessAmount(rs.getString("successAmount")).transactionDate(rs.getString("transactionDate")).build();
    }

}
