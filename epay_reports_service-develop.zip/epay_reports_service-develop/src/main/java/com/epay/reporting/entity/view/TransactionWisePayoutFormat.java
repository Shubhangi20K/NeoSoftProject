package com.epay.reporting.entity.view;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

/**
 * Class Name: TransactionPayout
 * *
 * Description: This class is used to hold and represent the TransactionWisePayout report data.
 * Author: Saurabh Mahto
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TransactionWisePayoutFormat {
    private String settlementFileNumber;
    private String settlementTime;
    private String mId;
    private String merchantName;
    private String merchantOrderNo;
    private String transactionId;
    private String transactionBookingDate;
    private String transactionCurrency;
    private BigDecimal transactionAmount;
    private String settlementCurrency;
    private BigDecimal settlementAmount;
    private BigDecimal commissionPayable;
    private BigDecimal gst;
    private BigDecimal payoutAmount;
    private String gatewayName;
    private String gatewayTraceNumber;
    private String payMode;
    private String payProcId;
    private String otherDetails;
    private Character transactionFeeFlag;
    private String cin;
}
