package com.epay.reporting.service;

import com.epay.reporting.dao.ReportDao;
import com.epay.reporting.dao.ReportManagementDao;
import com.epay.reporting.dto.ReportAlertDto;
import com.epay.reporting.dto.ReportFile;
import com.epay.reporting.dto.ReportManagementDto;
import com.epay.reporting.etl.producer.ReportAlertGenerateProducer;
import com.epay.reporting.exception.ReportingException;
import com.epay.reporting.externalservice.S3Service;
import com.epay.reporting.util.ReportingConstant;
import com.epay.reporting.util.enums.ReportStatus;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sbi.epay.authentication.util.EPayAuthenticationConstant;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.slf4j.MDC;
import org.springframework.stereotype.Service;

import java.text.MessageFormat;
import java.util.List;
import java.util.UUID;
import java.util.function.Consumer;

import static com.epay.reporting.util.ErrorConstants.*;
import static org.apache.commons.lang3.StringUtils.equalsIgnoreCase;

/**
 * Class Name: ReportService
 * *
 * Description: This service class handles the business logic for generating reports
 * for different report types (Order, Transaction, and Refund). It retrieves data
 * from the database, formats it appropriately, and generates reports in various
 * formats (like CSV, XLSX). The service also handles the update of report statuses
 * during the report generation process.
 * *
 * Author: Bhoopendra Rajput
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Service
@RequiredArgsConstructor
public class ReportService {
    private static final List<String> orderHeader = List.of("Txn Date & Time", "Merchant Order Number", "Customer Id", "Txn Currency", "Order Amount", "SBIePay Order ID", "Order Id Status", "Attempts");
    private static final List<String> transactionHeader = List.of("Transaction Request Date & Time", "Transaction Success Date & Time", "Merchant Order No", "SBIEPAY ORDER ID", "Cust Id", "ATRN", "Gateway Trace Number", "Pay Mode Code", "Gateway Name", "Pay Proc", "Transaction Currency", "Merchant Order Amount", "Gateway Posting Amount", "Commission", "GST", "Order Status", "Transaction Status", "Settlement Status", "Refund Status", "Chargeback Status", "Amount Refunded", "Amount Chargeback", "CIN Number", "Merchant Other Details");
    private static final List<String> refundHeader = List.of("Merchant Order ID", "SBIePay Order ID", "Merchant Posting Amount", "Gateway Posting Amount", "ATRN", "Transaction Status", "Transaction success date and time", "ARRN", "Refund Type ", "Refund Currency", "Refund Amount", "Refund booking date", "Refund processed Date", "Refund Status", "Payment Gateway", "Payment Mode", "Amount Refunded", "Further Refund Allowed ", "Pending Amount for Refund", "Remark");
    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    private final ReportDao reportDao;
    private final ReportManagementDao reportManagementDao;
    private final FileGeneratorService fileGeneratorService;
    private final S3Service s3Service;
    private final ReportAlertGenerateProducer reportGeneratePublisher;
    private final ObjectMapper objectMapper;

    /**
     * Method Name: generateReport
     * <p>
     * Description: This method is the entry point for generating any report. It updates
     * the report status to 'GENERATION_STARTED' and then delegates the report generation
     * task to the appropriate method based on the report type. After completion, it
     * updates the report status to 'GENERATED' or 'GENERATION_FAILED' in case of an error.
     *
     * @param reportManagementId UUID - The unique identifier for the report management task.
     */

    public void generateReport(UUID reportManagementId) {
        log.info("Starting report generation for ReportManagementId: {}", reportManagementId);
        ReportManagementDto reportManagementDto = reportManagementDao.updateReportStatus(reportManagementId, ReportStatus.GENERATION_STARTED);
        try {
            log.info("Report generation Request Received for {} with info reportManagementDto : {} ", reportManagementDto.getReport(), reportManagementDto);
            switch (reportManagementDto.getReport()) {
                case ORDER ->
                        buildReport(reportManagementDto, orderHeader, reportDao.getOrderReportData(reportManagementDto));
                case TRANSACTION ->
                        buildReport(reportManagementDto, transactionHeader, reportDao.getTransaction(reportManagementDto));
                case REFUNDS ->
                        buildReport(reportManagementDto, refundHeader, reportDao.getRefundReportData(reportManagementDto));
                default ->
                        throw new ReportingException(INVALID_ERROR_CODE, MessageFormat.format(INVALID_ERROR_MESSAGE, "Report Generation Request", "Implementation need to check"));
            }
            log.info("Report generation Request Completed for {} with info reportManagementDto : {} ", reportManagementDto.getReport(), reportManagementDto);
        } catch (ReportingException e) {
            String errorReason = equalsIgnoreCase(NO_RECORD_FOUND, e.getErrorMessage()) ? NO_RECORD_FOUND : "Report Generation Failed: " + MDC.get(EPayAuthenticationConstant.CORRELATION_ID);
            reportManagementDao.updateStatusAndRemarks(reportManagementDto.getId(), ReportStatus.GENERATION_FAILED, errorReason);
            log.error("Error in Report Generation for {} with info reportManagementDto : {} and error : {} ", reportManagementDto.getReport(), reportManagementDto, e.getErrorMessage());
            throw e;
        } catch (Exception e) {
            reportManagementDao.updateStatusAndRemarks(reportManagementDto.getId(), ReportStatus.GENERATION_FAILED, "Report Generation Failed : " + MDC.get(EPayAuthenticationConstant.CORRELATION_ID));
            log.error("Error in Report Generation for {} with info reportManagementDto : {} and error : {} ", reportManagementDto.getReport(), reportManagementDto, e.getMessage());
            throw new ReportingException(GENERATION_ERROR_CODE, MessageFormat.format(GENERATION_ERROR_MESSAGE, "Report"));
        }
    }

    /**
     * Method Name: reportRegeneration
     * <p>
     * Description: This method fetches all reports that are scheduled for generation
     * and triggers their generation process.
     */
    public void reportRegeneration() {
        log.info("Fetching reports with status TO_BE_GENERATE...");
        List<ReportManagementDto> reportManagementDtos = reportManagementDao.findReportByStatus(ReportStatus.TO_BE_GENERATE);
        log.info("Found {} reports available for re-generation.", reportManagementDtos.size());
        reportManagementDtos.forEach(consumerWithIgnoreReportException(e -> generateReport(e.getId())));
        log.info("Report generation process completed for all pending reports.");
    }

    /**
     * Consumer will process method and ignore the report exception.
     *
     * @param consumer Consumer<T>
     * @param <T>      Consumer
     * @return <T>
     */
    public <T> Consumer<T> consumerWithIgnoreReportException(Consumer<T> consumer) {
        return t -> {
            try {
                consumer.accept(t);
            } catch (ReportingException e) {
                log.error("Exception occurred while executing with param {}", t);
            }
        };
    }


    /**
     * Method Name: buildReport
     * <p>
     * Description: This method is responsible for building the final report file.
     * It uses the file generator service to create the file model and then generates the
     * actual report file. Once the report file is generated, it updates the report
     * status and file path in the database.
     *
     * @param reportManagementDto ReportManagementDto - The report management details.
     * @param header              List<String> - The headers for the report.
     * @param fileData            List<List<Object>> - The report data.
     */
    private void buildReport(ReportManagementDto reportManagementDto, List<String> header, List<List<Object>> fileData) {
        log.info("Building report for ReportManagementId: {} and format: {}", reportManagementDto.getId(), reportManagementDto.getFormat());
        ReportFile reportFile = fileGeneratorService.generateFile(reportManagementDto.getFormat(), reportManagementDto.getReport(), reportManagementDto.getMId(), header, fileData);
        uploadFileOnS3(reportManagementDto, reportFile);
    }

    private void uploadFileOnS3(ReportManagementDto reportManagementDto, ReportFile reportFile) {
        String s3FileName = s3Service.uploadFile(reportFile.getName(), reportFile.getContent(), true);
        reportManagementDao.updateStatusAndFilePath(reportManagementDto.getId(), ReportStatus.GENERATED, s3FileName);
        publishReportGenerationAlert(reportManagementDto);
        log.info("Report generated and file path [{}] updated for ReportManagementId: {}", s3FileName, reportManagementDto);
    }

    /**
     * publishing report name to kafka
     *
     * @param reportManagementDto ReportManagementDto
     */
    private void publishReportGenerationAlert(ReportManagementDto reportManagementDto) {
        try {
            String alertMessage = objectMapper.writeValueAsString(ReportAlertDto.builder().mId(reportManagementDto.getMId()).reportName(reportManagementDto.getReport().getName()).alertType(ReportingConstant.REPORT_GENERATION).build());
            reportGeneratePublisher.publish(reportManagementDto.getReport().getName() + "_" + reportManagementDto.getId(), alertMessage);
        } catch (Exception e) {
            log.error("Error in publishing alert", e);
        }
    }

}
