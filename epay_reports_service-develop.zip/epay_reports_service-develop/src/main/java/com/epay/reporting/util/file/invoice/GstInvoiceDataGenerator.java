package com.epay.reporting.util.file.invoice;

import com.epay.reporting.entity.view.GstReport;
import com.epay.reporting.util.ReportingConstant;
import com.epay.reporting.util.enums.Report;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.experimental.UtilityClass;

import java.util.*;

@UtilityClass
public class GstInvoiceDataGenerator {
    private static final LoggerUtility log = LoggerFactoryUtility.getLogger(GstInvoiceDataGenerator.class);

    public static Map<String, List<GstReport>> convertInvoiceGstMonthWise(List<GstReport> gstReportData) {
        log.debug("Converting merchant GST data into month-wise groups.");
        Map<String, List<GstReport>> gstDataMonthBy = new HashMap<>();
        gstReportData.forEach(merchantFeesReport -> {
            if (gstDataMonthBy.containsKey(merchantFeesReport.getTransactionMonth())) {
                gstDataMonthBy.get(merchantFeesReport.getTransactionMonth()).add(merchantFeesReport);
            } else {
                List<GstReport> merchantFeesReports = new ArrayList<>();
                merchantFeesReports.add(merchantFeesReport);
                gstDataMonthBy.put(merchantFeesReport.getTransactionMonth(), merchantFeesReports);
            }
        });
        log.debug("Conversion completed. Grouped by {} months.", gstDataMonthBy.size());
        return gstDataMonthBy;
    }

    public static Map<String, Object> createCSVTemplate(Report report, String reportDate, List<GstReport> gstReports) {
        log.info("Creating CSV template input for report: {} on date: {}", report.getName(), reportDate);
        List<String> headers = Arrays.asList("Transaction Number", "GST", "GST Charged", "GST Of", "Narration", "Date");
        List<List<Object>> rows = new ArrayList<>();
        for (GstReport gstReport : gstReports) {
            List<Object> row = Arrays.asList(
                    gstReport.getTransactionNumber(),
                    ReportingConstant.GST_PERCENTAGE,
                    gstReport.getGstCharged(),
                    ReportingConstant.GST_OF,
                    ReportingConstant.NARRATION,
                    gstReport.getTransactionDate());
            rows.add(row);
        }

        Map<String, Object> dataMap = new HashMap<>();
        dataMap.put("headers", headers);
        dataMap.put("rows", rows);
        Map<String, Object> input = new HashMap<>();
        input.put("map", dataMap);
        input.put("report", reportDate);
        return input;
    }

}
