package com.epay.reporting.model.request;


import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import static com.epay.reporting.util.ErrorConstants.HIBERNATOR_REQUIRED_ERROR_MESSAGE;

/**
 * Class Name: ReportManagementRequest
 * Description: This class represents a request body for report management, including the parameters necessary
 * for generating a report. It contains details such as the report name, merchant ID, date range, and the report format.
 * Author: Bhoopendra Rajput
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * Version: 1.0
 */
@AllArgsConstructor
@Data
@Builder
@NoArgsConstructor
public class ReportManagementRequest {
    @NotBlank(message = HIBERNATOR_REQUIRED_ERROR_MESSAGE)
    private String report;
    @NotBlank(message = HIBERNATOR_REQUIRED_ERROR_MESSAGE)
    @JsonProperty("mId")
    private String mId;
    @NotNull(message = HIBERNATOR_REQUIRED_ERROR_MESSAGE)
    private Long durationFromDate;
    @NotNull(message = HIBERNATOR_REQUIRED_ERROR_MESSAGE)
    private Long durationToDate;
    @NotBlank(message = HIBERNATOR_REQUIRED_ERROR_MESSAGE)
    private String format;
}
