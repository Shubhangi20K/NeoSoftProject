package com.epay.reporting.entity.view;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RecentTransactionReport {

    private Long totalTransactionCount;
    private String totalOrderAmount;
    private String totalRefundAmount;
    private String totalTaxAmount;
    private String totalNetSettlementAmount;
    private String totalSettledAmount;
    private String totalPendingSettlementAmount;
    private String transactionDate;
}
