package com.epay.reporting.dao;

import com.epay.reporting.entity.view.GstReport;
import com.epay.reporting.entity.view.MerchantFeesReport;
import com.epay.reporting.repository.view.InvoiceRepository;
import com.epay.reporting.util.enums.Report;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

import static com.epay.reporting.util.file.invoice.FeesInvoiceDataGenerator.convertInvoiceFeeMonthWise;
import static com.epay.reporting.util.file.invoice.FeesInvoiceDataGenerator.createPdfTemplateInput;
import static com.epay.reporting.util.file.invoice.GstInvoiceDataGenerator.convertInvoiceGstMonthWise;
import static com.epay.reporting.util.file.invoice.GstInvoiceDataGenerator.createCSVTemplate;

/**
 * Class Name: InvoiceDao
 * Description: This class provides data access logic for fetching and processing
 * merchant fee data for invoice reports. It interacts with the `InvoiceRepository`
 * to retrieve merchant fees data, then processes the data month-wise for generating
 * invoice templates. The class also provides logging functionality for traceability.
 * Author: Bhoopendra Rajput
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * Version: 1.0
 */
@Component
@RequiredArgsConstructor
public class InvoiceDao {
    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    private final InvoiceRepository invoiceRepository;

    /**
     * Method Name: getFeesInvoiceData
     * Description: This method fetches merchant fee invoice data for a given merchant ID
     * and a list of report dates. It retrieves the data from the `InvoiceRepository`, processes
     * the data by grouping it month-wise, and generates the required invoice templates in the form
     * of a list of maps. Logs are added to track the process and help with debugging.
     * @param mId String - The merchant ID for which the invoice data is to be fetched.
     * @param reportMonths List<String> - A list of report dates for which the invoice data is needed.
     * @return List<Map<String, Object>> - A list of maps containing the processed invoice data, grouped by fee month.
     */
    public List<Map<String, Object>> getFeesInvoiceData(String mId, List<String> reportMonths) {
        log.info("Fetching Fees Invoice Data for MerchantId: {} and reportMonths {}", mId, reportMonths);
        List<MerchantFeesReport> merchantFeesData = invoiceRepository.getMerchantFeesInvoice(mId, reportMonths);
        Map<String, List<MerchantFeesReport>> feesDataMonthBy = convertInvoiceFeeMonthWise(merchantFeesData);
        log.info("Returning processed Fees Invoice data for {} months. Fetched {} records", feesDataMonthBy.size(), feesDataMonthBy.size());
        return feesDataMonthBy.keySet().stream().map(feeMonth -> createPdfTemplateInput(Report.FEES_INVOICE, feeMonth, feesDataMonthBy.get(feeMonth))).toList();
    }
    /**
     * Method Name: getGstInvoiceData
     * @param mId String - The merchant ID for which the invoice data is to be fetched.
     * @param reportMonths List<String> - A list of report dates for which the invoice data is needed.
     */
    public List<Map<String, Object>> getGstInvoiceData(String mId, List<String> reportMonths) {
        log.info("Fetching GST Invoice Data for MerchantId: {} and reportMonths {}", mId, reportMonths);
        List<GstReport> merchantGstData = invoiceRepository.getMerchantGstInvoice(mId, reportMonths);
        Map<String, List<GstReport>> gstDataMonthBy = convertInvoiceGstMonthWise(merchantGstData);
        log.info("Returning processed GST Invoice data for {} months. Fetched {} records", gstDataMonthBy.size(), merchantGstData.size());
        return gstDataMonthBy.entrySet().stream().map(entry -> createCSVTemplate(Report.GST_INVOICE, entry.getKey(), entry.getValue())).toList();
    }
}
