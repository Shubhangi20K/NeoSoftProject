package com.epay.reporting.model.response;


import com.epay.reporting.util.enums.Frequency;
import com.epay.reporting.util.enums.Report;
import com.epay.reporting.util.enums.ReportFormat;
import com.epay.reporting.util.enums.ReportScheduledStatus;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

import java.util.UUID;

@AllArgsConstructor
@Getter
@Setter
@ToString
@Builder
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ReportScheduleManagementResponse {

    private UUID scheduleRequestId;
    private Report report;
    private String mId;
    private ReportFormat format;
    private Frequency frequency;
    private String scheduleExecutionTime;
    private Long nextScheduleExecutionTime;
    private Long lastScheduleExecutionTime;
    private ReportScheduledStatus status;
    private Long requestStateTime;
    private Long executionTime;
    private String scheduleExecutionDate;
    private String reportDuration;
}
