package com.epay.reporting.config.aws;

import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.Getter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.auth.signer.AwsS3V4Signer;
import software.amazon.awssdk.auth.signer.S3SignerExecutionAttribute;
import software.amazon.awssdk.core.client.config.ClientOverrideConfiguration;
import software.amazon.awssdk.core.client.config.SdkAdvancedClientOption;
import software.amazon.awssdk.core.interceptor.ExecutionAttributes;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3Client;

import java.net.URI;

/**
 * Class Name: S3Config
 * Description: The S3Config class reads the application configuration for AWS S3 and sets up the necessary
 * configurations to create an S3Client for interacting with Amazon S3 services.
 * Author: Bhoopendra Rajput
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * Version:1.0
 */
@Configuration
@Getter
public class S3Config {
    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    @Value("${aws.s3.key}")
    private String accessKey;

    @Value("${aws.s3.secret}")
    private String secretKey;

    @Value("${aws.s3.region}")
    private String region;

    @Value("${aws.s3.url}")
    private String endPoint;

    @Value("${aws.s3.bucket.report}")
    private String reportBucket;


    @Value("${aws.s3.bucket.ops}")
    private String opsBucket;

    /**
     * Creating S3Client bean in spring application context.
     *
     * @return S3Client
     */
    @Bean
    public S3Client s3client() {
        log.info("s3EndPoint: {}", endPoint);
        log.info("region: {}", region);

        StaticCredentialsProvider provider = StaticCredentialsProvider.create(AwsBasicCredentials.builder().accessKeyId(accessKey).secretAccessKey(secretKey).build());

        return S3Client.builder().endpointOverride(URI.create(endPoint))
                .credentialsProvider(provider)
                .forcePathStyle(true)
                .region(Region.of(region))
                .overrideConfiguration(ClientOverrideConfiguration.builder()
                        .putAdvancedOption(SdkAdvancedClientOption.SIGNER, AwsS3V4Signer.create())
                        .executionAttributes(ExecutionAttributes.builder()
                                .put(S3SignerExecutionAttribute.ENABLE_PAYLOAD_SIGNING, false).build())
                        .build()
                )
                .build();
    }
}
