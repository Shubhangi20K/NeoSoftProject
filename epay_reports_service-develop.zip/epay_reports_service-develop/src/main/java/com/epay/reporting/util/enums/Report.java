package com.epay.reporting.util.enums;

import com.epay.reporting.exception.ReportingException;
import com.epay.reporting.util.ErrorConstants;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

import java.text.MessageFormat;
import java.util.Arrays;

import static com.epay.reporting.util.ErrorConstants.INVALID_FORMAT;

/**
 * Name: Report
 * Description: Represents different types of reports that can be generated (e.g., Order, Settlements, etc.).
 * *
 * Author: Bhoopendra Rajput
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Getter
@RequiredArgsConstructor
public enum Report {

    ORDER("Order","report"),
    SETTLEMENTS("Settlements", "settlements"),
    TRANSACTION("Transaction", "report"),
    REFUNDS("Refunds", "report"),
    CHARGEBACK("Chargeback", "chargeback"),
    FEES_INVOICE("Fees_Report","merchant_fees_report"),
    GST_INVOICE("GST_REPORT", "report"),
    //this reports are for OPS service
    TRANSACTION_MIS("TRANSACTION_MIS","report"),
    SETTLEMENT_FILE("SETTLEMENT_FILE","report"),
    TRANSACTION_WISE_PAYOUT_MIS("TRANSACTION_WISE_PAYOUT_MIS","report"),
    TRANSACTION_WISE_REFUND_MIS("TRANSACTION_WISE_REFUND_MIS", "report"),
    MERCHANT_WISE_PAYOUT_MIS("MERCHANT_WISE_PAYOUT_MIS","report"),
    SBIEPAY_AGG_BANKSTMT_REPORT("SBIEPAY_AGG_BANKSTMT_REPORT", "report"),
    AAT_PAYOUT("AAT_PAYOUT","report"),
    NEFT_PAYOUT("NEFT_PAYOUT","report"),
    BAD_RECORD("BAD_RECORD","report"),
    FAILED_REPORT("FAILED_REPORT","report");
    private final String name;
    private final String templateName;


    /**
     * Returns the Report enum corresponding to the provided name (case-insensitive).
     *
     * @param name The name of the report.
     * @return Corresponding Report enum.
     */
    public static Report getName(String name) {
        return Arrays.stream(values()).filter(rt -> rt.name().equalsIgnoreCase(name)).findFirst().orElseThrow(() -> new ReportingException(ErrorConstants.INVALID_ENUM_ERROR_CODE, MessageFormat.format(ErrorConstants.INVALID_ENUM_ERROR_MESSAGE, "Report")));
    }

}