package com.epay.reporting.scheduler;

import com.epay.reporting.service.ReportScheduleManagementService;
import com.sbi.epay.authentication.util.EPayAuthenticationConstant;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;
import org.slf4j.MDC;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.UUID;

/**
 * Class Name: ReportScheduleManagementScheduler
 * Description: This class is responsible for scheduling and executing tasks related to report management. It leverages the
 * ReportScheduleManagementService to automate report-related processes, ensuring timely generation and delivery of reports.
 * Author: Ranu Jain
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * Version: 1.0
 */
@Component
@RequiredArgsConstructor
public class ReportScheduleManagementScheduler {
    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());

    private final ReportScheduleManagementService reportScheduleManagementService;

    /**
     * Schedules and executes the report generation based on the specified cron expression.
     *
     * @Scheduled(cron = "${scheduled.cron.time}") The cron expression defines the schedule for executing the report generation.
     * @SchedulerLock(name = "Report_Scheduler", lockAtLeastFor = "PT30S", lockAtMostFor = "PT2M") Ensures that the report generation task
     * is locked for at least 30 seconds and at most 2 minutes to prevent concurrent executions.
     */
    @Scheduled(cron = "${scheduled.cron.time}")
    @SchedulerLock(name = "Report_Scheduler", lockAtLeastFor = "PT30S", lockAtMostFor = "PT2M")
    public void scheduleReportGeneration() {
        MDC.put(EPayAuthenticationConstant.CORRELATION_ID, String.valueOf(UUID.randomUUID()));
        MDC.put(EPayAuthenticationConstant.SCENARIO, "ReportScheduleManagementScheduler");
        MDC.put(EPayAuthenticationConstant.OPERATION, "scheduleReportGeneration");
        log.info("Scheduler called for scheduleReportGeneration");
        reportScheduleManagementService.executeReportBySchedule();
        log.info("Scheduler completed for scheduleReportGeneration");
    }
}
