package com.epay.reporting.etl.producer;

import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

/**
 * Class Name: KafkaMessagePublisher
 * Description: The KafkaMessagePublisher class is responsible for publishing messages to a specified Kafka topic.
 * It provides a method to send messages to a Kafka topic using the KafkaTemplate. The class logs the start and completion
 * of the message publishing process, including the topic, key, and message details.
 * Author: Bhoopendra Rajput
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * Version: 1.0
 */
@Component
@RequiredArgsConstructor
public class KafkaMessagePublisher {

    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    private final KafkaTemplate<String, String> kafkaTemplate;

    public void publish(String topic, String key, String message) {
        log.info("Start message publishing to kafka topic: {} , key : {} and  message : {}", topic, key, message);
        kafkaTemplate.send(topic, key, message);
        log.info("Complete message publishing to kafka topic: {} , key : {} and  message : {}", topic, key, message);
    }

}
