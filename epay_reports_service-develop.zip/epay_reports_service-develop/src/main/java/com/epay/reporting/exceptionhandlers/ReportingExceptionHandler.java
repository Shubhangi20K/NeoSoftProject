package com.epay.reporting.exceptionhandlers;

import com.epay.reporting.dto.ErrorDto;
import com.epay.reporting.exception.ReportingException;
import com.epay.reporting.exception.ValidationException;
import com.epay.reporting.model.response.ReportingResponse;
import com.epay.reporting.util.ErrorConstants;
import com.epay.reporting.util.ReportUtils;
import com.epay.reporting.util.ReportingConstant;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.ConstraintViolationException;
import org.hibernate.exception.SQLGrammarException;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.lang.Nullable;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import static com.epay.reporting.util.ErrorConstants.*;
import static com.epay.reporting.util.ReportingConstant.*;
import static org.apache.commons.lang3.StringUtils.contains;

/**
 * Class Name: GlobalExceptionHandler
 * *
 * Description:
 * *
 * Author: The ReportingExceptionHandler class is responsible for handling exceptions globally within the reporting module.
 * It extends ResponseEntityExceptionHandler and provides custom exception handling logic for reporting-related errors.
 * The class uses a logger to capture error details and provides appropriate responses for various exceptions encountered during report generation.
 * Author: Bhoopendra Rajput
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * Version: 1.0
 */
@ControllerAdvice
public class ReportingExceptionHandler extends ResponseEntityExceptionHandler {
    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());

    /**
     * @param ex ReportingException
     * @return ResponseEntity
     */
    @ExceptionHandler(value = {ReportingException.class})
    public ResponseEntity<Object> handleEPayServiceException(RuntimeException ex) {
        logger.error("ReportingException occurred: {}", ex.getMessage(), ex);
        ErrorDto errorDto;
        switch (ex) {
            case ReportingException me ->
                    errorDto = ErrorDto.builder().errorCode(me.getErrorCode()).errorMessage(me.getErrorMessage()).build();
            default ->
                    errorDto = ErrorDto.builder().errorCode(GENERIC_ERROR_CODE).errorMessage(ex.getLocalizedMessage()).build();
        }
        return generateResponseWithErrors(List.of(errorDto));
    }

    /**
     * Handle ValidationException
     *
     * @param ex ValidationException
     * @return ResponseEntity
     */
    @ExceptionHandler(ValidationException.class)
    public ResponseEntity<Object> handleValidationException(ValidationException ex) {
        logger.error("ValidationException occurred: {}", ex.getMessage(), ex);

        if (CollectionUtils.isEmpty(ex.getErrorMessages())) {
            ErrorDto errorDto = ErrorDto.builder().errorCode(ex.getErrorCode()).errorMessage(ex.getErrorMessage()).build();
            return generateResponseWithErrors(List.of(errorDto));
        }
        return generateResponseWithErrors(ex.getErrorMessages());
    }

    /**
     * Handle handleDBException exception
     *
     * @param ex DataAccessException
     * @return ResponseEntity
     */
    @ExceptionHandler(value = {DataAccessException.class, DataIntegrityViolationException.class, ConstraintViolationException.class, SQLGrammarException.class})
    public ResponseEntity<Object> handleDBException(Exception ex) {
        logger.error("Database exception occurred: {}", ex.getMessage(), ex);
        String errorMessage;
        switch (ex) {
            case DataIntegrityViolationException de -> errorMessage = de.getMostSpecificCause().getMessage();
            case DataAccessException de -> errorMessage = de.getMostSpecificCause().getMessage();
            case ConstraintViolationException de -> errorMessage = de.getConstraintViolations().toString();
            case SQLGrammarException de -> errorMessage = de.getLocalizedMessage();
            default -> errorMessage = ex.getMessage();
        }
        logger.error("Error in handleDBException: {}", errorMessage);
        ErrorDto errorDto = ErrorDto.builder().errorCode(ErrorConstants.GENERIC_ERROR_CODE).errorMessage(errorMessage).build();
        return ResponseEntity.internalServerError().body(ReportingResponse.builder().status(RESPONSE_FAILURE).errors(List.of(errorDto)).build());
    }

    /**
     * @param ex HttpMessageNotReadableException
     * @param headers HttpHeaders
     * @param status HttpStatusCode
     * @param request WebRequest
     * @return ResponseEntity
     */
    @Override
    protected ResponseEntity<Object> handleHttpMessageNotReadable(
            HttpMessageNotReadableException ex, HttpHeaders headers, HttpStatusCode status, WebRequest request) {
        String reason = ReportUtils.getParsingError(ex.getCause());
        ErrorDto errorDto = ErrorDto.builder().errorCode(INVALID_ERROR_CODE).errorMessage(MessageFormat.format(INVALID_ERROR_MESSAGE, "Request object", reason)).build();
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ReportingResponse.builder().status(RESPONSE_FAILURE).errors(List.of(errorDto)).build());
    }

    /**
     * Handle general exception
     *
     * @param ex Exception
     * @return ResponseEntity
     */
    @ExceptionHandler(value = {Exception.class})
    public ResponseEntity<Object> handleGenericException(Exception ex) {
        logger.error("Unhandled exception occurred: {}", ex.getMessage(), ex);
        ErrorDto errorDto = ErrorDto.builder().errorCode(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value())).errorMessage(ex.getMessage()).build();
        return ResponseEntity.internalServerError().body(ReportingResponse.builder().status(RESPONSE_FAILURE).errors(List.of(errorDto)).build());
    }

    /**
     * Handle Runtime exception
     *
     * @param ex RuntimeException
     * @return ResponseEntity
     */
    @ExceptionHandler(value = {IllegalArgumentException.class, IllegalStateException.class})
    protected ResponseEntity<Object> handleConflict(RuntimeException ex) {
        logger.error("Conflict exception occurred: {}", ex.getMessage(), ex);
        ErrorDto errorDto = ErrorDto.builder().errorCode(String.valueOf(HttpStatus.CONFLICT.value())).errorMessage(ex.getLocalizedMessage()).build();
        return ResponseEntity.status(HttpStatus.CONFLICT).body(ReportingResponse.builder().status(RESPONSE_FAILURE).errors(List.of(errorDto)).build());
    }

    @Override
    protected ResponseEntity<Object> handleExceptionInternal(Exception ex, @Nullable Object body, HttpHeaders headers, HttpStatusCode statusCode, WebRequest request) {
        logger.error("Spring internal exception occurred: {}", ex.getMessage(), ex);
        if (request instanceof ServletWebRequest servletWebRequest) {
            HttpServletResponse response = servletWebRequest.getResponse();
            if (response != null && response.isCommitted()) {
                return null;
            }
        }
        ErrorDto errorDto = ErrorDto.builder().errorCode(GENERIC_ERROR_CODE).errorMessage(GENERIC_ERROR_MESSAGE).build();
        return ResponseEntity.status(statusCode).body(ReportingResponse.builder().status(ReportingConstant.RESPONSE_FAILURE).errors(List.of(errorDto)).build());
    }

    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(
            MethodArgumentNotValidException ex, HttpHeaders headers, HttpStatusCode status, WebRequest request) {

        List<ErrorDto> errors = new ArrayList<>();
        ex.getBindingResult().getFieldErrors().forEach(fieldError ->
                errors.add(ErrorDto.builder()
                        .errorCode(ErrorConstants.REQUIRED_ERROR_CODE)
                        .errorMessage(fieldError.getField() + fieldError.getDefaultMessage())
                        .build())
        );

        return ResponseEntity.status(HttpStatus.OK)
                .body(ReportingResponse.builder().status(RESPONSE_FAILURE).errors(errors).build());
    }
    /**
     * Preparing errors in API response object.
     *
     * @param errors List
     * @return ResponseEntity
     */
    private ResponseEntity<Object> generateResponseWithErrors(List<ErrorDto> errors) {
        logger.info("Returning error response with {} errors", errors.size());
        return ResponseEntity.ok().body(ReportingResponse.builder().status(RESPONSE_FAILURE).errors(errors).build());
    }
}
