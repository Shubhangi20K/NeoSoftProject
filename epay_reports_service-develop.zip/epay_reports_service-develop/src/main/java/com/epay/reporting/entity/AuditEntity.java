package com.epay.reporting.entity;

import jakarta.persistence.MappedSuperclass;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.LastModifiedBy;

import java.io.Serializable;

/**
 * Class Name: AuditEntity
 * Description:
 * This class represents a base entity for auditing purposes. It extends the AuditEntityByDate class
 * and implements Serializable. It includes fields to track who created and last modified the entity
 * (createdBy and updatedBy). The class uses annotations to automatically populate these fields with
 * the user responsible for creating or updating the entity.
 * Author: V1018344
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * Version: 1.0
 */
@Getter
@Setter
@MappedSuperclass
public class AuditEntity extends AuditEntityByDate implements Serializable {

    @CreatedBy
    private String createdBy;

    @LastModifiedBy
    private String updatedBy;

}