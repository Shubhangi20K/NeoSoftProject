package com.epay.reporting.dao;

import com.epay.reporting.entity.view.TransactionWisePayoutFormat;
import com.epay.reporting.mapper.TransactionMerchantPayoutMapper;
import com.epay.reporting.repository.view.ViewTransactionWisePayoutRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * Class Name: TransactionDashboardDao
 * *
 * Class for accessing Operation-related data.
 * *
 * Author: Saurabh Mahto(V1018841)
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */

@Service
@RequiredArgsConstructor
public class TransactionMerchantPayoutDao {
    private final ViewTransactionWisePayoutRepository viewTransactionWisePayoutRepository;
    private final TransactionMerchantPayoutMapper transactionMerchantPayoutMapper;

    public List<List<Object>> getTransactionMerchantPayouts(List<UUID> mpId){
        List<TransactionWisePayoutFormat> viewTransactionMis = viewTransactionWisePayoutRepository.fetchTransactionMerchantPayouts(mpId);
        return viewTransactionMis.stream().map(transactionMerchantPayoutMapper::mapToList).collect(Collectors.toList());
    }
}
