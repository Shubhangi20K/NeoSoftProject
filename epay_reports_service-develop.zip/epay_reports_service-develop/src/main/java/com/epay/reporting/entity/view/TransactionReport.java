package com.epay.reporting.entity.view;

import lombok.*;

import java.math.BigDecimal;

/**
 * Class Name: TransactionReport
 * *
 * Description:This class represents a report of a transaction. It holds details such as
 * the transaction ID, transaction type, date, amount, and status.
 * Author: V1018344
 * Copyright (c) 2025 [State Bank of India]
 * ALl rights reserved
 * *
 * Version: 1.0
 */
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Data
public class TransactionReport {


    private String mId;
    private String transactionDate;
    private String trnxSuccessDateAndTime;
    private String merchantOrderNumber;
    private String sbiOrderRefNumber;
    private String customerId;
    private String atrnNum;
    private String gateWayTraceNumber;
    private String payModeName;
    private String bankName;
    private String payProc;
    private String transactionCurrency;
    private BigDecimal orderAmount;
    private BigDecimal gatewayPostingAmount;
    private BigDecimal commission;
    private BigDecimal gst;
    private String orderStatus;
    private String transactionStatus;
    private String settlementStatus;
    private String refundStatus;
    private String chargeBackStatus;
    private String refundAmount;
    private String chargeBackAmount;
    private String cinNumber;
    private String merchantOtherDetails;
}
