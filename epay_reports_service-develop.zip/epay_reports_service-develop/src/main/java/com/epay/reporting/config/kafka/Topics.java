package com.epay.reporting.config.kafka;

import lombok.Getter;
import lombok.Setter;
import org.apache.kafka.clients.admin.NewTopic;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

/**
 * Class Name: Topics
 * Description:The Topics class is used to hold the configuration values related to Kafka topics. It reads these
 * values from the application's properties file using `@Value` annotations. This class contains settings
 * like the Kafka topic name, number of partitions, and replication factor for Kafka topics.
 * Author: Bhoopendra Rajput
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * Version: 1.0
 */
@Getter
@Setter
@Component
public class Topics {

    @Value("${spring.kafka.topic.report}")
    private String reportTopic;

    @Value("${spring.kafka.topic.alert}")
    private String reportAlertTopic;

    @Value("${spring.kafka.topic.reconReport.generator}")
    private String opsReportGeneration;

    @Value("${spring.kafka.topic.reconReport.confirmation}")
    private String opsReportConfirmationTopic;

    @Value("${spring.kafka.topic.partitions}")
    private int noOfPartitions;

    @Value("${spring.kafka.topic.replicationFactor}")
    private short replicationFactor;

    @Bean
    public NewTopic reportTopic() {
        return new NewTopic(reportTopic, noOfPartitions, replicationFactor);
    }
}
