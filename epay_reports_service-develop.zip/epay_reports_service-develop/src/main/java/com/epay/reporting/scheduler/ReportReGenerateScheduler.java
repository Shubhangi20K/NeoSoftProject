package com.epay.reporting.scheduler;

import com.epay.reporting.service.ReportService;
import com.sbi.epay.authentication.util.EPayAuthenticationConstant;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;
import org.slf4j.MDC;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.UUID;

/**
 * Class Name: ReportReGenerateScheduler
 * Description: This class is responsible for scheduling and executing tasks related to report management. It leverages the
 * ReportScheduleManagementService to automate report-related processes, ensuring timely generation and delivery of reports.
 * Author: Subhra
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * Version: 1.0
 */
@Component
@RequiredArgsConstructor
public class ReportReGenerateScheduler {
    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    private final ReportService reportService;

    @Scheduled(cron = "${scheduled.regenerate.time}")
    @SchedulerLock(name = "Report_Management_Scheduler", lockAtLeastFor = "PT30S", lockAtMostFor = "PT2M")
    public void reportReGenerateScheduler() {
        MDC.put(EPayAuthenticationConstant.CORRELATION_ID, String.valueOf(UUID.randomUUID()));
        MDC.put(EPayAuthenticationConstant.SCENARIO, "ReportReGenerateScheduler");
        MDC.put(EPayAuthenticationConstant.OPERATION, "reportReGenerateScheduler");
        log.info("Scheduler called for scheduleReportManagement");
        reportService.reportRegeneration();
        log.info("Scheduler completed for scheduleReportManagement");
    }
}
