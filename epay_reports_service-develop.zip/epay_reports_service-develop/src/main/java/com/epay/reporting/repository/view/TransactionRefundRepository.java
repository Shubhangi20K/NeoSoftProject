package com.epay.reporting.repository.view;

import com.epay.reporting.entity.view.TransactionWiseRefundFormat;
import com.epay.reporting.util.queries.ReconQueries;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
@RequiredArgsConstructor
public class TransactionRefundRepository {

    private final NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    public List<TransactionWiseRefundFormat> fetchTransactionRefund(List<UUID> mpId) {
        List<String> mpIdString=mpId.stream().map(id -> id.toString().replace("-","").toUpperCase()).toList();
        MapSqlParameterSource params = new MapSqlParameterSource();
        params.addValue("mpId", mpIdString);
        return namedParameterJdbcTemplate.query(ReconQueries.TRANSACTION_REFUND,params, new BeanPropertyRowMapper<>(TransactionWiseRefundFormat.class));
    }
}
