package com.epay.reporting.dao;

import com.epay.reporting.entity.view.SbiEpayAggBankStmtReport;
import com.epay.reporting.mapper.SBIAccountPayoutMapper;
import com.epay.reporting.repository.view.SBIAccountPayoutRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Class Name: SBIAccountPayoutDao
 * *
 * Class for accessing Operation-related data.
 * *
 * Author: Saurabh Mahto(V1018841)
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */

@Service
@RequiredArgsConstructor
public class SBIAccountPayoutDao {
    
    private final SBIAccountPayoutRepository sbiAccountPayoutRepository;
    private final SBIAccountPayoutMapper sbiAccountPayoutMapper;

    public List<List<Object>> getSBIAccountPayouts(String mId){
        List<SbiEpayAggBankStmtReport> SbiEpayAggBankStmtReports = sbiAccountPayoutRepository.fetchSBIEPAYAccountPayout(mId);
        return SbiEpayAggBankStmtReports.stream().map(sbiAccountPayoutMapper::mapToList).collect(Collectors.toList());
    }

}
