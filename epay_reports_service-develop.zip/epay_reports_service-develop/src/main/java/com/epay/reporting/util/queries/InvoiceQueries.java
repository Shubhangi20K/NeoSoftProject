package com.epay.reporting.util.queries;

import lombok.experimental.UtilityClass;

/**
 * Class Name: InvoiceQueries
 * *
 * Description: This class contains SQL queries related to the Invoice
 * *
 * Author: Bhoopendra Rajput
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@UtilityClass
public class InvoiceQueries {
    public static final String  JDBC_TXN_INVOICE = """
                    SELECT TO_CHAR(TO_DATE(vti.TRANSACTION_DATE, 'DD-MM-YY'), 'Mon-YYYY') as transactionDate,
                    COUNT(vti.ATRN_NUM) as transactionCount, vti.PayMode_code as payMode,
                    SUM(vti.MERCHANT_FEE_AMOUNT)as merchantFeeAmount,
                    SUM(vti.SERVICE_TAX_AMOUNT)as merchantServiceTaxAmount,
                    SUM(vti.MERCHANT_FEE_AMOUNT)+ SUM(vti.SERVICE_TAX_AMOUNT) as merchantTotalCommission,
                    vti. merchant_name as merchantName,mi.GST_NUMBER as gstNumber,
                    mi.address_line1 as address1, mi.address_line2 as address2, mi.state as state, mi.city as city,
                    mi.country as country, mi.pincode as pincode
                    FROM view_transaction_fees_invoice vti
                    JOIN MERCHANT_INFO_MERCH mi on mi.mid = vti.mid
                    WHERE vti.MID = :mId AND vti.PAYMODE_CODE is NOT NULL AND vti.atrn_num is NOT NULL AND
                    TO_CHAR(TO_DATE(vti.TRANSACTION_DATE, 'DD-MM-YY'), 'Mon-YYYY') IN (:reportMonth)
                    GROUP BY TO_CHAR(TO_DATE(vti.TRANSACTION_DATE, 'DD-MM-YY'), 'Mon-YYYY'), vti.paymode_code,
                    vti.merchant_name, mi.GST_NUMBER,mi.address_line1, mi.address_line2 , mi.state, mi.city, mi.country, mi.pincode
                    ORDER BY TO_CHAR(TO_DATE(vti.TRANSACTION_DATE, 'DD-MM-YY'), 'Mon-YYYY') desc
            """;
    public static final String JDBC_GST_INVOICE = """
                    SELECT TRANSACTION_NUMBER AS transactionNumber,
                    TO_CHAR(transaction_date, 'DD-MM-YY') as transactionDate,
                    TO_CHAR(TO_DATE(transaction_date, 'DD-MM-YY'), 'Mon-YYYY') as transactionMonth,
                    CASE
                        WHEN MERCHANT_GST_CHARGED > 0 THEN MERCHANT_GST_CHARGED
                        ELSE CUSTOMER_GST_CHARGED
                    END AS gstCharged
                    FROM view_gst_invoice
                    WHERE MID = :mId
                    AND TO_CHAR(TO_DATE(transaction_date, 'DD-MM-YY'), 'Mon-YYYY') IN (:reportMonth)
                    ORDER BY transaction_date DESC
            """;
}