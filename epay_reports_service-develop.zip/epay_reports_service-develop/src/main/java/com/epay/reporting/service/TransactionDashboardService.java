package com.epay.reporting.service;

import com.epay.reporting.config.ReportingConfig;
import com.epay.reporting.dao.TransactionDashboardDao;
import com.epay.reporting.entity.view.RecentTransactionReport;
import com.epay.reporting.entity.view.TransactionPaymodeReport;
import com.epay.reporting.entity.view.TransactionSummaryReport;
import com.epay.reporting.model.request.RecentTransactionRequest;
import com.epay.reporting.model.request.TransactionPayModeRequest;
import com.epay.reporting.model.request.TransactionSummaryRequest;
import com.epay.reporting.model.response.ReportingResponse;
import com.epay.reporting.util.ReportingConstant;
import com.epay.reporting.util.enums.Frequency;
import com.epay.reporting.util.enums.Report;
import com.epay.reporting.util.enums.ReportFormat;
import com.epay.reporting.util.file.model.FileModel;
import com.epay.reporting.validator.MIdValidator;
import com.epay.reporting.validator.TransactionDashboardValidator;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * Class Name: TransactionDashboardService
 * *
 * Description: This service class handles the business logic for Transaction Dashboard
 * *
 * Author: Bhoopendra Rajput
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Service
@RequiredArgsConstructor
public class TransactionDashboardService {
    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());

    private final TransactionDashboardDao transactionDashboardDao;
    private final FileGeneratorService fileGeneratorService;
    private final ReportingConfig reportingConfig;
    private final TransactionDashboardValidator transactionDashboardValidator;

    /**
     * Fetches transaction trends (daily, weekly, or monthly) for a given merchant ID and frequency.
     * @param mId - Merchant ID
     * @param frequency - Frequency of the trends
     * @return List of transaction trend data
     */
    public ReportingResponse<TransactionSummaryReport> getTransactionTrends(String mId, String frequency) {
        transactionDashboardValidator.validateTransactionTrendsRequest(mId, frequency);
        log.info("Fetching Transaction Trends for MerchantId: {} and frequency {}", mId, frequency);
        List<TransactionSummaryReport> transactionDailyTrends = transactionDashboardDao.getTransactionTrends(mId, Frequency.getName(frequency));
        return ReportingResponse.<TransactionSummaryReport>builder().status(ReportingConstant.RESPONSE_SUCCESS).data(transactionDailyTrends).total((long) transactionDailyTrends.size()).build();
    }

    /**
     * Fetches recent transaction (daily, or monthly) for a given merchant ID, frequency, from Date and to date.
     * @param mId - Merchant ID
     * @return List of recent transaction data
     */
    public ReportingResponse<RecentTransactionReport> getRecentTransactionsSummary(String mId, RecentTransactionRequest recentTransactionRequest, Pageable pageable) {
        transactionDashboardValidator.validateRequest(mId, recentTransactionRequest);
        log.info("Fetching Recent Transaction for MerchantId: {} and frequency {}", mId, recentTransactionRequest);
        Page<RecentTransactionReport> transactionDailyTrends = transactionDashboardDao.getRecentTransactionSummary(mId, recentTransactionRequest, pageable);
        return ReportingResponse.<RecentTransactionReport>builder().data(transactionDailyTrends.stream().toList()).count(transactionDailyTrends.stream().count()).total(transactionDailyTrends.getTotalElements()).status(ReportingConstant.RESPONSE_SUCCESS).build();
    }

    public void downloadRecentTransactionReport(HttpServletResponse httpResponse, String mId, RecentTransactionRequest recentTransactionRequest) {
        Pageable pageable = PageRequest.of(0, reportingConfig.getReportPageSize());
        List<RecentTransactionReport> recentTransactionReportList = getRecentTransactionsSummary(mId, recentTransactionRequest, pageable).getData();
        List<List<Object>> fileData = recentTransactionReportList.stream().map(this::convertToListOfObject).toList();
        buildReport(mId, getHeaders(), fileData, httpResponse);
    }

    /**
     * Fetches the transaction payMode report for a given Merchant ID (MID) and date range.
     *
     * @param mId                       Merchant ID for which the report is to be fetched
     * @param transactionPayModeRequest Request object containing the date range (fromDate and toDate)
     * @return ReportingResponse<TransactionPayModeReport> containing the list of transaction payMode reports
     */
    public ReportingResponse<TransactionPaymodeReport> getTransactionPayModeReport(String mId, TransactionPayModeRequest transactionPayModeRequest) {
        transactionDashboardValidator.validateTransactionPayModeRequest(mId, transactionPayModeRequest);
        log.info("Fetching transaction pay mode report for MID: {} and Request: {}", mId, transactionPayModeRequest);
        List<TransactionPaymodeReport> transactionDailyPayMode = transactionDashboardDao.getTransactionPayModeReport(mId, transactionPayModeRequest);
        return ReportingResponse.<TransactionPaymodeReport>builder().data(transactionDailyPayMode).status(ReportingConstant.RESPONSE_SUCCESS).build();
    }

    /**
     * This method generates the daily transaction report with failure details and percentage calculation.
     *
     * @param mId                       Merchant ID
     * @param transactionSummaryRequest Request object containing the date range (fromDate and toDate)
     * @return List of TransactionSummaryReport
     */
    public ReportingResponse<TransactionSummaryReport> getTransactionSummaryReport(String mId, TransactionSummaryRequest transactionSummaryRequest) {
        transactionDashboardValidator.validateTransactionSummaryRequest(mId, transactionSummaryRequest);
        log.info("Fetching transaction summary report for MID: {}, TransactionSummaryRequest : {}", mId, transactionSummaryRequest);
        List<TransactionSummaryReport> transactionSummaryReports = transactionDashboardDao.getTransactionSummaryReport(mId, transactionSummaryRequest);
        return ReportingResponse.<TransactionSummaryReport>builder().data(transactionSummaryReports).status(ReportingConstant.RESPONSE_SUCCESS).build();
    }

    /**
     * Method Name: convertToListOfObject
     * <p>
     * Description: This method converts an OrderReport object into a list of objects
     * where each element represents a field value in the report.
     *
     * @param recentTransactionReport OrderReport - The order report to convert.
     * @return List<Object> - A list of field values of the OrderReport.
     */
    protected List<Object> convertToListOfObject(RecentTransactionReport recentTransactionReport) {
        return List.of(StringUtils.isEmpty(recentTransactionReport.getTransactionDate()) ? StringUtils.EMPTY : recentTransactionReport.getTransactionDate(),
                ObjectUtils.isEmpty(recentTransactionReport.getTotalTransactionCount()) ? 0 : recentTransactionReport.getTotalTransactionCount(),
                ObjectUtils.isEmpty(recentTransactionReport.getTotalOrderAmount()) ? 0.00 : recentTransactionReport.getTotalOrderAmount(),
                ObjectUtils.isEmpty(recentTransactionReport.getTotalTaxAmount()) ? 0.00 : recentTransactionReport.getTotalTaxAmount(),
                ObjectUtils.isEmpty(recentTransactionReport.getTotalRefundAmount()) ? 0.00 : recentTransactionReport.getTotalRefundAmount(),
                ObjectUtils.isEmpty(recentTransactionReport.getTotalNetSettlementAmount()) ? 0.00 : recentTransactionReport.getTotalNetSettlementAmount(),
                ObjectUtils.isEmpty(recentTransactionReport.getTotalSettledAmount()) ? 0.00 : recentTransactionReport.getTotalSettledAmount(),
                ObjectUtils.isEmpty(recentTransactionReport.getTotalPendingSettlementAmount()) ? 0.00 : recentTransactionReport.getTotalPendingSettlementAmount()
                );
    }

    /**
     * Creating CSV content and setting it in response output stream.
     * @param mId String
     * @param header List<String> header
     * @param fileData ist<List<Object>>
     * @param response HttpServletResponse
     */
    protected void buildReport(String mId, List<String> header, List<List<Object>> fileData, HttpServletResponse response) {
        FileModel fileModel = fileGeneratorService.buildFileModel(
                ReportFormat.CSV, header, fileData, Map.of("headers", header, "rows", fileData)
        );
        log.info("File model created, generating file for transactions.");
        fileGeneratorService.downloadFile(response, ReportFormat.CSV, Report.TRANSACTION, mId, fileModel);
    }

    protected List<String> getHeaders() {
        return Arrays.asList(
                "Txn. Day/Month",
                "Txn. Count",
                "Total Order Amt",
                "Total Txn fee",
                "Refund adjusted",
                "Net Settlement Amt",
                "Settled Amt",
                "Pending Amt"

        );
    }
}
