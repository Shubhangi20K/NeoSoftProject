package com.epay.reporting.dto.ops;



import com.epay.reporting.util.enums.Report;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;
/**
 * Class Name: OpsReportRequestDto
 * Description: This class serves as a Data Transfer Object (DTO) for managing report-related details within
 * the application.
 * Author: Saurabh Mahto(V1018841)
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * Version:1.0
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class OpsReportRequestDto {

    private Report reportType;
    private UUID rrId;
    private ReportFilterDto reportFilter;

}
