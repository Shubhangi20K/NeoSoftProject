package com.epay.reporting.mapper;

import com.epay.reporting.entity.view.TransactionWiseRefundFormat;
import org.apache.commons.lang3.StringUtils;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;

import java.math.BigDecimal;
import java.util.List;

import static org.thymeleaf.util.ObjectUtils.nullSafe;

@Mapper(builder = @Builder(disableBuilder = true), componentModel = "spring")
public interface TransactionRefundMapper {

    default List<Object> mapToList(TransactionWiseRefundFormat transactionWiseRefundFormat){
        return List.of(
                nullSafe(transactionWiseRefundFormat.getSettlementFileNumber(), StringUtils.EMPTY),
                nullSafe(transactionWiseRefundFormat.getSettlementTime(), StringUtils.EMPTY),
                nullSafe(transactionWiseRefundFormat.getMId(), StringUtils.EMPTY),
                nullSafe(transactionWiseRefundFormat.getMerchantName(), StringUtils.EMPTY),
                nullSafe(transactionWiseRefundFormat.getMerchantOrderNumber(), StringUtils.EMPTY),
                nullSafe(transactionWiseRefundFormat.getTransactionId(), StringUtils.EMPTY),
                nullSafe(transactionWiseRefundFormat.getTransactionDate(), StringUtils.EMPTY),
                nullSafe(transactionWiseRefundFormat.getTransactionCurrency(), StringUtils.EMPTY),
                nullSafe(transactionWiseRefundFormat.getTransactionAmt(), BigDecimal.ZERO),
                nullSafe(transactionWiseRefundFormat.getRefundCurrency(), StringUtils.EMPTY),
                nullSafe(transactionWiseRefundFormat.getRefundAmt(), BigDecimal.ZERO),
                nullSafe(transactionWiseRefundFormat.getCommissionPayable(), 0),
                nullSafe(transactionWiseRefundFormat.getGst(), BigDecimal.ZERO),
                nullSafe(transactionWiseRefundFormat.getNetRefundAmount(), BigDecimal.ZERO),
                nullSafe(transactionWiseRefundFormat.getGatewayName(), StringUtils.EMPTY),
                nullSafe(transactionWiseRefundFormat.getGatewayTraceNumber(), StringUtils.EMPTY),
                nullSafe(transactionWiseRefundFormat.getPayMode(), StringUtils.EMPTY),
                nullSafe(transactionWiseRefundFormat.getRefundType(), StringUtils.EMPTY),
                nullSafe(transactionWiseRefundFormat.getRefundBookingDate(), StringUtils.EMPTY),
                nullSafe(transactionWiseRefundFormat.getArrnNum(), StringUtils.EMPTY)
        );
    }
}
