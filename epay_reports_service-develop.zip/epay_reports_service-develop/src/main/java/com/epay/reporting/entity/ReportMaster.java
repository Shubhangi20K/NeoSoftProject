package com.epay.reporting.entity;

import com.epay.reporting.util.enums.Report;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.CreatedDate;

import java.util.UUID;

/**
 * Class Name: ReportMaster
 * Description: This class represents the master entity for managing reports. It is annotated with @Entity,
 * mapping it to the "REPORT_MASTER" table in the database. The class uses Lombok annotations for
 * automatic generation of getters, setters, constructors, and the builder pattern, which reduces
 * boilerplate code. It encapsulates the details for report management at a master level.
 * Author: V1018344
 * Copyright (c) 2025 [State Bank of India]
 * ALl rights reserved
 * *
 * Version: 1.0
 */

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "REPORT_MASTER")
public class ReportMaster {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(nullable = false, updatable = false, unique = true)
    private UUID id;
    @Enumerated(EnumType.STRING)
    private Report name;
    private String description;
    @CreatedDate
    private Long createdAt;
    private int sequence;
}