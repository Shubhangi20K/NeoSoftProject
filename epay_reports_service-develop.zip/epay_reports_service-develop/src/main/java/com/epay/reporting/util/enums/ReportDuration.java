package com.epay.reporting.util.enums;

import com.epay.reporting.exception.ReportingException;
import com.epay.reporting.util.ErrorConstants;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.tuple.Pair;

import java.text.MessageFormat;
import java.time.LocalDate;
import java.util.Arrays;

@Getter
@RequiredArgsConstructor
public enum ReportDuration {
    YESTERDAY("YESTERDAY", 1),
    LAST_7_DAYS("LAST_7_DAYS", 7),
    LAST_30_DAYS("LAST_30_DAYS", 30),
    LAST_90_DAYS("LAST_90_DAYS", 90),
    CURRENT_MONTH("CURRENT_MONTH", 0), //kept it 0 as it has no use
    PREVIOUS_MONTH("PREVIOUS_MONTH", 0); //kept it 0 as it has no use

    private final String name;
    private final int days;

    public Pair<LocalDate, LocalDate> calculateRange(LocalDate executionDate) {
        return switch (this) {
            case YESTERDAY, LAST_7_DAYS, LAST_30_DAYS, LAST_90_DAYS ->
                    Pair.of(executionDate.minusDays(days), executionDate);

            case CURRENT_MONTH ->
                    Pair.of(executionDate.withDayOfMonth(1), executionDate);

            case PREVIOUS_MONTH -> {
                LocalDate firstDay = executionDate.minusMonths(1).withDayOfMonth(1);
                LocalDate lastDay = executionDate.withDayOfMonth(1);
                yield Pair.of(firstDay, lastDay);
            }
        };
    }

    public static ReportDuration fromString(String duration) {
        return Arrays.stream(values())
                .filter(d -> d.name().equalsIgnoreCase(duration))
                .findFirst()
                .orElseThrow(() -> new ReportingException(ErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(ErrorConstants.INVALID_ERROR_MESSAGE, "ReportDuration", "Valid report durations are " + Arrays.toString(ReportDuration.values()))));
    }
}
