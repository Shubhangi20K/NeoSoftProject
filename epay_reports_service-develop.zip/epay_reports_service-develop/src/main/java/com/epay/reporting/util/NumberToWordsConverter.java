package com.epay.reporting.util;

import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * Class Name: NumberToWordsConverter
 * *
 * Description: Utility to convert number to words
 * *
 * Author: Bhoopendra Rajput
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
public class NumberToWordsConverter {
    public static final String[] units = {"", "One", "Two", "Three", "Four",
            "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve",
            "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen",
            "Eighteen", "Nineteen"};
    public static final String[] tens = {
            "",         // 0
            "",     // 1
            "Twenty",   // 2
            "Thirty",   // 3
            "Forty",    // 4
            "Fifty",    // 5
            "Sixty",    // 6
            "Seventy",  // 7
            "Eighty",   // 8
            "Ninety"    // 9
    };
    /**
     * To convert long number to words
     * @param n long
     * @return String
     */
    public static String convert(final long n) {
        if (n < 0) {
            return "Minus " + convert(-n);
        }
        if (n < 20) {
            return units[(int) n];
        }
        if (n < 100) {
            return tens[(int) (n / 10)] + ((n % 10 != 0) ? " " : "") + units[(int) (n % 10)];
        }
        if (n < 1000) {
            return units[(int) (n / 100)] + " Hundred" + ((n % 100 != 0) ? " " : "") + convert(n % 100);
        }
        if (n < 100000) {
            return convert(n / 1000) + " Thousand" + ((n % 10000 != 0) ? " " : "") + convert(n % 1000);
        }
        if (n < 10000000) {
            return convert(n / 100000) + " Lakh" + ((n % 100000 != 0) ? " " : "") + convert(n % 100000);
        }
        return convert(n / 10000000) + " Crore" + ((n % 10000000 != 0) ? " " : "") + convert(n % 10000000);
    }

    /**
     * To convert BigDecimal number to words
     * @param bigDecimal BigDecimal
     * @return String
     */
    public static String convert(final BigDecimal bigDecimal) {
        StringBuilder words = new StringBuilder();
        long l = bigDecimal.setScale(0, RoundingMode.DOWN).longValue();
        words.append(convert(l));
        BigDecimal fractPart = bigDecimal.remainder(BigDecimal.ONE);
        if (fractPart.signum() != 0 && StringUtils.isNotEmpty(fractPart.toString()) && !StringUtils.equals(fractPart.toString(), "0.00")) {
            words.append(" Point ");
            fractPart.toString().chars().mapToObj(c -> (char) c).dropWhile(ch -> ch == '.').filter(Character::isDigit)
                    .mapToInt(Character::getNumericValue)
                    .forEach(
                            num -> words.append(convert(num))
                    );
        }
        return words.toString();
    }
}