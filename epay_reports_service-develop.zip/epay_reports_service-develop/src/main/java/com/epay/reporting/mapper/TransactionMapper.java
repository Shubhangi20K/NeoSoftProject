package com.epay.reporting.mapper;

import com.epay.reporting.entity.view.TransactionReport;
import org.apache.commons.lang3.StringUtils;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;

import java.math.BigDecimal;
import java.util.List;

import static org.thymeleaf.util.ObjectUtils.nullSafe;

@Mapper(builder = @Builder(disableBuilder = true), componentModel = "spring")
public interface TransactionMapper {
    default List<Object> mapToList(TransactionReport transactionReport) {
        return List.of(
                nullSafe(transactionReport.getTransactionDate(), StringUtils.EMPTY),
                nullSafe(transactionReport.getTrnxSuccessDateAndTime(), StringUtils.EMPTY),
                nullSafe(transactionReport.getMerchantOrderNumber(), StringUtils.EMPTY),
                nullSafe(transactionReport.getSbiOrderRefNumber(), StringUtils.EMPTY),
                nullSafe(transactionReport.getCustomerId(), StringUtils.EMPTY),
                nullSafe(transactionReport.getAtrnNum(), StringUtils.EMPTY),
                nullSafe(transactionReport.getGateWayTraceNumber(), "NA"),
                nullSafe(transactionReport.getPayModeName(), StringUtils.EMPTY),
                nullSafe(transactionReport.getBankName(), StringUtils.EMPTY),
                nullSafe(transactionReport.getPayProc(), StringUtils.EMPTY),
                nullSafe(transactionReport.getTransactionCurrency(), StringUtils.EMPTY),
                nullSafe(transactionReport.getOrderAmount(), BigDecimal.ZERO),
                nullSafe(transactionReport.getGatewayPostingAmount(), BigDecimal.ZERO),
                nullSafe(transactionReport.getCommission(), BigDecimal.ZERO),
                nullSafe(transactionReport.getGst(), BigDecimal.ZERO),
                nullSafe(transactionReport.getOrderStatus(), StringUtils.EMPTY),
                nullSafe(transactionReport.getTransactionStatus(), StringUtils.EMPTY),
                nullSafe(transactionReport.getSettlementStatus(), StringUtils.EMPTY),
                nullSafe(transactionReport.getRefundStatus(), StringUtils.EMPTY),
                nullSafe(transactionReport.getChargeBackStatus(), StringUtils.EMPTY),
                nullSafe(transactionReport.getRefundAmount(), BigDecimal.ZERO),
                nullSafe(transactionReport.getChargeBackAmount(), BigDecimal.ZERO),
                nullSafe(transactionReport.getCinNumber(), StringUtils.EMPTY),
                nullSafe(transactionReport.getMerchantOtherDetails(), StringUtils.EMPTY));
    }
}
