package com.epay.reporting.repository;


import com.epay.reporting.entity.ReportScheduleManagement;
import com.epay.reporting.util.enums.ReportScheduledStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

/**
 * Class Name: ReportScheduleManagementRepository
 * Description: This interface extends `JpaRepository` and defines methods for interacting with the `ReportScheduleManagement` entity.
 * It includes a custom query method to find reports by their status and next scheduled execution time.
 * Author: Ranu Jain
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * Version: 1.0
 */
@Repository
public interface ReportScheduleManagementRepository extends JpaRepository<ReportScheduleManagement, UUID> {

    /**
     * Finds a list of `ReportScheduleManagement` entities by their status and next scheduled execution time.
     *
     * @param status the status of the report schedule
     * @param endTime the time threshold for the next scheduled execution
     * @return a list of `ReportScheduleManagement` entities that match the given status and next scheduled execution time criteria
     */
    @Query("SELECT r FROM ReportScheduleManagement r " +
            "WHERE r.status = :status " +
            "AND r.nextScheduleExecutionTime <= :endTime ")
    List<ReportScheduleManagement> findByStatusAndNextScheduleExecutionTime(
            @Param("status") ReportScheduledStatus status,
            @Param("endTime") Long endTime
    );

    /**
     * Finds all `ReportScheduleManagement` entities that match the given specification and paginates the results.
     *
     * @param specification the specification that defines the query criteria
     * @param pageable the pagination information
     * @return a page of `ReportScheduleManagement` entities that match the specification
     */
    Page<ReportScheduleManagement> findAll(Specification<ReportScheduleManagement> specification, Pageable pageable);

}
