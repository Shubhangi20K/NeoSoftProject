package com.epay.reporting.entity.event.audit;


import com.epay.reporting.entity.AuditEntityByDate;
import com.epay.reporting.util.enums.InterfaceType;
import jakarta.persistence.*;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.SuperBuilder;

import java.util.UUID;

/**
 * Class Name: EventSendLog
 * Description: saving send logs
 * Copyright (c) [2025] [State Bank of India]
 * All rights reserved.
 * Author:@V0000001(Shilpa Kothre)
 * Version:1.0
 */

@EqualsAndHashCode(callSuper = true)
@Entity(name = "EVENT_SEND_LOG")
@Builder
@Data
public class EventSendLog extends AuditEntityByDate {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID eslId;
    @Enumerated(EnumType.STRING)
    private InterfaceType interfaceType;
    private String topic;
    private String routingKey;
    private String message;
}

