package com.epay.reporting.util;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.exc.UnrecognizedPropertyException;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import jakarta.servlet.http.HttpServletResponse;
import lombok.experimental.UtilityClass;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.StringEscapeUtils;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;

import java.security.SecureRandom;
import java.util.Calendar;
import java.util.Optional;

/**
 * Class Name: ReportUtils
 * *
 * Description: Utility class for generating report-related information such as invoice numbers and HSN/SAC numbers.
 * The methods provided in this class help with generating unique invoice numbers based on the current date
 * and generating random HSN/SAC numbers for tax-related purposes.
 * *
 * Author: Bhoopendra Rajput
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@UtilityClass
public class ReportUtils {
    private static final LoggerUtility log = LoggerFactoryUtility.getLogger(ReportUtils.class);

    /**
     * Generates a unique invoice number based on the current date.
     * The invoice number format is: (day * 10000) + (month * 100) + year
     *
     * @return the generated invoice number
     */
    public static long getInvoiceNumber() {
        log.debug("Fetching InvoiceNumber");

        // Get the current date components
        Calendar calendar = Calendar.getInstance();
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        int month = calendar.get(Calendar.MONTH) + 1; // Months are 0-based
        int year = calendar.get(Calendar.YEAR);

        // Generate a "random" number using day, month, and year
        return (day * 10000L) + (month * 100L) + year;
    }

    /**
     * Generates a random HSN/SAC number using the current year and a random 4-digit number.
     * The generated format will be: "HSC-SAC:{year}-{randomNumber}"
     *
     * @return the generated HSN/SAC number
     */
    public static String getHSNSacNumber() {
        log.debug("Fetching HSN/SAC numbers");

        String year = String.valueOf(java.time.Year.now());
        // Current year
        int randomPart = new SecureRandom().nextInt(9000) + 1000;
        // Random 4-digit number
        return "HSC-SAC:" + year + "-" + randomPart;
    }

    /**
     * Set the response headers for a downloadable file
     * @param response    HttpServletResponse
     * @param contentType String
     * @param fileName    String
     */
    public static void setHeader(HttpServletResponse response, String contentType, String fileName) {
        log.info("Started setHeader for contentType: {}, fileName: {}", contentType, fileName);
        response.setContentType(contentType);
        response.setHeader(HttpHeaders.CONTENT_DISPOSITION, StringEscapeUtils.escapeJava("attachment;filename=" + fileName));
        HttpHeaders headers = new HttpHeaders();
        ContentDisposition contentDisposition = ContentDisposition.attachment().filename(fileName).build();
        headers.setContentDisposition(contentDisposition);
        response.setHeader(HttpHeaders.CONTENT_DISPOSITION, headers.getFirst(HttpHeaders.CONTENT_DISPOSITION));
        response.setHeader(HttpHeaders.ACCESS_CONTROL_EXPOSE_HEADERS, HttpHeaders.CONTENT_DISPOSITION);
    }

    /**
     * Parse exception error message.
     * @param cause JsonProcessingException
     * @return error message
     */
    public static String getParsingError(Throwable cause) {
        if (cause instanceof UnrecognizedPropertyException unrecognizedPropertyException) {
            return "Unrecognized field: '" + unrecognizedPropertyException.getPropertyName() + "'.";
        } else if (cause instanceof JsonParseException jsonParseException && StringUtils.startsWithIgnoreCase(jsonParseException.getMessage(),"Duplicate field")) {
            return jsonParseException.getMessage().substring(0, jsonParseException.getMessage().indexOf("\n")) + ".";
        } else if (cause instanceof JsonMappingException jsonMappingException) {
            Optional<String> fieldName = jsonMappingException.getPath().stream().map(JsonMappingException.Reference::getFieldName).reduce((first, second) -> second);
            if (fieldName.isPresent()) {
                return "Invalid input for field: '" + fieldName.get() + "'.";
            }
        }
        return "Invalid input.";
    }
}
