package com.epay.reporting.specification;

import com.epay.reporting.entity.ReportScheduleManagement;
import com.epay.reporting.model.request.ReportScheduleManagementSearchRequest;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.util.StringUtils;

import java.util.UUID;
/**
 * Class Name: ReportScheduleManagementSpecification
 * *
 * Description: This class constructs dynamic query predicates for filtering `ReportScheduleManagement` entities
 * based on various filter criteria such as report ID, merchant ID (MId), frequency, format, and date range (start and end execution time).
 * The predicates are used in a JPA Specification to create complex queries.
 * *
 * Author: Bhoopendra Rajput
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
public class ReportScheduleManagementSpecification {
    private static final LoggerUtility logger = LoggerFactoryUtility.getLogger(ReportScheduleManagementSpecification.class);

    /**
     * Creates a Specification for searching `ReportScheduleManagement` entities based on the provided
     * search criteria in `ReportScheduleManagementSearchRequest`.
     *
     * @param reportId The ID of the report for filtering.
     * @param searchRequest The request object containing the filter parameters.
     * @return A Specification for querying `ReportScheduleManagement` entities.
     */
    public static Specification<ReportScheduleManagement> searchSchedulerManagement(UUID reportId, ReportScheduleManagementSearchRequest searchRequest) {
        return (root, query, criteriaBuilder) -> {
            logger.debug("Building query predicates for report ID: {} and search request: {}", reportId, searchRequest);

            // Apply filters based on the fields present in the search request
            Predicate predicate = criteriaBuilder.conjunction();
            if (ObjectUtils.isNotEmpty(searchRequest.getReport())) {
                predicate = criteriaBuilder.and(predicate, getReportIdPredicate(root, criteriaBuilder, reportId));
            }

            if (StringUtils.hasText(searchRequest.getMId())) {
                predicate = criteriaBuilder.and(predicate, getMIdPredicate(root, criteriaBuilder, searchRequest.getMId()));
            }

            if (ObjectUtils.isNotEmpty(searchRequest.getFrequency())) {
                predicate = criteriaBuilder.and(predicate, getFrequencyPredicate(root, criteriaBuilder, searchRequest.getFrequency()));
            }

            if (ObjectUtils.isNotEmpty(searchRequest.getFormat())) {
                predicate = criteriaBuilder.and(predicate, getFormatPredicate(root, criteriaBuilder, searchRequest.getFormat()));
            }

            if (searchRequest.getScheduleStartExecutionTime() != null) {
                predicate = criteriaBuilder.and(predicate, getDurationFromDatePredicate(root, criteriaBuilder, searchRequest.getScheduleStartExecutionTime()));
            }

            if (searchRequest.getScheduleEndExecutionTime() != null) {
                predicate = criteriaBuilder.and(predicate, getDurationToDatePredicate(root, criteriaBuilder, searchRequest.getScheduleEndExecutionTime()));
            }

            logger.debug("Final query predicate: {}", predicate);
            return predicate;
        };
    }

    /**
     * Creates a predicate for filtering by report ID.
     *
     * @param root The root entity in the criteria query.
     * @param criteriaBuilder The criteria builder for creating the predicate.
     * @param reportId The report ID to filter by.
     * @return A predicate for filtering by report ID.
     */
    private static Predicate getReportIdPredicate(Root<ReportScheduleManagement> root, CriteriaBuilder criteriaBuilder, UUID reportId) {
        logger.debug("Creating predicate for reportId: {}", reportId);
        return criteriaBuilder.equal(root.get("reportId"), reportId);
    }

    /**
     * Creates a predicate for filtering by MId (Merchant ID).
     *
     * @param root The root entity in the criteria query.
     * @param criteriaBuilder The criteria builder for creating the predicate.
     * @param mId The merchant ID to filter by.
     * @return A predicate for filtering by MId.
     */
    private static Predicate getMIdPredicate(Root<ReportScheduleManagement> root, CriteriaBuilder criteriaBuilder, String mId) {
        logger.debug("Creating predicate for MId: {}", mId);
        return criteriaBuilder.equal(root.get("mId"), mId);
    }


    /**
     * Creates a predicate for filtering by report format.
     *
     * @param root The root entity in the criteria query.
     * @param criteriaBuilder The criteria builder for creating the predicate.
     * @param reportFormat The format of the report to filter by.
     * @return A predicate for filtering by report format.
     */
    private static Predicate getFormatPredicate(Root<ReportScheduleManagement> root, CriteriaBuilder criteriaBuilder, String reportFormat) {
        logger.debug("Creating predicate for format: {}", reportFormat);
        return criteriaBuilder.equal(root.get("format"), reportFormat.toUpperCase());
    }

    /**
     * Creates a predicate for filtering by frequency.
     *
     * @param root The root entity in the criteria query.
     * @param criteriaBuilder The criteria builder for creating the predicate.
     * @param frequency The frequency of the report to filter by.
     * @return A predicate for filtering by frequency.
     */
    private static Predicate getFrequencyPredicate(Root<ReportScheduleManagement> root, CriteriaBuilder criteriaBuilder, String frequency) {
        logger.debug("Creating predicate for frequency: {}", frequency);
        return criteriaBuilder.equal(root.get("frequency"), frequency.toUpperCase());
    }

    /**
     * Creates a predicate for filtering by the schedule start execution time (greater than or equal to).
     *
     * @param root The root entity in the criteria query.
     * @param criteriaBuilder The criteria builder for creating the predicate.
     * @param fromDate The start execution time to filter by.
     * @return A predicate for filtering by schedule start execution time.
     */
    private static Predicate getDurationFromDatePredicate(Root<ReportScheduleManagement> root, CriteriaBuilder criteriaBuilder, Long fromDate) {
        logger.debug("Creating predicate for schedule start execution time (fromDate): {}", fromDate);
        return criteriaBuilder.greaterThanOrEqualTo(root.get("createdAt"), fromDate);
    }

    /**
     * Creates a predicate for filtering by the schedule end execution time (less than or equal to).
     *
     * @param root The root entity in the criteria query.
     * @param criteriaBuilder The criteria builder for creating the predicate.
     * @param toDate The end execution time to filter by.
     * @return A predicate for filtering by schedule end execution time.
     */
    private static Predicate getDurationToDatePredicate(Root<ReportScheduleManagement> root, CriteriaBuilder criteriaBuilder, Long toDate) {
        logger.debug("Creating predicate for schedule end execution time (toDate): {}", toDate);
        return criteriaBuilder.lessThanOrEqualTo(root.get("createdAt"), toDate);
    }

}
