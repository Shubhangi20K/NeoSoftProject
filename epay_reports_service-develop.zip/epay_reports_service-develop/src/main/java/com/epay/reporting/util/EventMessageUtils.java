package com.epay.reporting.util;

import com.epay.reporting.entity.event.audit.EventErrorLog;
import com.epay.reporting.entity.event.audit.EventReceivedLog;
import com.epay.reporting.entity.event.audit.EventSendLog;
import com.epay.reporting.util.enums.InterfaceType;
import lombok.experimental.UtilityClass;
import org.apache.kafka.clients.consumer.ConsumerRecord;

/**
 * Class Name: EventMessageUtils
 * Description: utility class for message logs
 * Copyright (c) [2025] [State Bank of India]
 * All rights reserved.
 * Author:@V0000001(Shilpa Kothre)
 * Version:1.0
 */
@UtilityClass
public class EventMessageUtils {


    public static EventReceivedLog buildEventReceivedLog(InterfaceType interfaceType, ConsumerRecord<String, String> consumerRecord) {
        return EventReceivedLog.builder().interfaceType(interfaceType).topic(consumerRecord.topic()).routingKey(consumerRecord.key()).message(consumerRecord.value()).build();
    }

    public static EventSendLog buildEventSendLog(InterfaceType interfaceType, String topic, String key, String message) {
        return EventSendLog.builder().interfaceType(interfaceType).topic(topic).routingKey(key).message(message).build();
    }

    public static EventErrorLog buildEventErrorLog(InterfaceType interfaceType, ConsumerRecord<String, String> consumerRecord, String message) {
        return EventErrorLog.builder().interfaceType(interfaceType).topic(consumerRecord.topic()).routingKey(consumerRecord.key()).message(message).build();
    }

    public static EventErrorLog buildEventErrorLog(InterfaceType interfaceType, String topic, String key, String message) {
        return EventErrorLog.builder().interfaceType(interfaceType).topic(topic).routingKey(key).message(message).build();
    }
}

