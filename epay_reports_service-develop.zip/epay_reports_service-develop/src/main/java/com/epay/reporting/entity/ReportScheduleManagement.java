package com.epay.reporting.entity;

import com.epay.reporting.util.enums.Frequency;
import com.epay.reporting.util.enums.ReportFormat;
import com.epay.reporting.util.enums.ReportScheduledStatus;
import jakarta.persistence.*;
import lombok.*;

import java.util.UUID;

/**
 * Class Name: ReportScheduleManagement
 * Description:This class represents the entity for managing the scheduling of reports. It extends the AuditEntity
 * class, inheriting auditing fields such as createdBy, updatedBy, and timestamps for creation and
 * last modification. The entity is mapped to the "REPORT_SCHEDULE_MANAGEMENT" table in the database.
 * The class contains fields for tracking the report's unique ID, report ID, schedule execution time,
 * frequency of execution, format of the report, and status. It also includes fields for managing
 * next and last schedule execution times. The class uses UUID for the report ID and ID, and enums
 * for report frequency, format, and status.
 * Author: V1018344
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * Version: 1.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@Entity
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "REPORT_SCHEDULE_MANAGEMENT")
public class ReportScheduleManagement extends AuditEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(name = "ID", nullable = false, updatable = false, unique = true)
    private UUID id;

    private UUID reportId;
    
    @Column(name="MID")
    private String mId;

    @Enumerated(EnumType.STRING)
    private Frequency frequency;
    @Enumerated(EnumType.STRING)
    private ReportFormat format;

    private String scheduleExecutionTime;
    private Long nextScheduleExecutionTime;
    private Long lastScheduleExecutionTime;
    private String remarks;

    @Enumerated(EnumType.STRING)
    private ReportScheduledStatus status;

    private String reportDuration;
    private String scheduleExecutionDate;

 }