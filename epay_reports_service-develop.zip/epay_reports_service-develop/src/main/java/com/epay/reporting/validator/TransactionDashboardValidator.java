package com.epay.reporting.validator;

import com.epay.reporting.exception.ValidationException;
import com.epay.reporting.model.request.RecentTransactionRequest;
import com.epay.reporting.model.request.TransactionPayModeRequest;
import com.epay.reporting.model.request.TransactionSummaryRequest;
import com.epay.reporting.util.enums.Frequency;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import static com.epay.reporting.util.DateTimeUtils.*;
import static com.epay.reporting.util.ErrorConstants.*;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.time.YearMonth;

/**
 * Class Name: TransactionDashboardValidator
 * *
 * Description: This class validates the dashboard transactions
 * *
 * Author: Ranu Jain
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Component
@RequiredArgsConstructor
public class TransactionDashboardValidator extends BaseValidator {

    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private final MIdValidator mIdValidator;
    private final InvoiceValidator invoiceValidator;

    /**
     * Validates the report schedule management request by checking mandatory fields and their values.
     * Also validates the MId by checking if it's active.
     *
     * @param recentTransactionRequest The request object containing the recent transaction request details.
     * @throws ValidationException if any validation fails.
     */
    public void validateRequest(String mId, RecentTransactionRequest recentTransactionRequest) {
        logger.debug("Request Validation start for {}", recentTransactionRequest);
        errorDtoList = new ArrayList<>();
        validationMandatory(recentTransactionRequest);
        checkLeadingTrailingAndSingleSpace(recentTransactionRequest);
        validateFieldsValue(recentTransactionRequest);
        mIdValidator.validateActiveMId(mId);
        logger.debug("Request Validation end for {}", recentTransactionRequest);
    }

    /**
     * Validates the report schedule management request by checking mandatory fields and their values.
     * Also validates the MId by checking if it's active.
     *
     * @param mId : String The merchant id.
     * @param frequency : String Frequency either DAILY/MONTHLY/YEARLY
     * @throws ValidationException if any validation fails.
     */
    public void validateTransactionTrendsRequest(String mId, String frequency) {
        logger.debug("Request Transaction Trends Validation start for mid : {} and frequency : {}", mId, frequency);
        errorDtoList = new ArrayList<>();
        validationMandatory(mId, frequency);
        checkLeadingTrailingAndSingleSpace(mId, frequency);
        validateFieldsValue(mId, frequency);
        mIdValidator.validateActiveMId(mId);
        logger.debug("Request Transaction Trends Validation end for mid : {} and frequency : {}", mId, frequency);
    }

    /**
     * Validates the validate Transaction Summary Request by checking mandatory fields and their values.
     * Also validates the MId by checking if it's active.
     *
     * @param mId : String The merchant id.
     * @param transactionSummaryRequest : TransactionSummaryRequest
     */
    public void validateTransactionSummaryRequest(String mId, TransactionSummaryRequest transactionSummaryRequest) {
        logger.debug("Request Transaction Trends Validation start for mid : {} and frequency : {}", mId);
        errorDtoList = new ArrayList<>();
        validationMandatory(mId, transactionSummaryRequest);
        checkLeadingTrailingAndSingleSpace(mId, transactionSummaryRequest);
        validateFieldsValue(mId, transactionSummaryRequest);
        mIdValidator.validateActiveMId(mId);
        logger.debug("Request Transaction Trends Validation end for mid : {} and frequency : {}", mId);
    }

    /**
     * Validates the validate Transaction Pay mode Request by checking mandatory fields and their values.
     * Also validates the MId by checking if it's active.
     *
     * @param mId : String The merchant id.
     * @param transactionPayModeRequest : TransactionSummaryRequest
     */
    public void validateTransactionPayModeRequest(String mId, TransactionPayModeRequest transactionPayModeRequest) {
        logger.debug("Request Transaction pay mode Validation start for mid : {} and frequency : {}", mId);
        errorDtoList = new ArrayList<>();
        mIdValidator.validateMid(mId);
        validationMandatory(transactionPayModeRequest);
        checkLeadingTrailingAndSingleSpace(transactionPayModeRequest);
        validateFieldsValue(transactionPayModeRequest);
    }
    /**
     * Checks for mandatory fields request.
     *
     * @param recentTransactionRequest RecentTransactionRequest.
     */
    private void validationMandatory(RecentTransactionRequest recentTransactionRequest) {
        checkMandatoryField(recentTransactionRequest.getFrequency(), FREQUENCY);
        checkMandatoryField(recentTransactionRequest.getFromDate(), FROM_DATE);
        checkMandatoryField(recentTransactionRequest.getToDate(), TO_DATE);
        throwIfErrors();
    }

    /**
     * Checks for mandatory fields in the request.
     *
     * @param mId String.
     * @throws ValidationException if any mandatory field is missing.
     */
    private void validationMandatory(String mId, TransactionSummaryRequest transactionSummaryRequest) {
        checkMandatoryField(mId, MID);
        checkMandatoryField(transactionSummaryRequest.getFromDate(), FROM_DATE);
        checkMandatoryField(transactionSummaryRequest.getToDate(), TO_DATE);
        throwIfErrors();
    }

    /**
     * Checks for mandatory fields in the request.
     * @throws ValidationException if any mandatory field is missing.
     */
    private void validationMandatory(TransactionPayModeRequest transactionPayModeRequest) {
        checkMandatoryField(transactionPayModeRequest.getFromDate(), FROM_DATE);
        checkMandatoryField(transactionPayModeRequest.getToDate(), TO_DATE);
        throwIfErrors();
    }

    /**
     * Checks for mandatory fields in the download request.
     *
     * @param mId The Merchant ID.
     * @throws ValidationException if any mandatory field is missing.
     */
    private void validationMandatory(String mId, String frequency) {
        checkMandatoryField(mId, MID);
        checkMandatoryField(frequency, FREQUENCY);
        throwIfErrors();
    }

    /**
     * Validates that all fields in the CaptchaRequest do not have leading, trailing, or multiple spaces.
     *
     * @param mId String.
     */
    private void checkLeadingTrailingAndSingleSpace(String mId, String frequency) {
        checkForLeadingTrailingAndSingleSpace(mId, MID);
        checkForLeadingTrailingAndSingleSpace(frequency, FREQUENCY);
        throwIfErrors();
    }

    /**
     * Validates that all fields in the RecentTransactionRequest do not have leading, trailing, or multiple spaces.
     *
     * @param recentTransactionRequest RecentTransactionRequest.
     */
    private void checkLeadingTrailingAndSingleSpace(RecentTransactionRequest recentTransactionRequest) {
        checkForLeadingTrailingAndSingleSpace(recentTransactionRequest.getFrequency(), FREQUENCY);
        checkForLeadingTrailingAndSingleSpace(recentTransactionRequest.getFromDate(), FROM_DATE);
        checkForLeadingTrailingAndSingleSpace(recentTransactionRequest.getToDate(), TO_DATE);
        throwIfErrors();
    }

    /**
     * Validates that all fields in the checkLeadingTrailingAndSingleSpace do not have leading, trailing, or multiple spaces.
     *
     * @param mId String.
     */
    private void checkLeadingTrailingAndSingleSpace(String mId, TransactionSummaryRequest transactionSummaryRequest) {
        checkForLeadingTrailingAndSingleSpace(mId, MID);
        checkForLeadingTrailingAndSingleSpace(transactionSummaryRequest.getFromDate(), FROM_DATE);
        checkForLeadingTrailingAndSingleSpace(transactionSummaryRequest.getToDate(), TO_DATE);
        throwIfErrors();
    }

    /**
     * Validates that all fields in the checkLeadingTrailingAndSingleSpace do not have leading, trailing, or multiple spaces.
     */
    private void checkLeadingTrailingAndSingleSpace(TransactionPayModeRequest transactionPayModeRequest) {
        checkForLeadingTrailingAndSingleSpace(transactionPayModeRequest.getFromDate(), FROM_DATE);
        checkForLeadingTrailingAndSingleSpace(transactionPayModeRequest.getToDate(), TO_DATE);
        throwIfErrors();
    }

    /**
     * Method name : validateFieldsValue
     * Description : Validates fields values of merchant customer creation request
     * @param mId : String
     */
    private void validateFieldsValue(String mId, String frequency) {
        validateFieldLength(mId, MID_LENGTH, MID);
        throwIfErrors();
        validateFieldWithRegex(mId, ALLOWED_DIGIT_REGEX, MID, INCORRECT_FORMAT);
        validateFieldWithRegex(frequency, ALLOWED_ALPHABET_REGEX, FREQUENCY, INCORRECT_FORMAT);
        throwIfErrors();
        validateFieldValue(frequency, Stream.of(Frequency.values()).map(Enum::name).toList(), FREQUENCY);
        throwIfErrors();
    }

    /**
     * Validates the values of fields in the RecentTransactionRequest object.
     * @param recentTransactionRequest RecentTransactionRequest the request object containing details to be validated.
     */
    private void validateFieldsValue(RecentTransactionRequest recentTransactionRequest) {
        validateFixedFieldLength(recentTransactionRequest.getFromDate(), ALLOWED_DATE_LENGTH,FROM_DATE);
        validateFixedFieldLength(recentTransactionRequest.getToDate(), ALLOWED_DATE_LENGTH,TO_DATE);
        validateFieldLength(recentTransactionRequest.getFrequency(), ALLOWED_FREQUENCY_LENGTH,FREQUENCY);
        throwIfErrors();
        validateFieldWithRegex(recentTransactionRequest.getFromDate(), MONTH_FORMAT_REGEX_DD_MMM_YYYY, FROM_DATE, INCORRECT_FORMAT);
        validateFieldWithRegex(recentTransactionRequest.getToDate(), MONTH_FORMAT_REGEX_DD_MMM_YYYY, TO_DATE, INCORRECT_FORMAT);
        validateFieldWithRegex(recentTransactionRequest.getFrequency(), ALLOWED_ALPHABET_REGEX, FREQUENCY, INCORRECT_FORMAT);
        throwIfErrors();
        validateFieldValue(recentTransactionRequest.getFrequency(), Stream.of(Frequency.values()).map(Enum::name).toList(), FREQUENCY);
        throwIfErrors();
    }

    /**
     * Method name : validateFieldsValue
     * Description : Validates fields values of merchant customer creation request
     * @param mId : String
     */
    private void validateFieldsValue(String mId, TransactionSummaryRequest transactionSummaryRequest) {
        validateFieldLength(mId, MID_LENGTH, MID);
        throwIfErrors();
        validateFieldWithRegex(mId, ALLOWED_DIGIT_REGEX, MID,  INCORRECT_FORMAT);
        throwIfErrors();
        invoiceValidator.validateRequestMonths(List.of(transactionSummaryRequest.getFromDate(),transactionSummaryRequest.getToDate()));
        validateMonthsBetweenDate(transactionSummaryRequest);
        throwIfErrors();
    }

    /**
     * Method name : validateMonthsBetweenDate
     * Description : Validates fields values of TransactionSummaryRequest
     * @param request : TransactionSummaryRequest
     */
    private void validateMonthsBetweenDate(TransactionSummaryRequest request) {
        logger.info("Validating fromDate: {} and toDate: {}", request.getFromDate(), request.getToDate());
        YearMonth fromYM = YearMonth.parse(request.getFromDate(), FORMATTER_MMM_YYYY);
        YearMonth toYM = YearMonth.parse(request.getToDate(), FORMATTER_MMM_YYYY);

        LocalDate fromDate = fromYM.atDay(1);
        LocalDate toDate = toYM.atEndOfMonth();

        // Set final formatted dates for query
        request.setFromDate(fromDate.format(FORMATTER_DD_MMM_YYYY));
        request.setToDate(toDate.format(FORMATTER_DD_MMM_YYYY));

        logger.info("Validating fromDate should not be more than 1 year old, fromDate: {} and toDate: {}", request.getFromDate(), request.getToDate());
        if (fromDate.isBefore(LocalDate.now().minusYears(ONE))) {
            addError(FROM_DATE, INVALID_ERROR_CODE, MessageFormat.format(FROM_DATE_YEAR_DIFF_ERROR, ONE));
            throwIfErrors();
        }

        logger.info("Validating toDate should be >= fromDate, fromDate: {} and toDate: {}", request.getFromDate(), request.getToDate());
        if (toYM.isBefore(fromYM)) {
            addError(TO_DATE, INVALID_ERROR_CODE, MessageFormat.format(INVALID_ERROR_MESSAGE, TO_DATE, TO_DATE_DIFF_ERROR));
            throwIfErrors();
        }
        logger.info("Validating difference should be max 3 months (2 months apart), fromDate: {} and toDate: {}", request.getFromDate(), request.getToDate());
        long monthDiff = ChronoUnit.MONTHS.between(fromYM, toYM);
        if (monthDiff > MONTH_DEFF_LENGTH) {
            addError("Date", INVALID_ERROR_CODE, THREE_MONTH_DIFF_ERROR);
        }

        throwIfErrors();
    }

    /**
     * Method name : validateFieldsValue
     * Description : Validates fields values of merchant customer creation request
     */
    private void validateFieldsValue(TransactionPayModeRequest transactionSummaryRequest) {
        validateFieldLength(transactionSummaryRequest.getFromDate(), ALLOWED_SUMMARY_DATE_LENGTH,FROM_DATE);
        throwIfErrors();
        validateFieldLength(transactionSummaryRequest.getToDate(), ALLOWED_SUMMARY_DATE_LENGTH,TO_DATE);
        throwIfErrors();
        validateFieldWithRegex(transactionSummaryRequest.getFromDate(), ALLOWED_SUMMARY_DATE_REGEX, FROM_DATE, INCORRECT_FORMAT);
        throwIfErrors();
        validateFieldWithRegex(transactionSummaryRequest.getToDate(), ALLOWED_SUMMARY_DATE_REGEX, TO_DATE, INCORRECT_FORMAT);
        throwIfErrors();
    }

}
