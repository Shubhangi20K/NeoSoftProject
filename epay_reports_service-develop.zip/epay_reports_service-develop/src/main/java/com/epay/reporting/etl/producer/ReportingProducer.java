package com.epay.reporting.etl.producer;

import com.epay.reporting.config.kafka.Topics;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Class Name: ReportingProducer
 * Description: The ReportingProducer class serves as an abstract base class for producers that publish report-related messages to Kafka.
 * It provides common functionality for constructing the routing key and accessing the KafkaMessagePublisher and Topics.
 * Subclasses must implement the publish method to send specific messages to the Kafka topic.
 * Author: Bhoopendra Rajput
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * Version: 1.0
 */
public abstract class ReportingProducer {

    @Autowired
    protected KafkaMessagePublisher kafkaMessagePublisher;

    @Autowired
    protected Topics topics;

    String getRoutingKey(String routingKey) {
        return "report." + routingKey;
    }

    public abstract void publish(String routingKey, String message);
}