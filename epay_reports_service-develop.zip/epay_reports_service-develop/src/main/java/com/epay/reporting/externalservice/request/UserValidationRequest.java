package com.epay.reporting.externalservice.request;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Class Name: UserValidationRequest
 * Description: The UserValidationRequest class is a data transfer object (DTO) used for carrying user validation request details.
 * It holds the necessary fields such as request type and user name to facilitate user validation processes.
 * The class is annotated with Lombok annotations for automatic generation of getter, setter, builder methods, and constructors.
 * Author: Bhoopendra Rajput
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * Version: 1.0
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UserValidationRequest {

    private String requestType;
    private String userName;
}
