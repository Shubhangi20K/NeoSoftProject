package com.epay.reporting.dto;

import com.epay.reporting.util.enums.Frequency;
import com.epay.reporting.util.enums.Report;
import com.epay.reporting.util.enums.ReportFormat;
import com.epay.reporting.util.enums.ReportScheduledStatus;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

/**
 * Class Name: ReportScheduleManagementDto
 * Description: This class represents a Data Transfer Object (DTO) for managing the scheduling of reports.
 * It includes details such as the scheduled time, report type, frequency, and any other relevant scheduling
 * information required to manage the generation and delivery of reports. The `@JsonInclude` annotation ensures
 * that only non-null fields are included in the serialized JSON response.
 * Author: Bhoopendra Rajput
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * Version:1.0
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ReportScheduleManagementDto {

    @JsonIgnore
    private UUID id;
    @JsonIgnore
    private UUID reportId;
    private Report report;
    private String mId;
    private Frequency frequency;
    private ReportFormat format;
    private String scheduleExecutionTime;
    private Long nextScheduleExecutionTime;
    private Long lastScheduleExecutionTime;
    private ReportScheduledStatus status;
    private String reportDuration;
    private String scheduleExecutionDate;
    private Long createdAt;
    private Long updatedAt;
}