package com.epay.reporting.util.enums;

import com.epay.reporting.exception.ReportingException;
import com.epay.reporting.util.ErrorConstants;

import java.text.MessageFormat;
import java.util.Arrays;
/**
 * Name: Frequency
 * Description: Represents different frequency types for reports (Daily, Monthly, Yearly).
 * *
 * Author: Bhoopendra Rajput
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
public enum Frequency {
    DAILY, MONTHLY;

    /**
     * Returns the Frequency enum corresponding to the provided name (case-insensitive).
     *
     * @param name The name of the frequency.
     * @return Corresponding Frequency enum.
     */
    public static Frequency getName(String name) {
        return Arrays.stream(values()).filter(rt -> rt.name().equalsIgnoreCase(name)).findFirst().orElseThrow(() -> new ReportingException(ErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(ErrorConstants.INVALID_ERROR_MESSAGE, "Frequency", "Valid Frequency are " + Arrays.toString(Frequency.values()))));
    }
}
