package com.epay.reporting.repository.view;

import com.epay.reporting.entity.view.OrderReport;
import com.epay.reporting.entity.view.RefundReport;
import com.epay.reporting.entity.view.TransactionReport;
import com.epay.reporting.util.queries.ReportQueries;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

/**
 * Class Name: ReportRepository
 * Description: This class is responsible for interacting with the database to retrieve various types of reports such as order reports, refund reports, and transaction reports for a specific merchant ID and date range. It utilizes `NamedParameterJdbcTemplate` to execute SQL queries and maps the results to the appropriate report objects.
 * Author: Bhoopendra Rajput
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * Version:1.0
 */
@Repository
@RequiredArgsConstructor
public class ReportRepository {

    private final NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    public List<OrderReport> fetchOrderReportData(String mId, Long startDate, Long endDate) {
        SqlParameterSource parameters = new MapSqlParameterSource(Map.of("mId", mId, "startDate", startDate, "endDate", endDate));
        return namedParameterJdbcTemplate.query(ReportQueries.JDBC_ORDER_REPORT, parameters, new BeanPropertyRowMapper<>(OrderReport.class));
    }

    public List<RefundReport> fetchRefundReportData(String mId, Long startDate, Long endDate) {
        SqlParameterSource parameters = new MapSqlParameterSource(Map.of("mId", mId, "startDate", startDate, "endDate", endDate));
        return namedParameterJdbcTemplate.query(ReportQueries.JDBC_REFUND_REPORT, parameters, new BeanPropertyRowMapper<>(RefundReport.class));
    }

    public List<TransactionReport> getTransaction(String mId, Long startDate, Long endDate) {
        SqlParameterSource parameters = new MapSqlParameterSource(Map.of("mId", mId, "startDate", startDate, "endDate", endDate));
        return namedParameterJdbcTemplate.query(ReportQueries.JDBC_TRANSACTION_REPORT, parameters, new BeanPropertyRowMapper<>(TransactionReport.class));
    }

}