package com.epay.reporting.config.audit;

import com.sbi.epay.authentication.model.EPayPrincipal;
import org.springframework.data.domain.AuditorAware;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.Optional;

/**
 * Class Name: SpringSecurityAuditorAware
 * Description: The SpringSecurityAuditorAware class is used to provide the current auditor's username in a Spring Security context.
 * It retrieves the username of the currently authenticated user or a default name if no authentication is found.
 * Author: Bhoopendra Rajput
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * Version: 1.0
 */
public class SpringSecurityAuditorAware implements AuditorAware<String> {

    /**
     * Get the current auditor (username) from the authentication context.
     * This method checks if the user is authenticated and returns their username.
     * If no authentication is present, it returns a default username "SBIEPay".
     *
     * @return Optional<String> containing the username of the current auditor
     */
    @Override
    public Optional<String> getCurrentAuditor() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if(authentication!=null) {
            Object principal = authentication.getPrincipal();
            if (principal instanceof EPayPrincipal ePayPrincipal) {
                return Optional.of(ePayPrincipal.getUsername());
            }
            return Optional.of((String) principal);
        } else {
            return Optional.of("SBIEPay");
        }
    }
}