package com.epay.reporting.util.queries;

import lombok.experimental.UtilityClass;

@UtilityClass
public class ReconQueries {

    public static final String GET_VIEW_TRANSACTION_MIS= """
            SELECT
                               MERCHANT_ID AS mId,
                               MERCHANT_NAME AS merchantName,
                               MERCHANT_CATEGORY AS merchantCategory,
                               ORDER_REF_NUMBER AS orderRefNumber,
                               ATRN_NUM AS atrnNum,
                               INSTRUCTION_DATEAND_TIME AS instructionDateandTime,
                               CURRENCY_CODE AS currencyCode,
                               ORDER_AMOUNT AS orderAmount,
                               TOTAL_FEE_ABS AS totalFeeAbs,
                               GST_NUMBER AS gstNumber,
                               GATEWAY_POSTING_AMOUNT AS gatewayPostingAmount,
                               AMOUNT_SETTLED AS amountSettled,
                               AVAILABLE_REFUND_AMOUNT AS availableRefundAmount,
                               PAY_MODE AS payMode,
                               CHANNEL_BANK AS channelBank,
                               GATEWAY_TRACE_NUMBER AS gatewayTraceNumber,
                               TRANSACTION_STATUS AS transactionStatus,
                               REMARK AS remark,
                               MERCHANT_RISK_CATEGORY AS merchantRiskCategory,
                               ACCESS_MEDIUM AS accessMedium,
                               PAY_PROC_ID AS payProcId,
                               PAY_PROC_TYPE AS payProcType,
                               MERCHANT_AUTHORIZE AS merchantAuthorize,
                               MERCHANT_AUTHORIZE_DATE AS merchantAuthorizeDate,
                               AUTO_SETTLEMENT AS autoSettlement,
                               BEARABLE_ENTITY AS bearableEntity,
                               CIN AS cin,
                               FAIL_REASON AS failReason,
                               MERCHANT_FEE_BEARABLE_ABS AS merchantFeeBearableAbs,
                               MERCHANT_GST_BEARABLE_ABS AS merchantGstBearableAbs,
                               CUSTOMER_FEE_BEARABLE_ABS AS customerFeeBearableAbs,
                               CUSTOMER_GST_BEARABLE_ABS AS customerGstBearableAbs,
                               SUB_STATUS_DESCRIPTION AS sbuStatusDescription,
                               PAYMENT_SUCCESS_DATE AS paymentSuccessDate
            FROM VIEW_TRANSACTION_MIS
            WHERE MERCHANT_ID = :mId
            """;
    public static final String GET_SBIEPAY_AGG_BANK_DETAILS = """
    SELECT
        MERCHANT_ID AS mId,
        MERCHANT_CATEGORY AS merchantCategory,
        MERCHANT_NAME AS merchantName,
        ORDER_REF_NUMBER AS orderRefNumber,
        ATRN_NUM AS atrnNum,
        TRANSACTION_DATE AS transactionDate,
        ORDER_AMOUNT AS orderAmount,
        CURRENCY_CODE AS currencyCode,
        TRANSACTION_STATUS AS transactionStatus,
        ETL_UPLOAD_DATE AS etlUploadDate,
        ETL_STATUS AS etlStatus,
        CHANNEL_BANK AS channelBank,
        GATEWAY_TRACE_NUMBER AS gatewayTraceNumber,
        PAY_MODE AS payMode,
        GATEWAY_STATUS AS gatewayStatus
    FROM VIEW_SBIEPAY_AGG_BANKSTMT_REPORT
    WHERE MERCHANT_ID = :mId
    """;


    public static final String GET_TRANSACTION_WISE_PAYOUT = """
    SELECT
         SETTLEMENT_FILE_NUMBER AS settlementFileNumber,
         SETTLEMENT_TIME AS settlementTime,
         MERCHANT_ID AS mId,
         MERCHANT_NAME AS merchantName,
         MERCHANT_ORDER_NO AS merchantOrderNo,
         TRANSACTION_ID AS transactionId,
         TRANSACTION_BOOKING_DATE AS transactionBookingDate,
         TRANSACTION_CURRENCY AS transactionCurrency,
         TRANSACTION_AMOUNT AS transactionAmount,
         SETTLEMENT_CURRENCY AS settlementCurrency,
         SETTLEMENT_AMOUNT AS settlementAmount,
         COMMISSION_PAYABLE AS commissionPayable,
         GST AS gst,
         PAYOUT_AMOUNT AS payoutAmount,
         GATEWAY_NAME AS gatewayName,
         GATEWAY_TRACE_NUMBER AS gatewayTraceNumber,
         PAY_MODE AS payMode,
         PAY_PROC_ID AS payProcId,
         OTHER_DETAILS AS otherDetails,
         TRANSACTION_FEE_FLAG AS transactionFeeFlag,
         CIN AS cin
    FROM VIEW_TRANSACTION_WISE_PAYOUT_FORMAT
    WHERE HEXTORAW(MP_ID) IN (:mpId)
    """;


    public static final String MERCHANT_PAYOUT = """
                SELECT vmp.MERCHANT_ID AS mId,
                vmp.MERCHANT_NAME as merchantName,
                vmp.TRANSACTION_AMOUNT as transactionAmount,
                vmp.TRANSACTION_CURRENCY as transactionCurrency,
                vmp.SETTLEMENT_AMOUNT as settlementAmount,
                vmp.SETTLEMENT_CURRENCY as settlementCurrency,
                vmp.COMMISSION_PAYABLE as commissionPayable,
                vmp.GST as gst,
                vmp.PAYOUT_AMOUNT as payoutAmount,
                vmp.REFUND_ADJUSTED as refundAdjusted,
                vmp.TDR_ON_REFUND_AMOUNT as tdrOnRefundAmount,
                vmp.GST_ON_REFUND_AMOUNT as gstOnRefundAmount,
                vmp.NET_REFUND_AMOUNT as netRefundAmount,
                vmp.NET_PAYOUT_AMOUNT as netPayoutAmount,
                vmp.PAYOUT_DATE as payoutDate,
                vmp.TRANSACTION_COUNT as transactionCount
                from VIEW_MERCHANT_WISE_PAYOUT_MIS_FORMAT vmp
                WHERE HEXTORAW(vmp.MP_ID) IN (:mpId)
            """;

    public static final String TRANSACTION_REFUND = """
                       SELECT  vtr.SETTLEMENT_FILE_NUMBER as settlementFileNumber,
                       vtr.SETTLEMENT_TIME as settlementTime,
                       vtr.MERCHANT_ID as mId,
                       vtr.MERCHANT_NAME as merchantName,
                       vtr.MERCHANT_ORDER_NUMBER as merchantOrderNumber,
                       vtr.TRANSACTION_ID as transactionId,
                       vtr.TRANSACTION_DATE as transactionDate,
                       vtr.TRANSACTION_CURRENCY as transactionCurrency,
                       vtr.TRANSACTION_AMT as transactionAmt,
                       vtr.REFUND_CURRENCY as refundCurrency,
                       vtr.REFUND_AMT as refundAmt,
                       vtr.COMMISSION_PAYABLE as commissionPayable,
                       vtr.GST as gst,
                       vtr.NET_REFUND_AMOUNT as netRefundAmount,
                       vtr.GATEWAY_NAME as gatewayName,
                       vtr.GATEWAY_TRACE_NUMBER as gatewayTraceNumber,
                       vtr.PAY_MODE as payMode,
                       vtr.REFUND_TYPE as refundType,
                       vtr.REFUND_BOOKING_DATE as refundBookingDate,
                       vtr.ARRN_NUM as arrnNum
                       from VIEW_TRANSACTION_WISE_REFUND_FORMAT vtr
                       WHERE  HEXTORAW(vtr.MP_ID) IN (:mpId)
            """;


    public static final String AAT_MERCHANT_ACCOUNT_PAYOUT = """
            SELECT  '01'||
            LPAD(A.ACCOUNT_NUMBER,17,0)||
            LPAD(REPLACE(TO_CHAR((A.TXN_AMT-A.REFUNDED_AMOUNT),'FM9999999990.00'),'.',''), 16, '0')||
            'SETTLEMENTTOMERCHANTACCOUNT'
            FROM  MERCHANT_PAYOUT A,AGGMERCHANTBANKACCOUNTS B WHERE  A.ACCOUNT_ID=B.ACCOUNTID
            AND A.ACCOUNT_NUMBER=B.ACCOUNTNUMBER
            AND HEXTORAW(A.MP_ID) IN (:mpId)
            UNION ALL
            SELECT  '51'||
            LPAD(33324315125,17,0)||
            LPAD(REPLACE(TO_CHAR(SUM(A.TXN_AMT-A.REFUNDED_AMOUNT),'FM9999999990.00'),'.',''), 16, '0')||
            'SBIePAYPAYOUTTOTHEMERCHANTS'
            FROM  MERCHANT_PAYOUT A,AGGMERCHANTBANKACCOUNTS B WHERE  A.ACCOUNT_ID=B.ACCOUNTID
            AND A.ACCOUNT_NUMBER=B.ACCOUNTNUMBER
            AND HEXTORAW(A.MP_ID) IN (:mpId)
            """;

    public static final String NEFT_MERCHANT_ACCOUNT_PAYOUT ="""
        SELECT
              'R41' ||--TYPE
              LPAD(REPLACE(TO_CHAR((A.TXN_AMT-A.REFUNDED_AMOUNT),'FM9999999990.00'),'.',''), 16, '0') ||--FINAL_PAYOUT
              LPAD((0), 16,0) ||--COMMISSION AMOUNT
              LPAD(33324315125, 19, 0) ||--SBIACCNO
              RPAD('SBIePay', 35)|| --REMITTER NAME
              RPAD('State Bank of India Payment Aggregator', 35)||--REMITTER ADDRESS
              RPAD((A.ACCOUNT_NUMBER),32)||--BENEFI ACC NO
              RPAD(C.ACCHOLDERNAME, 35)||--BENEFI NAME
              RPAD(D.MERCHANTOFFICEADDRESS, 35)||--BENEFI ADDRESS
              RPAD(B.IFSCCODE,11)||----BENEFI IFSC
              RPAD('SETTLEMENTTOMERCHANTACCOUNT', 35)||
              RPAD('URGENT', 35)||
              RPAD('SBIePAY PAYMENT', 58)||
              RPAD('ATRN000001436573ops@sbiepay.in', 51) AS "PAYOUT DETAILS"
    FROM MERCHANT_PAYOUT A,BANKBRANCHES B ,AGGMERCHANTBANKACCOUNTS C,AGGREGATORMERCHANT D
    WHERE A.BANK_ID=B.BANKID
    and B.BANKID=c.BANKID
    AND B.IFSCCODE=C.BRANCHCODE----------------NEED TO ADD THIS CONDITION
    AND A.ACCOUNT_ID=C.ACCOUNTID
    AND A.ACCOUNT_NUMBER=C.ACCOUNTNUMBER(+)
    AND A.MERCHANT_ID=D.MERCHANTID
    AND C.MERCHANTID=D.MERCHANTID
    AND HEXTORAW(A.MP_ID) IN (:mpId)
""";

    public static final String BAD_RECORDS= """
            SELECT br.MERCHANT_ID AS mId,
            br.ROW_NUMBER AS rowNumber,
            br.ATRN_NUM AS atrnNum,
            br.TXN_AMOUNT AS txnAmount,
            br.BANK_REF_NUMBER AS bankRefNumber,
            br.RECON_STATUS AS reconStatus,
            br.SETTLEMENT_STATUS AS settlementStatus,
            br.PAYOUT_STATUS AS reconStatus,
            br.REMARK AS remark
            FROM RECON_FILE_DTLS br
            WHERE HEXTORAW(br.rf_id)= :rfId
            AND br.RECON_STATUS IN ('UNMATCHED','DUPLICATE')
            """;

    public static final String FAILED_RECORDS= """
            SELECT br.MERCHANT_ID AS mId,
            br.ROW_NUMBER AS rowNumber,
            br.ATRN_NUM AS atrnNum,
            br.TXN_AMOUNT AS txnAmount,
            br.BANK_REF_NUMBER AS bankRefNumber,
            br.RECON_STATUS AS reconStatus,
            br.SETTLEMENT_STATUS AS settlementStatus,
            br.PAYOUT_STATUS AS reconStatus,
            br.REMARK AS remark
            FROM RECON_FILE_DTLS br
            WHERE HEXTORAW(br.rf_id)= :rfId
            AND br.RECON_STATUS ='FAIL'
            """;
}
