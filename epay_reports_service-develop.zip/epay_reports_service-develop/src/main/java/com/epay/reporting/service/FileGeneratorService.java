package com.epay.reporting.service;

import com.epay.reporting.dto.ReportFile;
import com.epay.reporting.dto.TxtFileModel;
import com.epay.reporting.externalservice.S3Service;
import com.epay.reporting.util.ReportUtils;
import com.epay.reporting.util.enums.Report;
import com.epay.reporting.util.enums.ReportFormat;
import com.epay.reporting.util.file.generator.FileGenerator;
import com.epay.reporting.util.file.generator.ZipFileGenerator;
import com.epay.reporting.util.file.model.FileModel;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.apache.commons.io.FilenameUtils;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;


import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Class Name: FileGeneratorService
 * Description: This service handles the logic for generating files, including the creation of individual files
 * and the generation of zip archives. It uses `FileGenerator` and `ZipFileGenerator` components to produce
 * file outputs in different formats and efficiently manages file generation processes.
 * Author: Bhoopendra Rajput
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * Version: 1.0
 */
@Service
@RequiredArgsConstructor
public class FileGeneratorService {
    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    private final FileGenerator fileGenerator;
    private final ZipFileGenerator zipFileGenerator;
    private final S3Service s3Service;

    /**
     * Initiates the file download process for a specific report and format.
     * This method delegates the task of downloading the file to the `FileGenerator` service,
     * which handles the actual file creation and response streaming for the client.
     *
     * @param response     The HTTP response object used to send the file content to the client.
     * @param reportFormat The format of the report (e.g., CSV, XLS, PDF).
     * @param report       The report object containing the data to be included in the generated file.
     * @param mId          The merchant ID associated with the report.
     * @param fileModel    The model containing the necessary data and configurations for the file generation.
     */
    public void downloadFile(HttpServletResponse response, ReportFormat reportFormat, Report report, String mId, FileModel fileModel) {
        log.info("Started downloadFile for reportFormat: {}, report: {},mId: {},fileModel: {}", reportFormat, report.getName(), mId, fileModel);
        fileGenerator.downloadFile(response, reportFormat, report, mId, fileModel);
    }

    /**
     * Generates a file based on the provided report format and other details.
     * This method delegates to the `FileGenerator` service to create a file based on the report format
     * (CSV, XLS, PDF), report data, and merchant ID. It returns the generated file for further processing.
     *
     * @param reportFormat The format of the report (e.g., CSV, XLS, PDF).
     * @param report       The report object containing the data to be included in the generated file.
     * @param mId          The merchant ID associated with the report.
     * @return File The generated file.
     */
    public ReportFile generateFile(ReportFormat reportFormat, Report report, String mId, List<String> header, List<List<Object>> fileData) {
        FileModel fileModel = buildFileModel(reportFormat, header, fileData, Map.of("headers", header, "rows", fileData));
        log.info("Started fileGenerator for reportFormat: {}, report: {}, mId: {}, fileModel: {}", reportFormat, report.getName(), mId, fileModel);
        return fileGenerator.generateFile(reportFormat, report, mId, fileModel);
    }

    /**
     * Generates a file based on the provided report format and other details.
     * This method delegates to the `FileGenerator` service to create a file based on the report format
     * (CSV, XLS, PDF), report data, and merchant ID. It returns the generated file for further processing.
     *
     * @param reportFormat The format of the report (e.g., CSV, XLS, PDF).
     * @param report       The report object containing the data to be included in the generated file.
     * @return File The generated file.
     */
    public ReportFile generateFile(ReportFormat reportFormat, Report report, List<String> header, List<List<Object>> fileData,UUID rfId) {
        FileModel fileModel = buildFileModel(reportFormat, header, fileData, null);
        log.info("Started fileGenerator for reportFormat: {}, report: {}", reportFormat, report.getName());
        return fileGenerator.generateFile(reportFormat, report, fileModel,rfId);
    }

    /**
     * Generates a file based on the provided report format and other details.
     * This method delegates to the `FileGenerator` service to create a file based on the report format
     * TXT, report data. It returns the generated file for further processing.
     *
     * @param report       The report object containing the data to be included in the generated file.
     * @param txtFileModel The model containing the necessary data and configurations for the file generation.
     * @return File The generated file.
     */
    public ReportFile generateFile(Report report, TxtFileModel txtFileModel) {
        log.info("Started fileGenerator for reportFormat: TXT, report: {}", report.getName());
        return fileGenerator.generateFile(report, txtFileModel);
    }

    /**
     * Initiates the generation of a zip file containing multiple reports.
     * This method delegates the task of generating and zipping files to the `ZipFileGenerator` service,
     * allowing for the packaging of multiple files (e.g., CSVs, PDFs) into a single archive for download.
     *
     * @param response     The HTTP response object used to send the zip file to the client.
     * @param reportFormat The format of the reports (e.g., CSV, XLS, PDF).
     * @param report       The report object containing the data to be included in the generated files.
     * @param mId          The merchant ID associated with the reports.
     * @param fileModels   A list of file models, each containing the necessary data and configurations for individual file generation.
     */
    public void generateZipFile(HttpServletResponse response, ReportFormat reportFormat, Report report, String mId, List<FileModel> fileModels) {
        log.info("Started zipFileGenerator for reportFormat: {}, report: {}, mId: {}, fileModels: {}", reportFormat, report.getName(), mId, fileModels);
        zipFileGenerator.generateZipFile(response, reportFormat, report, mId, fileModels);
    }

    /**
     * Builds a file model based on the provided report format and file data.
     * This method prepares the file model containing the header, data, and additional information
     * required for generating a report in the desired format. It can be used for different formats
     * like CSV, PDF, etc.
     *
     * @param reportFormat The format of the report (e.g., CSV, PDF).
     * @param header       The list of headers for the report.
     * @param fileData     The data to be included in the report.
     * @param pdfFileData  Additional data for generating PDF reports (e.g., images, text).
     * @return FileModel The generated file model containing the necessary data for file generation.
     */
    public FileModel buildFileModel(ReportFormat reportFormat, List<String> header, List<List<Object>> fileData, Map<String, Object> pdfFileData) {
        log.debug("Started buildFileModel for reportFormat: {}, header: {}, fileData: {}, pdfFileData: {}", reportFormat, header, fileData, pdfFileData);
        return fileGenerator.buildFileModel(reportFormat, header, fileData, pdfFileData);
    }

    /**
     * Building content type and setting file in response.
     *
     * @param httpResponse HttpServletResponse
     * @param reportFormat ReportFormat
     * @param filePath     String
     */
    public void downloadFile(HttpServletResponse httpResponse, ReportFormat reportFormat, String filePath) {
        log.info("Started downloadFile for reportFormat: {}, filePath: {}", reportFormat, filePath);
        String contentType = switch (reportFormat) {
            case CSV -> "text/csv";
            case XLSX -> "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
            case PDF -> MediaType.APPLICATION_PDF_VALUE;
            case TXT -> "text/TXT";
        };
        ReportUtils.setHeader(httpResponse, contentType, FilenameUtils.getName(filePath));
        s3Service.downloadFile(httpResponse, filePath);
    }

}
