package com.epay.reporting.repository.view;

import com.epay.reporting.entity.view.SbiEpayAggBankStmtReport;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;

import static com.epay.reporting.util.queries.ReconQueries.GET_SBIEPAY_AGG_BANK_DETAILS;
/**
 * Class Name: SBIAccountPayoutRepository
 * *
 * Description: This class is responsible for interacting with the database to retrieve Bankstmt records .
 * Author: Saurabh mahto(V1018841)
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * Version:1.0
 */

@Repository
@RequiredArgsConstructor
public class SBIAccountPayoutRepository {
    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    private final NamedParameterJdbcTemplate jdbcTemplate;

    public List<SbiEpayAggBankStmtReport> fetchSBIEPAYAccountPayout(String mId){
        log.info("Getting data for {} mId.", mId);
        MapSqlParameterSource params = new MapSqlParameterSource().addValue("mId", mId);
        return jdbcTemplate.query(GET_SBIEPAY_AGG_BANK_DETAILS, params,  new BeanPropertyRowMapper<>(SbiEpayAggBankStmtReport.class));
    }
}
