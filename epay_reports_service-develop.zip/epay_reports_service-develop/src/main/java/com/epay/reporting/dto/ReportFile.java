package com.epay.reporting.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Class Name: ReportFile
 * Description: This class represents a report file, containing the file's name and its content.
 * It serves as a DTO to store the details of a report file, which can include file content (as a byte array)
 * and the file name. The class is annotated with Lombok annotations (`@Builder`, `@Data`, `@AllArgsConstructor`,
 * `@NoArgsConstructor`) to facilitate object construction and eliminate boilerplate code for getter, setter,
 * constructor, and toString methods.
 * Author: Bhoopendra Rajput
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * Version:1.0
 */
@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ReportFile {
    private String name;
    private byte[] content;
}
