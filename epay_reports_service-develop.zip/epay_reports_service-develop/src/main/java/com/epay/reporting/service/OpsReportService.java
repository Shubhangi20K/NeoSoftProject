package com.epay.reporting.service;

import com.epay.reporting.dao.OpsReportDao;
import com.epay.reporting.dto.ReportFile;
import com.epay.reporting.dto.ReportResponseDto;
import com.epay.reporting.dto.TxtFileModel;
import com.epay.reporting.dto.ops.OpsReportRequestDto;
import com.epay.reporting.etl.producer.OpsReportConfirmationPublisher;
import com.epay.reporting.exception.ReportingException;
import com.epay.reporting.externalservice.S3Service;
import com.epay.reporting.util.enums.Report;
import com.epay.reporting.util.enums.ReportFormat;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.text.MessageFormat;
import java.util.List;
import java.util.UUID;

import static com.epay.reporting.util.ErrorConstants.INVALID_ERROR_CODE;
import static com.epay.reporting.util.ErrorConstants.INVALID_ERROR_MESSAGE;
import static com.epay.reporting.util.ReportingConstant.REPORT_TYPE;
import static com.epay.reporting.util.enums.Report.*;

/**
 * Class Name: OpsReportService
 * *
 * Description: To define business logic for all the Recon request.
 * Description: This service defines the business logic for handling all Recon-related requests. It interacts
 * with the `Dao classes` for data access, the `FileGeneratorService` for file creation.
 * It processes the necessary logic for generating, managing, and validating invoices,
 * providing the core functionality of the invoice management system.
 * <p>
 * Author: Saurabh Mahto(V1018841)
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Service
@RequiredArgsConstructor
public class OpsReportService {

    private static final List<String> MERCHANT_PAYOUT_HEADER = List.of("MERCHANT ID", "MERCHANT NAME", "TRANSACTION AMOUNT", "TRANSACTION CURRENCY", "SETTLEMENT AMOUNT", "SETTLEMENT CURRENCY", "COMMISSION PAYABLE", "GST", "PAYOUT AMOUNT", "REFUND AMOUNT", "TDR ON REFUND AMOUNT", "GST ON REFUND AMOUNT", "NET REFUND AMOUNT", "NET PAYOUT AMOUNT", "PAYOUT DATE", "TRANSACTION COUNT");
    private static final List<String> TRANSACTION_REFUND_HEADER = List.of("SETTLEMENT FILE NUMBER", "SETTLEMENT DATE", "MERCHANT ID", "MERCHANT NAME", "MERCHANT ORDER NUMBER", "TRANSACTION ID", "TRANSACTION BOOKING DATE & TIME", "TRANSACTION CURRENCY", "TRANSACTION AMOUNT", "REFUND CURRENCY", "REFUND AMOUNT", "COMMISSION PAYABLE", "GST", "NET REFUND AMOUNT", "GATEWAY NAME", "GATEWAY TRACE NO", "PAY MODE CODE", "REFUND TYPE", "REFUND BOOKING DATE", "ARRN NO");
    private static final List<String> TRANSACTION_MIS_HEADER = List.of("MERCHANT ID", "MERCHANT NAME", "MERCHANT CATEGORY", "MERCHANT ORDER NO", "TRANSACTION ID", "INSTRUCTION DATE AND TIME", "TRANSACTION CURRENCY", "MERCHANT ORDER AMOUNT", "TOTAL FEE ABS", "GST", "GATEWAY POSTING AMOUNT", "AMOUNT SETTLED", "AVAILABLE REFUND AMOUNT", "PAY MODE CODE", "PAY GATEWAY", "GATEWAY TRACE NUMBER", "STATUS", "REMARK", "MERCHANT RISK CATEGORY", "ACCESS MEDIUM", "PAY PROC", "PAY PROC TYPE", "MERCHANT AUTHORIZE", "MERCHANT AUTHORIZE DATE", "AUTO SETTLEMENT", "TRANSACTION FEE FLAG", "CIN NUMBER", "RESPONSE REASON", "MERCHANT BEARABLE FEE", "MERCHANT BEARABLE GST", "CUSTOMER BEARABLE FEE", "CUSTOMER BEARABLE GST", "SUB STATUS DESCRIPTION", "PAYMENT SUCCESS DATE");
    private static final List<String> TRANSACTION_PAYOUT_HEADER = List.of("SETTLEMENT FILE NUMBER", "SETTLEMENT DATE & TIME", "MERCHANT ID", "MERCHANT NAME", "MERCHANT ORDER NO", "TRANSACTION ID", "TRANSACTION BOOKING DATE & TIME", "TRANSACTION CURRENCY", "TRANSACTION AMOUNT", "SETTLEMENT CURRENCY", "SETTLEMENT AMOUNT", "COMMISSION PAYABLE", "GST", "PAYOUT AMOUNT", "GATEWAY NAME", "GATEWAY TRACE NUMBER", "PAY MODE CODE", "PAY PROC", "OTHER DETAILS", "TRANSACTION FEE FLAG", "CIN NUMBER");
    private static final List<String> SBI_EPAY_AGG_BANK_HEADER = List.of("MERCHANT ID", "MERCHANT CATEGORY", "MERCHANT NAME", "MERCHANT ORDER NUMBER", "TRANSACTION ID", "TRANSACTION BOOKING DATE & TIME", "TRANSACTION AMOUNT", "TRANSACTION CURRENCY", "TRANSACTION STATUS", "ETL UPLOAD DATE", "ETL STATUS", "GATEWAY NAME", "GATEWAY TRACE NUMBER", "PAY MODE CODE", "GATEWAY STATUS");
    private static final List<String> BAD_AND_FAILED_REPORT_HEADER = List.of("MERCHANT_ID","ROW_NUMBER","ATRN_NUM","TXN_AMOUNT","BANK_REF_NUMBER","RECON_STATUS","SETTLEMENT_STATUS","PAYOUT_STATUS","REMARK");
    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());

    private final FileGeneratorService fileGeneratorService;
    private final S3Service s3Service;
    private final OpsReportDao opsReportDao;
    private final OpsReportConfirmationPublisher reportConfirmationPublisher;
    private final ObjectMapper objectMapper;

    /**
     * This will generate the Report based on Report type.
     *
     * @param opsReportRequestDto Ops Requested DTO
     */
    public void reportGeneration(OpsReportRequestDto opsReportRequestDto) {
        log.info("Processing OpsReportRequestDto with reportType: {}", opsReportRequestDto.getReportType());
        switch (opsReportRequestDto.getReportType()) {
            case TRANSACTION_MIS ->
                    generateCsvReport(TRANSACTION_MIS_HEADER, opsReportDao.getTransactionMISByMID(opsReportRequestDto.getReportFilter()), TRANSACTION_MIS, opsReportRequestDto.getRrId(),null);
            case TRANSACTION_WISE_PAYOUT_MIS ->
                    generateCsvReport(TRANSACTION_PAYOUT_HEADER, opsReportDao.getTransactionMerchantPayouts(opsReportRequestDto.getReportFilter()), TRANSACTION_WISE_PAYOUT_MIS, opsReportRequestDto.getRrId(),null);
            case SBIEPAY_AGG_BANKSTMT_REPORT ->
                    generateCsvReport(SBI_EPAY_AGG_BANK_HEADER, opsReportDao.getSBIAccountPayouts(opsReportRequestDto.getReportFilter()), SBIEPAY_AGG_BANKSTMT_REPORT, opsReportRequestDto.getRrId(),null);
            case MERCHANT_WISE_PAYOUT_MIS ->
                    generateCsvReport(MERCHANT_PAYOUT_HEADER, opsReportDao.getMerchantPayoutData(opsReportRequestDto.getReportFilter()), MERCHANT_WISE_PAYOUT_MIS, opsReportRequestDto.getRrId(),null);
            case TRANSACTION_WISE_REFUND_MIS ->
                    generateCsvReport(TRANSACTION_REFUND_HEADER, opsReportDao.getTransactionRefundData(opsReportRequestDto.getReportFilter()), TRANSACTION_WISE_REFUND_MIS, opsReportRequestDto.getRrId(),null);
            case AAT_PAYOUT ->
                    generateTxtReport(AAT_PAYOUT, opsReportRequestDto.getRrId(), opsReportDao.getAATMerchantAccountPayoutDao(opsReportRequestDto.getReportFilter()));
            case NEFT_PAYOUT ->
                    generateTxtReport(NEFT_PAYOUT, opsReportRequestDto.getRrId(), opsReportDao.getNEFTMerchantAccountPayoutDao(opsReportRequestDto.getReportFilter()));
            case BAD_RECORD ->
                    generateCsvReport(BAD_AND_FAILED_REPORT_HEADER,opsReportDao.getBadRecordDetails(opsReportRequestDto.getReportFilter()),BAD_RECORD,opsReportRequestDto.getRrId(),opsReportRequestDto.getReportFilter().getRfId());
            case FAILED_REPORT ->
                    generateCsvReport(BAD_AND_FAILED_REPORT_HEADER,opsReportDao.getFailedReportDetails(opsReportRequestDto.getReportFilter()),FAILED_REPORT,opsReportRequestDto.getRrId(),opsReportRequestDto.getReportFilter().getRfId());
            default ->
                    throw new ReportingException(INVALID_ERROR_CODE, MessageFormat.format(INVALID_ERROR_MESSAGE, REPORT_TYPE, opsReportRequestDto.getReportType()));
        }
    }

    private void generateCsvReport(List<String> header, List<List<Object>> data, Report report, UUID rrId,UUID rfId) {
        ReportFile reportFile = fileGeneratorService.generateFile(ReportFormat.CSV, report, header, data,rfId);
        uploadFileOnS3(reportFile, rrId, ReportFormat.CSV, report);
    }

    /**
     * Builds the txt report, uploads it to S3, and saves report details in DB
     *
     * @param report Report type
     * @param rrId   Report UUID
     */
    private void generateTxtReport(Report report, UUID rrId, List<String> lines) {
        ReportFile reportFile = fileGeneratorService.generateFile(report, TxtFileModel.builder().lines(lines).build());
        uploadFileOnS3(reportFile, rrId, ReportFormat.TXT, report);
    }

    private void uploadFileOnS3(ReportFile reportFile, UUID rrId, ReportFormat reportFormat, Report report) {
        String s3FileName = s3Service.uploadFile(reportFile.getName(), reportFile.getContent(), false);
        log.info("Report uploaded to S3 with file name: {}", s3FileName);
        opsReportDao.saveReport(rrId, reportFormat, s3FileName);
        log.info("Report data saved in DB for ReportID: {}", rrId);
        publishReportConfirmation(rrId, s3FileName, report);
    }

    /**
     * @param id         UUID
     * @param s3FilePath String
     * @param report     Report
     */
    private void publishReportConfirmation(UUID id, String s3FilePath, Report report) {
        try {
            String reportConfirmationMessage = objectMapper.writeValueAsString(ReportResponseDto.builder().rrId(id).s3FilePath(s3FilePath).build());
            reportConfirmationPublisher.publish(StringUtils.join(report.getName(), "_", id), reportConfirmationMessage);
        } catch (Exception e) {
            log.error("Error in publishing alert", e);
        }
    }

}
