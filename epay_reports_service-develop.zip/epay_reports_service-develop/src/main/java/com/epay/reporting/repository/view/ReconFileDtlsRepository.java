package com.epay.reporting.repository.view;

import com.epay.reporting.entity.view.ReconFileDtls;

import com.epay.reporting.util.queries.ReconQueries;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;



@Repository
@RequiredArgsConstructor
public class ReconFileDtlsRepository {
    private final NamedParameterJdbcTemplate jdbcTemplate;

    public List<ReconFileDtls> getReconFileDtls(UUID rfId){
        String rfIdString= rfId.toString().replace("-","").toUpperCase();
        MapSqlParameterSource params = new MapSqlParameterSource();
        params.addValue("rfId", rfIdString);
        return jdbcTemplate.query(ReconQueries.BAD_RECORDS, params,  new BeanPropertyRowMapper<>(ReconFileDtls.class));
    }

    public List<ReconFileDtls> getFailedReconFileDtls(UUID rfId){
        String rfIdString= rfId.toString().replace("-","").toUpperCase();
        MapSqlParameterSource params = new MapSqlParameterSource();
        params.addValue("rfId", rfIdString);
        return jdbcTemplate.query(ReconQueries.FAILED_RECORDS, params,  new BeanPropertyRowMapper<>(ReconFileDtls.class));
    }


}
