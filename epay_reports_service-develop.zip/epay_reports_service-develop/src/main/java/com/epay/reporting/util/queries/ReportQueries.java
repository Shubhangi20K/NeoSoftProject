package com.epay.reporting.util.queries;

import lombok.experimental.UtilityClass;

/**
 * Class Name: ReportQueries
 * *
 * Description: This class contains SQL queries related to the Report
 * *
 * Author: Bhoopendra Rajput
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@UtilityClass
public class ReportQueries {

    public static final String JDBC_ORDER_REPORT = """
                   SELECT o.TRANSACTION_DATE as transactionDate, o.MERCHANT_ORDER_NUMBER as merchantOrderNumber,
                   o.CUSTOMER_ID as customerId, o.TRANSACTION_CURRENCY as transactionCurrency,
                   o.ORDER_AMOUNT as orderAmount, o.SBI_ORDER_REF_NUMBER as sbiOrderRefNumber,
                   o.ORDER_STATUS as status, o.ATTEMPTS as attempts, o.MID as mId
                   FROM VIEW_ORDER_REPORT o
                   WHERE o.MID = :mId
                   AND o.TRANSACTION_DATE BETWEEN TO_DATE('1970-01-01','YYYY-MM-DD')+(:startDate/1000/86400) AND TO_DATE('1970-01-01','YYYY-MM-DD')+(:endDate/1000/86400)
                   ORDER BY o.TRANSACTION_DATE desc
            """;

    public static final String JDBC_REFUND_REPORT = """
                             SELECT refund.MERCHANT_ORDER_NUMBER as merchantOrderID,
                              refund.SBI_ORDER_REF_NUMBER as sbiEPayOrderID,
                              refund.MERCHANT_POSTING_AMOUNT  as merchantPostingAmount,
                              refund.GATEWAY_POSTING_AMOUNT  as gatewayPostingAmount,
                              refund.ATRN_NUM as atrn,
                              refund.TRANSACTION_STATUS as transactionStatus,
                              refund.TRANSACTION_SUCCESS_DATE_AND_TIME  as transactionSuccessDateAndTime,
                              refund.ARRN_NUM as arrn,
                              refund.REFUND_TYPE as refundType,
                              refund.TRANSACTION_CURRENCY  as refundCurrency,
                              refund.REFUND_AMOUNT as refundAmount,
                              refund.refund_Booking_Date as refundBookingDate,
                              refund.REFUND_PROCESSED_DATE as refundProcessedDate,
                              refund_status as refundStatus,
                              bank_name as paymentGateway,
                              refund.PAYMODE_NAME as paymentMode,
                              amount_refunded as amountRefunded,
                              refund.FURTHER_REFUND_ALLOWED as furtherRefundAllowed ,
                              refund.PENDING_AMOUNT_FOR_REFUND as pendingAmountforRefund,
                              refund.REMARK as remark
                              FROM VIEW_REFUND_REPORT refund
                   WHERE refund.mid = :mId
                   AND refund.refund_Booking_Date BETWEEN TO_DATE('1970-01-01','YYYY-MM-DD')+ (:startDate/1000/86400) AND TO_DATE('1970-01-01','YYYY-MM-DD')+(:endDate/1000/86400)
                   ORDER BY refund.refund_Booking_Date desc
            """;

    public static final String JDBC_TRANSACTION_REPORT = """
                             SELECT trans.MID AS mid,
                             trans.TRANSACTION_DATE AS transactionDate,
                             trans.TRANSACTION_SUCCESS_DATE AS trnxSuccessDateAndTime,
                             trans.MERCHANT_ORDER_NUMBER AS merchantOrderNumber,
                             trans.SBIEPAY_ORDER_ID AS sbiOrderRefNumber,
                             trans.CUSTOMER_ID AS customerId,
                             trans.ATRN_NUM AS atrnNum,
                             trans.BANK_REFERENCE_NUMBER AS gateWayTraceNumber,
                             trans.PAYMODE_NAME AS payModeName,
                             trans.BANK_NAME as bankName,
                             trans.PAY_PROC_ID as payProc,
                             trans.TRANSACTION_CURRENCY AS transactionCurrency,
                             trans.ORDER_AMOUNT AS orderAmount,
                             trans.GATEWAY_POSTING_AMOUNT as gatewayPostingAmount,
                             trans.COMMISSION as commission,
                             trans.GST as gst,
                             trans.ORDER_STATUS AS orderStatus,
                             trans.TRANSACTION_STATUS AS transactionStatus,
                             trans.SETTLEMENT_STATUS as settlementStatus,
                             trans.REFUND_STATUS as refundStatus,
                             trans.CHARGEBACK_STATUS as chargeBackStatus,
                             trans.REFUND_AMOUNT as refundAmount,
                             trans.AMOUNT_CHARGEBACK as chargeBackAmount,
                             trans.CIN_NUMBER as cinNumber,
                             trans.MERCHANT_OTHER_DETAILS as merchantOtherDetails
                             FROM VIEW_TRANSACTION_REPORT trans WHERE trans.MID = :mId
                             AND trans.TRANSACTION_DATE BETWEEN TO_DATE('1970-01-01','YYYY-MM-DD')+(:startDate/1000/86400) AND TO_DATE('1970-01-01','YYYY-MM-DD')+(:endDate/1000/86400)
                             ORDER BY trans.TRANSACTION_DATE desc
            """;
}