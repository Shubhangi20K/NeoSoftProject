package com.epay.reporting.externalservice;


import com.epay.reporting.client.ApiClient;
import com.epay.reporting.exception.ReportingException;
import com.epay.reporting.externalservice.request.UserValidationRequest;
import com.epay.reporting.model.response.ReportingResponse;
import com.epay.reporting.util.EPayIdentityUtil;
import com.epay.reporting.util.ErrorConstants;
import com.sbi.epay.authentication.providers.EPayTokenProvider;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import reactor.core.publisher.Mono;

import java.net.URI;

/**
 * Class Name: MerchantServiceClient
 * *
 * Description:  This class provides methods for interacting with the Merchant Service API,
 * specifically for validating merchant-related data, such as user, token, and merchant ID (MID) access.
 * It extends the ApiClient class, utilizing WebClient for making HTTP requests.
 * This service supports different types of validations including login, token validation,
 * and access rights for active and non-active merchant IDs.
 * Author: V1018482
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
public class MerchantServiceClient extends ApiClient {

    public static final String MID_VALIDATION = "/validation/access/";
    public static final String ACTIVE_MID_VALIDATION = "/validation/access/active/";
    public static final String USER_VALIDATION = "/validation/user";
    public static final String TOKEN_VALIDATION = "/validation/token";
    public static final String BEARER = "Bearer ";

    private final EPayTokenProvider ePayTokenProvider;

    /**
     * Constructor for initializing the MerchantServiceClient with a base URL and EPayTokenProvider.
     *
     * @param baseUrl the base URL of the Merchant Service API
     * @param ePayTokenProvider the provider for fetching ePay tokens
     */
    public MerchantServiceClient(String baseUrl, EPayTokenProvider ePayTokenProvider) {
        super(baseUrl);
        this.ePayTokenProvider = ePayTokenProvider;
    }

    /**
     * Validates the user by making a POST request to the user validation endpoint.
     *
     * @param userName the username to validate
     * @return a ReportingResponse containing validation status as a String
     */
    public ReportingResponse<String> validateMerchantUser(String userName) {
        UserValidationRequest userValidationReq = UserValidationRequest.builder().requestType("LOGIN").userName(userName).build();
        return post(USER_VALIDATION, userValidationReq, new ParameterizedTypeReference<>() {});
    }

    /**
     * Validates the provided token by making a GET request to the token validation endpoint.
     *
     * @param token the token to validate
     * @return a ReportingResponse containing validation status as a String
     */
    public ReportingResponse<String> validateMerchantToken(String token) {
        return get(TOKEN_VALIDATION, token, new ParameterizedTypeReference<>() {});
    }

    /**
     * Validates access to a merchant ID (MID) for the current user.
     *
     * @param mId the merchant ID to validate
     * @return a ReportingResponse containing validation status as a String
     */
    public ReportingResponse<String> validateMIdAccess(String mId) {
        String token = ePayTokenProvider.getToken();
        String urlPath = MID_VALIDATION + EPayIdentityUtil.getUserPrincipal().getUsername() + "/" + mId;
        return get(urlPath, token, new ParameterizedTypeReference<>() {
        });
    }

    /**
     * Validates access to an active merchant ID (MID) for the current user.
     *
     * @param mId the merchant ID to validate
     * @return a ReportingResponse containing validation status as a String
     */
    public ReportingResponse<String> validateActiveMIdAccess(String mId) {
        String token = ePayTokenProvider.getToken();
        String urlPath = ACTIVE_MID_VALIDATION + EPayIdentityUtil.getUserPrincipal().getUsername() + "/" + mId;
        return get(urlPath, token, new ParameterizedTypeReference<>() {
        });
    }

}
