package com.epay.reporting.controller;

import com.epay.reporting.dto.ReportMasterDto;
import com.epay.reporting.model.response.ReportingResponse;
import com.epay.reporting.service.ReportMasterService;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import io.swagger.v3.oas.annotations.Operation;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Class Name: ReportMasterController
 * *
 * Description:This class defines the endpoints for managing and processing report-related operations. It interacts with
 * the ReportMasterService to handle various report tasks, such as creation, retrieval, and updates.
 * *
 * Author: V1018344
 * Copyright (c) 2025 [State Bank of India]
 * ALl rights reserved
 * *
 * Version: 1.0
 */

@RestController
@RequestMapping("/report")
@RequiredArgsConstructor
public class ReportMasterController {
    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    private final ReportMasterService reportMasterService;

    /**
     * Retrieves a list of all available report names.
     *
     * @return ReportingResponse<String> A response containing a list of report names.
     */
    @GetMapping
    @Operation(summary = "Endpoint to provide the list for report names")
    public ReportingResponse<ReportMasterDto> getAllReportNames() {
        log.info("Request received to retrieve all available report names.");
        return reportMasterService.getAllReportNames();
    }
}
