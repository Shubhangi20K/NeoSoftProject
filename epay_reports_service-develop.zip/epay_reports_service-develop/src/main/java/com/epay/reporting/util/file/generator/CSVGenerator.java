package com.epay.reporting.util.file.generator;

import com.epay.reporting.dto.ReportFile;
import com.epay.reporting.exception.ReportingException;
import com.epay.reporting.util.ErrorConstants;
import com.epay.reporting.util.ReportingConstant;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import jakarta.servlet.http.HttpServletResponse;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.StringEscapeUtils;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.MessageFormat;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import static com.epay.reporting.util.DateTimeUtils.FORMATTER_DD_MM_YY_HH_MM_SS;
import static com.epay.reporting.util.ReportUtils.setHeader;

/**
 * Class Name: CSVGenerator
 * *
 * Description:Class for generating and downloading CSV files for reports.
 * *
 * Author: Bhoopendra Rajput
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class CSVGenerator {

    private static final LoggerUtility log = LoggerFactoryUtility.getLogger(CSVGenerator.class);


    /**
     * Downloads the generated CSV file for the given report name and merchant ID.
     *
     * @param response - HTTP response to write the CSV to
     * @param reportName - Name of the report
     * @param mId - Merchant ID
     * @param headerName - List of CSV headers
     * @param objects - Data to populate the CSV
     */
    protected static void downloadCsvFile(HttpServletResponse response, String reportName, String mId, List<String> headerName, List<List<Object>> objects) {
        log.info("Started download CSV file for reportName: {}, headerName: {},  objects: {}", reportName, headerName, CollectionUtils.size(objects));
        try {
            String fileName = getFileName(reportName, mId);
            String csvContent = generateCSV(headerName, objects);

            setHeader(response, "text/csv", fileName);
            OutputStream outputStream = response.getOutputStream();
            outputStream.write(csvContent.getBytes(StandardCharsets.UTF_8));
            outputStream.flush();
        } catch (Exception e) {
            log.error("Error occurred during CSV File downloading : {}", e.getMessage());
            throw new ReportingException(ErrorConstants.FILE_GENERATION_ERROR_CODE, MessageFormat.format(ErrorConstants.FILE_GENERATION_ERROR_MESSAGE, "csv", e.getMessage()));
        }
    }
    /**
     * Generates a CSV file from the provided data and saves it to the file system.
     *
     * @param reportName - Name of the report
     * @param mId - Merchant ID
     * @param headerName - List of CSV headers
     * @param objects - Data to populate the CSV
     * @return - Generated CSV file
     */
    protected static ReportFile csvFileGenerator(String reportName, String mId, List<String> headerName, List<List<Object>> objects) {
        log.info("Started csv file generator for reportName : {}, mId {}, headerName: {},  objects.size: {}", reportName, mId, headerName, CollectionUtils.size(objects));
        String fileName = getFileName(reportName, mId);
        String csvContent = generateCSV(headerName, objects);
        return ReportFile.builder().name(fileName).content(csvContent.getBytes(StandardCharsets.UTF_8)).build();
    }

    /**
     * Generates a CSV file from the provided data and saves it to the file system.
     *
     * @param reportName - Name of the report
     * @param headerName - List of CSV headers
     * @param objects - Data to populate the CSV
     * @return - Generated CSV file
     */
    protected static ReportFile csvFileGenerator(String reportName, List<String> headerName, List<List<Object>> objects,UUID rfId) {
        log.info("Started csv file generator for reportName : {}, mId {}, headerName: {},  objects.size: {}", reportName, headerName, CollectionUtils.size(objects));
        String fileName;
        if(ObjectUtils.notEqual(rfId,null)){
            fileName=getFileName(reportName,rfId);
        }else {
            fileName = getFileName(reportName);
        }
        String csvContent = generateCSV(headerName, objects);
        return ReportFile.builder().name(fileName).content(csvContent.getBytes(StandardCharsets.UTF_8)).build();
    }

    /**
     * Constructs the file name for the CSV file based on the report name and merchant ID.
     *
     * @param reportName - Name of the report
     * @param mId - Merchant ID
     * @return - Generated file name
     */
    private static String getFileName(String reportName, String mId) {
        return ReportingConstant.REPORT_ROOT_FOLDER + StringEscapeUtils.escapeJava(mId + "_" + reportName + "_" + System.currentTimeMillis() + ".csv");
    }

    /**
     * Constructs the file name for the CSV file based on the report name and merchant ID.
     *
     * @param reportName - Name of the report
     * @return - Generated file name
     */
    private static String getFileName(String reportName) {
        return String.format("%s%s_%s.csv", ReportingConstant.REPORT_ROOT_FOLDER, StringEscapeUtils.escapeJava(reportName), LocalDateTime.now().format(FORMATTER_DD_MM_YY_HH_MM_SS));
    }

    /**
     * Constructs the file name for the CSV file based on the report name and rfId.
     *
     * @param reportName - Name of the report
     * @return - Generated file name
     */
    private static String getFileName(String reportName, UUID rfId){
        return String.format("%s_%s_%s.csv",StringEscapeUtils.escapeJava(reportName),rfId.toString().toUpperCase().replaceAll("-",""), LocalDateTime.now().format(FORMATTER_DD_MM_YY_HH_MM_SS));
    }
    /**
     * Generates the CSV content as a string.
     *
     * @param headers - List of headers for the CSV
     * @param objects - List of data rows for the CSV
     * @return - CSV content as a string
     */

    private static String generateCSV(List<String> headers, List<List<Object>> objects) {
        StringBuilder csvContent = new StringBuilder();
        csvContent.append(String.join(",", headers)).append("\n");
        for (List<Object> rowData : objects) {
            String row = rowData.stream()
                    .map(data -> ObjectUtils.isNotEmpty(data) ? data.toString() : StringUtils.EMPTY)
                    .collect(Collectors.joining(","));
            csvContent.append(row).append("\n");
        }
        return csvContent.toString();
    }

}
