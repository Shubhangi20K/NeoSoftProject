package com.epay.reporting.model.request;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import static com.epay.reporting.util.ErrorConstants.HIBERNATOR_REQUIRED_ERROR_MESSAGE;

/**
 * Class Name: TransactionPayModeRequest
 * Description: This class is used to represent the request data for fetching transaction data based on payment modes
 * within a specified date range. The class contains fields for the start and end dates for filtering transactions.
 * Author: Bhoopendra Rajput
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * Version: 1.0
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TransactionPayModeRequest {
    @NotBlank(message = HIBERNATOR_REQUIRED_ERROR_MESSAGE)
    private String fromDate;
    @NotBlank(message = HIBERNATOR_REQUIRED_ERROR_MESSAGE)
    private String toDate;

}
