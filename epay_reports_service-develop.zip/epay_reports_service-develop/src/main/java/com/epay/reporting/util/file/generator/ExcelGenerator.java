package com.epay.reporting.util.file.generator;

import com.epay.reporting.dto.ReportFile;
import com.epay.reporting.exception.ReportingException;
import com.epay.reporting.util.ErrorConstants;
import com.epay.reporting.util.ReportingConstant;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletResponse;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.StringEscapeUtils;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.MessageFormat;
import java.util.Date;
import java.util.List;
import java.util.stream.IntStream;

import static com.epay.reporting.util.ReportUtils.setHeader;

/**
 * Class Name: ExcelGenerator
 * *
 * Description: Report generation logic for Order, Transaction, Refund.
 * <p>
 * This class provides functionality to generate and download Excel files.
 * It supports two primary operations:
 * 1. Generate an Excel file with a report and download it via HTTP response.
 * 2. Generate an Excel file and save it to the local file system.
 * The generated Excel files are in `.xlsx` format.
 * *
 * Author: Bhoopendra Rajput
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class ExcelGenerator {

    private static final String YYYY_MM_DD = "yyyy-mm-dd";
    private static final LoggerUtility log = LoggerFactoryUtility.getLogger(ExcelGenerator.class);

    protected static void downloadExcelFile(HttpServletResponse response, String reportName, String mId, List<String> headerName, List<List<Object>> objects) {
        String fileName = getFileName(reportName, mId);
        log.info("Starting download of Excel file with name: {}", fileName);
        setHeader(response, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", fileName);
        try (Workbook workbook = createExcelWorkBook(reportName, headerName, objects); ServletOutputStream outputStream = response.getOutputStream()) {
            workbook.write(outputStream);
        } catch (Exception e) {
            log.error("Error occurred during Excel File downloading : {}", e.getMessage());
            throw new ReportingException(ErrorConstants.FILE_GENERATION_ERROR_CODE, MessageFormat.format(ErrorConstants.FILE_GENERATION_ERROR_MESSAGE, "xlsx", e.getMessage()));
        }
    }
    /**
     * Method Name: excelFileGenerator
     * This method generates an Excel file and saves it to the local file system.
     *
     * @param reportName The name of the report to be included in the Excel file.
     * @param mId The unique identifier for the file, used to name the file.
     * @param headerName A list of header names for the Excel sheet.
     * @param objects A list of data rows where each row is a list of cell values.
     * @return The generated Excel file.
     */
    protected static ReportFile excelFileGenerator(String reportName, String mId, List<String> headerName, List<List<Object>> objects) {
        String fileName = getFileName(reportName, mId);
        log.info("Excel file fileName {}, Sheet Name {}", fileName, reportName);
        try ( Workbook workbook = createExcelWorkBook(reportName, headerName, objects); ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
            workbook.write(outputStream);
            log.info("Excel content added in byte array, write operation completed.");
            return ReportFile.builder().name(fileName).content(outputStream.toByteArray()).build();
        } catch (IOException e) {
            log.error("An error occurred in excelFileGenerator method: {}", e.getMessage());
            throw new ReportingException(ErrorConstants.FILE_GENERATION_ERROR_CODE, MessageFormat.format(ErrorConstants.FILE_GENERATION_ERROR_MESSAGE, "csv", e.getMessage()));
        }
    }

    /**
     * Method Name: getFileName
     * Helper method to generate the file name for the Excel file.
     *
     * @param reportName The name of the report.
     * @param mId The unique identifier.
     * @return The generated file name including path.
     */
    private static String getFileName(String reportName, String mId) {
        return ReportingConstant.REPORT_ROOT_FOLDER + StringEscapeUtils.escapeJava(mId + "_" + reportName + "_" + System.currentTimeMillis() + ".xlsx");
    }

    /**
     * Method Name: createExcelWorkBook
     * Helper method to create an Excel workbook with the provided report name, headers, and data.
     *
     * @param sheetName The name of the sheet.
     * @param headers The headers for the sheet.
     * @param data The data to populate the sheet.
     * @return A Workbook object containing the Excel data.
     */
    private static Workbook createExcelWorkBook(String sheetName, List<String> headers, List<List<Object>> data) {
        log.info("Creating Excel workbook for sheet: {}", sheetName);
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet(sheetName);
        setHeaderRowInSheet(sheet, headers);
        setRowDataInSheet(sheet, data);
        return workbook;
    }


    /**
     * Method Name: setHeaderRowInSheet
     * Helper method to set the header row in the sheet.
     *
     * @param sheet The sheet to which the header row is to be added.
     * @param headers The headers to be written in the first row.
     */
    private static void setHeaderRowInSheet(Sheet sheet, List<String> headers) {
        Row headerRow = sheet.createRow(0);
        IntStream.range(0, headers.size()).forEachOrdered(i -> {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(headers.get(i));
        });
        log.info("Header row set with {} columns.", headers.size());

    }

    /**
     * Method Name: setRowDataInSheet
     * Helper method to set data rows in the sheet.
     *
     * @param sheet The sheet to which the data rows are to be added.
     * @param data The list of data rows to be written.
     */
    private static void setRowDataInSheet(Sheet sheet, List<List<Object>> data) {
        int rowNum = 1;
        for (List<Object> rowData : data) {
            Row row = sheet.createRow(rowNum++);
            setColumnData(row, rowData);
        }
        log.info("Data rows set with {} rows.", data.size());

    }
    /**
     * Method Name: setColumnData
     * Helper method to set the column data for each row.
     *
     * @param row The row to which the data will be added.
     * @param rowData The list of data for the row.
     */
    private static void setColumnData(Row row, List<Object> rowData) {
        int columnNum = 0;
        for (Object columnData : rowData) {
            Cell cell = row.createCell(columnNum++);
            writeCellData(cell, columnData);
        }
    }

    /**
     * Method Name: writeCellData
     * Writes the given value to an Excel cell in the appropriate format based on its type.
     *
     * @param cell  The Excel cell to write to.
     * @param value The value to write (must implement ExcelWritable).
     */

    private static void writeCellData(Cell cell, Object value) {
        if (ObjectUtils.isEmpty(value)) {
            cell.setCellValue(StringUtils.EMPTY);
            return;
        }
        switch (value) {
            case String s -> cell.setCellValue(s);
            case Integer i -> cell.setCellValue((i).doubleValue());
            case Long l -> cell.setCellValue((l).doubleValue());
            case Double d -> cell.setCellValue(d);
            case Boolean b -> cell.setCellValue(b);
            case Date date -> {
                cell.setCellValue(date);
                cell.setCellStyle(getDateCellStyle(cell.getSheet().getWorkbook()));
            }
            default -> cell.setCellValue(value.toString());
        }

    }

    /**
     * Method Name: getDateCellStyle
     * Helper method to create a date style for Excel cells.
     *
     * @param workbook The workbook to which the style will be applied.
     * @return The date cell style.
     */
    private static CellStyle getDateCellStyle(Workbook workbook) {
        CellStyle style = workbook.createCellStyle();
        CreationHelper createHelper = workbook.getCreationHelper();
        style.setDataFormat(createHelper.createDataFormat().getFormat(YYYY_MM_DD));
        return style;
    }

}
