package com.epay.reporting.entity;

import jakarta.persistence.EntityListeners;
import jakarta.persistence.MappedSuperclass;
import lombok.Getter;
import lombok.Setter;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.io.Serializable;

/**
 * Class Name: AuditEntityByDate
 * Description:This class serves as a base entity for tracking the creation and last modification timestamps
 * of an entity. It implements Serializable and uses the @EntityListeners annotation to automatically
 * capture auditing information. The class contains fields to store the creation timestamp (createdAt)
 * and the last modified timestamp (updatedAt).
 * Author: V1018344
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * Version: 1.0
 */
@Getter
@Setter
@MappedSuperclass
@EntityListeners(AuditingEntityListener.class)
public class AuditEntityByDate implements Serializable {

    @CreatedDate
    private Long createdAt;

    @LastModifiedDate
    private Long updatedAt;

}
