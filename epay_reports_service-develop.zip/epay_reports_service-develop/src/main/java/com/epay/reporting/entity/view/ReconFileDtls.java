package com.epay.reporting.entity.view;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
/**
 * Class Name: ReconFileDtls
 * *
 * Description: This class is used to hold and represent the Bad report data.
 * Author: Saurabh Mahto
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ReconFileDtls {
    private Integer rowNumber;
    private String mId;
    private String atrnNum;
    private BigDecimal txnAmount;
    private String bankRefNumber;
    private String payoutStatus;
    private String reconStatus;
    private String settlementStatus;
    private String remark;
}
