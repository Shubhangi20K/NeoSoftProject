package com.epay.reporting.etl.listener;

import com.epay.reporting.exception.ReportingException;
import com.epay.reporting.service.ReportService;
import com.epay.reporting.util.enums.InterfaceType;
import com.sbi.epay.authentication.util.EPayAuthenticationConstant;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.MDC;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import java.util.UUID;

import static com.epay.reporting.util.EventMessageUtils.buildEventErrorLog;
import static com.epay.reporting.util.EventMessageUtils.buildEventReceivedLog;

/**
 * Class Name: ReportGenerationListener
 * Description: The ReportGenerationListener class listens for Kafka messages containing report generation requests.
 * It extracts the report ID from the message, generates a unique correlation ID for the request, and invokes the report generation service.
 * In case of any error during the process, it logs the details of the error.
 * Author: Bhoopendra Rajput
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * Version: 1.0
 */
@Component
@RequiredArgsConstructor
public class ReportGenerationListener {
    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    private final ReportService reportService;
    private final ApplicationEventPublisher publisher;

    @KafkaListener(topics = "${spring.kafka.topic.report}")
    public void onMessage(ConsumerRecord<String, String> consumerRecord) {
        log.info("Reporting generation request received for key : {}", consumerRecord.key());
        log.debug("Reporting generation request received for key : {} and value : {}", consumerRecord.key(), consumerRecord.value());
        try {
            publisher.publishEvent(buildEventReceivedLog(InterfaceType.REPORT_GENERATION_TOPIC, consumerRecord));
            MDC.put(EPayAuthenticationConstant.CORRELATION_ID, String.valueOf(UUID.randomUUID()));
            reportService.generateReport(UUID.fromString(consumerRecord.value()));
        } catch (ReportingException e) {
            publisher.publishEvent(buildEventErrorLog(InterfaceType.REPORT_GENERATION_TOPIC, consumerRecord, e.getMessage()));
            log.error("Error during reporting kafka listening message[key:{} and value: {}], error: {}", consumerRecord.key(), consumerRecord.value(), e.getErrorMessage());
        }
    }
}