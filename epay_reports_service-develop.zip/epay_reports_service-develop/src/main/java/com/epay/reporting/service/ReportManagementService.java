package com.epay.reporting.service;

import com.epay.reporting.dao.ReportManagementDao;
import com.epay.reporting.dto.ReportManagementDto;
import com.epay.reporting.mapper.ReportManagementMapper;
import com.epay.reporting.model.request.DownloadRequest;
import com.epay.reporting.model.request.ReportManagementRequest;
import com.epay.reporting.model.response.ReportManagementResponse;
import com.epay.reporting.model.response.ReportingResponse;
import com.epay.reporting.util.enums.ReportStatus;
import com.epay.reporting.validator.ReportManagementValidator;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

import static com.epay.reporting.util.ReportingConstant.REPORT_GENERATION_REQ_RECEIVED_SUCCESS;
import static com.epay.reporting.util.ReportingConstant.RESPONSE_SUCCESS;

/**
 * Class Name: ReportManagementService
 * *
 * Description: This service handles the business logic for generating reports related to Orders, Transactions,
 * and Refunds. It interacts with the `ReportManagementDao` for data access, the `ReportManagementMapper` for
 * entity-to-DTO mappings, and the `ReportManagementValidator` to ensure data validity. It also utilizes the
 * `FileGeneratorService` for generating the reports in the appropriate file formats.
 * Author: Bhoopendra Rajput
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * Version:1.0
 */
@Service
@RequiredArgsConstructor
public class ReportManagementService {
    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    private final ReportManagementDao reportManagementDao;
    private final ReportManagementMapper mapper;
    private final ReportManagementValidator reportManagementValidator;
    private final FileGeneratorService fileGeneratorService;

    /**
     * Searches for and retrieves report management data based on the provided search criteria and pagination.
     * This method validates the search request, fetches the filtered report management data from the data layer,
     * and maps it to the response format. It also provides the total count and the total number of elements
     * for pagination.
     *
     * @param reportManagementRequest The search criteria for fetching report management data.
     * @param pageable                The pagination details for the request.
     * @return A `ReportingResponse` containing a list of `ReportManagementResponse` objects along with the count
     * of the results and total elements.
     */
    public ReportingResponse<ReportManagementResponse> searchAndGetReportManagement(ReportManagementRequest reportManagementRequest, Pageable pageable) {
        log.info("Search and get ReportManagement Request {}", reportManagementRequest);
        reportManagementValidator.validateSearchRequest(reportManagementRequest);
        Page<ReportManagementDto> reportManagementDTOs = reportManagementDao.searchAndGetReportManagement(reportManagementRequest, pageable);
        List<ReportManagementResponse> reportManagementResponses = mapper.mapDtoListToResponseList(reportManagementDTOs.getContent());
        log.info("Returning list of ReportManagement {}", reportManagementResponses);
        return ReportingResponse.<ReportManagementResponse>builder().status(RESPONSE_SUCCESS).data(reportManagementResponses).count(reportManagementDTOs.stream().count()).total(reportManagementDTOs.getTotalElements()).build();
    }

    /**
     * Saves a new report management request to the system.
     * This method validates the incoming report management request, converts it into a Data Transfer Object (DTO),
     * and then persists it to the database. Upon successful insertion, it returns a success response with a message
     * indicating that the request has been received successfully.
     *
     * @param reportManagementRequest The report management request that contains the report details to be saved.
     * @return A `ReportingResponse` containing a success message stating that the report management request was
     * received successfully.
     */
    public ReportingResponse<String> save(ReportManagementRequest reportManagementRequest) {
        log.info("Saving ReportManagement for mId: {}, reportManagementRequest: {}", reportManagementRequest.getMId(), reportManagementRequest);
        reportManagementValidator.validateRequest(reportManagementRequest);
        reportManagementDao.saveReportManagement(mapper.mapRequestToDto(reportManagementRequest));
        return ReportingResponse.<String>builder().status(RESPONSE_SUCCESS).data(List.of(REPORT_GENERATION_REQ_RECEIVED_SUCCESS)).build();
    }

    /**
     * Validate the requested report is available to download , if present then set it in the http servlet response.
     *
     * @param httpResponse    HttpServletResponse
     * @param mId             String
     * @param downloadRequest DownloadRequest
     */
    public void downloadReport(HttpServletResponse httpResponse, String mId, DownloadRequest downloadRequest) {
        log.info("Download report for mId: {}, downloadRequest: {}", mId, downloadRequest);
        reportManagementValidator.validateDownloadRequest(mId, downloadRequest);
        ReportManagementDto reportManagementDto = reportManagementDao.getReportManagement(mId, downloadRequest.getFilePath(), ReportStatus.GENERATED);
        fileGeneratorService.downloadFile(httpResponse, reportManagementDto.getFormat(), reportManagementDto.getFilePath());
    }
}
