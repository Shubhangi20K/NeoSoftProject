package com.epay.reporting.entity.view;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Class Name: TransactionSummaryReport
 * Description:This class represents a summary report of transactions. It contains details such as the total
 * success amount, total success count, total failure count, transaction date, total failure amount,
 * and percentages for success and failure. Additionally, it includes a list of daily failure reports
 * for further breakdown.
 * Author: V1018344
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * Version: 1.0
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TransactionSummaryReport {

    private String totalSuccessAmount;
    private Long totalSuccessCount;
    private Long totalFailureCount;
    private String transactionDate;
    private String totalFailureAmount;
    private Double successPercentage;
    private Double failPercentage;
    private List<TransactionFailureSummaryReport> transactionDailyFailure;

}
