package com.epay.reporting.service;

import com.epay.reporting.dao.TransactionSummaryDao;
import com.epay.reporting.entity.view.RefundSummaryReport;
import com.epay.reporting.entity.view.TransactionDailySummaryReport;
import com.epay.reporting.model.response.ReportingResponse;
import com.epay.reporting.entity.view.SettlementSummaryReport;
import com.epay.reporting.util.ReportingConstant;
import com.epay.reporting.validator.MIdValidator;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

import static com.epay.reporting.util.ReportingConstant.RESPONSE_SUCCESS;

@Service
@RequiredArgsConstructor
public class TransactionDailySummaryService {

    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());

    private final TransactionSummaryDao transactionSummaryDao;
    private final MIdValidator mIdValidator;

    /**
     * Fetches transaction summary for a given merchant ID for current date.
     * @param mId - Merchant ID
     * @return List of transaction summary data
     */
    public ReportingResponse<TransactionDailySummaryReport> getDailyTransactionSummary(String mId) {
        mIdValidator.validateMIdAccess(mId);
        log.info("Fetching Transaction summary for MerchantId: {}", mId);
        List<TransactionDailySummaryReport> transactionSummary = transactionSummaryDao.getTransactionSummary(mId);
        return ReportingResponse.<TransactionDailySummaryReport>builder().status(RESPONSE_SUCCESS).data(transactionSummary).total((long) transactionSummary.size()).build();
    }

    /**
     * Fetches settlement summary for a given merchant ID for current date.
     * @param mId - Merchant ID
     * @return List of settlement amount data
     */
    public ReportingResponse<SettlementSummaryReport> getSettlementDailySummary(String mId) {
        mIdValidator.validateMIdAccess(mId);
        log.info("Fetching current day Settlement Summary for MerchantId: {}", mId);
        List<SettlementSummaryReport> settlementSummary = transactionSummaryDao.getDailySettlementSummary(mId);
        return ReportingResponse.<SettlementSummaryReport>builder().status(RESPONSE_SUCCESS).data(settlementSummary).total((long) settlementSummary.size()).build();
    }

    /**
     * Fetches refund summary for a given merchant ID for current date.
     * @param mId - Merchant ID
     * @return List of refund summary data
     */
    public ReportingResponse<RefundSummaryReport> getDailyRefundSummary(String mId) {
        mIdValidator.validateMid(mId);
        log.info("Fetching current day Refund summary for MerchantId: {}", mId);
        List<RefundSummaryReport> refundSummary = transactionSummaryDao.getDailyRefundSummary(mId);
        return ReportingResponse.<RefundSummaryReport>builder().status(RESPONSE_SUCCESS).data(refundSummary).total((long) refundSummary.size()).build();
    }

}
