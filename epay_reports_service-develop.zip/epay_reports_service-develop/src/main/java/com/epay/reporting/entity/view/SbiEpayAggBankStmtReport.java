package com.epay.reporting.entity.view;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

/**
 * Class Name: SBIAccountPayout
 * *
 * Description: This class is used to hold and represent the sbiepay bankStmt report data.
 * Author: Saurabh Mahto
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SbiEpayAggBankStmtReport {
    private String mId;
    private Character merchantCategory;
    private String merchantName;
    private String orderRefNumber;
    private String atrnNum;
    private String transactionDate;
    private BigDecimal orderAmount;
    private String currencyCode;
    private String transactionStatus;
    private String etlUploadDate;
    private String etlStatus;
    private String channelBank;
    private String gatewayTraceNumber;
    private String payMode;
    private String gatewayStatus;
}
