package com.epay.reporting.dao;

import com.epay.reporting.entity.view.MerchantWisePayoutMisFormat;
import com.epay.reporting.mapper.MerchantPayoutMapper;
import com.epay.reporting.repository.view.MerchantPayoutRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class MerchantPayoutDao {

    private final MerchantPayoutRepository merchantPayoutRepository;
    private final MerchantPayoutMapper merchantPayoutMapper;

    /**
     * Fetches Merchant Payout data from DB
     *
     * @param mpId List of UUIDs
     * @return List of MerchantPayout
     */
    public List<List<Object>> getMerchantPayoutData(List<UUID> mpId) {
        List<MerchantWisePayoutMisFormat> merchantWisePayoutMisFormats =  merchantPayoutRepository.fetchMerchantPayout(mpId);
        return merchantWisePayoutMisFormats.stream().map(merchantPayoutMapper::mapToList).collect(Collectors.toList());
    }


}
