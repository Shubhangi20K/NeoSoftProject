package com.epay.reporting.model.request;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import static com.epay.reporting.util.ErrorConstants.HIBERNATOR_REQUIRED_ERROR_MESSAGE;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class RecentTransactionRequest {

    private String frequency;
    @NotBlank(message = HIBERNATOR_REQUIRED_ERROR_MESSAGE)
    private String fromDate;
    @NotBlank(message = HIBERNATOR_REQUIRED_ERROR_MESSAGE)
    private String toDate;

}
