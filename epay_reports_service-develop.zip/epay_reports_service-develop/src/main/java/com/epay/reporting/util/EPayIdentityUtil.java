package com.epay.reporting.util;

import com.sbi.epay.authentication.model.EPayPrincipal;
import org.springframework.security.core.context.SecurityContextHolder;
/**
 * Class Name: EPayIdentityUtil
 * *
 * Description: Utility class to retrieve the current authenticated user's principal (EPayPrincipal) from the security context.
 * This class provides methods for extracting user-related information in the context of the current authenticated session.
 * *
 * Author: Bhoopendra Rajput
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
public class EPayIdentityUtil {
    /**
     * Retrieves the current authenticated user's principal from the security context.
     *
     * @return the EPayPrincipal object representing the current authenticated user
     */
    public static EPayPrincipal getUserPrincipal() {
       return (EPayPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    }
}
