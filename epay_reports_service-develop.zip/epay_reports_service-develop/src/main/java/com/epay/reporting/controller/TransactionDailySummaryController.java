package com.epay.reporting.controller;

import com.epay.reporting.entity.view.RefundSummaryReport;
import com.epay.reporting.entity.view.TransactionDailySummaryReport;
import com.epay.reporting.model.response.ReportingResponse;
import com.epay.reporting.entity.view.SettlementSummaryReport;
import com.epay.reporting.service.TransactionDailySummaryService;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import io.swagger.v3.oas.annotations.Operation;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

/**
 * Class Name: InvoiceController
 * *
 * Description: To handle the daily Transaction details request and provide the response.
 * *
 * Author: Ravi Rathore
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@RestController
@RequestMapping("/daily/summary")
@RequiredArgsConstructor
public class TransactionDailySummaryController {

    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    private final TransactionDailySummaryService transactionDailySummaryService;

    /**
     * Retrieves transaction summary data for a given merchant ID (MID).
     *
     * @param mId The merchant ID (MID) for which the transaction summary are to be fetched.
     * @return ReportingResponse<TransactionSummaryReportResponse> A response containing the current day transaction summary data for the specified merchant.
     */
    @GetMapping("/transaction/{mId}")
    @Operation(summary = "Get Current Day Transaction Summary Data based on MId")
    public ReportingResponse<TransactionDailySummaryReport> getDailyTransactionSummary(@PathVariable String mId) {
        log.info("Transaction Summary Request : mId {}", mId);
        return transactionDailySummaryService.getDailyTransactionSummary(mId);
    }

    /**
     * Retrieves settlement data for a given merchant ID (MID).
     *
     * @param mId The merchant ID (MID) for which the settlement data are to be fetched.
     * @return ReportingResponse<SettlementSummaryReport> A response containing the current day settlement summary data for the specified merchant.
     */
    @GetMapping("/settlement/{mId}")
    @Operation(summary = "Get Current Day Settlement Summary Data based on MId")
    public ReportingResponse<SettlementSummaryReport> getDailySettlementSummary(@PathVariable String mId) {
        log.info("Get Settlement Amount Request : mId {}", mId);
        return transactionDailySummaryService.getSettlementDailySummary(mId);
    }

    /**
     * Retrieves Refund data for a given merchant ID (MID).
     *
     * @param mId The merchant ID (MID) for which the refund trends are to be fetched.
     * @return ReportingResponse<RefundSummaryReport> A response containing the current day refund summary data for the specified merchant.
     */
    @GetMapping("/refund/{mId}")
    @Operation(summary = "Get Current Day Refund Summary Data based on MId")
    public ReportingResponse<RefundSummaryReport> getDailyRefundSummary(@PathVariable String mId) {
        log.info("Get Refund Summary Request : mId {}", mId);
        return transactionDailySummaryService.getDailyRefundSummary(mId);
    }
}
