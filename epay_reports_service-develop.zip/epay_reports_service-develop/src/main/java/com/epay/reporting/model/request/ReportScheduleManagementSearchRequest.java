package com.epay.reporting.model.request;


import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotBlank;
import lombok.*;

import static com.epay.reporting.util.ErrorConstants.HIBERNATOR_REQUIRED_ERROR_MESSAGE;

/**
 * Class Name: ReportScheduleManagementSearchRequest
 * Description: This class represents the search request for managing scheduled reports. It includes various filters
 * to query the report schedules, such as the report name, merchant ID, frequency, format, and the start and end time
 * for the report schedule execution.
 * Author: Bhoopendra Rajput
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * Version: 1.0
 */
@Data
@AllArgsConstructor
@Builder
@NoArgsConstructor
public class ReportScheduleManagementSearchRequest {

    private String report;
    @NotBlank(message = HIBERNATOR_REQUIRED_ERROR_MESSAGE)
    @JsonProperty("mId")
    private String mId;
    private String frequency;
    private String format;
    private Long scheduleStartExecutionTime;
    private Long scheduleEndExecutionTime;

}
