package com.epay.reporting.etl.producer;

import com.epay.reporting.util.enums.InterfaceType;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Component;

import static com.epay.reporting.util.EventMessageUtils.buildEventErrorLog;
import static com.epay.reporting.util.EventMessageUtils.buildEventSendLog;

@Component
@RequiredArgsConstructor
public class ReportAlertGenerateProducer extends ReportingProducer{

    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    private final ApplicationEventPublisher publisher;

    @Override
    public void publish(String routingKey, String message) {
        String kafkaRoutingKey = getRoutingKey(routingKey);
        try {
            log.info("Report alert generation publishing for key : {}", kafkaRoutingKey);
            log.debug("Report alert generation publishing for key : {} and value : {}", kafkaRoutingKey, message);
            kafkaMessagePublisher.publish(topics.getReportAlertTopic(), kafkaRoutingKey, message);
            publisher.publishEvent(buildEventSendLog(InterfaceType.REPORT_ALERT_GENERATION_TOPIC, topics.getReportAlertTopic(), kafkaRoutingKey, message));
            log.debug("Report alert generation has been published");
        } catch (Exception e) {
            log.error("Error in report alert generation {} publish {}", kafkaRoutingKey, e.getMessage());
            publisher.publishEvent(buildEventErrorLog(InterfaceType.REPORT_ALERT_GENERATION_TOPIC, topics.getReportAlertTopic(), kafkaRoutingKey, e.getMessage()));
        }
    }
}
