package com.epay.reporting.dto;

import com.epay.reporting.util.enums.Report;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

/**
 * Class Name: OpsReportRequestDto
 * Description:This class represents a Data Transfer Object (DTO) for the master details of a report.
 * It includes the report's name and description, which provide essential information about the report.
 * The `@JsonIgnore` annotation is used to exclude the `id` field from the JSON serialization, while the
 * `@JsonInclude` annotation ensures that only non-null fields are included in the output JSON.
 * Author: V1018344
 * Copyright (c) 2025 [State Bank of India]
 * ALl rights reserved
 * Version: 1.0
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ReportMasterDto {

    @JsonIgnore
    private UUID id;
    private Report name;
    private String description;
    private int sequence;
}
