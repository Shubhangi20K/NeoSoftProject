package com.epay.reporting.dao;

import com.epay.reporting.dto.ReportManagementDto;
import com.epay.reporting.entity.view.OrderReport;
import com.epay.reporting.entity.view.RefundReport;
import com.epay.reporting.entity.view.TransactionReport;
import com.epay.reporting.mapper.OrderMapper;
import com.epay.reporting.mapper.RefundMapper;
import com.epay.reporting.mapper.TransactionMapper;
import com.epay.reporting.repository.view.ReportRepository;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Class Name: ReportDao
 * Description: This class serves as the Data Access Object (DAO) for fetching report data
 * related to orders, refunds, and transactions. It interacts with the `ReportRepository`
 * to retrieve data and provides methods to get the respective reports based on the given
 * merchant ID and date range.
 * Author: Bhoopendra Rajput
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * Version: 1.0
 */
@Component
@RequiredArgsConstructor
public class ReportDao {
    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    private final ReportRepository reportRepository;
    private final OrderMapper orderMapper;
    private final TransactionMapper transactionMapper;
    private final RefundMapper refundMapper;

    /**
     * Method Name: getOrderReportData
     * Description: This method retrieves the order report data for a given merchant
     * ID and date range. It queries the `ReportRepository` to fetch the relevant data
     * for orders placed within the specified start and end dates.
     *
     * @return List<OrderReport> - A list of `OrderReport` objects representing the fetched order data.
     */
    public List<List<Object>> getOrderReportData(ReportManagementDto reportManagement) {
        log.info("Fetching Order Report Data for reportManagement {}", reportManagement);
        List<OrderReport> orderReports = reportRepository.fetchOrderReportData(reportManagement.getMId(), reportManagement.getDurationFromDate(), reportManagement.getDurationToDate());
        return orderReports.stream().map(orderMapper::mapToList).collect(Collectors.toList());
    }

    /**
     * Method Name: getRefundReportData
     * Description: This method retrieves the refund report data for a given merchant
     * ID and date range. It queries the `ReportRepository` to fetch the relevant data
     * for refunds processed within the specified start and end dates.
     *
     * @return List<RefundReport> - A list of `RefundReport` objects representing the fetched refund data.
     */
    public List<List<Object>> getRefundReportData(ReportManagementDto reportManagement) {
        log.info("Fetching Refund Report Data for reportManagement {} ", reportManagement);
        List<RefundReport> refundReports = reportRepository.fetchRefundReportData(reportManagement.getMId(), reportManagement.getDurationFromDate(), reportManagement.getDurationToDate());
        return refundReports.stream().map(refundMapper::mapToList).collect(Collectors.toList());
    }

    /**
     * Method Name: getTransaction
     * <p>
     * Description: This method retrieves the transaction report data for a given
     * merchant ID and date range. It queries the `ReportRepository` to fetch the relevant
     * data for transactions within the specified start and end dat
     *
     * @return List<TransactionReport> - A list of `TransactionReport` objects representing the fetched transaction data.
     */
    public List<List<Object>> getTransaction(ReportManagementDto reportManagement) {
        log.info("Fetching Transaction Report Data for reportManagement {} ", reportManagement);
        List<TransactionReport> transaction = reportRepository.getTransaction(reportManagement.getMId(), reportManagement.getDurationFromDate(), reportManagement.getDurationToDate());
        return transaction.stream().map(transactionMapper::mapToList).collect(Collectors.toList());
    }
}