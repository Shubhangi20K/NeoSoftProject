package com.epay.reporting.repository.view;

import com.epay.reporting.entity.view.SettlementSummaryReport;
import com.epay.reporting.entity.view.TransactionDailySummaryReport;
import com.epay.reporting.exception.ReportingException;
import com.epay.reporting.util.DateTimeUtils;
import com.epay.reporting.util.queries.TransactionDashboardQueries;
import lombok.RequiredArgsConstructor;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.text.MessageFormat;
import java.util.List;

import static com.epay.reporting.util.ErrorConstants.*;
import static com.epay.reporting.util.ReportingConstant.SETTLEMENT;
import static com.epay.reporting.util.ReportingConstant.TRANSACTION;
import static com.epay.reporting.util.queries.TransactionDashboardQueries.JDBC_CURRENT_PAST_SETTLEMENT;

@Repository
@RequiredArgsConstructor
public class TransactionSummaryRepository {

    private final NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    /**
     * Fetches transaction summary for a given merchant ID for current date.
     *
     * @param mId the merchant ID to filter the transaction trends by
     * @return a list of TransactionSummaryReportResponse objects representing the transaction summary
     */
    public List<TransactionDailySummaryReport> getCurrentTransactionSummary(String mId) {
        try {
            String sql = TransactionDashboardQueries.JDBC_CURRENT_TRANSACTION_SUMMARY;
            MapSqlParameterSource parameters = new MapSqlParameterSource();
            parameters.addValue(MID, mId);
            parameters.addValue(CURRENT_DATE, DateTimeUtils.getDate(DateTimeUtils.getCurrentTimeInMills(), DateTimeUtils.FORMATTER_DD_MM_YYYY));
            return namedParameterJdbcTemplate.query(sql, parameters, new BeanPropertyRowMapper<>(TransactionDailySummaryReport.class));
        } catch (EmptyResultDataAccessException e) {
            throw new ReportingException(NOT_FOUND_ERROR_CODE, MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, TRANSACTION));
        }
    }

    /**
     * Fetches Settlement data for a given merchant ID for current date.
     *
     * @param mId the merchant ID to filter the transaction trends by
     * @return a list of SettlementAmountResponse objects representing the Settlement amount
     */
    public List<SettlementSummaryReport> getCurrentSettlementSummary(String mId) {
        try {
            MapSqlParameterSource parameters = new MapSqlParameterSource();
            parameters.addValue(MID, mId);
            parameters.addValue(CURRENT_DATE, DateTimeUtils.getDate(DateTimeUtils.getCurrentTimeInMills(), DateTimeUtils.FORMATTER_DD_MM_YYYY));
            parameters.addValue(PREVIOUS_DATE, DateTimeUtils.getDate(DateTimeUtils.deductHourFromNow(24), DateTimeUtils.FORMATTER_DD_MM_YYYY));
            return namedParameterJdbcTemplate.query(JDBC_CURRENT_PAST_SETTLEMENT, parameters, new BeanPropertyRowMapper<>(SettlementSummaryReport.class));
        } catch (EmptyResultDataAccessException e) {
            throw new ReportingException(NOT_FOUND_ERROR_CODE, MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, SETTLEMENT));
        }
    }

}
