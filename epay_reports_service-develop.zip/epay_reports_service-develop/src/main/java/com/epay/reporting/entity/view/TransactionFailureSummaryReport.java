package com.epay.reporting.entity.view;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Class Name: TransactionFailureSummaryReport
 * Description: This class is used to hold and represent the summary data of failed transactions.
 * It contains information related to transactions that failed, such as failure reason,
 * transaction details, failure status, and other relevant attributes necessary for generating
 * reports about transaction failures. This class acts as a data transfer object (DTO) for
 * processing and presenting transaction failure data within the system.
 * Author: Subhra Goswami
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * Version: 1.0
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TransactionFailureSummaryReport {
    private String failureReason;
    private Long failureCount;
    private Double failurePercentage;
}
