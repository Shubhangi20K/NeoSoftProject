package com.epay.reporting.repository.view;

import com.epay.reporting.entity.view.TransactionMIS;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;


import static com.epay.reporting.util.queries.ReconQueries.GET_VIEW_TRANSACTION_MIS;
/**
 * Class Name: TransactionMISRepository
 * *
 * Description: This class is responsible for interacting with the database to retrieve Transaction Mis records .
 * Author: Saurabh mahto(V1018841)
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * Version:1.0
 */

@Repository
@RequiredArgsConstructor
public class TransactionMISRepository {
    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    private final NamedParameterJdbcTemplate jdbcTemplate;

    public List<TransactionMIS> fetchTransactionMISData(String mId){
        log.info("Getting data for {} mId.", mId);
        MapSqlParameterSource params = new MapSqlParameterSource().addValue("mId", mId);
        return jdbcTemplate.query(GET_VIEW_TRANSACTION_MIS, params,  new BeanPropertyRowMapper<>(TransactionMIS.class));
    }
}
