package com.epay.reporting.repository.view;

import com.epay.reporting.entity.view.GstReport;
import com.epay.reporting.entity.view.MerchantFeesReport;
import com.epay.reporting.util.queries.InvoiceQueries;
import lombok.RequiredArgsConstructor;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

import static com.epay.reporting.util.ErrorConstants.REPORT_MONTHS;
import static com.epay.reporting.util.ReportingConstant.MID;

/**
 * Class Name: InvoiceRepository
 * *
 * Description: This class is responsible for interacting with the database to retrieve invoice records related to transactions and GST.
 * It specifically contains methods for querying merchant fees invoices based on the merchant ID and report dates.
 * Author: Bhoopendra Rajput
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * Version:1.0
 */
@Repository
@RequiredArgsConstructor
public class InvoiceRepository {

    private final NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    /**
     *
     * @param mId String
     * @param reportMonths List</String>
     * @return List
     */
    public List<MerchantFeesReport> getMerchantFeesInvoice(String mId, List<String> reportMonths) {
        SqlParameterSource parameters = new MapSqlParameterSource(Map.of(MID, mId, REPORT_MONTHS, reportMonths));
        return namedParameterJdbcTemplate.query(InvoiceQueries.JDBC_TXN_INVOICE, parameters, new BeanPropertyRowMapper<>(MerchantFeesReport.class));
    }

    public List<GstReport> getMerchantGstInvoice(String mId, List<String> reportMonths) {
        SqlParameterSource parameters = new MapSqlParameterSource(Map.of(MID, mId, REPORT_MONTHS, reportMonths));
        return namedParameterJdbcTemplate.query(InvoiceQueries.JDBC_GST_INVOICE, parameters, new BeanPropertyRowMapper<>(GstReport.class));
    }
}
