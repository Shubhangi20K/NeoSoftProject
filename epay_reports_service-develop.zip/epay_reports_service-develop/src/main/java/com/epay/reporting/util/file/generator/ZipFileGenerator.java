package com.epay.reporting.util.file.generator;

import com.epay.reporting.dto.ReportFile;
import com.epay.reporting.exception.ReportingException;
import com.epay.reporting.util.ErrorConstants;
import com.epay.reporting.util.enums.Report;
import com.epay.reporting.util.enums.ReportFormat;
import com.epay.reporting.util.file.model.FileModel;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.MessageFormat;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import static com.epay.reporting.util.ReportUtils.setHeader;
import static java.lang.String.format;

/**
 * Class Name: ZipFileGenerator
 * *
 * Description: This class handles the creation of ZIP files containing report files. It processes report data
 * and generates ZIP files, either for download via HTTP or for further processing.
 * *
 * Author: Bhoopendra Rajput
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved.
 * *
 * Version: 1.0
 */
@Component
@RequiredArgsConstructor
public class ZipFileGenerator {
    private static final LoggerUtility log = LoggerFactoryUtility.getLogger(ZipFileGenerator.class);
    private final FileGenerator fileGenerator;
    /**
     * Generates a ZIP file containing multiple report files, and sends it as a downloadable response.
     *
     * @param response the HttpServletResponse to write the ZIP file to
     * @param reportFormat the format of the report (e.g., PDF, CSV)
     * @param report the specific report to be generated
     * @param mId the merchant ID
     * @param fileModels list of FileModel objects containing the data for the report files
     */
    public void generateZipFile(HttpServletResponse response, ReportFormat reportFormat, Report report, String mId, List<FileModel> fileModels) {
        log.info("Starting ZIP file generation for report: {} and merchant ID: {}", report.getName(), mId);
        try {
            ByteArrayOutputStream byteArrayOutputStream;
            if(fileModels.size()> 1) {
               byteArrayOutputStream = generateZipFile(reportFormat, report, mId, fileModels);
            }else {
                byteArrayOutputStream = generateConsolidatedZipFile(reportFormat, report, mId, fileModels);
            }
            setHeader(response, "application/zip", format("%s_%s_%s.zip", mId, report.getName(), System.currentTimeMillis()));
            response.setContentLength(byteArrayOutputStream.size());
            response.getOutputStream().write(byteArrayOutputStream.toByteArray());
            response.getOutputStream().flush();
            log.info("ZIP file successfully generated and sent to the response.");
        } catch (Exception e) {
            log.error("Error occurred during zipFileGenerator : {}", e.getMessage());
            throw new ReportingException(ErrorConstants.FILE_GENERATION_ERROR_CODE, MessageFormat.format(ErrorConstants.FILE_GENERATION_ERROR_MESSAGE, "zip", e.getMessage()));
        }

    }
    /**
     * Generates a ZIP file containing multiple report files as byte arrays.
     *
     * @param reportFormat the format of the report (e.g., PDF, CSV)
     * @param report the specific report to be generated
     * @param mId the merchant ID
     * @param fileModels list of FileModel objects containing the data for the report files
     * @return a ByteArrayOutputStream containing the ZIP file data
     * @throws IOException if an error occurs during ZIP file creation
     */
    private ByteArrayOutputStream generateZipFile(ReportFormat reportFormat, Report report, String mId, List<FileModel> fileModels) throws IOException {
        log.info("Generating ZIP file for report: {} with format: {}", report.getName(), reportFormat.name());
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        ZipOutputStream zos = new ZipOutputStream(byteArrayOutputStream);
            for (FileModel fileModel : fileModels) {
                ReportFile reportFile = fileGenerator.generateFile(reportFormat, report, mId, fileModel);
                ZipEntry zipEntry = new ZipEntry(getZipFileName(reportFormat, report, fileModel));
                zos.putNextEntry(zipEntry);
                byte[] content = reportFile.getContent();
                if (content != null && content.length > 0) {
                    zos.write(content);
                } else {
                    log.info("Skipping empty file: {}", zipEntry.getName());
                }
                zos.closeEntry();
            }
            zos.finish();

        log.info("ZIP file generation completed for report: {}", report.getName());
        return byteArrayOutputStream;
    }

    private ByteArrayOutputStream generateConsolidatedZipFile(ReportFormat reportFormat, Report report, String mId, List<FileModel> fileModels) throws IOException {
        log.debug("Generating ZIP file for report: {} with format: {}", report.getName(), reportFormat.name());
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();

        try (ZipOutputStream zos = new ZipOutputStream(byteArrayOutputStream)) {
            for (FileModel fileModel : fileModels) {
                ReportFile reportFile = fileGenerator.generateFile(reportFormat, report, mId, fileModel);
                String zipEntryName = getZipFileName(reportFormat, report, fileModel);
                ZipEntry zipEntry = new ZipEntry(zipEntryName);
                zos.putNextEntry(zipEntry);
                zos.write(reportFile.getContent());
                zos.closeEntry();
            }
            zos.finish();
        }

        log.debug("ZIP file generation completed for report: {}", report.getName());
        return byteArrayOutputStream;
    }

    /**
     * Creates a filename for a report file inside the ZIP archive.
     *
     * @param reportFormat the format of the report (e.g., PDF, CSV)
     * @param report the specific report to be generated
     * @param fileModel the file model containing data for the report file
     * @return a string representing the file name inside the ZIP archive
     */
    private static String getZipFileName(ReportFormat reportFormat, Report report, FileModel fileModel) {
        return MessageFormat.format("{0}_{1}.{2}", fileModel.getReportMonth(), report.getName(), reportFormat.name().toLowerCase());
    }

    /**
     * Converts a file to a ByteArrayOutputStream, used for cases where file data needs to be written to a byte array.
     *
     * @param file the file to be converted
     * @return a ByteArrayOutputStream containing the file data
     * @throws IOException if an error occurs while reading the file
     */
    // Method to convert a file to ByteArrayOutputStream
    private static ByteArrayOutputStream convertFileToByteArrayOutputStream(File file) throws IOException {
        log.debug("Converting file: {} to ByteArrayOutputStream", file.getName());
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        try (FileInputStream fis = new FileInputStream(file)) {
            byte[] buffer = new byte[1024]; // Read buffer
            int bytesRead;
            while ((bytesRead = fis.read(buffer)) != -1) {
                byteArrayOutputStream.write(buffer, 0, bytesRead);
            }
        }
        log.debug("File conversion to ByteArrayOutputStream completed: {}", file.getName());
        return byteArrayOutputStream;
    }
}
