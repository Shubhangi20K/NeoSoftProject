package com.epay.reporting.util.enums;

import com.epay.reporting.exception.ReportingException;
import com.epay.reporting.util.ErrorConstants;
import lombok.Getter;

import java.text.MessageFormat;
import java.util.Arrays;
/**
 * Name: ReportFormat
 * Description: Represents the format types in which a report can be generated (CSV, XLS, PDF).
 * *
 * Author: Bhoopendra Rajput
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Getter
public enum ReportFormat {
    CSV, XLSX, PDF,TXT;

    /**
     * Returns the ReportFormat enum corresponding to the provided name (case-insensitive).
     *
     * @param name The name of the format.
     * @return Corresponding ReportFormat enum.
     */
    public static ReportFormat getName(String name) {
        return Arrays.stream(values()).filter(rt -> rt.name().equalsIgnoreCase(name)).findFirst().orElseThrow(() -> new ReportingException(ErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(ErrorConstants.INVALID_ERROR_MESSAGE, "ReportFormat", "Valid ReportFormat are " + Arrays.toString(ReportFormat.values()))));
    }

}
