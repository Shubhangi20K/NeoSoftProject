package com.epay.reporting.validator;

import com.epay.reporting.dto.ErrorDto;
import com.epay.reporting.util.ErrorConstants;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.text.MessageFormat;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import static com.epay.reporting.util.DateTimeUtils.FORMATTER_MMM_YYYY;
import static com.epay.reporting.util.ErrorConstants.*;

@Component
@RequiredArgsConstructor
public class InvoiceValidator extends BaseValidator {
    public void validateRequestMonths(List<String> dates) {
        errorDtoList = new ArrayList<>();
        validationMandatory(dates);
        YearMonth currentMonth = YearMonth.now();

        for (String d : dates) {
            try {
                checkForLeadingTrailingAndSingleSpace(d, "date");
                throwIfErrors();
                YearMonth yearMonth = YearMonth.parse(d, FORMATTER_MMM_YYYY);
                int year = yearMonth.getYear();

                // Validate year range (adjust lower bound as needed)
                if (year < INVALID_YEAR || year > currentMonth.getYear()) {
                    errorDtoList.add(ErrorDto.builder()
                            .errorCode(ErrorConstants.INVALID_ERROR_CODE)
                            .errorMessage(MessageFormat.format(ErrorConstants.INVALID_ERROR_MESSAGE, YEAR, INVALID_YEAR_MESSAGE))
                            .build());
                    continue;
                }

                // Validate future month only if year is the current year
                if (year == currentMonth.getYear() && yearMonth.getMonthValue() > currentMonth.getMonthValue()) {
                    errorDtoList.add(ErrorDto.builder()
                            .errorCode(ErrorConstants.INVALID_ERROR_CODE)
                            .errorMessage(MessageFormat.format(ErrorConstants.INVALID_ERROR_MESSAGE, MONTH, INVALID_MONTH_MESSAGE))
                            .build());
                }

            } catch (DateTimeParseException e) {
                errorDtoList.add(ErrorDto.builder()
                        .errorCode(ErrorConstants.DATE_FORMAT_ERROR_CODE)
                        .errorMessage(MessageFormat.format(ErrorConstants.DATE_FORMAT_ERROR_MESSAGE, DATE_FORMAT))
                        .build());
            }
        }

        throwIfErrors();
    }

    /**
     * Validates all mandatory fields
     *
     * @param dates List<String>
     */
    private void validationMandatory(List<String> dates) {
        checkMandatoryCollection(dates, REPORT_MONTHS);
        dates.forEach(date -> {
            checkMandatoryField(date, REPORT_MONTHS);
            throwIfErrors();
        });
    }
}
