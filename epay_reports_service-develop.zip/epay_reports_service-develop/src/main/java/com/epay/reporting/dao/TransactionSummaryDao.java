package com.epay.reporting.dao;

import com.epay.reporting.entity.view.RefundSummaryReport;
import com.epay.reporting.entity.view.SettlementSummaryReport;
import com.epay.reporting.entity.view.TransactionDailySummaryReport;
import com.epay.reporting.repository.view.TransactionSummaryRepository;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class TransactionSummaryDao {

    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    private final TransactionSummaryRepository transactionSummaryRepository;
    private final RefundSummaryDao refundSummaryDao;

    /**
     * Fetches transaction summary for a given merchant ID for current date.
     *
     * @param mId - Merchant ID
     * @return List of transaction summary data
     */
    public List<TransactionDailySummaryReport> getTransactionSummary(String mId) {
        log.info("Fetching Transaction summary for MerchantId: {}", mId);
        return transactionSummaryRepository.getCurrentTransactionSummary(mId);
    }

    /**
     * Fetches settlement amount data for a given merchant ID for current date.
     *
     * @param mId - Merchant ID
     * @return List of settlement amount data
     */
    public List<SettlementSummaryReport> getDailySettlementSummary(String mId) {
        log.info("Fetching Settlement summary for MerchantId: {}", mId);
        return transactionSummaryRepository.getCurrentSettlementSummary(mId);
    }

    /**
     * Fetches refund summary for a given merchant ID for current date.
     *
     * @param mId - Merchant ID
     * @return List of refund summary data
     */
    public List<RefundSummaryReport> getDailyRefundSummary(String mId) {
        return refundSummaryDao.getDailyRefundSummary(mId);
    }
}
