package com.epay.reporting.util.file.model;

import lombok.Data;
/**
 * Class Name: FileModel
 * *
 * Description: This is an abstract base class for different file models. It holds common properties
 * related to a file, such as the report month. The child classes like CSVFileModel, ExcelFileModel,
 * and PdfFileModel extend this class and provide specific data for different file formats.
 * *
 * Author: Bhoopendra Rajput
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Data
public abstract class FileModel {

    /**
     * The month associated with the report.
     */
    private String reportMonth;
}
