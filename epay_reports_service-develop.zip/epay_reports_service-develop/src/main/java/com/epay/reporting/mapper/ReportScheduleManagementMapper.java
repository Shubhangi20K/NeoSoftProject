package com.epay.reporting.mapper;

import com.epay.reporting.dto.ReportScheduleManagementDto;
import com.epay.reporting.entity.ReportScheduleManagement;
import com.epay.reporting.model.request.ReportScheduleManagementRequest;
import com.epay.reporting.model.response.ReportScheduleManagementResponse;
import com.epay.reporting.util.enums.Frequency;
import com.epay.reporting.util.enums.Report;
import com.epay.reporting.util.enums.ReportFormat;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import java.util.List;

/**
 * Class Name: ReportScheduleManagementMapper
 * Description:This interface provides the mapping logic for converting between different data transfer objects (DTOs),
 * requests, responses, and entities related to the Report Schedule Management module.
 * It uses MapStruct annotations to automatically generate implementation classes for the mapping functions.
 * The interface includes custom mappings for fields such as report, format, and frequency,
 * converting string values into specific enum types (Report, ReportFormat, and Frequency).
 * It also handles mapping timestamps and other attributes between entities and DTOs.
 * Author: V1018344
 * Copyright (c) 2025 [State Bank of India]
 * ALl rights reserved
 * *
 * Version: 1.0
 */
@Mapper(builder = @Builder(disableBuilder = true), componentModel = "spring")
public interface ReportScheduleManagementMapper {

    /**
     * Maps the ReportScheduleManagement entity to its corresponding DTO (Data Transfer Object).
     *
     * @param reportScheduleManagement the entity to be converted
     * @return the corresponding ReportScheduleManagementDto
     */
    ReportScheduleManagementDto mapEntityToDto(ReportScheduleManagement reportScheduleManagement);

    /**
     * Maps a ReportScheduleManagementDto to a ReportScheduleManagement entity.
     *
     * @param reportScheduleManagementDto the DTO to be converted
     * @return the corresponding ReportScheduleManagement entity
     */
    ReportScheduleManagement mapDtoToEntity(ReportScheduleManagementDto reportScheduleManagementDto);

//    @Mapping(source = "id", target = "scheduleRequestId")
//    ReportScheduleManagementResponse mapDtoListToResponse(ReportScheduleManagementDto reportScheduleManagementDto);

    /**
     * Maps a ReportScheduleManagementDto to a ReportScheduleManagementResponse object,
     * including custom mappings for timestamps and scheduleRequestId.
     *
     * @param reportScheduleManagementDto the DTO to be mapped
     * @return the corresponding ReportScheduleManagementResponse
     */
    @Mapping(source = "createdAt", target = "requestStateTime")
    @Mapping(source = "updatedAt", target = "executionTime")
    @Mapping(source = "id", target = "scheduleRequestId")
    ReportScheduleManagementResponse mapDtoToResponse(ReportScheduleManagementDto reportScheduleManagementDto);

    /**
     * Maps a list of ReportScheduleManagementDto objects to a list of ReportScheduleManagementResponse objects.
     *
     * @param reportScheduleManagementDto the list of DTOs to be mapped
     * @return the list of corresponding ReportScheduleManagementResponse objects
     */
    List<ReportScheduleManagementResponse> mapDtoListToResponseList(List<ReportScheduleManagementDto> reportScheduleManagementDto);

    /**
     * Maps the ReportScheduleManagementRequest to a ReportScheduleManagementDto with custom mappings for report, format, and frequency.
     *
     * @param reportScheduleManagementRequest the request object containing report, format, and frequency information
     * @return the mapped ReportScheduleManagementDto
     */
    @Mapping(source="report", target = "report", qualifiedByName = "customStringToReport")
    @Mapping(source="format", target = "format", qualifiedByName = "customStringToReportFormat")
    @Mapping(source="frequency", target = "frequency", qualifiedByName = "customStringToFrequency")
    ReportScheduleManagementDto mapRequestToDto(ReportScheduleManagementRequest reportScheduleManagementRequest);

    /**
     * Custom method to convert a report name (String) to the corresponding Report enum.
     *
     * @param reportName the name of the report
     * @return the corresponding Report enum
     */
    @Named("customStringToReport")
    default Report customStringToReport(String reportName) {
        return Report.getName(reportName);
    }

    /**
     * Custom method to convert a format name (String) to the corresponding ReportFormat enum.
     *
     * @param formatName the name of the format
     * @return the corresponding ReportFormat enum
     */
    @Named("customStringToReportFormat")
    default ReportFormat customStringToReportFormat(String formatName) {
        return ReportFormat.getName(formatName);
    }

    /**
     * Custom method to convert a frequency name (String) to the corresponding Frequency enum.
     *
     * @param frequencyName the name of the frequency
     * @return the corresponding Frequency enum
     */
    @Named("customStringToFrequency")
    default Frequency customStringToFrequency(String frequencyName) {
        return Frequency.getName(frequencyName);
    }



}
