package com.epay.reporting.util.file.model;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;
import java.util.StringJoiner;

/**
 * Class Name: CSVFileModel
 * *
 * Description: This class represents the model for a CSV file, holding the headers and the data
 * of the CSV file. It extends the FileModel class which contains common properties related to files.
 * It uses Lombok annotations for automatic generation of getters, setters, equals, and hashCode methods.
 * *
 * Author: Bhoopendra Rajput
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Builder
@Data
@EqualsAndHashCode(callSuper = true)
public class CSVFileModel extends FileModel {
    /**
     * The headers of the CSV file.
     */
    private List<String> headers;

    /**
     * The data of the CSV file, represented as a list of rows, where each row is a list of objects.
     */
    private List<List<Object>> fileData;

    @Override
    public String toString() {
        return new StringJoiner(", ", CSVFileModel.class.getSimpleName() + "[", "]")
                .add("FileModel=" + super.toString())
                .add("headers=" + headers)
                .toString();
    }
}
