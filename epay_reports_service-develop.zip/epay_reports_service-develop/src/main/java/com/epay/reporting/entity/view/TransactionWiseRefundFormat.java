package com.epay.reporting.entity.view;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TransactionWiseRefundFormat {

    private String settlementFileNumber;
    private String settlementTime;
    private String mId;
    private String merchantName;
    private String merchantOrderNumber;
    private String transactionId;
    private String transactionDate;
    private String transactionCurrency;
    private BigDecimal transactionAmt;
    private String refundCurrency;
    private BigDecimal refundAmt;
    private Integer commissionPayable;
    private BigDecimal gst;
    private BigDecimal netRefundAmount;
    private String gatewayName;
    private String gatewayTraceNumber;
    private String payMode;
    private String refundType;
    private String refundBookingDate;
    private String arrnNum;

}
