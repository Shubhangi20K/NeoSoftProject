package com.epay.reporting.validator;

import com.epay.reporting.dao.ReportManagementDao;
import com.epay.reporting.dto.ErrorDto;
import com.epay.reporting.exception.ValidationException;
import com.epay.reporting.model.request.DownloadRequest;
import com.epay.reporting.model.request.ReportManagementRequest;
import com.epay.reporting.util.ErrorConstants;
import com.epay.reporting.util.enums.Report;
import com.epay.reporting.util.enums.ReportFormat;
import com.epay.reporting.util.enums.ReportStatus;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import static com.epay.reporting.util.DateTimeUtils.*;
import static com.epay.reporting.util.DateTimeUtils.getNextDayStartInMillis;

import static com.epay.reporting.util.ErrorConstants.*;
import static com.epay.reporting.util.ErrorConstants.MID;
import static com.epay.reporting.util.ReportingConstant.*;

/**
 * Class Name: ReportManagementValidator
 * *
 * Description: This class is responsible for validating all report-related download requests, ensuring that the provided
 * report details, such as report type, format, date range, and merchant ID (MId), are valid. It also validates if the
 * requested reports exist and are accessible for download.
 * *
 * Author: Bhoopendra Rajput
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Component
@RequiredArgsConstructor
public class ReportManagementValidator extends BaseValidator {
    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());

    private final MIdValidator mIdValidator;
    private final ReportManagementDao reportManagementDao;

    /**
     * Validates a report management request by checking mandatory fields and their values.
     * Also validates the MId by checking if it's active.
     *
     * @param reportManagementRequest The request object containing the report details.
     * @throws ValidationException if any validation fails.
     */
    public void validateRequest(ReportManagementRequest reportManagementRequest) {
        logger.debug("Request Validation start for {}", reportManagementRequest);
        errorDtoList = new ArrayList<>();
        validationMandatory(reportManagementRequest);
        validateFieldValue(reportManagementRequest);
        mIdValidator.validateActiveMId(reportManagementRequest.getMId());
        logger.debug("Request Validation end for {}", reportManagementRequest);
    }
    /**
     * Validates a search request for report management by checking the mandatory MId and validating the MId's access.
     *
     * @param reportManagementRequest The request object containing the search details.
     * @throws ValidationException if any validation fails.
     */
    public void validateSearchRequest(ReportManagementRequest reportManagementRequest) {
        logger.debug("SearchRequest Validation start for {}", reportManagementRequest);
        errorDtoList = new ArrayList<>();
        validateMandatoryFields(reportManagementRequest);
        logger.debug("Report Management mandatory validation completed for {}", reportManagementRequest);
        checkLeadingTrailingAndSingleSpace(reportManagementRequest);
        logger.debug("Report Management leading and trailing space validation completed for {}", reportManagementRequest);
        validateFieldsValue(reportManagementRequest);
        logger.debug("Report Management field validation completed for {}", reportManagementRequest);
        mIdValidator.validateMIdAccess(reportManagementRequest.getMId());
        logger.debug("Report Management mId validation completed for mId: {}", reportManagementRequest.getMId());
        throwIfErrors();
        logger.debug("SearchRequest Validation end for {}", reportManagementRequest);
    }

    /**
     * Checks for mandatory fields in the provided report management request.
     *
     * @param reportManagementRequest The request object containing the report details.
     * @throws ValidationException if any mandatory field is missing.
     */
    private void validationMandatory(ReportManagementRequest reportManagementRequest) {
        checkMandatoryField(reportManagementRequest.getMId(), MID);
        checkMandatoryField(reportManagementRequest.getReport(), REPORT);
        checkMandatoryDateField(reportManagementRequest.getDurationFromDate(), DURATION_FROM_DATE);
        checkMandatoryDateField(reportManagementRequest.getDurationToDate(), DURATION_TO_DATE);
        checkMandatoryField(reportManagementRequest.getFormat(), FORMAT);
        throwIfErrors();
    }

    /**
     * Validates that all mandatory fields in the request are present.
     *  @param reportManagementRequest ReportManagementRequest the request object containing user details to be validated.
     */
    private void validateMandatoryFields(ReportManagementRequest reportManagementRequest) {
        checkMandatoryField(reportManagementRequest.getMId(), MID);
        checkMandatoryField(reportManagementRequest.getDurationFromDate(), DURATION_FROM_DATE);
        checkMandatoryField(reportManagementRequest.getDurationToDate(), DURATION_TO_DATE);
        throwIfErrors();
    }

    /**
     * Validates that all fields in the checkLeadingTrailingAndSingleSpace do not have leading, trailing, or multiple spaces.
     *
     * @param reportManagementRequest ReportManagementRequest
     */
    private void checkLeadingTrailingAndSingleSpace(ReportManagementRequest reportManagementRequest) {
        checkForLeadingTrailingAndSingleSpace(reportManagementRequest.getMId(), MID);
        checkForLeadingTrailingAndSingleSpace(reportManagementRequest.getReport(), REPORT);
        checkForLeadingTrailingAndSingleSpace(reportManagementRequest.getFormat(), FORMAT);
        throwIfErrors();
    }

    /**
     * Validates the values of fields in the request object.
     * @param reportManagementRequest ReportManagementRequest the request object containing user details to be validated.
     */
    private void validateFieldsValue(ReportManagementRequest reportManagementRequest) {
        validateFieldLength(reportManagementRequest.getFormat(), FORMAT_LENGTH, FORMAT);
        validateFixedFieldLength(String.valueOf(reportManagementRequest.getDurationFromDate()), MILLIS_LENGTH, DURATION_FROM_DATE);
        validateFixedFieldLength(String.valueOf(reportManagementRequest.getDurationToDate()), MILLIS_LENGTH, DURATION_TO_DATE);
        throwIfErrors();
        validateDate(reportManagementRequest);
        validateFieldValue(reportManagementRequest.getFormat(), Stream.of(ReportFormat.values()).map(Enum::name).toList(), FORMAT);
        validateFieldValue(reportManagementRequest.getReport(), Stream.of(Report.values()).map(Enum::name).toList(), REPORT);
        throwIfErrors();
    }
    /**
     * Validates the values of report type and format in the provided report management request.
     *
     * @param reportManagementRequest The request object containing the report details.
     * @throws ValidationException if the report or format value is invalid.
     */
    private void validateFieldValue(ReportManagementRequest reportManagementRequest) {
        mIdValidator.validateMIdValue(reportManagementRequest.getMId());
        validateLeadingTrailingSpace(reportManagementRequest);
        validateDate(reportManagementRequest);
        validateFieldsLength(reportManagementRequest);
        validateFieldValue(reportManagementRequest.getReport(), List.of(Report.ORDER.name(), Report.REFUNDS.name(), Report.TRANSACTION.name(), Report.SETTLEMENTS.name(), Report.CHARGEBACK.name()), REPORT);
        validateFieldValue(reportManagementRequest.getFormat(), List.of(ReportFormat.CSV.name(), ReportFormat.XLSX.name()), FORMAT);
        throwIfErrors();
    }

    /**
     * Validates a download request by checking the mandatory fields and ensuring the report exists in the system.
     *
     * @param mId The Merchant ID.
     * @param downloadRequest The download request object.
     * @throws ValidationException if any validation fails.
     */
    public void validateDownloadRequest(String mId, DownloadRequest downloadRequest) {
        logger.debug("Download Request Validation start for {}", downloadRequest);
        errorDtoList = new ArrayList<>();
        validationMandatory(mId, downloadRequest);
        checkLeadingTrailingAndSingleSpace(mId, downloadRequest);
        validateFieldsValue(mId, downloadRequest);
        mIdValidator.validateMIdAccess(mId);
        isReportExist(mId, downloadRequest);
    }

    /**
     * Checks for mandatory fields in the download request.
     *
     * @param mId The Merchant ID.
     * @param downloadRequest The download request object.
     * @throws ValidationException if any mandatory field is missing.
     */
    private void validationMandatory(String mId, DownloadRequest downloadRequest) {
        checkMandatoryField(mId, MID);
        checkMandatoryField(downloadRequest.getFilePath(), FILE_PATH);
        throwIfErrors();
    }

    /**
     * Validates that all fields in the checkLeadingTrailingAndSingleSpace do not have leading, trailing, or multiple spaces.
     *
     * @param mId String
     */
    private void checkLeadingTrailingAndSingleSpace( String mId, DownloadRequest downloadRequest) {
        checkForLeadingTrailingAndSingleSpace(mId, MID);
        checkForLeadingTrailingAndSingleSpace(downloadRequest.getFilePath(), FILE_PATH);
        throwIfErrors();
    }


    /**
     * Method name : validateFieldsValue
     * Description : Validates fields values
     * @param mId String
     */
    private void validateFieldsValue(String mId, DownloadRequest downloadRequest) {
        validateFieldLength(mId, MID_LENGTH, MID);
        validateFieldLength(downloadRequest.getFilePath(), MAX_FILE_PATH_LENGTH, FILE_PATH);
        validateFieldWithRegex(mId, ALLOWED_DIGIT_REGEX, MID, INCORRECT_FORMAT);
        throwIfErrors();
    }

    /**
     * Validates if the requested report exists by checking the MId, file path, and report status.
     *
     * @param mId The Merchant ID.
     * @param downloadRequest The download request object.
     * @throws ValidationException if the report does not exist or is not available for download.
     */
    private void isReportExist(String mId, DownloadRequest downloadRequest) {
        if(!reportManagementDao.isReportExistsByMIdAndFilePathAndStatus(mId, downloadRequest.getFilePath(), ReportStatus.GENERATED)) {
            errorDtoList.add(ErrorDto.builder().errorCode(ErrorConstants.REPORT_NOT_AVAILABLE_CODE).errorMessage(ErrorConstants.REPORT_NOT_AVAILABLE_MESSAGE).build());
        }
        throwIfErrors();
    }

    /**
     * validates fromDate and toDate
     * @param reportManagementRequest ReportManagementRequest
     */
    private void validateDate(ReportManagementRequest reportManagementRequest) {
        // validating is durationFromDate is not greater than currentDate
        if (reportManagementRequest.getDurationFromDate() > getNextDayStartInMillis()) {
            errorDtoList.add(ErrorDto.builder().errorCode(INVALID_ERROR_CODE).errorMessage(MessageFormat.format(INVALID_ERROR_MESSAGE, DURATION_FROM_DATE, FUTURE_DATE_ERROR)).build());
        }

        // validating is durationToDate is not greater than currentDate
        if (reportManagementRequest.getDurationToDate() > getNextDayStartInMillis()) {
            errorDtoList.add(ErrorDto.builder().errorCode(INVALID_ERROR_CODE).errorMessage(MessageFormat.format(INVALID_ERROR_MESSAGE, DURATION_TO_DATE, FUTURE_DATE_ERROR)).build());
            throwIfErrors();
        }

        throwIfErrors();

        // validating is durationFromDate is not past 12 months from currentDate
        if (calculateDaysBetween(endOfDayMillis(), reportManagementRequest.getDurationFromDate()) > ALLOWED_FROM_DATE_DIFF) {
            addError(FROM_DATE, INVALID_ERROR_CODE, MessageFormat.format(INVALID_ERROR_MESSAGE, FROM_DATE, PAST_DATE_12M_ERROR));
            throwIfErrors();
        }

        // validating is durationFromDate is not greater than durationToDate
        if (reportManagementRequest.getDurationFromDate() > reportManagementRequest.getDurationToDate()) {
            errorDtoList.add(ErrorDto.builder().errorCode(INVALID_ERROR_CODE).errorMessage(MessageFormat.format(INVALID_ERROR_MESSAGE, DURATION_FROM_DATE, FROM_TO_DATE_ERROR)).build());
            throwIfErrors();
        }

        //From-To date difference more than 1 month
        if (calculateDaysBetween(reportManagementRequest.getDurationFromDate(), reportManagementRequest.getDurationToDate()) > ALLOWED_FROM_TO_DATE_DIFF) {
            addError(FROM_DATE, INVALID_ERROR_CODE, MessageFormat.format(INVALID_ERROR_MESSAGE, FROM_DATE, DATE_DIFF_1M_ERROR));
            throwIfErrors();
        }
    }

    /**
     * validates length of fields
     * @param reportManagementRequest ReportManagementRequest
     */
    private void validateFieldsLength(ReportManagementRequest reportManagementRequest) {
        validateFieldLength(reportManagementRequest.getFormat(), FORMAT_LENGTH, FORMAT);
        validateFixedFieldLength(String.valueOf(reportManagementRequest.getDurationFromDate()), MILLIS_LENGTH, DURATION_FROM_DATE);
        validateFixedFieldLength(String.valueOf(reportManagementRequest.getDurationToDate()), MILLIS_LENGTH, DURATION_TO_DATE);
        throwIfErrors();
    }

    /**
     * validates leading and trailing space
     * @param reportManagementRequest ReportManagementRequest
     */
    private void validateLeadingTrailingSpace(ReportManagementRequest reportManagementRequest) {
        checkForLeadingTrailingAndSingleSpace(reportManagementRequest.getFormat(), FORMAT);
        throwIfErrors();
        checkForLeadingTrailingAndSingleSpace(reportManagementRequest.getReport(), REPORT);
        throwIfErrors();
    }
}