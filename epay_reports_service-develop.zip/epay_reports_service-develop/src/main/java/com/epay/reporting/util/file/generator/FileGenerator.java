package com.epay.reporting.util.file.generator;

import com.epay.reporting.dto.ReportFile;
import com.epay.reporting.dto.TxtFileModel;
import com.epay.reporting.util.enums.Report;
import com.epay.reporting.util.enums.ReportFormat;
import com.epay.reporting.util.file.model.CSVFileModel;
import com.epay.reporting.util.file.model.ExcelFileModel;
import com.epay.reporting.util.file.model.FileModel;
import com.epay.reporting.util.file.model.PdfFileModel;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Class Name: FileGenerator
 * *
 * Description: The FileGenerator class is responsible for generating files in different formats (CSV, XLS, PDF)
 * based on the provided report and data. It can either generate the file for local saving
 * or initiate a download for the user via HTTP response.
 * *
 * Author: Bhoopendra Rajput
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Component
@RequiredArgsConstructor
public class FileGenerator {
    private static final LoggerUtility logger = LoggerFactoryUtility.getLogger(FileGenerator.class);


    private final PdfGenerator pdfGenerator;
    private final TxtGenerator txtGenerator;

    /**
     * This method handles the downloading of files based on the requested format.
     * Depending on the requested format (CSV, XLS, PDF), it invokes the respective generator
     * to create the file and send it as a response to the client.
     *
     * @param response The HTTP response object used to send the file to the client.
     * @param reportFormat The format of the report (CSV, XLS, or PDF).
     * @param report The report details containing the report name and template name.
     * @param mId The unique identifier for the report.
     * @param fileModel The file model containing the report data.
     */
    public void downloadFile(HttpServletResponse response, ReportFormat reportFormat, Report report, String mId, FileModel fileModel) {
        logger.info("Download requested for report format: {}, report: {}, mId: {}", reportFormat, report.getName(), mId);
        switch (reportFormat) {
            case CSV -> {
                CSVFileModel csvFileModel = (CSVFileModel) fileModel;
                CSVGenerator.downloadCsvFile(response, report.getName(), mId, csvFileModel.getHeaders(), csvFileModel.getFileData());
                logger.debug("CSV file generation complete for report: {}", report.getName());
            }
            case XLSX -> {
                ExcelFileModel xlsFileModel = (ExcelFileModel) fileModel;
                ExcelGenerator.downloadExcelFile(response, report.getName(), mId, xlsFileModel.getHeaders(), xlsFileModel.getFileData());
                logger.debug("Excel file generation complete for report: {}", report.getName());
            }
            case PDF -> {
                PdfFileModel pdfFileModel = (PdfFileModel) fileModel;
                pdfGenerator.downloadPdfFile(response, report.getName(), mId, report.getTemplateName(), pdfFileModel.getFileData());
                logger.debug("PDF file generation complete for report: {}", report.getName());
            }
            default -> {
                logger.error("Unsupported report format: {}", reportFormat);
                throw new IllegalArgumentException("Requested File Formatter not supported");
            }
        }
    }


    /**
     * This method generates a file in the requested format and returns it as a File object.
     * The file is generated based on the provided report data.
     *
     * @param reportFormat The format of the report (CSV, XLS, or PDF).
     * @param report The report details containing the report name and template name.
     * @param mId The unique identifier for the report.
     * @param fileModel The file model containing the report data.
     * @return A File object representing the generated report.
     */
    public ReportFile generateFile(ReportFormat reportFormat, Report report, String mId, FileModel fileModel) {
        logger.info("Generating file for report format: {}, report: {}, mId: {}", reportFormat, report.getName(), mId);
        switch (reportFormat) {
            case CSV -> {
                CSVFileModel csvFileModel = (CSVFileModel) fileModel;
                return CSVGenerator.csvFileGenerator(report.getName(), mId, csvFileModel.getHeaders(), csvFileModel.getFileData());
            }
            case XLSX -> {
                ExcelFileModel xlsFileModel = (ExcelFileModel) fileModel;
                return ExcelGenerator.excelFileGenerator(report.getName(), mId, xlsFileModel.getHeaders(), xlsFileModel.getFileData());
            }
            case PDF -> {
                PdfFileModel pdfFileModel = (PdfFileModel) fileModel;
                return pdfGenerator.pdfFileGenerator(report.getName(), mId, report.getTemplateName(), pdfFileModel.getFileData());
            }
            default -> {
                logger.error("Unsupported report format: {}", reportFormat);
                throw new IllegalArgumentException("Requested File Formatter not supported");
            }
        }
    }

    /**
     * This method generates a file in the requested format and returns it as a File object.
     * The file is generated based on the provided report data.
     *
     * @param reportFormat The format of the report (CSV, XLS, or PDF).
     * @param report The report details containing the report name and template name.

     * @param fileModel The file model containing the report data.
     * @return A File object representing the generated report.
     */
    public ReportFile generateFile(ReportFormat reportFormat, Report report, FileModel fileModel,UUID rfId) {
        logger.info("Generating file for report format: {}, report: {}, mId: {}", reportFormat, report.getName());
        CSVFileModel csvFileModel = (CSVFileModel) fileModel;
        return CSVGenerator.csvFileGenerator(report.getName(), csvFileModel.getHeaders(), csvFileModel.getFileData(),rfId);
    }

    public ReportFile generateFile(Report report, TxtFileModel txtFileModel){
        logger.info("Generating file for report format: TXT, report: {}", report.getName());
        return txtGenerator.txtFileGenerator(report,txtFileModel);
    }


    /**
     * This method builds the appropriate file model based on the requested report format
     * and the provided data (headers, fileData, pdfFileData).
     *
     * @param reportFormat The format of the report (CSV, XLS, or PDF).
     * @param header The headers for the report (used in CSV and Excel formats).
     * @param fileData The data for the report (used in CSV and Excel formats).
     * @param pdfFileData The data for the PDF report (used in PDF format).
     * @return A FileModel representing the data to be used for generating the report.
     */
    public FileModel buildFileModel(ReportFormat reportFormat, List<String> header, List<List<Object>> fileData, Map<String, Object> pdfFileData) {
        logger.info("Building file model for report format: {}", reportFormat);
        return switch (reportFormat) {
            case CSV -> CSVFileModel.builder().headers(header).fileData(fileData).build();
            case XLSX -> ExcelFileModel.builder().headers(header).fileData(fileData).build();
            case PDF -> PdfFileModel.builder().fileData(pdfFileData).build();
            case TXT -> null;
            case null -> CSVFileModel.builder().headers(header).fileData(fileData).build();
        };
    }

}
