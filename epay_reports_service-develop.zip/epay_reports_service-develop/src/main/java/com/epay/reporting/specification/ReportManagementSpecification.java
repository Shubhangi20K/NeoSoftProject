package com.epay.reporting.specification;

import com.epay.reporting.entity.ReportManagement;
import com.epay.reporting.model.request.ReportManagementRequest;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.util.StringUtils;

import java.util.UUID;

/**
 * Class Name: ReportManagementSpecification
 * *
 * Description: This class is responsible for constructing dynamic query predicates for filtering the `ReportManagement`
 * entities based on various fields such as report ID, MId, format, and date ranges. The filters are applied
 * through a Specification for use in a JPA query.
 * *
 * Author: Bhoopendra Rajput
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
public class ReportManagementSpecification {
    private static final LoggerUtility logger = LoggerFactoryUtility.getLogger(ReportManagementSpecification.class);

    /**
     * Creates a dynamic Specification for querying `ReportManagement` based on the provided `ReportManagementRequest`
     * and `reportId`. It constructs predicates for filtering entities by report ID, MId, format, and date ranges.
     *
     * @param reportId The ID of the report to filter by.
     * @param reportManagementRequest The request containing filter parameters.
     * @return A Specification for querying `ReportManagement` entities.
     */
    public static Specification<ReportManagement> searchReportManagement(UUID reportId, ReportManagementRequest reportManagementRequest) {
        return (root, query, criteriaBuilder) -> {
            logger.debug("Building query predicates for report ID: {} and request: {}", reportId, reportManagementRequest);

            Predicate predicate = criteriaBuilder.conjunction();

            // Apply filters based on the fields present in the request
            if (ObjectUtils.isNotEmpty(reportManagementRequest.getReport())) {
                predicate = criteriaBuilder.and(predicate, getReportIdPredicate(root, criteriaBuilder, reportId));
            }

            if (StringUtils.hasText(reportManagementRequest.getMId())) {
                predicate = criteriaBuilder.and(predicate, getMIdPredicate(root, criteriaBuilder, reportManagementRequest.getMId()));
            }

            if (ObjectUtils.isNotEmpty(reportManagementRequest.getFormat())) {
                predicate = criteriaBuilder.and(predicate, getFormatPredicate(root, criteriaBuilder,reportManagementRequest.getFormat()));
            }

            if (reportManagementRequest.getDurationFromDate() != null) {
                predicate = criteriaBuilder.and(predicate, getDurationFromDatePredicate(root, criteriaBuilder, reportManagementRequest.getDurationFromDate()));
            }

            if (reportManagementRequest.getDurationToDate() != null) {
                predicate = criteriaBuilder.and(predicate, getDurationToDatePredicate(root, criteriaBuilder, reportManagementRequest.getDurationToDate()));
            }

            logger.debug("Final query predicate: {}", predicate);
            return predicate;
        };
    }

    /**
     * Creates a predicate for filtering by report ID.
     *
     * @param root The root entity in the criteria query.
     * @param criteriaBuilder The criteria builder for creating the predicate.
     * @param reportId The report ID to filter by.
     * @return A predicate for filtering by report ID.
     */
    private static Predicate getReportIdPredicate(Root<ReportManagement> root, CriteriaBuilder criteriaBuilder, UUID reportId) {
        logger.debug("Creating predicate for reportId: {}", reportId);
        return criteriaBuilder.equal(root.get("reportId"), reportId);
    }

    /**
     * Creates a predicate for filtering by MId (Merchant ID).
     *
     * @param root The root entity in the criteria query.
     * @param criteriaBuilder The criteria builder for creating the predicate.
     * @param mId The merchant ID to filter by.
     * @return A predicate for filtering by MId.
     */
    private static Predicate getMIdPredicate(Root<ReportManagement> root, CriteriaBuilder criteriaBuilder, String mId) {
        logger.debug("Creating predicate for MId: {}", mId);
        return criteriaBuilder.equal(root.get("mId"), mId);
    }

    /**
     * Creates a predicate for filtering by report format.
     *
     * @param root The root entity in the criteria query.
     * @param criteriaBuilder The criteria builder for creating the predicate.
     * @param reportFormat The format of the report to filter by.
     * @return A predicate for filtering by report format.
     */
    private static Predicate getFormatPredicate(Root<ReportManagement> root, CriteriaBuilder criteriaBuilder, String reportFormat ) {
        logger.debug("Creating predicate for format: {}", reportFormat);
        return criteriaBuilder.equal(root.get("format"), reportFormat.toUpperCase());
    }

    /**
     * Creates a predicate for filtering by duration from date (greater than or equal to).
     *
     * @param root The root entity in the criteria query.
     * @param criteriaBuilder The criteria builder for creating the predicate.
     * @param durationFromDate The from date to filter by.
     * @return A predicate for filtering by duration from date.
     */
    private static Predicate getDurationFromDatePredicate(Root<ReportManagement> root, CriteriaBuilder criteriaBuilder, Long durationFromDate) {
        logger.debug("Creating predicate for durationFromDate: {}", durationFromDate);
        return criteriaBuilder.greaterThanOrEqualTo(root.get("durationFromDate"), durationFromDate);
    }

    /**
     * Creates a predicate for filtering by duration to date (less than or equal to).
     *
     * @param root The root entity in the criteria query.
     * @param criteriaBuilder The criteria builder for creating the predicate.
     * @param durationToDate The to date to filter by.
     * @return A predicate for filtering by duration to date.
     */
    private static Predicate getDurationToDatePredicate(Root<ReportManagement> root, CriteriaBuilder criteriaBuilder, Long durationToDate) {
        logger.debug("Creating predicate for durationToDate: {}", durationToDate);
        return criteriaBuilder.lessThanOrEqualTo(root.get("durationToDate"), durationToDate);
    }

}
