package com.epay.reporting.util.file.invoice;

import com.epay.reporting.entity.view.MerchantFeesReport;
import com.epay.reporting.util.DateTimeUtils;
import com.epay.reporting.util.ReportUtils;
import com.epay.reporting.util.enums.Report;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.text.MessageFormat;
import java.time.YearMonth;
import java.util.*;

import static com.epay.reporting.util.DateTimeUtils.FORMATTER_MMM_YYYY;
import static com.epay.reporting.util.DateTimeUtils.FORMATTER_MONTH_YEAR;
import static com.epay.reporting.util.NumberToWordsConverter.convert;
import static com.epay.reporting.util.ReportingConstant.REPORT_INVOICE_NO;

/**
 * Class Name: FeesInvoiceDataGenerator
 *
 * Description: This class generates the necessary data for fees invoice reports. It processes a list of
 * MerchantFeesReport objects to organize and compute relevant information for generating PDF templates.
 *
 * Author: Bhoopendra Rajput
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved.
 * *
 * Version: 1.0
 */
public class FeesInvoiceDataGenerator {
    private static final LoggerUtility log = LoggerFactoryUtility.getLogger(FeesInvoiceDataGenerator.class);

    /**
     * Converts a list of merchant fees data to a map where the key is the transaction date and the value
     * is a list of MerchantFeesReport objects for that date.
     *
     * @param merchantFeesData the list of MerchantFeesReport objects to be processed
     * @return a Map where the key is the transaction date and the value is a list of MerchantFeesReport
     */
    public static Map<String, List<MerchantFeesReport>> convertInvoiceFeeMonthWise(List<MerchantFeesReport> merchantFeesData) {
        log.debug("Converting merchant fees data into month-wise groups.");
        Map<String, List<MerchantFeesReport>> feesDataMonthBy = new HashMap<>();
        merchantFeesData.forEach(merchantFeesReport -> {
            if (feesDataMonthBy.containsKey(merchantFeesReport.getTransactionDate())) {
                feesDataMonthBy.get(merchantFeesReport.getTransactionDate()).add(merchantFeesReport);
            } else {
                List<MerchantFeesReport> merchantFeesReports = new ArrayList<>();
                merchantFeesReports.add(merchantFeesReport);
                feesDataMonthBy.put(merchantFeesReport.getTransactionDate(), merchantFeesReports);
            }
        });
        log.debug("Conversion completed. Grouped by {} months.", feesDataMonthBy.size());
        return feesDataMonthBy;
    }
    /**
     * Creates the input map for the PDF template using the report and merchant fees data.
     *
     * @param report the report type (used to fetch the report name)
     * @param reportDate the date of the report
     * @param merchantFeesReports the list of merchant fees reports to be processed
     * @return a Map containing all the necessary data for the PDF template
     */
    public static Map<String, Object>  createPdfTemplateInput(Report report, String reportDate, List<MerchantFeesReport> merchantFeesReports) {
        log.info("Creating PDF template input for report: {} on date: {}", report.getName(), reportDate);
        Map<String, Object> input = new HashMap<>();
        MerchantFeesReport merchantFeesReport = merchantFeesReports.getFirst();
        YearMonth yearMonth = YearMonth.parse(reportDate, FORMATTER_MMM_YYYY);
        CommissionTaxAmount result = getCommissionTaxAmount(merchantFeesReports);

        input.put("reportName", MessageFormat.format(REPORT_INVOICE_NO, yearMonth.format(FORMATTER_MONTH_YEAR), yearMonth.getYear() - 2000, 10 + yearMonth.getMonthValue()));
        input.put("report", reportDate);
        input.put("date", DateTimeUtils.getDate(DateTimeUtils.getCurrentTimeInMills(), DateTimeUtils.FORMATTER_DD_MM_YYYY));
        input.put("merchantName", StringUtils.isEmpty(merchantFeesReport.getMerchantName()) ? StringUtils.EMPTY : merchantFeesReport.getMerchantName());
        input.put("gstNo", StringUtils.isEmpty(merchantFeesReport.getGstNumber()) ? StringUtils.EMPTY : merchantFeesReport.getGstNumber());
        input.put("address", buildMerchantAddress(merchantFeesReport));
        input.put("invoiceNum", ReportUtils.getInvoiceNumber());
        input.put("hsnSacNum", ReportUtils.getHSNSacNumber());
        input.put("merchantFeesList", merchantFeesReports);
        input.put("totalMerchantServiceTaxAmount", result.totalServiceTaxAmount());
        input.put("totalMerchantTotalCommission", result.totalCommissionAmount());
        input.put("totalMerchantTotalCommissionInWords", convert(result.totalCommissionAmount()));

        log.info("PDF template input created successfully.");
        return input;
    }

    /**
     * Aggregates the commission and tax amounts from the list of MerchantFeesReport objects.
     *
     * @param merchantFeesReports the list of merchant fees reports
     * @return a CommissionTaxAmount object containing the total service tax and commission amounts
     */

    private static CommissionTaxAmount getCommissionTaxAmount(List<MerchantFeesReport> merchantFeesReports) {
        log.debug("Calculating total service tax and commission amounts.");
        // Aggregate totals for service tax and total commission
        BigDecimal totalServiceTaxAmount = BigDecimal.ZERO;
        BigDecimal totalCommissionAmount = BigDecimal.ZERO;
        for (MerchantFeesReport report : merchantFeesReports) {
            totalServiceTaxAmount = totalServiceTaxAmount.add(report.getMerchantServiceTaxAmount());
            totalCommissionAmount = totalCommissionAmount.add(report.getMerchantTotalCommission());
        }
        log.debug("Total service tax: {}, total commission: {}", totalServiceTaxAmount, totalCommissionAmount);
        return new CommissionTaxAmount(totalServiceTaxAmount, totalCommissionAmount);
    }
    /**
     * Builds the complete address of the merchant by concatenating its address fields.
     *
     * @param report the MerchantFeesReport object containing address details
     * @return a string containing the full address of the merchant
     */
    private static String buildMerchantAddress(MerchantFeesReport report) {
        log.debug("Building merchant address.");
        String address1 = StringUtils.isEmpty(report.getAddress1()) ? StringUtils.EMPTY : report.getAddress1();
        String address2 = StringUtils.isEmpty(report.getAddress2()) ? StringUtils.EMPTY : report.getAddress2();
        String city = StringUtils.isEmpty(report.getCity()) ? StringUtils.EMPTY : report.getCity();
        String state = StringUtils.isEmpty(report.getState()) ? StringUtils.EMPTY : report.getState();
        String pincode = StringUtils.isEmpty(report.getPincode()) ? StringUtils.EMPTY : report.getPincode();

        String address = String.join(" ", address1, address2, city, state, pincode).trim();
        log.debug("Merchant address built: {}", address);
        return String.join(" ", address1, address2, city, state, pincode).trim();
    }

    private record CommissionTaxAmount(BigDecimal totalServiceTaxAmount, BigDecimal totalCommissionAmount) {
    }
}
