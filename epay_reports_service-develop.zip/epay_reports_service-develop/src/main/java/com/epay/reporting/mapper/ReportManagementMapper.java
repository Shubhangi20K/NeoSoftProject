package com.epay.reporting.mapper;

import com.epay.reporting.dto.ReportManagementDto;
import com.epay.reporting.entity.ReportManagement;
import com.epay.reporting.model.request.ReportManagementRequest;
import com.epay.reporting.model.response.ReportManagementResponse;
import com.epay.reporting.util.enums.Report;
import com.epay.reporting.util.enums.ReportFormat;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import java.util.List;

/**
 * Class Name: ReportMasterMapper
 * *
 * Description:This interface provides the mapping logic for converting between different data transfer objects (DTOs),
 * requests, responses, and entities related to the Report Management module. It uses MapStruct annotations
 * to automatically generate implementation classes for the mapping functions.
 * The interface includes custom mappings for report and format fields, which are converted from String values to
 * specific enum types (Report and ReportFormat). It also maps timestamps and other attributes between entities and DTOs.
 * Author: V1018344
 * Copyright (c) 2025 [State Bank of India]
 * ALl rights reserved
 * *
 * Version: 1.0
 */

@Mapper(builder = @Builder(disableBuilder = true), componentModel = "spring")
public interface ReportManagementMapper {

    /**
     * Maps the ReportManagement entity to its corresponding DTO (Data Transfer Object).
     *
     * @param reportManagement the entity to be converted
     * @return the corresponding ReportManagementDto
     */
    ReportManagementDto mapEntityToDto(ReportManagement reportManagement);

    List<ReportManagementDto> mapEntityToDto(List<ReportManagement> reportManagements);

    /**
     * Maps the ReportManagementRequest to a ReportManagementDto with custom mappings for report and format.
     *
     * @param reportManagementRequest the request object containing report and format information
     * @return the mapped ReportManagementDto
     */
    @Mapping(source="report", target = "report", qualifiedByName = "customStringToReport")
    @Mapping(source="format", target = "format", qualifiedByName = "customStringToReportFormat")
    ReportManagementDto mapRequestToDto(ReportManagementRequest reportManagementRequest);

    /**
     * Maps a ReportManagementDto to a ReportManagementResponse object.
     *
     * @param reportManagementDto the DTO to be mapped
     * @return the mapped ReportManagementResponse
     */
    @Mapping(source = "createdAt", target = "requestStateTime")
    @Mapping(source = "updatedAt", target = "executionTime")
    ReportManagementResponse mapDtoToResponse(ReportManagementDto reportManagementDto);

    /**
     * Maps a list of ReportManagementDto objects to a list of ReportManagementResponse objects.
     *
     * @param reportManagementDtos the list of ReportManagementDto objects to be mapped
     * @return the list of mapped ReportManagementResponse objects
     */
    List<ReportManagementResponse> mapDtoListToResponseList(List<ReportManagementDto> reportManagementDtos);

    /**
     * Maps a ReportManagementDto to a ReportManagement entity.
     *
     * @param reportManagementDto the DTO to be mapped
     * @return the mapped ReportManagement entity
     */
    ReportManagement mapDtoToEntity(ReportManagementDto reportManagementDto);

    /**
     * Custom method to convert a report name (String) to the corresponding Report enum.
     *
     * @param reportName the name of the report
     * @return the corresponding Report enum
     */
    @Named("customStringToReport")
    default Report customStringToReport(String reportName) {
        return Report.getName(reportName);
    }

    /**
     * Custom method to convert a format name (String) to the corresponding ReportFormat enum.
     *
     * @param formatName the name of the format
     * @return the corresponding ReportFormat enum
     */
    @Named("customStringToReportFormat")
    default ReportFormat customStringToReportFormat(String formatName) {
        return ReportFormat.getName(formatName);
    }
}
