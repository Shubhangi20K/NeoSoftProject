package com.epay.reporting.repository;

import com.epay.reporting.entity.ReportMaster;
import com.epay.reporting.util.enums.Report;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;
import java.util.UUID;

/**
 * Class Name: ReportMasterRepository
 * *
 * Description:This interface extends `JpaRepository` and defines a method for interacting with the `ReportMaster` entity.
 * It includes a custom query to find a report by its name, which is represented by the `Report` enum.
 * *
 * Author: V1018344
 * Copyright (c) 2025 [State Bank of India]
 * ALl rights reserved
 * *
 * Version: 1.0
 */
public interface ReportMasterRepository extends JpaRepository<ReportMaster, UUID> {

    /**
     * Finds a ReportMaster entity by its name.
     *
     * @param name the name of the report represented as an enum value of `Report`
     * @return an Optional containing the ReportMaster entity if found, otherwise empty
     */
    Optional<ReportMaster> findByName(Report name);

}
