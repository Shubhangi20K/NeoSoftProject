package com.epay.reporting.util.enums;

import com.epay.reporting.exception.ReportingException;
import com.epay.reporting.util.ErrorConstants;
import lombok.Getter;
import lombok.RequiredArgsConstructor;

import java.text.MessageFormat;
import java.util.Arrays;

/**
 * Name: ReportScheduledStatus
 * Description: Represents the various statuses that a scheduled report can have (e.g., to be started, in queue, cancelled).
 * *
 * Author: Bhoopendra Rajput
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Getter
@RequiredArgsConstructor
public enum ReportScheduledStatus {
    TO_BE_START("TO BE STARTED"), IN_QUEUE("IN QUEUE"), CANCELLED("CANCELLED");
    private final String name;
    public static ReportScheduledStatus getName(String name) {
        return Arrays.stream(values()).filter(rt -> rt.name().equalsIgnoreCase(name)).findFirst().orElseThrow(() -> new ReportingException(ErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(ErrorConstants.INVALID_ERROR_MESSAGE, "ReportScheduledStatus", "Valid ReportScheduledStatus are " + Arrays.toString(ReportScheduledStatus.values()))));
    }
}
