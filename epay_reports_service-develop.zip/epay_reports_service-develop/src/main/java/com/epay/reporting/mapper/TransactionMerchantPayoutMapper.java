package com.epay.reporting.mapper;

import com.epay.reporting.entity.view.TransactionWisePayoutFormat;
import org.apache.commons.lang3.StringUtils;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;

import java.math.BigDecimal;
import java.util.List;

import static org.thymeleaf.util.ObjectUtils.nullSafe;

@Mapper(builder = @Builder(disableBuilder = true), componentModel = "spring")
public interface TransactionMerchantPayoutMapper {
    default List<Object> mapToList(TransactionWisePayoutFormat payoutFormat){
        return List.of(
                nullSafe(payoutFormat.getSettlementFileNumber(), StringUtils.EMPTY),
                nullSafe(payoutFormat.getSettlementTime(), StringUtils.EMPTY),
                nullSafe(payoutFormat.getMId(), StringUtils.EMPTY),
                nullSafe(payoutFormat.getMerchantName(), StringUtils.EMPTY),
                nullSafe(payoutFormat.getMerchantOrderNo(), StringUtils.EMPTY),
                nullSafe(payoutFormat.getTransactionId(), StringUtils.EMPTY),
                nullSafe(payoutFormat.getTransactionBookingDate(), StringUtils.EMPTY),
                nullSafe(payoutFormat.getTransactionCurrency(), StringUtils.EMPTY),
                nullSafe(payoutFormat.getTransactionAmount(), BigDecimal.ZERO),
                nullSafe(payoutFormat.getSettlementCurrency(), StringUtils.EMPTY),
                nullSafe(payoutFormat.getSettlementAmount(), BigDecimal.ZERO),
                nullSafe(payoutFormat.getCommissionPayable(), BigDecimal.ZERO),
                nullSafe(payoutFormat.getGst(), BigDecimal.ZERO),
                nullSafe(payoutFormat.getPayoutAmount(), BigDecimal.ZERO),
                nullSafe(payoutFormat.getGatewayName(), StringUtils.EMPTY),
                nullSafe(payoutFormat.getGatewayTraceNumber(), StringUtils.EMPTY),
                nullSafe(payoutFormat.getPayMode(), StringUtils.EMPTY),
                nullSafe(payoutFormat.getPayProcId(), StringUtils.EMPTY),
                nullSafe(payoutFormat.getOtherDetails(), StringUtils.EMPTY),
                nullSafe(payoutFormat.getTransactionFeeFlag(), StringUtils.EMPTY),
                nullSafe(payoutFormat.getCin(), StringUtils.EMPTY)
        );
    }
}
