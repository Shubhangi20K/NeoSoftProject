package com.epay.reporting.etl.producer;

import com.epay.reporting.util.enums.InterfaceType;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Component;

import static com.epay.reporting.util.EventMessageUtils.buildEventErrorLog;
import static com.epay.reporting.util.EventMessageUtils.buildEventSendLog;

/**
 * Class Name: ReportGenerationProducer
 * Description: The ReportGenerationProducer class is responsible for publishing report generation requests to a Kafka topic.
 * It extends the ReportingProducer class and overrides the publish method to log the request details and send the message
 * to the appropriate Kafka topic using the KafkaMessagePublisher.
 * Author: Bhoopendra Rajput
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * Version: 1.0
 */
@RequiredArgsConstructor
@Component
public class ReportGenerationProducer extends ReportingProducer {
    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    private final ApplicationEventPublisher publisher;

    @Override
    public void publish(String routingKey, String message) {
        String kafkaRoutingKey = getRoutingKey(routingKey);
        try {
            log.info("Report generation publishing for key : {}", kafkaRoutingKey);
            log.debug("Report generation publishing for key : {} and value : {}", kafkaRoutingKey, message);
            kafkaMessagePublisher.publish(topics.getReportTopic(), kafkaRoutingKey, message);
            publisher.publishEvent(buildEventSendLog(InterfaceType.REPORT_TOPIC, topics.getReportTopic(), kafkaRoutingKey, message));
            log.debug("Report generation has been published");
        } catch (Exception e) {
            log.error("Error in report generation key {} publish {}", kafkaRoutingKey, e.getMessage());
            publisher.publishEvent(buildEventErrorLog(InterfaceType.REPORT_TOPIC, topics.getReportTopic(), kafkaRoutingKey, e.getMessage()));
        }
    }
}
