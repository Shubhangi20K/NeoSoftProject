package com.epay.reporting.entity.view;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class GstReport {
    private String transactionNumber;
    private double gstCharged;
    private String transactionDate;
    private String transactionMonth;
}
