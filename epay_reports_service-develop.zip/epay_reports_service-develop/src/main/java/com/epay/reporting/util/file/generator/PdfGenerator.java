package com.epay.reporting.util.file.generator;

import com.epay.reporting.dto.ReportFile;
import com.epay.reporting.exception.ReportingException;
import com.epay.reporting.util.ErrorConstants;
import com.epay.reporting.util.ReportingConstant;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.apache.commons.text.StringEscapeUtils;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;
import org.xhtmlrenderer.pdf.ITextRenderer;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.MessageFormat;
import java.util.Map;

import static com.epay.reporting.util.ReportUtils.setHeader;

/**
 * Class Name: PdfGenerator
 * *
 * Description: This class is responsible for generating and serving PDF files. It takes an input template
 * and data, processes it to generate PDF content, and can either return it as a file for download or as
 * a byte array for further processing. The PDF generation is handled using the ITextRenderer library.
 * *
 * Author: Bhoopendra Rajput
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved.
 * *
 * Version: 1.0
 */
@Component
@RequiredArgsConstructor
public class PdfGenerator {

    private static final String TEMPLATE_FOLDER = "pdf/";
    private static final LoggerUtility log = LoggerFactoryUtility.getLogger(PdfGenerator.class);
    private final TemplateEngine templateEngine;

    /**
     * Generate a file name for the PDF based on the report name, merchant ID, and current timestamp.
     *
     * @param reportName the name of the report
     * @param mId the merchant ID
     * @return a string representing the file path and name
     */
    private static String getFileName(String reportName, String mId) {
        log.debug("Generating file name for report: {} and merchant ID: {}", reportName, mId);
        return ReportingConstant.REPORT_ROOT_FOLDER +StringEscapeUtils.escapeJava(mId + "_" + reportName + "_" + System.currentTimeMillis() + ".pdf");
    }

    /**
     * Generates and serves a PDF file for download via HTTP response. This method uses the
     * ITextRenderer to create the PDF from a template and data.
     *
     * @param response the HttpServletResponse to write the PDF to
     * @param reportName the name of the report
     * @param mId the merchant ID
     * @param template the template file to generate the PDF from
     * @param input the data map for the template
     */
    protected void downloadPdfFile(HttpServletResponse response, String reportName, String mId, String template, Map<String, Object> input) {
        log.info("Starting PDF download for report: {} and merchant ID: {}", reportName, mId);
        // Set the response headers for a downloadable file
        setHeader(response, MediaType.APPLICATION_PDF_VALUE, getFileName(reportName, mId));

        // Write the PDF content to the response output stream
        try (ServletOutputStream outputStream = response.getOutputStream()) {
            log.debug("Rendering PDF content for template: {}", template);
            ITextRenderer renderer = new ITextRenderer();
            renderer.setDocumentFromString(getPdfContent(input, template));
            renderer.layout();
            renderer.createPDF(outputStream);
            log.info("PDF generated and written to response successfully.");
        } catch (Exception e) {
            log.error("An error occurred in downloadPdfFile method: {}", e.getMessage());
            throw new ReportingException(ErrorConstants.FILE_GENERATION_ERROR_CODE, MessageFormat.format(ErrorConstants.FILE_GENERATION_ERROR_MESSAGE, "pdf", e.getMessage()));
        }
    }
    /**
     * Generates a PDF file and returns it as a byte array wrapped in a ReportFile object. This method
     * is used when the PDF needs to be returned as a file object for further processing (e.g., storage).
     *
     * @param reportName the name of the report
     * @param mId the merchant ID
     * @param template the template file to generate the PDF from
     * @param input the data map for the template
     * @return a ReportFile containing the generated PDF byte array
     */
    protected ReportFile pdfFileGenerator(String reportName, String mId, String template, Map<String, Object> input) {
        log.info("Starting PDF generation for report: {} and merchant ID: {}", reportName, mId);
        String fileName = getFileName(reportName, mId);
        try (ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream()) {
            log.debug("Rendering PDF content for template: {}", template);
            ITextRenderer renderer = new ITextRenderer();
            renderer.setDocumentFromString(getPdfContent(input, template));
            renderer.layout();
            renderer.createPDF(byteArrayOutputStream);
            log.info("PDF file successfully generated and returned as byte array.");
            return ReportFile.builder().name(fileName).content(byteArrayOutputStream.toByteArray()).build();
        } catch (IOException e) {
            log.error("An error occurred in pdfFileGenerator method: {}", e.getMessage());
            throw new ReportingException(ErrorConstants.FILE_GENERATION_ERROR_CODE, MessageFormat.format(ErrorConstants.FILE_GENERATION_ERROR_MESSAGE, "pdf", e.getMessage()));
        }
    }
    /**
     * Processes the input data and template to generate the PDF content as a string.
     * This method uses the Thymeleaf template engine to render the final PDF content.
     *
     * @param input the data map for the template
     * @param template the template name
     * @return the generated PDF content as a string
     */
    private String getPdfContent(Map<String, Object> input, String template) {
        log.debug("Processing PDF content for template: {}", template);
        Context context = new Context();
        context.setVariable("map", input);
        return templateEngine.process(TEMPLATE_FOLDER + template, context);
    }
}
