package com.epay.reporting.etl.producer;

import com.epay.reporting.util.enums.InterfaceType;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Component;

import static com.epay.reporting.util.EventMessageUtils.buildEventErrorLog;
import static com.epay.reporting.util.EventMessageUtils.buildEventSendLog;

@Component
@RequiredArgsConstructor
public class OpsReportConfirmationPublisher extends ReportingProducer {
    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    private final ApplicationEventPublisher publisher;

    @Override
    public void publish(String routingKey, String message) {
        String kafkaRoutingKey = getRoutingKey(routingKey);
        try {
            log.info("Report confirmation request publishing for key : {}", kafkaRoutingKey);
            log.debug("Report confirmation request publishing for key : {} and value : {}", kafkaRoutingKey, message);
            kafkaMessagePublisher.publish(topics.getOpsReportConfirmationTopic(), kafkaRoutingKey, message);
            publisher.publishEvent(buildEventSendLog(InterfaceType.REPORT_RECON_CONFIRMATION_TOPIC, topics.getOpsReportConfirmationTopic(), kafkaRoutingKey, message));
            log.debug("Report confirmation has been published");
        } catch (Exception e) {
            log.error("Error in report confirmation {} publish {} ", kafkaRoutingKey, e.getMessage());
            publisher.publishEvent(buildEventErrorLog(InterfaceType.REPORT_RECON_CONFIRMATION_TOPIC, topics.getOpsReportConfirmationTopic(), kafkaRoutingKey, e.getMessage()));
        }
    }
}
