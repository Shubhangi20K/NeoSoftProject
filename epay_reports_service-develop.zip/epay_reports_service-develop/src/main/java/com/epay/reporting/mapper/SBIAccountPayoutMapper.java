package com.epay.reporting.mapper;

import com.epay.reporting.entity.view.SbiEpayAggBankStmtReport;
import org.apache.commons.lang3.StringUtils;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;

import java.math.BigDecimal;
import java.util.List;

import static org.thymeleaf.util.ObjectUtils.nullSafe;

@Mapper(builder = @Builder(disableBuilder = true), componentModel = "spring")
public interface SBIAccountPayoutMapper {
    default List<Object> mapToList(SbiEpayAggBankStmtReport sbiEpayAggBankStmtReport){
        return List.of(
                nullSafe(sbiEpayAggBankStmtReport.getMId(), StringUtils.EMPTY),
                nullSafe(sbiEpayAggBankStmtReport.getMerchantCategory(), StringUtils.EMPTY),
                nullSafe(sbiEpayAggBankStmtReport.getMerchantName(), StringUtils.EMPTY),
                nullSafe(sbiEpayAggBankStmtReport.getOrderRefNumber(), StringUtils.EMPTY),
                nullSafe(sbiEpayAggBankStmtReport.getAtrnNum(), StringUtils.EMPTY),
                nullSafe(sbiEpayAggBankStmtReport.getTransactionDate(), StringUtils.EMPTY),
                nullSafe(sbiEpayAggBankStmtReport.getOrderAmount(), BigDecimal.ZERO),
                nullSafe(sbiEpayAggBankStmtReport.getCurrencyCode(), StringUtils.EMPTY),
                nullSafe(sbiEpayAggBankStmtReport.getTransactionStatus(), StringUtils.EMPTY),
                nullSafe(sbiEpayAggBankStmtReport.getEtlUploadDate(), StringUtils.EMPTY),
                nullSafe(sbiEpayAggBankStmtReport.getEtlStatus(), StringUtils.EMPTY),
                nullSafe(sbiEpayAggBankStmtReport.getChannelBank(), StringUtils.EMPTY),
                nullSafe(sbiEpayAggBankStmtReport.getGatewayTraceNumber(), StringUtils.EMPTY),
                nullSafe(sbiEpayAggBankStmtReport.getPayMode(), StringUtils.EMPTY),
                nullSafe(sbiEpayAggBankStmtReport.getGatewayStatus(), StringUtils.EMPTY)
        );
    }
}
