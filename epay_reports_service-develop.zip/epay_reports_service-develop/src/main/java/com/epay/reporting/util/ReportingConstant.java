package com.epay.reporting.util;

import lombok.experimental.UtilityClass;

/**
 * Class Name: TransactionConstant
 * *
 * Description: To define all project constants except error.
 * *
 * Author: Bhoopendra Rajput
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
@UtilityClass
public class ReportingConstant {

    public static final int RESPONSE_SUCCESS = 1;
    public static final int RESPONSE_FAILURE = 0;
    public static final long MIN_TIMESTAMP = 946684800000L; //1 Jan 2000
    public static final long MAX_TIMESTAMP = System.currentTimeMillis() + (50L * 365 * 24 * 60 * 60 * 1000); // 50 years
    public static final String REPORT_ROOT_FOLDER= "";

    //report scheduler management
    public static final String UPDATED_SUCCESSFULLY = "updated successfully";
    public static final String SCHEDULER_CANCELED = "scheduler cancelled";
    public static final int PAGE_SIZE = 50;
    public static final String REPORT_GENERATION = "Report Generation";
    public static final double GST_PERCENTAGE = 18;
    public static final String GST_OF = "ORDER";
    public static final String NARRATION = "SBIEPAYSETTLEMENT";
    public static final String NOT_AVAILABLE = "NA";
    public static final String MID = "mId";
    public static final String RFS_ID = "rfsId";
    public static final String TRANSACTION = "Transaction";
    public static final String REFUND = "Refund";
    public static final String SETTLEMENT = "Settlement";
    public static final String REMARK = "Remark";
    public static final String REPORT_GENERATION_REQ_RECEIVED_SUCCESS = "Report generation request is received successfully.";
    public static final String REPORT_GENERATED_SUCCESSFULLY = "report generated successfully";
    public static final String REPORT_INVOICE_NO = "SBIePay/{0}/{1}{2}";

    public static final int ALLOWED_FROM_TO_DATE_DIFF = 31;
    public static final int ALLOWED_FROM_DATE_DIFF = 365;
    public static final String NA = "NA";
    public static final String REPORT_TYPE = "Report Type";
    public static final String PAYOUT_DETAILS = "PAYOUT DETAILS";
}