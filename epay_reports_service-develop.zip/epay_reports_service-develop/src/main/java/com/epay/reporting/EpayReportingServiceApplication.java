package com.epay.reporting;

import com.epay.reporting.config.audit.SpringSecurityAuditorAware;
import net.javacrumbs.shedlock.spring.annotation.EnableSchedulerLock;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.actuate.autoconfigure.security.servlet.ManagementWebSecurityAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.domain.AuditorAware;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * Class Name: EpayReportingServiceApplication
 * *
 * Description: This class main method is to start the spring boot application.
 * *
 * Author: Bhoopendra Rajput
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@SpringBootApplication(exclude = {SecurityAutoConfiguration.class, ManagementWebSecurityAutoConfiguration.class})
@ComponentScan(basePackages = {"com.epay.reporting", "com.sbi.epay"})
@EnableJpaAuditing(auditorAwareRef = "auditorAware")
@EnableScheduling
@EnableSchedulerLock(defaultLockAtMostFor = "PT10M")
public class EpayReportingServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(EpayReportingServiceApplication.class, args);
	}

	@Bean
	public AuditorAware<String> auditorAware() {
		return new SpringSecurityAuditorAware();
	}

}