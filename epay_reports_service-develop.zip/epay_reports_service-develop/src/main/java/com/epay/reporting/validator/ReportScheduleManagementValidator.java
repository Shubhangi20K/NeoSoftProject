package com.epay.reporting.validator;

import com.epay.reporting.exception.ValidationException;
import com.epay.reporting.model.request.CancelScheduleRequest;
import com.epay.reporting.model.request.ReportScheduleManagementRequest;
import com.epay.reporting.model.request.ReportScheduleManagementSearchRequest;
import com.epay.reporting.model.request.ReportScheduleManagementUpdateRequest;
import com.epay.reporting.util.enums.Frequency;
import com.epay.reporting.util.enums.Report;
import com.epay.reporting.util.enums.ReportDuration;
import com.epay.reporting.util.enums.ReportFormat;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static com.epay.reporting.util.ErrorConstants.*;
import static com.epay.reporting.util.ReportingConstant.REMARK;
import static com.epay.reporting.util.enums.Frequency.DAILY;

/**
 * Class Name: ReportScheduleManagementValidator
 * *
 * Description: This class validates the report scheduling requests, including both the creation of a new schedule and
 * the search for existing schedules. It ensures that the provided schedule request contains valid values for the
 * report type, frequency, format, and schedule time. It also validates the merchant ID (MId) to ensure access and
 * existence.
 * *
 * Author: Bhoopendra Rajput
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Component
@RequiredArgsConstructor
public class ReportScheduleManagementValidator extends BaseValidator {

    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private final MIdValidator mIdValidator;

    /**
     * Validates the report schedule management request by checking mandatory fields and their values.
     * Also validates the MId by checking if it's active.
     *
     * @param reportScheduleManagementRequest The request object containing the report scheduling details.
     * @throws ValidationException if any validation fails.
     */
    public void validateRequest(ReportScheduleManagementRequest reportScheduleManagementRequest) {
        logger.debug("Request Validation start for {}", reportScheduleManagementRequest);
        errorDtoList = new ArrayList<>();
        validationMandatory(reportScheduleManagementRequest);
        validateLeadingTrailing(reportScheduleManagementRequest);
        validateFieldValue(reportScheduleManagementRequest);
        mIdValidator.validateActiveMId(reportScheduleManagementRequest.getMId());
        logger.debug("Request Validation end for {}", reportScheduleManagementRequest);
    }

    /**
     * Validates the report schedule management search request by checking the mandatory MId field.
     *
     * @param searchRequest The search request object.
     * @throws ValidationException if any validation fails.
     */
    public void validateRequest(ReportScheduleManagementSearchRequest searchRequest) {
        logger.debug("SearchRequest Validation start for {}", searchRequest);
        errorDtoList = new ArrayList<> ();
        mIdValidator.validateMid(searchRequest.getMId());
        validationMandatory(searchRequest);
        validateLeadingAndTralingFields(searchRequest);
        validateFieldsValues(searchRequest);
        logger.debug("SearchRequest Validation end for {}", searchRequest);
    }

    /**
     * Validates the fields values
     *
     * @param searchRequest request object.
     * @throws ValidationException if any validation fails.
     */
    private void validateFieldsValues(ReportScheduleManagementSearchRequest searchRequest) {
        validateFieldValue(searchRequest.getReport(), List.of(Report.ORDER.name(), Report.REFUNDS.name(), Report.TRANSACTION.name(), Report.SETTLEMENTS.name(), Report.CHARGEBACK.name()), REPORT);
        validateFieldValue(searchRequest.getFrequency(), List.of(Frequency.DAILY.name(), Frequency.MONTHLY.name()), FREQUENCY);
        validateFieldValue(searchRequest.getFormat(), List.of(ReportFormat.CSV.name(), ReportFormat.XLSX.name()), FORMAT);
        validateFieldWithRegex(String.valueOf(searchRequest.getScheduleStartExecutionTime()), NO_SPACE_INBETWEEN_STRING, FORMAT, INVALID_FORMAT);
        validateFieldWithRegex(String.valueOf(searchRequest.getScheduleStartExecutionTime()), NO_SPACE_INBETWEEN_STRING, FORMAT, INVALID_FORMAT);
        throwIfErrors();
    }

    /**
     * Validates the leading and trailing spaces
     *
     * @param searchRequest request object.
     * @throws ValidationException if any validation fails.
     */
    private void validateLeadingAndTralingFields(ReportScheduleManagementSearchRequest searchRequest) {
        checkForLeadingTrailingAndSingleSpace(searchRequest.getReport(), REPORT);
        checkForLeadingTrailingAndSingleSpace(searchRequest.getFrequency(), FREQUENCY);
        checkForLeadingTrailingAndSingleSpace(searchRequest.getFormat(), FORMAT);
        throwIfErrors();
    }

    /**
     * Validates the remark character length.
     *
     * @param cancelScheduleRequest  request object.
     * @throws ValidationException if any validation fails.
     */
    public void validateCancelScheduleRequest(String id, CancelScheduleRequest cancelScheduleRequest) {
        errorDtoList = new ArrayList<>();
        validationMandatory(id,cancelScheduleRequest);
        validateLeadingTrailing(id);
        validateFieldsValue(id,cancelScheduleRequest);
        throwIfErrors();
    }

    public void validateUpdateRequest(String id, ReportScheduleManagementUpdateRequest request) {
        errorDtoList = new ArrayList<>();
        validateLeadingTrailing(id,request);
        validateFieldValue(id,request);
    }

    /**
     * Checks for mandatory fields in the provided report schedule management request.
     *
     * @param reportScheduleManagementRequest The request object containing the report schedule details.
     * @throws ValidationException if any mandatory field is missing.
     */
    private void validationMandatory(ReportScheduleManagementRequest reportScheduleManagementRequest) {
        checkMandatoryField(reportScheduleManagementRequest.getMId(), MID);
        checkMandatoryField(reportScheduleManagementRequest.getReport(), REPORT);
        checkMandatoryField(reportScheduleManagementRequest.getScheduleExecutionTime(), SCHEDULE_EXECUTION_TIME);
        checkMandatoryField(reportScheduleManagementRequest.getFormat(), FORMAT);
        checkMandatoryField(reportScheduleManagementRequest.getFrequency(), FREQUENCY);
        if(!DAILY.name().equals(reportScheduleManagementRequest.getFrequency())) {
            checkMandatoryField(reportScheduleManagementRequest.getScheduleExecutionDate(), SCHEDULE_EXECUTION_DATE);
        }
        checkMandatoryField(reportScheduleManagementRequest.getReportDuration(), REPORT_DURATION);
        throwIfErrors();
    }

    /**
     * Checks for mandatory fields in the provided report schedule management request.
     *
     * @param cancelScheduleRequest The request object containing the report schedule details.
     */
    private void validationMandatory(String id, CancelScheduleRequest cancelScheduleRequest) {
        checkMandatoryField(id, REQUEST_ID);
        checkMandatoryField(cancelScheduleRequest.getRemarks(), REMARK);
        throwIfErrors();
    }

    /**
     * validates leading and trailing space
     * @param id String
     */
    private void validateLeadingTrailing(String id) {
        checkForLeadingTrailingAndSingleSpace(id, REQUEST_ID);
        throwIfErrors();
    }

    /**
     * validates leading and trailing space
     * @param cancelScheduleRequest request
     */
    private void validateFieldsValue(String id, CancelScheduleRequest cancelScheduleRequest) {
        validateFieldLength(id, MAX_UUID_ID_LENGTH, REQUEST_ID);
        validateFieldLength(cancelScheduleRequest.getRemarks(), REMARK_MAX_LENGTH, REMARK);
        throwIfErrors();
        validateFieldWithRegex(id, UUID_FORMAT_REGEX, REQUEST_ID, INCORRECT_FORMAT);
        throwIfErrors();
    }

    /**
     * Validates the values of report type, frequency, and format in the provided report schedule management request.
     *
     * @param reportScheduleManagementRequest The request object containing the report schedule details.
     * @throws ValidationException if the report, frequency, or format value is invalid.
     */
    private void validateFieldValue(ReportScheduleManagementRequest reportScheduleManagementRequest) {
        validateFieldValue(reportScheduleManagementRequest.getReport(), List.of(Report.ORDER.name(), Report.REFUNDS.name(), Report.TRANSACTION.name(), Report.SETTLEMENTS.name(), Report.CHARGEBACK.name()), REPORT);
        validateFieldValue(reportScheduleManagementRequest.getFrequency(), List.of(Frequency.DAILY.name(), Frequency.MONTHLY.name()), FREQUENCY);
        validateFieldValue(reportScheduleManagementRequest.getFormat(), List.of(ReportFormat.CSV.name(), ReportFormat.XLSX.name()), FORMAT);
        validateFieldValue(reportScheduleManagementRequest.getReportDuration(), List.of(ReportDuration.CURRENT_MONTH.name(), ReportDuration.LAST_7_DAYS.name(), ReportDuration.LAST_30_DAYS.name(), ReportDuration.LAST_90_DAYS.name(), ReportDuration.YESTERDAY.name(), ReportDuration.PREVIOUS_MONTH.name()), REPORT_DURATION);
        throwIfErrors();
        validateFieldWithRegex(reportScheduleManagementRequest.getScheduleExecutionTime(), SCHEDULE_EXECUTION_TIME_REGEX, SCHEDULE_EXECUTION_TIME, INVALID_FORMAT);
        validateFieldWithRegex(reportScheduleManagementRequest.getScheduleExecutionDate(), ALLOWED_DIGIT_REGEX, SCHEDULE_EXECUTION_DATE, INVALID_FORMAT);
        throwIfErrors();
        validateFieldValue(reportScheduleManagementRequest.getScheduleExecutionDate(), SCHEDULE_EXECUTION_DATE, SCHEDULE_EXECUTION_DATE_MAX_VALUE);
        throwIfErrors();
    }

    private void validateFieldValue(String id, ReportScheduleManagementUpdateRequest request) {
        validateFieldLength(request.getScheduleExecutionTime(), SCHEDULE_EXECUTION_TIME_LENGTH, SCHEDULE_EXECUTION_TIME);
        validateFieldLength(request.getScheduleExecutionDate(), SCHEDULE_EXECUTION_DATE_LENGTH, SCHEDULE_EXECUTION_DATE);
        validateFieldLength(id, MAX_UUID_ID_LENGTH, REQUEST_ID);
        throwIfErrors();
        validateFieldWithRegex(request.getFrequency(), CAPS_NO_SPACE_REGEX, FREQUENCY);
        validateFieldWithRegex(request.getFormat(), CAPS_NO_SPACE_REGEX, FORMAT);
        validateFieldWithRegex(id, UUID_FORMAT_REGEX, REQUEST_ID, INCORRECT_FORMAT);
        validateFieldWithRegex(request.getScheduleExecutionTime(), SCHEDULE_EXECUTION_TIME_REGEX, SCHEDULE_EXECUTION_TIME, INVALID_FORMAT);
        validateFieldWithRegex(request.getScheduleExecutionDate(), ALLOWED_DIGIT_REGEX, SCHEDULE_EXECUTION_DATE, INVALID_FORMAT);
        throwIfErrors();
        validateFieldValue(request.getScheduleExecutionDate(), SCHEDULE_EXECUTION_DATE, SCHEDULE_EXECUTION_DATE_MAX_VALUE);
        throwIfErrors();
        validateFieldValue(request.getFrequency(), Arrays.stream(Frequency.values()).map(Enum::name).toList(), FREQUENCY);
        validateFieldValue(request.getFormat(), List.of(ReportFormat.CSV.name(), ReportFormat.XLSX.name()), FORMAT);
        throwIfErrors();
    }

    /**
     * Checks for mandatory fields in the provided report schedule management search request.
     *
     * @param searchRequest The search request object.
     * @throws ValidationException if any mandatory field is missing.
     */
    private void validationMandatory(ReportScheduleManagementSearchRequest searchRequest) {
        checkMandatoryField(searchRequest.getMId(), MID);
        throwIfErrors();
    }

    /**
     * validates leading and trailing space
     * @param request request
     */
    private void validateLeadingTrailing(String id,ReportScheduleManagementUpdateRequest request) {
        checkForLeadingTrailingAndSingleSpace(id, REQUEST_ID);
        checkForLeadingTrailingAndSingleSpace(request.getFormat(), FORMAT);
        checkForLeadingTrailingAndSingleSpace(request.getFrequency(), FREQUENCY);
        checkForLeadingTrailingAndSingleSpace(request.getScheduleExecutionTime(), SCHEDULE_EXECUTION_TIME);
        checkForLeadingTrailingAndSingleSpace(request.getScheduleExecutionDate(), SCHEDULE_EXECUTION_DATE);
        throwIfErrors();
    }

    /**
     * validates leading and trailing space
     * @param request request
     */
    private void validateLeadingTrailing(ReportScheduleManagementRequest request) {
        checkForLeadingTrailingAndSingleSpace(request.getReport(), REPORT);
        checkForLeadingTrailingAndSingleSpace(request.getFormat(), FORMAT);
        checkForLeadingTrailingAndSingleSpace(request.getFrequency(), FREQUENCY);
        checkForLeadingTrailingAndSingleSpace(request.getScheduleExecutionTime(), SCHEDULE_EXECUTION_TIME);
        checkForLeadingTrailingAndSingleSpace(request.getScheduleExecutionDate(), SCHEDULE_EXECUTION_DATE);
        checkForLeadingTrailingAndSingleSpace(request.getReportDuration(), REPORT_DURATION);
        throwIfErrors();
    }

}