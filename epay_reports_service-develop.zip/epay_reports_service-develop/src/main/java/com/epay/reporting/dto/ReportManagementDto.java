package com.epay.reporting.dto;


import com.epay.reporting.util.enums.ReportFormat;
import com.epay.reporting.util.enums.Report;
import com.epay.reporting.util.enums.ReportStatus;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

/**
 * Class Name: ReportManagementDto
 * Description: This class serves as a Data Transfer Object (DTO) for managing report-related details within
 * the application. It includes information such as report ID, report metadata, scheduling details, status,
 * file path, creation timestamps, and remarks. The `@JsonIgnore` annotation is used to exclude certain fields
 * (like `id`, `reportId`, and `scheduledId`) from the JSON serialization, while the `@JsonInclude` annotation
 * ensures that only non-null fields are included in the output JSON.
 * Author: Bhoopendra Rajput
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * Version:1.0
 */
@Builder
@AllArgsConstructor
@Data
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ReportManagementDto {
    @JsonIgnore
    private UUID id;
    @JsonIgnore
    private UUID reportId;
    private Report report;
    private String mId;
    private Long durationFromDate;
    private Long durationToDate;
    private ReportFormat format;
    private ReportStatus status;
    private String filePath;
    private String remarks;
    @JsonIgnore
    private UUID scheduledId;
    private Long createdAt;
    private Long updatedAt;
}
