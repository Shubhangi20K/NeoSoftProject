package com.epay.reporting.mapper;

import com.epay.reporting.entity.view.ReconFileDtls;
import org.apache.commons.lang3.StringUtils;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;

import java.math.BigDecimal;
import java.util.List;

import static org.thymeleaf.util.ObjectUtils.nullSafe;

@Mapper(builder = @Builder(disableBuilder = true), componentModel = "spring")
public interface ReconFileDtlsMapper {
    default List<Object> mapToList(ReconFileDtls reconFileDtls){
        return List.of(
                nullSafe(reconFileDtls.getMId(), StringUtils.EMPTY),
                nullSafe(reconFileDtls.getRowNumber(), StringUtils.EMPTY),
                nullSafe(reconFileDtls.getAtrnNum(), StringUtils.EMPTY),
                nullSafe(reconFileDtls.getTxnAmount(), BigDecimal.ZERO),
                nullSafe(reconFileDtls.getBankRefNumber(),StringUtils.EMPTY),
                nullSafe(reconFileDtls.getPayoutStatus(),StringUtils.EMPTY),
                nullSafe(reconFileDtls.getReconStatus(),StringUtils.EMPTY),
                nullSafe(reconFileDtls.getSettlementStatus(),StringUtils.EMPTY),
                nullSafe(reconFileDtls.getRemark(),StringUtils.EMPTY));
    }
}
