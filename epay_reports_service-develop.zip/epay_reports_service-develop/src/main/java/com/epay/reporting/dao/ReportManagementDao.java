package com.epay.reporting.dao;

import com.epay.reporting.dto.ReportManagementDto;
import com.epay.reporting.entity.ReportManagement;
import com.epay.reporting.etl.producer.ReportGenerationProducer;
import com.epay.reporting.exception.ReportingException;
import com.epay.reporting.mapper.ReportManagementMapper;
import com.epay.reporting.model.request.ReportManagementRequest;
import com.epay.reporting.repository.ReportManagementRepository;
import com.epay.reporting.specification.ReportManagementSpecification;
import com.epay.reporting.util.DateTimeUtils;
import com.epay.reporting.util.ErrorConstants;
import com.epay.reporting.util.enums.Report;
import com.epay.reporting.util.enums.ReportStatus;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import java.text.MessageFormat;
import java.util.List;
import java.util.UUID;

/**
 * Class Name: ReportManagementDao
 * Description: Data access layer for handling Report Management operations like saving, updating,
 * and fetching report statuses and details from the database.
 * Author: Bhoopendra Rajput
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * Version: 1.0
 */
@Component
@RequiredArgsConstructor
public class ReportManagementDao {
    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());

    private final ReportManagementRepository reportManagementRepository;
    private final ReportManagementMapper mapper;
    private final ReportMasterDao reportMasterDao;
    private final ReportGenerationProducer reportGenerationProducer;

    /**
     * Method Name: saveReportManagement
     * Description: Saves a report management entry, generates a report ID,
     * and publishes a report generation message.
     * @param reportManagementDto - The DTO object containing report data to save.
     */
    public void saveReportManagement(ReportManagementDto reportManagementDto) {
        log.info("Saving report management for report: {}", reportManagementDto.getReport());
        UUID reportId = reportMasterDao.getReportIdByName(reportManagementDto.getReport());
        reportManagementDto.setReportId(reportId);
        reportManagementDto.setStatus(ReportStatus.TO_BE_GENERATE);
        ReportManagement reportManagement = mapper.mapDtoToEntity(reportManagementDto);
        UUID reportManagementId = reportManagementRepository.save(reportManagement).getId();
        reportGenerationProducer.publish(reportManagementDto.getReport().getName() + "_" + reportManagementId, String.valueOf(reportManagementId));
        log.info("Report management saved with ID: {}", reportManagementId);
    }
    /**
     * Method Name: saveAll
     * Description: Saves all the report management records in bulk and publishes
     * report generation messages for each saved record.
     * @param reportManagementList - List of ReportManagement entities to save.
     */
    public void saveAll(List<ReportManagement> reportManagementList) {
        log.info("Saving {} report management records.", reportManagementList.size());
        List<ReportManagement> reportManagements = reportManagementRepository.saveAll(reportManagementList);
        if (CollectionUtils.isNotEmpty(reportManagements)) {
            reportManagements.forEach(reportManagement -> reportGenerationProducer.publish(reportMasterDao.getReportNameById(reportManagement.getReportId()).getName() + "_" + reportManagement.getId(), String.valueOf(reportManagement.getId())));
        }
    }

    public void saveReport(ReportManagementDto reportManagementDto) {
        reportManagementRepository.save(mapper.mapDtoToEntity(reportManagementDto));
    }

    /**
     * Method Name: searchAndGetReportManagement
     * Description: Searches and returns a paginated list of report management records based on request filters.
     * @param reportManagementRequest - The request object containing search filters.
     * @param pageable - The pagination details for the query.
     * @return Page<ReportManagementDto> - A page of ReportManagementDto objects.
     */
    public Page<ReportManagementDto> searchAndGetReportManagement(ReportManagementRequest reportManagementRequest, Pageable pageable) {
        log.info("Searching for report management records with filters: {}", reportManagementRequest);
        UUID reportId = null;
        if (ObjectUtils.isNotEmpty(reportManagementRequest.getReport())) {
            reportId = reportMasterDao.getReportIdByName(Report.getName(reportManagementRequest.getReport()));
        }
        Specification<ReportManagement> specification = ReportManagementSpecification.searchReportManagement(reportId, reportManagementRequest);
        return reportManagementRepository.findAll(specification, pageable).map(this::convertEntityToDTO);
    }

    /**
     * Method Name: updateReportStatus
     * Description: Updates the status of a report management record by ID and returns the updated DTO.
     * @param reportManagementId - The ID of the report management record.
     * @param reportStatus - The new status to set for the report.
     * @return ReportManagementDto - The updated ReportManagement DTO.
     */
    public ReportManagementDto updateReportStatus(UUID reportManagementId, ReportStatus reportStatus) {
        log.info("Updating report status for report management ID: {} to status: {}", reportManagementId, reportStatus);
        ReportManagement reportManagement = getReportManagementByPastStatus(reportManagementId, reportStatus);
        reportManagement.setStatus(reportStatus);
        reportManagementRepository.save(reportManagement);
        return getReportManagementDto(reportManagement);
    }

    /**
     * Method Name: updateStatusAndFilePath
     * Description: Updates the status and file path for a report management record.
     * @param reportManagementId - The ID of the report management record.
     * @param reportStatus - The new status to set for the report.
     * @param fileName - The file path to save for the report.
     */
    public void updateStatusAndFilePath(UUID reportManagementId, ReportStatus reportStatus, String fileName) {
        log.info("Updating status and file path for report management ID: {} to status: {}, file path: {}", reportManagementId, reportStatus, fileName);
        try {
            ReportManagement reportManagement = getReportManagementByPastStatus(reportManagementId, reportStatus);
            reportManagement.setStatus(reportStatus);
            reportManagement.setFilePath(fileName);
            reportManagementRepository.save(reportManagement);
        } catch (ReportingException e) {
            log.error("Error in updateReportStatus of report {}, status : {}, error : {}", reportManagementId, reportStatus, e);
        }
    }


    /**
     * Method Name: updateStatusAndRemarks
     * Description: Updates the status and remarks for a report management record.
     * @param reportManagementId - The ID of the report management record.
     * @param reportStatus - The new status to set for the report.
     * @param remarks - The remarks to save for the report.
     */
    public void updateStatusAndRemarks(UUID reportManagementId, ReportStatus reportStatus, String remarks) {
        log.info("Updating status and remarks for report management ID: {} to status: {}, remarks: {}", reportManagementId, reportStatus, remarks);
        try {
            ReportManagement reportManagement = getReportManagementByPastStatus(reportManagementId, reportStatus);
            reportManagement.setStatus(reportStatus);
            reportManagement.setRemarks(remarks);
            reportManagementRepository.save(reportManagement);
        } catch (ReportingException e) {
            log.error("Error in updateReportStatus of report {}, status : {}, error : {}", reportManagementId, reportStatus, e);
        }

    }

    protected ReportManagementDto convertEntityToDTO(ReportManagement reportManagement) {
        return getReportManagementDto(reportManagement);
    }

    private ReportManagement getReportManagementByPastStatus(UUID reportManagementId, ReportStatus reportStatus) {
        log.info("Fetching report management record by past status for report ID: {} and status: {}", reportManagementId, reportStatus);
        List<ReportStatus> reportStatusCheckList = List.of();
        if (ReportStatus.TO_BE_GENERATE.equals(reportStatus)) {
            reportStatusCheckList = List.of(ReportStatus.GENERATED, ReportStatus.GENERATION_FAILED);
        } else if (ReportStatus.GENERATION_STARTED.equals(reportStatus)) {
            reportStatusCheckList = List.of(ReportStatus.TO_BE_GENERATE);
        } else if (ReportStatus.GENERATED.equals(reportStatus) || ReportStatus.GENERATION_FAILED.equals(reportStatus)) {
            reportStatusCheckList = List.of(ReportStatus.GENERATION_STARTED);
        }
        return reportManagementRepository.findByIdAndStatusIn(reportManagementId, reportStatusCheckList).orElseThrow(() -> new ReportingException(ErrorConstants.NOT_FOUND_ERROR_CODE, MessageFormat.format(ErrorConstants.NOT_FOUND_ERROR_MESSAGE, "Report")));
    }

    private ReportManagementDto getReportManagementDto(ReportManagement reportManagement) {
        ReportManagementDto reportManagementDto = mapper.mapEntityToDto(reportManagement);
        reportManagementDto.setReport(reportMasterDao.getReportNameById(reportManagementDto.getReportId()));
        return reportManagementDto;
    }


    /**
     * Method Name: isReportExistsByMIdAndFilePathAndStatus
     *
     * Description:Checks if a report exists for a specific merchant ID, file path, and status.
     *
     * @param mId - The merchant ID.
     * @param filePath - The file path of the report.
     * @param reportStatus - The status of the report.
     * @return boolean - Returns true if the report exists, false otherwise.
     */
    public boolean isReportExistsByMIdAndFilePathAndStatus(String mId, String filePath, ReportStatus reportStatus) {
        return reportManagementRepository.existsBymIdAndFilePathAndStatus(mId, filePath, reportStatus);
    }

    /**
     * Method Name: getReportManagement
     *
     * Description: Fetches a report management DTO based on merchant ID, file path, and status.
     *
     * @param mId - The merchant ID.
     * @param filePath - The file path of the report.
     * @param reportStatus - The status of the report.
     * @return ReportManagementDto - The ReportManagement DTO object.
     */
    public ReportManagementDto getReportManagement(String mId, String filePath, ReportStatus reportStatus) {
        return mapper.mapEntityToDto(reportManagementRepository.findBymIdAndFilePathAndStatus(mId, filePath, reportStatus));
    }

    /**
     * Fetch list of report management dto for given status.
     * @param status ReportStatus
     * @return List<ReportManagementDto>
     */
    public List<ReportManagementDto> findReportByStatus(ReportStatus status) {
        return mapper.mapEntityToDto(reportManagementRepository.findByStatus(status, DateTimeUtils.deductHourFromNow(1)));
    }
}