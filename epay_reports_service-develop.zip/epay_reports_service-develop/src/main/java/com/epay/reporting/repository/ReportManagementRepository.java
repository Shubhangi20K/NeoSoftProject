package com.epay.reporting.repository;


import com.epay.reporting.entity.ReportManagement;
import com.epay.reporting.util.enums.ReportStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Class Name: ReportManagementRepository
 * *
 * Description: This interface defines all JPA methods for interacting with the `ReportManagement` entity.
 * It extends the `JpaRepository` interface and provides custom query methods for report management
 * functionality including finding, checking existence, and fetching reports by specific criteria.
 * Author: Bhoopendra Rajput
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * Version:1.0
 */
@Repository
public interface ReportManagementRepository extends JpaRepository<ReportManagement, UUID> {

    /**
     * Finds all ReportManagement entities based on a custom specification and pageable parameters.
     *
     * @param specification the specification to filter the results
     * @param pageable pagination information
     * @return a page of filtered ReportManagement entities
     */
    Page<ReportManagement> findAll(Specification<ReportManagement> specification, Pageable pageable);

    /**
     * Finds a ReportManagement entity by its ID and a list of possible statuses.
     *
     * @param reportId the UUID of the report
     * @param reportStatus the list of report statuses to filter by
     * @return an optional containing the ReportManagement entity if found, otherwise empty
     */
    Optional<ReportManagement> findByIdAndStatusIn(UUID reportId, List<ReportStatus> reportStatus);

    /**
     * Checks if a ReportManagement entity with the given merchant ID, file path, and status exists.
     *
     * @param mId the merchant ID
     * @param filePath the file path of the report
     * @param status the status of the report
     * @return true if the entity exists, otherwise false
     */
    boolean existsBymIdAndFilePathAndStatus(String mId, String filePath, ReportStatus status);

    /**
     * Finds a ReportManagement entity by its merchant ID, file path, and status.
     *
     * @param mId the merchant ID
     * @param filePath the file path of the report
     * @param status the status of the report
     * @return the found ReportManagement entity
     */
    ReportManagement findBymIdAndFilePathAndStatus(String mId, String filePath, ReportStatus status);

    @Query("SELECT r FROM ReportManagement r WHERE r.createdAt <= :time AND r.status = :status")
    List<ReportManagement> findByStatus(@Param("status") ReportStatus status, @Param("time") Long time);
}
