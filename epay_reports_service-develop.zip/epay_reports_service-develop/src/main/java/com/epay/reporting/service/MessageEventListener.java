package com.epay.reporting.service;


import com.epay.reporting.entity.event.audit.EventErrorLog;
import com.epay.reporting.entity.event.audit.EventReceivedLog;
import com.epay.reporting.entity.event.audit.EventSendLog;
import com.epay.reporting.repository.event.audit.EventErrorLogRepository;
import com.epay.reporting.repository.event.audit.EventReceivedLogRepository;
import com.epay.reporting.repository.event.audit.EventSendLogRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Service;

/**
 * Class Name: MessageEventListener
 * Description: service for event logs
 * Copyright (c) [2025] [State Bank of India]
 * All rights reserved.
 * Author:@V0000001(Shilpa Kothre)
 * Version:1.0
 */

@Service
@RequiredArgsConstructor
public class MessageEventListener {

    private final EventErrorLogRepository eventErrorLogRepository;
    private final EventSendLogRepository eventSendLogRepository;
    private final EventReceivedLogRepository eventReceivedLogRepository;

    @EventListener
    @Transactional
    public void sendEvent(EventSendLog eventSendLog) {
        eventSendLogRepository.save(eventSendLog);
    }

    @EventListener
    @Transactional
    public void receivedEvent(EventReceivedLog eventReceivedLog) {
        eventReceivedLogRepository.save(eventReceivedLog);
    }

    @EventListener
    @Transactional
    public void errorEvent(EventErrorLog eventErrorLog) {
        eventErrorLogRepository.save(eventErrorLog);
    }
}

