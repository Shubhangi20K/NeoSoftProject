package com.epay.reporting.dao;

import com.epay.reporting.config.ReportingConfig;
import com.epay.reporting.dto.ReportScheduleManagementDto;
import com.epay.reporting.entity.ReportManagement;
import com.epay.reporting.entity.ReportScheduleManagement;
import com.epay.reporting.exception.ReportingException;
import com.epay.reporting.mapper.ReportScheduleManagementMapper;
import com.epay.reporting.model.request.CancelScheduleRequest;
import com.epay.reporting.model.request.ReportScheduleManagementSearchRequest;
import com.epay.reporting.model.request.ReportScheduleManagementUpdateRequest;
import com.epay.reporting.repository.ReportScheduleManagementRepository;
import com.epay.reporting.specification.ReportScheduleManagementSpecification;
import com.epay.reporting.util.DateTimeUtils;
import com.epay.reporting.util.ErrorConstants;
import com.epay.reporting.util.enums.*;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import java.text.MessageFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static com.epay.reporting.util.DateTimeUtils.FORMATTER_TIME_HH_MM;
import static com.epay.reporting.util.DateTimeUtils.ZONE_ID_INDIA;
import static com.epay.reporting.util.ErrorConstants.ONE;

/**
 * Class Name: ReportScheduleManagementDao
 * <p>
 * Description: Handles the CRUD operations for report scheduling management,
 * including saving, updating, searching, and canceling scheduled reports.
 * It communicates with the database via the `ReportScheduleManagementRepository`
 * and performs business logic to manage report schedules.
 * </p>
 * Author: Bhoopendra Rajput
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * <p>
 * Version: 1.0
 */
@Component
@RequiredArgsConstructor
public class ReportScheduleManagementDao {
    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    private final ReportScheduleManagementRepository reportScheduleManagementRepository;
    private final ReportScheduleManagementMapper mapper;
    private final ReportMasterDao reportMasterDao;
    private final ReportManagementDao reportManagementDao;
    private final ReportingConfig reportingConfig;


    /**
     * Method Name: save
     * Description: Saves a new report schedule to the database.
     * It calculates the next schedule execution time based on the frequency
     * and then saves the report schedule.
     *
     * @param reportScheduleManagementDto - Data Transfer Object containing report schedule details.
     */
    public void save(ReportScheduleManagementDto reportScheduleManagementDto) {
        log.info("Saving new report schedule for report: {}", reportScheduleManagementDto.getReport());

        UUID reportId = reportMasterDao.getReportIdByName(reportScheduleManagementDto.getReport());
        reportScheduleManagementDto.setReportId(reportId);
        reportScheduleManagementDto.setStatus(ReportScheduledStatus.TO_BE_START);
        Long nextExecutionTime;
        log.info("getScheduleExecutionTime: {}, Current IST Hours {}", LocalTime.parse(reportScheduleManagementDto.getScheduleExecutionTime(), FORMATTER_TIME_HH_MM), LocalTime.now(ZONE_ID_INDIA));
        if (reportScheduleManagementDto.getFrequency().equals(Frequency.DAILY) && LocalTime.parse(reportScheduleManagementDto.getScheduleExecutionTime(), FORMATTER_TIME_HH_MM).isAfter(LocalTime.now(ZONE_ID_INDIA))) {
            log.info("daily report schedule time is after current IST hour");
            nextExecutionTime = DateTimeUtils.getCurrentDateWithTime(reportScheduleManagementDto.getScheduleExecutionTime());
        } else {
            nextExecutionTime = DateTimeUtils.calculateNextExecutionTime(
                    reportScheduleManagementDto.getFrequency(),
                    reportScheduleManagementDto.getScheduleExecutionTime(),
                    reportScheduleManagementDto.getScheduleExecutionDate()
            );
        }
        reportScheduleManagementDto.setNextScheduleExecutionTime(nextExecutionTime);

        ReportScheduleManagement entity = mapper.mapDtoToEntity(reportScheduleManagementDto);
        reportScheduleManagementRepository.save(entity);

        log.info("Report schedule saved successfully with ID: {}", entity.getId());
    }

    /**
     * Method Name: executeReportBySchedule
     * <p>
     * Description: Executes reports based on their scheduled execution times.
     * It updates the execution times and saves the reports that need to be generated.
     */
    public void executeReportBySchedule() {
        log.info("Executing reports by schedule.");
        Long scheduleEndTime = DateTimeUtils.addMinutes(reportingConfig.getReportScheduleExecutionWindow());
        log.info("scheduleEndTime is : {}", scheduleEndTime);
        List<ReportScheduleManagement> reportScheduleManagement = findByStatusAndNextScheduleExecutionTime(scheduleEndTime);
        List<ReportManagement> reportManagementList = reportScheduleManagement.stream().map(schedule -> {
            schedule.setLastScheduleExecutionTime(DateTimeUtils.getCurrentTimeInMills());
            schedule.setNextScheduleExecutionTime(DateTimeUtils.calculateNextExecutionTime(schedule.getFrequency(), schedule.getScheduleExecutionTime(), schedule.getScheduleExecutionDate()));
            Pair<LocalDate, LocalDate> dateRange = calculateReportDateRange(schedule.getReportDuration(), LocalDate.now());
            return ReportManagement.builder().reportId(schedule.getReportId()).mId(schedule.getMId()).format(schedule.getFormat()).scheduledId(schedule.getId()).durationFromDate(dateRange.getLeft().atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()).durationToDate(dateRange.getRight().atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli() - ONE).scheduledId(schedule.getId()).status(ReportStatus.TO_BE_GENERATE).build();
        }).toList();
        reportScheduleManagementRepository.saveAll(reportScheduleManagement);
        reportManagementDao.saveAll(reportManagementList);
        log.info("Reports executed and saved successfully.");
    }

    /**
     * Method Name: searchAndGetAll
     * Description: Searches and retrieves report schedule management records
     * based on the given search criteria. This returns a paginated list of schedules.
     *
     * @param searchRequest - Criteria for searching report schedules.
     * @param pageable - Pagination information.
     * @return Page<ReportScheduleManagementDto> - Paginated list of report schedules.
     */
    public Page<ReportScheduleManagementDto> searchAndGetAll(ReportScheduleManagementSearchRequest searchRequest, Pageable pageable) {
        log.info("Searching for report schedules with request: {}", searchRequest);
        UUID reportId = null;
        if (ObjectUtils.isNotEmpty(searchRequest.getReport())) {
            reportId = reportMasterDao.getReportIdByName(Report.getName(searchRequest.getReport()));
        }
        Specification<ReportScheduleManagement> specification = ReportScheduleManagementSpecification.searchSchedulerManagement(reportId, searchRequest);
        return reportScheduleManagementRepository.findAll(specification, pageable).map(this::convertEntityToDTO);
    }

    /**
     * Method Name: update
     * Description: Updates an existing report schedule with new details provided in the update request.
     * @param id - The ID of the report schedule to update.
     * @param request - The update request containing new details for the schedule.
     */
    public void update(String id, ReportScheduleManagementUpdateRequest request) {
        log.info("Updating report schedule with ID: {}", id);
        ReportScheduleManagement reportScheduleManagement = reportScheduleManagementRepository.findById(UUID.fromString(id)).orElseThrow(() -> new ReportingException(ErrorConstants.NOT_FOUND_ERROR_CODE, MessageFormat.format(ErrorConstants.NOT_FOUND_ERROR_MESSAGE, ErrorConstants.SCHEDULE_REQUEST_ID)));
        mergeNonNullFields(reportScheduleManagement, request);
        reportScheduleManagementRepository.save(reportScheduleManagement);
        log.info("Report schedule with ID: {} updated successfully.", id);
    }

    /**
     * Method Name: cancelScheduler
     * Description: Cancels a report schedule by updating its status to CANCELLED.
     * It also clears the next execution time for the schedule.
     * @param id - The ID of the report schedule to cancel.
     */
    public void cancelScheduler(UUID id, CancelScheduleRequest cancelScheduleRequest) {
        log.info("Canceling report schedule with ID: {}", id);
        ReportScheduleManagement reportScheduleManagement = reportScheduleManagementRepository.findById(id).orElseThrow(() -> new ReportingException(ErrorConstants.NOT_FOUND_ERROR_CODE, MessageFormat.format(ErrorConstants.NOT_FOUND_ERROR_MESSAGE, ErrorConstants.SCHEDULE_REQUEST_ID)));
        reportScheduleManagement.setStatus(ReportScheduledStatus.CANCELLED);
        reportScheduleManagement.setNextScheduleExecutionTime(null);
        reportScheduleManagement.setRemarks(cancelScheduleRequest.getRemarks());
        reportScheduleManagementRepository.save(reportScheduleManagement);
        log.info("Report schedule with ID: {} canceled successfully.", id);
    }
    /**
     * Method Name: findByStatusAndNextScheduleExecutionTime
     * Description: Finds report schedules that are ready to be executed based on their status and next execution time.
     * @param scheduleEndTime - The calculated end time for the schedule.
     * @return List<ReportScheduleManagement> - List of report schedules ready for execution.
     */
    protected List<ReportScheduleManagement> findByStatusAndNextScheduleExecutionTime(long scheduleEndTime) {
        log.info("Finding report schedules to be executed with status: {} and next execution time before: {}", ReportScheduledStatus.TO_BE_START, scheduleEndTime);
        // TODO : Spring Batch need to user here
        return reportScheduleManagementRepository.findByStatusAndNextScheduleExecutionTime(ReportScheduledStatus.TO_BE_START, scheduleEndTime);
    }

    /**
     * Method Name: convertEntityToDTO
     * Description: Converts a ReportScheduleManagement entity to a Data Transfer Object (DTO).
     * @param reportScheduleManagement - The entity to convert.
     * @return ReportScheduleManagementDto - The corresponding DTO.
     */
    private ReportScheduleManagementDto convertEntityToDTO(ReportScheduleManagement reportScheduleManagement) {
        ReportScheduleManagementDto reportScheduleManagementDto = mapper.mapEntityToDto(reportScheduleManagement);
        reportScheduleManagementDto.setReport(reportMasterDao.getReportNameById(reportScheduleManagementDto.getReportId()));
        return reportScheduleManagementDto;
    }

    /**
     * Merges only the non-null fields from the update request into the existing report schedule entity.
     * <p>
     * For each field in the update request:
     * - If it is non-null, it overrides the corresponding field in the entity.
     * - If it is null, the existing field value is retained.
     * <p>
     * Uses Optional.ofNullable(...).ifPresent(...) to perform null-checks and conditional assignments.
     *
     * @param reportScheduleManagement The existing report schedule entity to update.
     * @param request                  The update request object that may contain new values.
     */
    private void mergeNonNullFields(ReportScheduleManagement reportScheduleManagement, ReportScheduleManagementUpdateRequest request) {
        Optional.ofNullable(request.getFormat()).map(StringUtils::upperCase).map(ReportFormat::valueOf).ifPresent(reportScheduleManagement::setFormat);
        Optional.ofNullable(request.getFrequency()).map(StringUtils::upperCase).map(Frequency::valueOf).ifPresent(reportScheduleManagement::setFrequency);
        Optional.ofNullable(request.getScheduleExecutionTime()).ifPresent(reportScheduleManagement::setScheduleExecutionTime);
        reportScheduleManagement.setScheduleExecutionDate(request.getScheduleExecutionDate());
    }

    /**
     * Calculates the date range for report generation based on the report duration type and execution date.
     * This version delegates the logic to the appropriate method in the ReportDuration enum.
     *
     * @param reportDuration The report duration as a string (e.g., "YESTERDAY", "LAST_7_DAYS").
     * @param executionDate  The base date to calculate the date range from.
     * @return A Pair containing the start and end dates (inclusive).
     * @throws IllegalArgumentException if the report duration is invalid.
     */
    private static Pair<LocalDate, LocalDate> calculateReportDateRange(String reportDuration, LocalDate executionDate) {
        ReportDuration durationEnum = ReportDuration.fromString(reportDuration);
        return durationEnum.calculateRange(executionDate);
    }
}