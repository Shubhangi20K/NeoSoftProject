package com.epay.reporting.util.file.generator;

import com.epay.reporting.dto.ReportFile;
import com.epay.reporting.dto.TxtFileModel;
import com.epay.reporting.util.ReportingConstant;
import com.epay.reporting.util.enums.Report;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;

import static com.epay.reporting.util.DateTimeUtils.FORMATTER_DD_MM_YY_HH_MM_SS;
/**
 * Class Name: TxtGenerator
 * *
 * Description:Class for generating and downloading CSV files for reports.
 * *
 * Author: Saurabh Mahto(V1018841)
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Component
@RequiredArgsConstructor
public class TxtGenerator {
    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());

    /**
     * Generates a TXT file from the provided data and saves it to the file system.
     *
     * @param reportName - Name of the report
     * @return - Generated TXT file
     */
    public ReportFile txtFileGenerator(Report reportName, TxtFileModel txtFileModel) {
        log.info("Started txt file generator for reportName : {}  objects.size: {}", reportName.getName(),  CollectionUtils.size(txtFileModel.getLines()));
        String fileName = getFileName(reportName.getName());
        String content = generateTxt(txtFileModel);
        return ReportFile.builder().name(fileName).content(content.getBytes(StandardCharsets.UTF_8)).build();
    }

    /**
     * Constructs the file name for the TXT file based on the report name.
     *
     * @param reportName - Name of the report
     * @return - Generated file name
     */
    private String getFileName(String reportName) {
        return String.format("%s%s_%s.txt", ReportingConstant.REPORT_ROOT_FOLDER,
                reportName, LocalDateTime.now().format(FORMATTER_DD_MM_YY_HH_MM_SS));
    }

    /**
     * Generates the TXT content as a string without header.
     *
     * @param txtFileModel - List of data rows for the txt
     * @return - Txt content as a string
     */
    private String generateTxt(TxtFileModel txtFileModel){
        return String.join("\n", txtFileModel.getLines());
    }
}
