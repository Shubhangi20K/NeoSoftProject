package com.epay.reporting.model.request;

import com.epay.reporting.util.enums.Frequency;
import com.epay.reporting.util.enums.ReportFormat;
import lombok.*;

/**
 * Class Name: ReportScheduleManagementUpdateRequest
 * Description: This class is used to represent the update request for scheduled reports. It includes fields to
 * update the frequency, format, and the next scheduled execution time for a specific report schedule.
 * Author: Bhoopendra Rajput
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * Version: 1.0
 */
@AllArgsConstructor
@Getter
@Setter
@ToString
@Builder
@NoArgsConstructor
public class ReportScheduleManagementUpdateRequest {
    private String frequency;
    private String format;
    private String scheduleExecutionTime;
    private String scheduleExecutionDate;
}
