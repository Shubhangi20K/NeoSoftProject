package com.epay.reporting.dao;

import com.epay.reporting.entity.view.TransactionMIS;
import com.epay.reporting.mapper.TransactionMISMapper;
import com.epay.reporting.repository.view.TransactionMISRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Class Name: TransactionMISDao
 * *
 * Class for accessing Operation-related data.
 * *
 * Author: Saurabh mahto(v1018841)
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */

@Service
@RequiredArgsConstructor
public class TransactionMISDao {
    private final TransactionMISRepository transactionMISRepository;
    private final TransactionMISMapper transactionMISMapper;

    public List<List<Object>> getTransactionMISByMID(String mId){
        List<TransactionMIS> transactionMIS = transactionMISRepository.fetchTransactionMISData(mId);
        return transactionMIS.stream().map(transactionMISMapper::mapToList).collect(Collectors.toList());
    }

}
