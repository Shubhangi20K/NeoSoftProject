package com.epay.reporting.config;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;

import java.io.IOException;

/**
 * Class Name: WhitespaceDeserializer
 * *
 * Description: This class is implementation class for String JsonDeserializer.
 * *
 * Author: V1018344(Subhra)
 * Copyright (c) 2025 [State Bank of India]
 * ALl rights reserved
 * *
 * Version: 1.0
 */
public class WhitespaceDeserializer extends JsonDeserializer<String> {
    @Override
    public String deserialize(JsonParser p, DeserializationContext context) throws IOException {
        String value = p.getValueAsString();
        return (value == null || value.trim().isEmpty()) ? null : value;
    }
}
