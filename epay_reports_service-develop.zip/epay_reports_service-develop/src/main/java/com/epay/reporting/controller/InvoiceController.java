package com.epay.reporting.controller;

import com.epay.reporting.dto.ops.OpsReportRequestDto;
import com.epay.reporting.model.response.ReportingResponse;
import com.epay.reporting.service.InvoiceService;
import com.epay.reporting.service.OpsReportService;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Class Name: InvoiceController
 * *
 * Description:This class handles all incoming requests related to invoice management and provides appropriate responses.
 * It interacts with the InvoiceService to process and retrieve invoice data as required by the client
 * *
 * Author: Bhoopendra Rajput
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@RestController
@RequestMapping("/invoice")
@RequiredArgsConstructor
public class InvoiceController {
    private  final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());

    private final InvoiceService invoiceService;

    /**
     * Generates the merchant fees invoice based on the provided merchant ID (MID) and report dates.
     *
     * @param mId The merchant ID (MID) for which the invoice is to be generated.
     * @param reportMonths A list of dates for which the fees invoice needs to be generated.
     * @param response The HTTP response object used to send the generated invoice file.
     * @return ReportingResponse<String> A response containing a success or error message related to the invoice generation.
     */
    @PostMapping("/fees/{mId}")
    @Operation(summary = "Endpoint to provide the invoice.")
        public ReportingResponse<String> generateMerchantFeesInvoice(HttpServletResponse response, @PathVariable String mId, @RequestBody List<String> reportMonths) {
        log.info("Get Invoice called : mId {} & reportMonths {}", mId, reportMonths);
        return invoiceService.generateMerchantFeesInvoice(mId, reportMonths, response);
    }
    /**
     * Generates the merchant gst invoice based on the provided merchant ID (MID) and report dates.
     *
     * @param mId The merchant ID (MID) for which the invoice is to be generated.
     * @param reportMonths A list of dates for which the gst invoice needs to be generated.
     * @param response The HTTP response object used to send the generated invoice file.
     * @return ReportingResponse<String> A response containing a success or error message related to the invoice generation.
     */
    @PostMapping("/gst/{mId}")
    public ReportingResponse<String> generateGstInvoice(HttpServletResponse response, @PathVariable String mId, @RequestBody List<String> reportMonths) {
        log.info("Get Gst called: mId {} & reportMonths {}", mId, reportMonths);
        return invoiceService.generateMerchantGstInvoice(mId, reportMonths, response);
    }

}