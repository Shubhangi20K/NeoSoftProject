package com.epay.reporting.model.request;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import static com.epay.reporting.util.ErrorConstants.HIBERNATOR_REQUIRED_ERROR_MESSAGE;

/**
 * Class Name: TransactionSummaryRequest
 * Description: This class is used to represent the request data for fetching transaction summary information within
 * a specified date range. It contains fields for the start and end dates to filter transactions accordingly.
 * Author: Bhoopendra Rajput
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * Version: 1.0
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TransactionSummaryRequest {
    @NotBlank(message = HIBERNATOR_REQUIRED_ERROR_MESSAGE)
    private String fromDate;
    @NotBlank(message = HIBERNATOR_REQUIRED_ERROR_MESSAGE)
    private String toDate;

}
