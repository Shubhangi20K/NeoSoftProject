package com.epay.reporting.mapper;

import com.epay.reporting.entity.view.MerchantWisePayoutMisFormat;
import org.apache.commons.lang3.StringUtils;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;

import java.math.BigDecimal;
import java.util.List;

import static org.thymeleaf.util.ObjectUtils.nullSafe;

@Mapper(builder = @Builder(disableBuilder = true), componentModel = "spring")
public interface MerchantPayoutMapper {
    default List<Object> mapToList(MerchantWisePayoutMisFormat merchantWisePayoutMisFormat){
        return List.of(
                nullSafe(merchantWisePayoutMisFormat.getMId(), StringUtils.EMPTY),
                nullSafe(merchantWisePayoutMisFormat.getMerchantName(), StringUtils.EMPTY),
                nullSafe(merchantWisePayoutMisFormat.getTransactionAmount(), BigDecimal.ZERO),
                nullSafe(merchantWisePayoutMisFormat.getTransactionCurrency(), StringUtils.EMPTY),
                nullSafe(merchantWisePayoutMisFormat.getSettlementAmount(), BigDecimal.ZERO),
                nullSafe(merchantWisePayoutMisFormat.getSettlementCurrency(), StringUtils.EMPTY),
                nullSafe(merchantWisePayoutMisFormat.getCommissionPayable(), BigDecimal.ZERO),
                nullSafe(merchantWisePayoutMisFormat.getGst(), BigDecimal.ZERO),
                nullSafe(merchantWisePayoutMisFormat.getPayoutAmount(), BigDecimal.ZERO),
                nullSafe(merchantWisePayoutMisFormat.getRefundAdjusted(), BigDecimal.ZERO),
                nullSafe(merchantWisePayoutMisFormat.getTdrOnRefundAmount(), BigDecimal.ZERO),
                nullSafe(merchantWisePayoutMisFormat.getGstOnRefundAmount(), BigDecimal.ZERO),
                nullSafe(merchantWisePayoutMisFormat.getNetRefundAmount(), BigDecimal.ZERO),
                nullSafe(merchantWisePayoutMisFormat.getNetPayoutAmount(), BigDecimal.ZERO),
                nullSafe(merchantWisePayoutMisFormat.getPayoutDate(), StringUtils.EMPTY),
                nullSafe(merchantWisePayoutMisFormat.getTransactionCount(), BigDecimal.ZERO)
        );
    }
}
