package com.epay.reporting.config;

import com.epay.reporting.externalservice.MerchantServiceClient;
import com.sbi.epay.authentication.providers.EPayTokenProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Class Name: ApiConfig
 * Description:The ApiConfig class provides the configuration for the API settings, which may include
 * HTTP clients, service endpoints, or other related API configuration parameters. It is
 * loaded during the application's initialization to ensure proper API setup.
 * Author: Bhoopendra Rajput
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * Version: 1.0
 */
@Configuration
public class ApiConfig {

    private final EPayTokenProvider ePayTokenProvider;
    @Value("${external.api.merchant.services.base.path}")
    private String merchantServicesBasePath;

    public ApiConfig(EPayTokenProvider ePayTokenProvider) {
        this.ePayTokenProvider = ePayTokenProvider;
    }

    @Bean
    public MerchantServiceClient constructMerchantServicesClient() {
        return new MerchantServiceClient(merchantServicesBasePath, ePayTokenProvider);
    }

}
