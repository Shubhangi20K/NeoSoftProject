--liquibase formatted sql
--changeset Saurabh:3
CREATE OR REPLACE VIEW "VIEW_MERCHANT_WISE_PAYOUT_MIS_FORMAT" as
select
        A.merchant_id,
        merchant_name,
        sum(debit_amt) as transaction_amount,
        currency_code as transaction_currency,
        sum(debit_amt)   AS settlement_amount,
        settlement_currency,
        sum(commission_payable)  commission_payable,
        sum(commission_gst_payable) gst,
        SUM(B.TXN_AMT)  - sum(commission_payable) - sum(commission_gst_payable)            AS payout_amount,
        SUM(B.refunded_amount)             AS refund_adjusted,
        sum(tdr_on_refund_amount)  AS tdr_on_refund_amount,
        sum(gst_on_refund_amount) as gst_on_refund_amount,
        SUM(B.refunded_amount)                           AS net_refund_amount,
        SUM(B.TXN_AMT)- SUM(B.refunded_amount) - sum(commission_payable) - sum(commission_gst_payable)  AS net_payout_amount,
        max(payout_date) as payout_date,
        sum(transaction_count)  AS transaction_count,
B.mp_id
from
(SELECT
        mi.mid                            AS merchant_id,
        mi.merchant_name,
        SUM(mp.debit_amt)              AS debit_amt,
        sum(order_amount)              as order_amount,
        MIN(mp.currency_code)             AS currency_code,
       'INR'   AS settlement_currency,
        SUM(hf.MERCHANT_FEE_BEARABLE_ABS + hf.customer_fee_bearable_abs) AS commission_payable,
        SUM(hf.merchant_gst_bearable_abs + hf.customer_gst_bearable_abs) AS commission_gst_payable,
        SUM(0)                            AS tdr_on_refund_amount,
        SUM(0)                            AS gst_on_refund_amount,
        MAX(to_char(
            TO_DATE('1970-01-01', 'YYYY-MM-DD') +(pi.created_date / 1000 / 86400), 'DD-MM-YYYY'
        ))                                AS payout_date,
        COUNT(mp.atrn_num)                AS transaction_count,
        mt.mp_id
FROM
    merchant_order_payments_txn mp
    JOIN merchant_info_merch mi
        ON mp.merchant_id = mi.mid
    JOIN merchant_order_hybrid_fee_dtls_txn hf
        ON mp.atrn_num = hf.atrn_num
        AND mp.merchant_id = hf.merchant_id
     JOIN  MERCHANT_PAYOUT mt on
    mt.merchant_id=mp.merchant_id
    JOIN PAYOUT_TXN_MAPPING pm
       ON
       mp.rf_id = pm.rf_id
       and   mt.mp_id=pm.mp_id
       and mp.atrn_num = pm.atrn_num
       and  hextoraw(mt.mp_id) = hextoraw(pm.mp_id)
    JOIN PAYOUT_INFO pi
        ON hextoraw(mt.PI_ID) = hextoraw(pi.pi_id)
GROUP BY
    mi.mid,
    mi.merchant_name,
    mt.mp_id) A, MERCHANT_PAYOUT B
    where
    B.mp_id = A.mp_id
group by
A.merchant_id,
merchant_name,
currency_code,
settlement_currency,
B.mp_id;