--liquibase formatted sql
--changeset Hrishikesh:2
CREATE OR REPLACE  VIEW "VIEW_ORDER_REPORT" ("MID", "TRANSACTION_DATE", "MERCHANT_ORDER_NUMBER", "CUSTOMER_ID", "TRANSACTION_CURRENCY", "ORDER_AMOUNT", "SBI_ORDER_REF_NUMBER", "ORDER_STATUS", "ATTEMPTS") AS
  SELECT MERCHANT_ID                                                                 AS MID,
    TO_DATE('1970-01-01','YYYY-MM-DD')+(CREATED_DATE/1000/86400) AS TRANSACTION_DATE,
    ORDER_REF_NUMBER                                                                 AS MERCHANT_ORDER_NUMBER,
    CUSTOMER_ID                                                                      AS CUSTOMER_ID,
    CURRENCY_CODE                                                                    AS TRANSACTION_CURRENCY,
    ORDER_AMOUNT                                                                     AS ORDER_AMOUNT,
    SBI_ORDER_REF_NUMBER                                                             AS SBI_ORDER_REF_NUMBER,
    STATUS                                                                           AS ORDER_STATUS,
    ORDER_RETRY_COUNT                                                                AS ATTEMPTS
  FROM MERCHANT_ORDERS_TXN;

