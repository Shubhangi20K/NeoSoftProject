 --liquibase formatted sql
 --changeset Saurabh:1
 CREATE OR REPLACE  VIEW "VIEW_SBIEPAY_AGG_BANKSTMT_REPORT" ("MERCHANT_ID", "MERCHANT_CATEGORY", "MERCHANT_NAME", "ORDER_REF_NUMBER", "ATRN_NUM", "TRANSACTION_DATE", "ORDER_AMOUNT", "CURRENCY_CODE", "TRANSACTION_STATUS", "ETL_UPLOAD_DATE", "ETL_STATUS", "CHANNEL_BANK", "GATEWAY_TRACE_NUMBER", "PAY_MODE", "GATEWAY_STATUS") AS
  SELECT
        mp.merchant_id,
        '' AS merchant_category,
        mi.merchant_name,
        mp.order_ref_number,
        mp.atrn_num,
        TO_CHAR(TO_DATE('1970-01-01','YYYY-MM-DD')+(CREATED_DATE/1000/86400),'DD-MM-YYYY HH24:MI:SS') AS TRANSACTION_DATE,
        mp.order_amount,
        mp.currency_code,
        mp.transaction_status,
        '' AS etl_upload_date,
        '' AS etl_status,
        mp.channel_bank,
        '' AS gateway_trace_number,
        mp.pay_mode,
        '' AS gateway_status
    FROM
        merchant_order_payments_txn mp,
        merchant_info_merch         mi
    WHERE
        mp.merchant_id = mi.mid;