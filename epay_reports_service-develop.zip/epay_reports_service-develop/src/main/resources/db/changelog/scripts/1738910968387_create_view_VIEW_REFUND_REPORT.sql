--liquibase formatted sql
--changeset Subhra:1
CREATE OR REPLACE  VIEW VIEW_REFUND_REPORT  AS
  SELECT
    T.MERCHANT_ID                                         AS MID,
    DATE '1970-01-01' + ( R.CREATED_DATE / 1000 ) / 86400 AS REFUND_BOOKING_DATE,
    O.ORDER_REF_NUMBER                                    AS MERCHANT_ORDER_NUMBER,
    O.CUSTOMER_ID                                         AS CUSTOMER_ID,
    O.CURRENCY_CODE                                       AS TRANSACTION_CURRENCY,
    O.ORDER_AMOUNT                                        AS ORDER_AMOUNT,
    T.DEBIT_AMT                                           AS DEBIT_AMOUNT,
    0                                                     AS MERCHANT_POSTING_AMOUNT,
    0                                                     AS GATEWAY_POSTING_AMOUNT,
    O.SBI_ORDER_REF_NUMBER                                AS SBI_ORDER_REF_NUMBER,
    O.STATUS                                              AS ORDER_STATUS,
    T.ATRN_NUM                                            AS ATRN_NUM,
    R.REFUND_TYPE                                         AS REFUND_TYPE,
    T.TRANSACTION_STATUS                                  AS TRANSACTION_STATUS,
    TO_CHAR(
        T.PAYMENT_SUCCESS_DATE, 'DD/MM/YYYY HH24:MI:SS'
    )                                                     AS TRANSACTION_SUCCESS_DATE_AND_TIME,
    ''                                                    AS REFUND_PROCESSED_DATE,
    R.REFUND_STATUS                                       AS REFUND_STATUS,
    T.PAY_MODE                                            AS PAYMODE_NAME,
    T.CHANNEL_BANK                                        AS BANK_NAME,
    NVL(
        T.AVAILABLE_REFUND_AMOUNT, 0
    )                                                     AS AMOUNT_REFUNDED,
    ''                                                    AS FURTHER_REFUND_ALLOWED,
    NVL(
        R.REFUND_AMOUNT - T.AVAILABLE_REFUND_AMOUNT, 0
    )                                                     AS PENDING_AMOUNT_FOR_REFUND,
    T.BANK_REFERENCE_NUMBER,
    0                                                     AS SETTLED_AMOUNT,
    NVL(
        R.REFUND_AMOUNT - T.AVAILABLE_REFUND_AMOUNT, 0
    )                                                        AS REFUND_AMOUNT,
    0                                                     AS CHARGEBACK_AMOUNT,
    R.REMARK                                              AS REMARK,R.ARRN_NUM
FROM
    MERCHANT_ORDER_PAYMENTS_TXN        T,
    MERCHANT_ORDERS_TXN                O,
    MERCHANT_ORDER_HYBRID_FEE_DTLS_TXN H,
    REFUND_BOOKING_TXN                 R
WHERE
    T.MERCHANT_ID = R.MERCHANT_ID
    AND T.ATRN_NUM = R.ATRN_NUM
    AND T.ATRN_NUM = H.ATRN_NUM
    AND T.ORDER_REF_NUMBER = O.ORDER_REF_NUMBER
    AND T.MERCHANT_ID = O.MERCHANT_ID
    AND T.SBI_ORDER_REF_NUMBER = O.SBI_ORDER_REF_NUMBER
    AND T.SBI_ORDER_REF_NUMBER = R.SBI_ORDER_REF_NUMBER;

