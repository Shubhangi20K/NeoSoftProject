--liquibase formatted sql
--changeset Saurabh:2
CREATE OR REPLACE  VIEW "VIEW_TRANSACTION_WISE_REFUND_FORMAT"  AS
  SELECT
        mp.rf_id               AS settlement_file_number,
        to_char(
            TO_DATE('1970-01-01', 'YYYY-MM-DD') +(mp.settlement_time / 1000 / 86400), 'DD-MM-YYYY HH24:MI:SS'
        )                AS settlement_time,
        mp.merchant_id,
        mi.merchant_name,
        mp.order_ref_number as MERCHANT_ORDER_NUMBER,
        mp.atrn_num as TRANSACTION_ID,
         to_char(
            TO_DATE('1970-01-01', 'YYYY-MM-DD') +(mp.created_date / 1000 / 86400), 'DD-MM-YYYY HH24:MI:SS'
        )                AS transaction_date,
        mp.currency_code as transaction_currency,
        mp.debit_amt as transaction_amt,
        mp.currency_code AS refund_currency,
        rb.refund_amount AS refund_amt,
        0             AS commission_payable,
        0 as gst,
        rb.REFUND_AMOUNT                AS net_refund_amount,
        mp.channel_bank as gateway_name,
        mp.bank_reference_number               AS gateway_trace_number,
        mp.pay_mode,
        rb.refund_type,
        to_char(
            TO_DATE('1970-01-01', 'YYYY-MM-DD') +(rb.created_date / 1000 / 86400), 'DD-MM-YYYY HH24:MI:SS'
        )                AS refund_booking_date,
        rb.arrn_num,
        rb.payout_id as mp_id
    FROM
        merchant_order_payments_txn        mp,
        merchant_orders_txn                mo,
        merchant_info_merch                mi,
        merchant_order_hybrid_fee_dtls_txn hf,
        refund_booking_txn                 rb
    WHERE
        mp.merchant_id = mi.mid
        AND mp.merchant_id = mo.merchant_id
        AND mp.sbi_order_ref_number = mo.sbi_order_ref_number
        AND mp.merchant_id = hf.merchant_id
        AND mp.atrn_num = hf.atrn_num
        AND mp.merchant_id = rb.merchant_id
        AND mp.atrn_num = rb.atrn_num
        AND mp.refund_status IS NOT NULL
        AND rb.refund_adjusted='Y'
        AND rb.payout_id IS NOT NULL;