--liquibase formatted sql
--changeset Subhra:0
CREATE OR REPLACE VIEW "VIEW_TRANSACTION_DASHBOARD_REPORT" ("MID", "TOTAL_TRANSACTION_COUNT", "TOTAL_ORDER_AMOUNT", "TOTAL_REFUND_AMOUNT", "TOTAL_TAX_AMOUNT", "TOTAL_NET_SETTLEMENT_AMOUNT", "TOTAL_SETTLED_AMOUNT", "TOTAL_PENDING_SETTLEMENT_AMOUNT", "TRANSACTION_DATE") AS
  SELECT A.MERCHANT_ID                                                                                                                                    AS MID,
  COUNT(*)                                                                                                                                              AS TOTAL_TRANSACTION_COUNT,
  SUM(NVL(A.ORDER_AMOUNT,0))                                                                                                                               AS TOTAL_ORDER_AMOUNT,
  SUM(NVL(C.REFUND_AMOUNT,0))                                                                                                                           AS TOTAL_REFUND_AMOUNT,
  SUM(B.MERCHANT_FEE_BEARABLE_ABS + B.CUSTOMER_FEE_BEARABLE_ABS + B.MERCHANT_GST_BEARABLE_ABS + B.CUSTOMER_GST_BEARABLE_ABS)                              AS TOTAL_TAX_AMOUNT,
  SUM(NVL(A.ORDER_AMOUNT,0) -      (B.MERCHANT_FEE_BEARABLE_ABS + B.CUSTOMER_FEE_BEARABLE_ABS + B.MERCHANT_GST_BEARABLE_ABS + B.CUSTOMER_GST_BEARABLE_ABS))-SUM(NVL(C.REFUND_AMOUNT,0))-SUM(NVL(A.CHARGEBACK_AMOUNT,0)) AS TOTAL_NET_SETTLEMENT_AMOUNT,
  0.00                                                                                                                                                  AS TOTAL_SETTLED_AMOUNT,
  SUM(NVL(A.ORDER_AMOUNT,0) -      (B.MERCHANT_FEE_BEARABLE_ABS + B.CUSTOMER_FEE_BEARABLE_ABS + B.MERCHANT_GST_BEARABLE_ABS + B.CUSTOMER_GST_BEARABLE_ABS))-SUM(NVL(C.REFUND_AMOUNT,0))-SUM(NVL(A.CHARGEBACK_AMOUNT,0))       AS TOTAL_PENDING_SETTLEMENT_AMOUNT,
  TRUNC(TO_DATE('1970-01-01','YYYY-MM-DD')+(A.CREATED_DATE/1000/86400))                                                                                                                                AS TRANSACTION_DATE
FROM MERCHANT_ORDER_PAYMENTS_txn A
INNER JOIN MERCHANT_ORDER_HYBRID_FEE_DTLS_TXN B
ON A.ATRN_NUM    =B.ATRN_NUM
AND A.MERCHANT_ID=B.MERCHANT_ID
LEFT JOIN
  (SELECT ATRN_NUM ,
    SUM(REFUND_AMOUNT) AS REFUND_AMOUNT
  FROM REFUND_BOOKING_TXN
  GROUP BY ATRN_NUM
  ) C
ON A.ATRN_NUM              = C.ATRN_NUM
WHERE A.TRANSACTION_STATUS = 'SUCCESS'
GROUP BY A.MERCHANT_ID,
  TRUNC(TO_DATE('1970-01-01','YYYY-MM-DD')+(A.CREATED_DATE/1000/86400))
  ORDER BY TRUNC(TO_DATE('1970-01-01','YYYY-MM-DD')+(A.CREATED_DATE/1000/86400));