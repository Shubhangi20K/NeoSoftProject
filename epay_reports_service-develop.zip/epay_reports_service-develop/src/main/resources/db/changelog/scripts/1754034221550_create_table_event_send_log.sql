--liquibase formatted sql
--changeset REPORT:1

CREATE TABLE EVENT_SEND_LOG(
        ESL_ID              RAW(16) DEFAULT SYS_GUID() PRIMARY KEY,
        INTERFACE_TYPE      VARCHAR2(50),
        TOPIC               VARCHAR2(50),
        ROUTING_KEY         VARCHAR2(150),
        MESSAGE             CLOB,
        CREATED_AT          NUMBER NOT NULL,
        UPDATED_AT          NUMBER
 );