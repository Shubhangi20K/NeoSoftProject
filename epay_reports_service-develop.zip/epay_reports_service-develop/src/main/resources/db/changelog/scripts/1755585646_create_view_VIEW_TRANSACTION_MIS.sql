--liquibase formatted sql
--changeset Saurabh:1
CREATE OR REPLACE  VIEW "VIEW_TRANSACTION_MIS" ("MERCHANT_ID", "MERCHANT_NAME", "MERCHANT_CATEGORY", "ORDER_REF_NUMBER", "ATRN_NUM", "INSTRUCTION_DATEAND_TIME", "CURRENCY_CODE", "ORDER_AMOUNT", "TOTAL_FEE_ABS", "GST_NUMBER", "GATEWAY_POSTING_AMOUNT", "AMOUNT_SETTLED", "AVAILABLE_REFUND_AMOUNT", "PAY_MODE", "CHANNEL_BANK", "GATEWAY_TRACE_NUMBER", "TRANSACTION_STATUS", "REMARK", "MERCHANT_RISK_CATEGORY", "ACCESS_MEDIUM", "PAY_PROC_ID", "PAY_PROC_TYPE", "MERCHANT_AUTHORIZE", "MERCHANT_AUTHORIZE_DATE", "AUTO_SETTLEMENT", "BEARABLE_ENTITY", "CIN", "FAIL_REASON", "MERCHANT_FEE_BEARABLE_ABS", "MERCHANT_GST_BEARABLE_ABS", "CUSTOMER_FEE_BEARABLE_ABS", "CUSTOMER_GST_BEARABLE_ABS", "SUB_STATUS_DESCRIPTION", "PAYMENT_SUCCESS_DATE", "RF_ID") AS
  SELECT
        mp.merchant_id,
        mi.merchant_name,
        ''                                                                                AS merchant_category,
        mp.order_ref_number,
        mp.atrn_num,
        0                                                                                 AS instruction_dateand_time,
        mp.currency_code,
        mp.order_amount,
        hf.merchant_fee_bearable_abs                                                      AS total_fee_abs,
        mi.gst_number,
        ( mp.order_amount + hf.merchant_fee_bearable_abs + hf.merchant_gst_bearable_abs ) AS gateway_posting_amount,
        mp.debit_amt                                                                      AS amount_settled,
        mp.available_refund_amount,
        mp.pay_mode,
        mp.channel_bank,
        ''                                                                                AS gateway_trace_number,
        mp.transaction_status,
        ''                                                                                AS remark,
        ''                                                                                AS merchant_risk_category,
        ''                                                                                AS access_medium,
        mp.pay_proc_id,
        mp.pay_proc_type,
        ''                                                                                AS merchant_authorize,
        0                                                                                 AS merchant_authorize_date,
        ''                                                                                AS auto_settlement,
        hf.bearable_entity,
        mp.cin,
        mp.fail_reason,
        hf.merchant_fee_bearable_abs,
        hf.merchant_gst_bearable_abs,
        hf.customer_fee_bearable_abs,
        hf.customer_gst_bearable_abs,
        ''                                                                                AS sub_status_description,
        mp.payment_success_date,
        mp.rf_id
    FROM
        merchant_order_payments_txn        mp,
        merchant_info_merch                mi,
        merchant_order_hybrid_fee_dtls_txn hf
    WHERE
        mp.merchant_id = mi.mid
        AND mp.merchant_id = hf.merchant_id
        AND mp.atrn_num = hf.atrn_num;

