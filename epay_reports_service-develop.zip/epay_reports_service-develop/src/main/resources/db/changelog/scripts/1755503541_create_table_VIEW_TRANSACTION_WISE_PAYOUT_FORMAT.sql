--liquibase formatted sql
--changeset Saurabh:1
CREATE OR REPLACE VIEW "VIEW_TRANSACTION_WISE_PAYOUT_FORMAT" ("SETTLEMENT_FILE_NUMBER", "SETTLEMENT_TIME", "MERCHANT_ID", "MERCHANT_NAME", "MERCHANT_ORDER_NO", "TRANSACTION_ID", "TRANSACTION_BOOKING_DATE", "TRANSACTION_CURRENCY", "TRANSACTION_AMOUNT", "SETTLEMENT_CURRENCY", "SETTLEMENT_AMOUNT", "COMMISSION_PAYABLE", "GST", "PAYOUT_AMOUNT", "GATEWAY_NAME", "GATEWAY_TRACE_NUMBER", "PAY_MODE", "PAY_PROC_ID", "OTHER_DETAILS", "TRANSACTION_FEE_FLAG", "CIN", "RF_ID", "MP_ID") AS
  SELECT
        mp.rf_id               AS settlement_file_number,
        to_char(
            TO_DATE('1970-01-01', 'YYYY-MM-DD') +(mp.settlement_time / 1000 / 86400), 'DD-MM-YYYY HH24:MI:SS'
        )                AS settlement_time,
        mp.merchant_id,
        mi.merchant_name,
        mp.order_ref_number as merchant_order_no,
        mp.atrn_num as transaction_id,
        to_char(
            TO_DATE('1970-01-01', 'YYYY-MM-DD') +(mp.created_date / 1000 / 86400), 'DD-MM-YYYY HH24:MI:SS'
        )                AS transaction_booking_date,
        mp.currency_code as transaction_currency,
        mp.debit_amt as transaction_amount,
        mp.currency_code AS settlement_currency,
        mp.debit_amt            AS settlement_amount,
         hf.MERCHANT_FEE_BEARABLE_ABS  + hf.customer_fee_bearable_abs              AS commission_payable,
        hf.merchant_gst_bearable_abs + hf.customer_gst_bearable_abs as gst,
        mp.order_amount -hf.MERCHANT_FEE_BEARABLE_ABS -   hf.merchant_gst_bearable_abs             AS payout_amount,
        mp.channel_bank as gateway_name,
        mp.bank_reference_number               AS gateway_trace_number,
        mp.pay_mode,
        mp.pay_proc_id,
        mo.other_details,
        hf.bearable_entity as transaction_fee_flag,
        mp.cin,
        mp.rf_id,
        pm.mp_id
    FROM
        merchant_order_payments_txn        mp,
        merchant_orders_txn                mo,
        merchant_info_merch                mi,
        merchant_order_hybrid_fee_dtls_txn hf,
        merchant_payout                    mt,
        payout_txn_mapping                 pm
    WHERE
        mp.merchant_id = mi.mid
        AND mp.merchant_id = mo.merchant_id
        AND mp.sbi_order_ref_number = mo.sbi_order_ref_number
        AND mp.merchant_id = hf.merchant_id
        AND mp.atrn_num = hf.atrn_num
        and hf.atrn_num=pm.atrn_num
        AND mt.mp_id = pm.mp_id
        AND mt.merchant_id = mp.merchant_id
        AND pm.atrn_num = mp.atrn_num;