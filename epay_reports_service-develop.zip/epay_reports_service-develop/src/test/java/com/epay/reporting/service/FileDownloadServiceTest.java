package com.epay.reporting.service;

import com.epay.reporting.exception.ReportingException;
import com.epay.reporting.util.ErrorConstants;
import com.epay.reporting.util.enums.ReportFormat;
import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class FileDownloadServiceTest {

    @InjectMocks
    private FileDownloadService fileDownloadService;

    @Mock
    private HttpServletResponse mockResponse;

    @Mock
    private ServletOutputStream mockOutputStream;

    @BeforeEach
    void setUp() throws IOException {
        MockitoAnnotations.openMocks(this);
        when(mockResponse.getOutputStream()).thenReturn(mockOutputStream);
    }

    @Test
    void testDownloadFile_csvFormat() throws IOException {
        String filePath = "src/test/resources/file.csv";
        InputStream mockInputStream = new ByteArrayInputStream("test data".getBytes());

        FileDownloadService spyService = spy(fileDownloadService);
        doReturn(mockInputStream).when(spyService).getFileContent(filePath);

        spyService.downloadFile(mockResponse, ReportFormat.CSV, filePath);

        verify(mockResponse).setContentType("text/csv");
        verify(mockResponse).setHeader("Content-Disposition", "attachment;filename=file.csv");
        verify(mockOutputStream, atLeastOnce()).write(any(byte[].class), anyInt(), anyInt());
    }

    @Test
    void testDownloadFile_xlsxFormat() throws IOException {
        String filePath = "src/test/resources/file.xlsx";
        InputStream mockInputStream = new ByteArrayInputStream("test data".getBytes());

        FileDownloadService spyService = spy(fileDownloadService);
        doReturn(mockInputStream).when(spyService).getFileContent(filePath);

        spyService.downloadFile(mockResponse, ReportFormat.XLSX, filePath);

        verify(mockResponse).setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        verify(mockResponse).setHeader("Content-Disposition", "attachment;filename=file.xlsx");
    }

    @Test
    void testDownloadFile_pdfFormat() throws IOException {
        String filePath = "src/test/resources/Report.pdf";
        InputStream mockInputStream = new ByteArrayInputStream("test data".getBytes());

        FileDownloadService spyService = spy(fileDownloadService);
        doReturn(mockInputStream).when(spyService).getFileContent(filePath);

        spyService.downloadFile(mockResponse, ReportFormat.PDF, filePath);

        verify(mockResponse).setContentType("application/pdf");
        verify(mockResponse).setHeader("Content-Disposition", "attachment;filename=Report.pdf");
        verify(mockOutputStream, atLeastOnce()).write(any(byte[].class), anyInt(), anyInt());
    }

    @Test
    void testDownloadFile_fileNotFound() {
        String filePath = "nonexistent.csv";

        FileDownloadService spyService = spy(fileDownloadService);
        doThrow(new ReportingException(ErrorConstants.NOT_FOUND_ERROR_CODE, "File not found"))
                .when(spyService).getFileContent(filePath);

        assertThrows(ReportingException.class, () ->
                spyService.downloadFile(mockResponse, ReportFormat.CSV, filePath));
    }
}