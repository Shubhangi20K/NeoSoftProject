package com.epay.reporting.service;

import com.epay.reporting.externalservice.MerchantServiceClient;
import com.epay.reporting.model.response.ReportingResponse;
import com.epay.reporting.util.ReportingConstant;
import com.sbi.epay.authentication.model.EPayPrincipal;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.Collections;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SecurityServiceTest {

    @InjectMocks
    SecurityService securityService;

    @Mock
    MerchantServiceClient merchantServiceClient;


    @Test
    void testLoadUserByUserName_Success() {
        String [] users  ={"testUser" ,"USER"};
        String userName = users[0];

        when(merchantServiceClient.validateMerchantUser(userName)).thenReturn(ReportingResponse.<String>builder().status(1).build());
        // When
        Optional<EPayPrincipal> result = securityService.loadUserByUserName(String.join(":",users));

        assertTrue(result.isPresent(), "Expected an EPayPrincipal object");
        assertEquals(userName, result.get().getAuthenticationId(), "Authentication ID should match the username");
        verify(merchantServiceClient, times(1)).validateMerchantUser(userName);
    }

    @Test
    void testIsTokenInValid_Success() {

        String token = "validToken";
        String tokenType = "USER";
        when(merchantServiceClient.validateMerchantToken(token)).thenReturn(ReportingResponse.<String>builder().status(1).build());
        boolean result = securityService.isTokenInValid(token, tokenType);
        assertFalse(result, "Expected token to be valid");
        verify(merchantServiceClient, times(1)).validateMerchantToken(token);
    }

}