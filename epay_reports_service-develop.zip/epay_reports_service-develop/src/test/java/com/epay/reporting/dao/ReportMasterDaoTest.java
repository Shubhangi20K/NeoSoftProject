package com.epay.reporting.dao;

import com.epay.reporting.dto.ReportMasterDto;
import com.epay.reporting.entity.ReportMaster;
import com.epay.reporting.exception.ReportingException;
import com.epay.reporting.mapper.ReportMasterMapper;
import com.epay.reporting.repository.ReportMasterRepository;
import com.epay.reporting.util.ErrorConstants;
import com.epay.reporting.util.enums.Report;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.text.MessageFormat;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class ReportMasterDaoTest {

    @InjectMocks
    ReportMasterDao reportMasterDao;

    @Mock
    private  ReportMasterRepository reportMasterRepository;
    @Mock
    private  ReportMasterMapper reportMasterMapper;

    ReportMaster reportMaster;

    Report report;

    UUID reportId=UUID.randomUUID();
    Optional<ReportMaster> masterOptional;
    @BeforeEach
    void setUp(){
        reportMaster=ReportMaster.builder().name(Report.REFUNDS).build();
        masterOptional=Optional.of(reportMaster);
        report=Report.REFUNDS;
    }

    @Test
    void testGetAllReportNames(){
        List<ReportMaster> reportMasterList = Arrays.asList(reportMaster);
        List<ReportMasterDto> reportMasterDtoList=Arrays.asList(ReportMasterDto.builder().name(Report.REFUNDS).build());
        when(reportMasterRepository.findAll()).thenReturn(reportMasterList);
        when(reportMasterMapper.mapEntityListToDtoList(reportMasterList)).thenReturn(reportMasterDtoList);
        List<ReportMasterDto> allReportNames = reportMasterDao.getAllReportNames();
        assertEquals(Report.REFUNDS,allReportNames.getFirst().getName());
    }

    @Test
    void testGetReportIdByName_Success(){
        when(reportMasterRepository.findByName(report)).thenReturn(masterOptional);
        reportMasterDao.getReportIdByName(report);
        verify(reportMasterRepository,times(1)).findByName(report);
    }

    @Test
    void testGetReportIdByName_ThrowsException_WhenNotFound() {
        when(reportMasterRepository.findByName(report)).thenReturn(Optional.empty());

        ReportingException thrown = assertThrows(ReportingException.class, () -> {
            reportMasterDao.getReportIdByName(report);
        });

        assertEquals(ErrorConstants.NOT_FOUND_ERROR_CODE, thrown.getErrorCode());
        assertEquals(MessageFormat.format(ErrorConstants.NOT_FOUND_ERROR_MESSAGE, "report"), thrown.getMessage());

    }


    @Test
    void testGetReportNameById_Success() {
        when(reportMasterRepository.findById(reportId)).thenReturn(Optional.of(reportMaster));

        Report result = reportMasterDao.getReportNameById(reportId);

        assertNotNull(result);
        assertEquals(Report.REFUNDS, result);
        verify(reportMasterRepository, times(1)).findById(reportId);
    }

    @Test
    void testGetReportNameById_ThrowsException_WhenNotFound() {
        when(reportMasterRepository.findById(reportId)).thenReturn(Optional.empty());

        ReportingException thrown = assertThrows(ReportingException.class, () -> {
            reportMasterDao.getReportNameById(reportId);
        });

        assertEquals(ErrorConstants.NOT_FOUND_ERROR_CODE, thrown.getErrorCode());
        assertEquals(MessageFormat.format(ErrorConstants.NOT_FOUND_ERROR_MESSAGE, "Report"), thrown.getMessage());

        verify(reportMasterRepository, times(1)).findById(reportId);
    }
}
