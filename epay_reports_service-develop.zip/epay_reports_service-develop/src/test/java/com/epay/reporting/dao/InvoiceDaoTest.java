package com.epay.reporting.dao;

import com.epay.reporting.entity.view.MerchantFeesReport;
import com.epay.reporting.repository.view.InvoiceRepository;
import com.epay.reporting.util.DateTimeUtils;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class InvoiceDaoTest {

    @InjectMocks
    InvoiceDao invoiceDao;
    @Mock
    private InvoiceRepository invoiceRepository;

    String mId="mid";
    List<String> dateList = Arrays.asList("date");

    @Test
    void testGetFeesInvoiceData(){
        List<MerchantFeesReport> merchantFeesReports = Arrays.asList(MerchantFeesReport.builder().city("thane").transactionDate("May-2025").merchantFeeAmount(BigDecimal.ONE).merchantServiceTaxAmount(BigDecimal.TEN).merchantTotalCommission(BigDecimal.ZERO).build());
        when(invoiceRepository.getMerchantFeesInvoice(mId, dateList)).thenReturn(merchantFeesReports);

        List<Map<String, Object>> feesInvoiceData = invoiceDao.getFeesInvoiceData(mId, dateList);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        String formattedDate=DateTimeUtils.getCurrentDate(formatter);

        assertEquals(formattedDate,feesInvoiceData.getFirst().get("date"));
    }
}
