package com.epay.reporting.service;

import com.epay.reporting.config.ReportingConfig;
import com.epay.reporting.dao.TransactionDashboardDao;
import com.epay.reporting.entity.view.RecentTransactionReport;
import com.epay.reporting.entity.view.TransactionPaymodeReport;
import com.epay.reporting.entity.view.TransactionSummaryReport;
import com.epay.reporting.model.request.RecentTransactionRequest;
import com.epay.reporting.model.request.TransactionPayModeRequest;
import com.epay.reporting.model.request.TransactionSummaryRequest;
import com.epay.reporting.model.response.ReportingResponse;
import com.epay.reporting.util.enums.Frequency;
import com.epay.reporting.util.enums.Report;
import com.epay.reporting.util.enums.ReportFormat;
import com.epay.reporting.util.file.model.CSVFileModel;
import com.epay.reporting.util.file.model.FileModel;
import com.epay.reporting.validator.MIdValidator;
import com.epay.reporting.validator.TransactionDashboardValidator;
import jakarta.servlet.http.HttpServletResponse;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class TransactionDashboardServiceTest {

  static final String MID = "mid";

  @InjectMocks TransactionDashboardService transactionDashboardService;

  @Mock TransactionDashboardDao transactionDashboardDao;
  @Mock private MIdValidator mIdValidator;
  @Mock private TransactionDashboardValidator transactionDashboardValidator;
  @Mock private HttpServletResponse httpResponse;
  @Mock private ReportingConfig reportingConfig;
  @Mock private FileGeneratorService fileGeneratorService;

  @Test
  void testGetTransactionTrends() {
    List<TransactionSummaryReport> transactionDailyTrends =
        Collections.singletonList(
            TransactionSummaryReport.builder()
                .totalSuccessAmount("1")
                .totalSuccessCount(1L)
                .build());
    when(transactionDashboardDao.getTransactionTrends(MID, Frequency.DAILY))
        .thenReturn(transactionDailyTrends);
    ReportingResponse<TransactionSummaryReport> transactionTrends =
        transactionDashboardService.getTransactionTrends(MID, Frequency.DAILY.name());
    assertEquals(1, transactionTrends.getData().getFirst().getTotalSuccessCount());
  }

  @Test
  void testGetTransactionPayModeReport() {
    TransactionPayModeRequest transactionPayModeRequest =
        TransactionPayModeRequest.builder().fromDate("2025-01-01").toDate("2025-01-20").build();
    List<TransactionPaymodeReport> transactionPaymodeReportList =
        Collections.singletonList(
            TransactionPaymodeReport.builder()
                .transactionDate("2025-01-01")
                .paymodeCode("paycode")
                .build());
    when(transactionDashboardDao.getTransactionPayModeReport(MID, transactionPayModeRequest))
        .thenReturn(transactionPaymodeReportList);

    ReportingResponse<TransactionPaymodeReport> reportingResponse =
        transactionDashboardService.getTransactionPayModeReport(MID, transactionPayModeRequest);
    assertNotNull(reportingResponse.getData());
  }

  @Test
  void testGetTransactionSummaryReport() {
    TransactionSummaryRequest transactionSummaryRequest =
        TransactionSummaryRequest.builder().fromDate("2025-01-01").build();
    TransactionSummaryReport transactionSummaryReport =
        TransactionSummaryReport.builder().totalFailureCount(30L).build();
    List<TransactionSummaryReport> transactionSummaryReports = new ArrayList<>();
    transactionSummaryReports.add(transactionSummaryReport);
    when(transactionDashboardDao.getTransactionSummaryReport(MID, transactionSummaryRequest))
        .thenReturn(transactionSummaryReports);

    ReportingResponse<TransactionSummaryReport> reportingResponse =
        transactionDashboardService.getTransactionSummaryReport(MID, transactionSummaryRequest);
    assertNotNull(reportingResponse.getData());
  }

  @Test
  void testGetRecentTransactionsSummary() {
    Pageable pageable = PageRequest.of(0, 10);
    RecentTransactionRequest recentTransactionRequest =
        RecentTransactionRequest.builder()
            .fromDate("2025-01-01")
            .toDate("2025-01-31")
            .frequency("DAILY")
            .build();
    doNothing().when(transactionDashboardValidator).validateRequest(MID, recentTransactionRequest);
    List<RecentTransactionReport> recentTransactionReport = new ArrayList<>();
    when(transactionDashboardDao.getRecentTransactionSummary(
            MID, recentTransactionRequest, pageable))
        .thenReturn(new PageImpl<>(recentTransactionReport));
    ReportingResponse<RecentTransactionReport> recentTransactionTrends =
        transactionDashboardService.getRecentTransactionsSummary(
            MID, recentTransactionRequest, pageable);
    assertNotNull(recentTransactionTrends.getData());
  }

  @Test
  void testGetDownloadRecentTransactionReport() {
    Pageable pageable = PageRequest.of(0, 10);

    when(reportingConfig.getReportPageSize()).thenReturn(10);
    RecentTransactionRequest recentTransactionRequest =
        RecentTransactionRequest.builder()
            .fromDate("2025-01-01")
            .toDate("2025-01-31")
            .frequency("DAILY")
            .build();
    doNothing().when(transactionDashboardValidator).validateRequest(MID, recentTransactionRequest);

    RecentTransactionReport rtr =
        RecentTransactionReport.builder()
            .totalOrderAmount("1")
            .totalTransactionCount(1L)
            .build();
    List<RecentTransactionReport> recentTransactionReport = List.of(rtr);
    when(transactionDashboardDao.getRecentTransactionSummary(
            MID, recentTransactionRequest, pageable))
        .thenReturn(new PageImpl<>(recentTransactionReport));

    List<String> headers = transactionDashboardService.getHeaders();
    List<List<Object>> fileData = List.of(transactionDashboardService.convertToListOfObject(rtr));

    FileModel fileModel = CSVFileModel.builder().headers(headers).fileData(fileData).build();

    when(fileGeneratorService.buildFileModel(
            ReportFormat.CSV, headers, fileData, Map.of("headers", headers, "rows", fileData)))
        .thenReturn(CSVFileModel.builder().headers(headers).fileData(fileData).build());

    doNothing()
        .when(fileGeneratorService)
        .downloadFile(httpResponse, ReportFormat.CSV, Report.TRANSACTION, MID, fileModel);

    transactionDashboardService.downloadRecentTransactionReport(
        httpResponse, MID, recentTransactionRequest);

    verify(transactionDashboardDao, times(1))
        .getRecentTransactionSummary(MID, recentTransactionRequest, pageable);
  }
}
