package com.epay.reporting.dao;

import com.epay.reporting.entity.view.RefundSummaryReport;
import com.epay.reporting.repository.view.RefundSummaryRepository;
import com.sbi.epay.logging.utility.LoggerUtility;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class RefundSummaryDaoTest {

    @InjectMocks
    private RefundSummaryDao refundSummaryDao;  // The DAO class to test

    @Mock
    private RefundSummaryRepository refundSummaryRepository;  // Mocked dependency

    @Mock
    private LoggerUtility loggerUtility;  // Mocked logger

    @BeforeEach
    void setUp() {
        // Any setup logic, if necessary.
    }

    @Test
    void testGetDailyRefundSummary_ShouldReturnRefundSummary() {
        // Arrange: Prepare input and mocked repository response
        String merchantId = "12345";
        List<RefundSummaryReport> expectedReport = List.of(RefundSummaryReport.builder().refundCount(1).totalAvailableAmt(BigDecimal.ONE).totalRefundAmt(BigDecimal.ONE).createdDate("").build(), RefundSummaryReport.builder().refundCount(1).totalAvailableAmt(BigDecimal.ONE).totalRefundAmt(BigDecimal.ONE).createdDate("").build());
        when(refundSummaryRepository.getRefundSummaryForCurrentDate(merchantId)).thenReturn(expectedReport);

        // Act: Call the method to test
        List<RefundSummaryReport> result = refundSummaryDao.getDailyRefundSummary(merchantId);

        // Assert: Verify the results
        assertNotNull(result);
        assertEquals(2, result.size());
        assertEquals(expectedReport, result);

        // Verify interactions with the mock repository
        verify(refundSummaryRepository).getRefundSummaryForCurrentDate(merchantId);
    }

    @Test
    void testGetDailyRefundSummary_ShouldReturnEmptyList_WhenNoDataFound() {
        // Arrange: Prepare input and mocked repository response (empty list)
        String merchantId = "67890";
        when(refundSummaryRepository.getRefundSummaryForCurrentDate(merchantId)).thenReturn(List.of());

        // Act: Call the method to test
        List<RefundSummaryReport> result = refundSummaryDao.getDailyRefundSummary(merchantId);

        // Assert: Verify the results
        assertNotNull(result);
        assertTrue(result.isEmpty(), "The result should be an empty list");

        // Verify interactions with the mock repository
    }
}
