package com.epay.reporting.validator;

import com.epay.reporting.dto.ErrorDto;
import com.epay.reporting.exception.ValidationException;
import com.epay.reporting.externalservice.MerchantServiceClient;
import com.epay.reporting.model.response.ReportingResponse;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static com.epay.reporting.util.ErrorConstants.FIXED_LENGTH_ERROR_CODE;
import static com.epay.reporting.util.ErrorConstants.INVALID_ERROR_CODE;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class MIdValidatorTest {

    @Mock
    MerchantServiceClient merchantServiceClient;

    @InjectMocks
    MIdValidator mIdValidator;

    private static final String VALID_MID = "1234567";
    private static final String INVALID_MID = "00000";


    @Test
    void testValidatedActiveMId_Success() {
        when(merchantServiceClient.validateActiveMIdAccess(VALID_MID)).thenReturn(ReportingResponse.<String>builder().status(1).build());
        assertDoesNotThrow(() -> mIdValidator.validateActiveMId (VALID_MID));
    }

    @Test
    void testValidatedActiveMId_Failure() {
        ValidationException exception = assertThrows(ValidationException.class, () -> mIdValidator.validateActiveMId(INVALID_MID));
        assertEquals(FIXED_LENGTH_ERROR_CODE, exception.getErrorMessages().getFirst().getErrorCode());
    }

    @Test
    void validatedMId_Success() {
        when(merchantServiceClient.validateMIdAccess(VALID_MID)).thenReturn(ReportingResponse.<String>builder().status(1).build());
        assertDoesNotThrow(() -> mIdValidator.validateMIdAccess(VALID_MID));
    }
    @Test
    void validatedMId_Failure() {
        ValidationException exception = assertThrows(ValidationException.class, () -> mIdValidator.validateMIdAccess(INVALID_MID));
        assertEquals(FIXED_LENGTH_ERROR_CODE, exception.getErrorMessages().getFirst().getErrorCode());
    }

}

