package com.epay.reporting.validator;

import com.epay.reporting.exception.ValidationException;
import com.epay.reporting.model.request.ReportScheduleManagementRequest;
import com.epay.reporting.model.request.ReportScheduleManagementSearchRequest;
import com.epay.reporting.util.enums.Frequency;
import com.epay.reporting.util.enums.Report;
import com.epay.reporting.util.enums.ReportFormat;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class ReportScheduleManagementValidatorTest {

    @InjectMocks
    private ReportScheduleManagementValidator validator;
    private final String mId="12345";

    @Mock
    private MIdValidator mIdValidator;

    private ReportScheduleManagementRequest validRequest() {
        return ReportScheduleManagementRequest.builder().mId(mId).report(Report.ORDER.name()).frequency(Frequency.DAILY.name()).format(ReportFormat.CSV.name()).scheduleExecutionTime("9:00 PM").build();
    }

    private ReportScheduleManagementSearchRequest validSearchRequest() {
        return ReportScheduleManagementSearchRequest.builder().mId(mId).build();
    }

    @Test
    void testValidateRequest_shouldThrowExceptionForMissingFields() {
        ReportScheduleManagementRequest request = ReportScheduleManagementRequest.builder().build();
        assertThrows(ValidationException.class, () -> validator.validateRequest(request));
    }

    @Test
    void testValidateRequest_shouldThrowExceptionForInvalidValues() {
        ReportScheduleManagementRequest request = new ReportScheduleManagementRequest();

        assertThrows(ValidationException.class, () -> validator.validateRequest(request));
    }

    @Test
    void testValidateRequest_shouldSuccessfully() {
        assertDoesNotThrow(() -> validator.validateRequest(validSearchRequest()));
    }

    @Test
    void testValidateRequest_shouldThrowExceptionForMissingMIdInSearchRequest() {
        ReportScheduleManagementSearchRequest request = ReportScheduleManagementSearchRequest.builder().build();
        assertThrows(ValidationException.class, () -> validator.validateRequest(request));
    }
}