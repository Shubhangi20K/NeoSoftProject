package com.epay.reporting.service;

import com.epay.reporting.dao.ReportMasterDao;
import com.epay.reporting.dto.ReportMasterDto;
import com.epay.reporting.model.response.ReportingResponse;
import com.epay.reporting.util.ReportingConstant;
import com.epay.reporting.util.enums.Report;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import java.util.Arrays;
import java.util.List;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

/**
 * Class Name: ReportMasterServiceTest
 * *
 * Description:
 * *
 * Author: V1018344
 * Copyright (c) 2025 [State Bank of India]
 * ALl rights reserved
 * *
 * Version: 1.0
 */

@ExtendWith(MockitoExtension.class)
class ReportMasterServiceTest {

    @InjectMocks
    ReportMasterService reportMasterService;

    @Mock
    ReportMasterDao reportMasterDao;

    @Test
    void testGetAllReportNames() {
        List<ReportMasterDto> reportMasterList = Arrays.asList(ReportMasterDto.builder().name(Report.ORDER).description("Order").build(),
                ReportMasterDto.builder().name(Report.TRANSACTION).description("Transaction").build());
        when(reportMasterDao.getAllReportNames()).thenReturn(reportMasterList);

        ReportingResponse<ReportMasterDto> reportingResponse =  reportMasterService.getAllReportNames();
        assertEquals(ReportingConstant.RESPONSE_SUCCESS,reportingResponse.getStatus());

    }


}