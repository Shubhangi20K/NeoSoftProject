package com.epay.reporting.service;

import com.epay.reporting.dao.ReportManagementDao;
import com.epay.reporting.dto.ReportManagementDto;
import com.epay.reporting.mapper.ReportManagementMapper;
import com.epay.reporting.model.request.DownloadRequest;
import com.epay.reporting.model.request.ReportManagementRequest;
import com.epay.reporting.model.response.ReportManagementResponse;
import com.epay.reporting.model.response.ReportingResponse;
import com.epay.reporting.util.enums.ReportStatus;
import com.epay.reporting.validator.ReportManagementValidator;
import jakarta.servlet.http.HttpServletResponse;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;

import java.util.List;
import java.util.UUID;

import static com.epay.reporting.util.ReportingConstant.REPORT_GENERATION_REQ_RECEIVED_SUCCESS;
import static com.epay.reporting.util.ReportingConstant.RESPONSE_SUCCESS;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.*;

/**
 * Class Name: ReportManagementServiceTest * Description: * Author: V1018344 Copyright (c) 2025 [State Bank of India]
 * ALl rights reserved * Version: 1.0
 */
@ExtendWith(MockitoExtension.class)
class ReportManagementServiceTest {
    @InjectMocks
    ReportManagementService reportManagementService;

    @Mock
    ReportManagementDao reportManagementDao;

    @Mock
    ReportManagementMapper mapper;

    @Mock
    ReportManagementValidator reportManagementValidator;

    @Mock
    private HttpServletResponse httpResponse;
    @Mock
    private FileGeneratorService fileGeneratorService;

    private final String mId = "mid";

    @Test
    void testSearchAndGetReportManagement() {

        Page<ReportManagementDto> reportManagementDTOs = new PageImpl<>(List.of(), PageRequest.of(0, 10), 2);

        doNothing().when(reportManagementValidator).validateSearchRequest(any());
        when(reportManagementDao.searchAndGetReportManagement(any(), any())).thenReturn(reportManagementDTOs);
        when(mapper.mapDtoListToResponseList(anyList())).thenReturn(List.of());

        ReportingResponse<ReportManagementResponse> reportManagementResponseReportingResponse = reportManagementService.searchAndGetReportManagement(ReportManagementRequest.builder().mId(mId).build(), PageRequest.of(0, 10));
        assertNotNull(reportManagementResponseReportingResponse);
        assertEquals(RESPONSE_SUCCESS, reportManagementResponseReportingResponse.getStatus());
    }

    @Test
    void testSaveReportManagement() {
        doNothing().when(reportManagementValidator).validateRequest(any());
        when(mapper.mapRequestToDto(any())).thenReturn(ReportManagementDto.builder().mId(mId).build());
        doNothing().when(reportManagementDao).saveReportManagement(any());

        ReportingResponse<String> reportingResponse = reportManagementService.save(ReportManagementRequest.builder().mId(mId).build());
        assertEquals(REPORT_GENERATION_REQ_RECEIVED_SUCCESS, reportingResponse.getData().getFirst());
        assertEquals(RESPONSE_SUCCESS, reportingResponse.getStatus());
    }


    @Test
    void testDownloadReport() {
        ReportManagementDto reportManagementDto = ReportManagementDto.builder().reportId(UUID.randomUUID()).build();
        DownloadRequest downloadRequest = new DownloadRequest();
        downloadRequest.setFilePath("/abc");
        doNothing().when(reportManagementValidator).validateDownloadRequest(mId, downloadRequest);
        when(reportManagementDao.getReportManagement(mId, downloadRequest.getFilePath(), ReportStatus.GENERATED)).thenReturn(reportManagementDto);
        doNothing().when(fileGeneratorService).downloadFile(httpResponse, reportManagementDto.getFormat(), reportManagementDto.getFilePath());
        reportManagementService.downloadReport(httpResponse, mId, downloadRequest);
        verify(fileGeneratorService, times(1)).downloadFile(httpResponse, reportManagementDto.getFormat(), reportManagementDto.getFilePath());

    }

}
