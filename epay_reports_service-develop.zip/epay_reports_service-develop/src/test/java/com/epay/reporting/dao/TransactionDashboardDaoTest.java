package com.epay.reporting.dao;

import com.epay.reporting.entity.view.RecentTransactionReport;
import com.epay.reporting.entity.view.TransactionFailureSummaryReport;
import com.epay.reporting.entity.view.TransactionPaymodeReport;
import com.epay.reporting.entity.view.TransactionSummaryReport;
import com.epay.reporting.model.request.RecentTransactionRequest;
import com.epay.reporting.model.request.TransactionPayModeRequest;
import com.epay.reporting.model.request.TransactionSummaryRequest;
import com.epay.reporting.repository.view.TransactionDashboardRepository;
import com.epay.reporting.util.enums.Frequency;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import java.util.Collections;
import java.util.List;
import org.springframework.data.domain.Page;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class TransactionDashboardDaoTest {

    static final String MID = "mid";
    @InjectMocks
    TransactionDashboardDao transactionDashboardDao;
    @Mock
    TransactionDashboardRepository transactionDashboardRepository;

    @Test
    void testGetTransactionTrends() {
        List<TransactionSummaryReport> transactionSummaryReportList = Collections.singletonList(TransactionSummaryReport.builder().transactionDate("2025-01-01").build());
        when(transactionDashboardRepository.getTransactionDailyTrendsByMidAndFrequency(MID, Frequency.DAILY)).thenReturn(transactionSummaryReportList);
        List<TransactionSummaryReport> response = transactionDashboardDao.getTransactionTrends(MID, Frequency.DAILY);
        assertNotNull(response);
    }

    @Test
    void testGetTransactionPayModeReport() {
        List<TransactionPaymodeReport> transactionPaymodeReportList = Collections.singletonList(TransactionPaymodeReport.builder().transactionDate("2025-01-01").paymodeCode("paycode").build());
        TransactionPayModeRequest transactionPayModeRequest = TransactionPayModeRequest.builder().fromDate("2025-01-01").toDate("2025-01-20").build();
        when(transactionDashboardRepository.getTransactionPayModeReport(MID, transactionPayModeRequest.getFromDate(), transactionPayModeRequest.getToDate())).thenReturn(transactionPaymodeReportList);
        List<TransactionPaymodeReport> transactionPayModeReport = transactionDashboardDao.getTransactionPayModeReport(MID, transactionPayModeRequest);
        assertNotNull(transactionPayModeReport);
    }

    @Test
    void testGetTransactionSummaryReport() {
        TransactionSummaryRequest transactionSummaryRequest = TransactionSummaryRequest.builder().fromDate("2025-01-01").build();
        TransactionSummaryReport transactionSummaryReport = TransactionSummaryReport.builder().transactionDate("2025-01-01").totalFailureCount(1L).totalSuccessCount(2L).build();
        Optional<TransactionSummaryReport> transactionSummaryReports = Optional.ofNullable(transactionSummaryReport);
        when(transactionDashboardRepository.getTransactionSummaryReport(MID, transactionSummaryRequest.getFromDate(), transactionSummaryRequest.getToDate())).thenReturn(transactionSummaryReports);

        List<TransactionFailureSummaryReport> transactionFailureSummaryReportList = Collections.singletonList(TransactionFailureSummaryReport.builder().failureReason("failed").failureCount(1L).build());
        when(transactionDashboardRepository.getTransactionFailureSummaryReport(MID, transactionSummaryRequest.getFromDate(), transactionSummaryRequest.getToDate())).thenReturn(transactionFailureSummaryReportList);

        List<TransactionSummaryReport> response = transactionDashboardDao.getTransactionSummaryReport(MID, transactionSummaryRequest);

        assertNotNull(response);

    }

    @Test
    void testGetRecentTransactionSummary() {
        Pageable pageable = PageRequest.of(0, 10);

        Page<RecentTransactionReport> recentTransactionReports = new PageImpl<>(List.of(), PageRequest.of(0, 10), 2);

        RecentTransactionRequest recentTransactionRequest = RecentTransactionRequest.builder().fromDate("2025-01-01").build();

        when(transactionDashboardRepository.getRecentTransactionSummaryDaily(MID, recentTransactionRequest, pageable))
                .thenReturn(recentTransactionReports);

        Page<RecentTransactionReport> response = transactionDashboardDao.getRecentTransactionSummary(MID, recentTransactionRequest, pageable);
        assertNotNull(response);
    }

    @Test
    void testGetRecentTransactionSummaryMonthly() {
        Pageable pageable = PageRequest.of(0, 10);

        Page<RecentTransactionReport> recentTransactionReports = new PageImpl<>(List.of(), PageRequest.of(0, 10), 2);

        RecentTransactionRequest recentTransactionRequest = RecentTransactionRequest.builder().frequency("MONTHLY").fromDate("2024-01-01").toDate("2025-02-02").build();

        when(transactionDashboardRepository.getRecentTransactionSummaryMonthly(MID, recentTransactionRequest, pageable)).thenReturn(recentTransactionReports);

        Page<RecentTransactionReport> response = transactionDashboardDao.getRecentTransactionSummary(MID, recentTransactionRequest, pageable);
        assertNotNull(response);
    }

}
