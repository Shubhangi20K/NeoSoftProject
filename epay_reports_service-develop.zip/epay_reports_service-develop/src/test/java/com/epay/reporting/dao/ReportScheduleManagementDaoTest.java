package com.epay.reporting.dao;

import com.epay.reporting.config.ReportingConfig;
import com.epay.reporting.dto.ReportScheduleManagementDto;
import com.epay.reporting.entity.ReportScheduleManagement;
import com.epay.reporting.exception.ReportingException;
import com.epay.reporting.mapper.ReportScheduleManagementMapper;
import com.epay.reporting.model.request.CancelScheduleRequest;
import com.epay.reporting.model.request.ReportScheduleManagementSearchRequest;
import com.epay.reporting.model.request.ReportScheduleManagementUpdateRequest;
import com.epay.reporting.repository.ReportScheduleManagementRepository;
import com.epay.reporting.util.ErrorConstants;
import com.epay.reporting.util.enums.Frequency;
import com.epay.reporting.util.enums.Report;
import com.epay.reporting.util.enums.ReportFormat;
import com.epay.reporting.util.enums.ReportScheduledStatus;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ReportScheduleManagementDaoTest {

    @InjectMocks
    private ReportScheduleManagementDao reportScheduleManagementDao;

    @Mock
    private ReportScheduleManagementRepository reportScheduleManagementRepository;

    @Mock
    private ReportScheduleManagementMapper mapper;

    @Mock
    private ReportMasterDao reportMasterDao;

    @Mock
    private ReportManagementDao reportManagementDao;

    @Mock
    private ReportingConfig reportingConfig;

    private UUID reportId;
    private UUID scheduleId;
    private ReportScheduleManagementDto reportScheduleDto;
    private ReportScheduleManagement reportScheduleEntity;

    @BeforeEach
    void setUpBeforeEach() {
        reportId = UUID.randomUUID();
        scheduleId = UUID.randomUUID();

        reportScheduleDto = new ReportScheduleManagementDto();
        reportScheduleDto.setReportId(reportId);
        reportScheduleDto.setReport(Report.REFUNDS);
        reportScheduleDto.setFrequency(Frequency.DAILY);
        reportScheduleDto.setScheduleExecutionTime("3:00 PM");

        reportScheduleEntity = new ReportScheduleManagement();
        reportScheduleEntity.setId(scheduleId);
        reportScheduleEntity.setReportId(reportId);
        reportScheduleEntity.setFrequency(Frequency.DAILY);
        reportScheduleEntity.setScheduleExecutionTime("3:00 PM");
        reportScheduleEntity.setStatus(ReportScheduledStatus.TO_BE_START);
    }

    @Test
    void testSave_ShouldSaveReportScheduleSuccessfully() {
        when(reportMasterDao.getReportIdByName(any())).thenReturn(reportId);
        when(mapper.mapDtoToEntity(any())).thenReturn(reportScheduleEntity);
        when(reportScheduleManagementRepository.save(any())).thenReturn(reportScheduleEntity);

        assertDoesNotThrow(() -> reportScheduleManagementDao.save(reportScheduleDto));

        verify(reportScheduleManagementRepository, times(1)).save(any());
    }

    @Test
    void testSearchAndGetAll_ShouldReturnPagedResults() {
        Page<ReportScheduleManagement> mockPage = new PageImpl<>(List.of(reportScheduleEntity));
        when(reportScheduleManagementRepository.findAll(any(Specification.class), any(Pageable.class))).thenReturn(mockPage);
        when(mapper.mapEntityToDto(any())).thenReturn(reportScheduleDto);

        Page<ReportScheduleManagementDto> result = reportScheduleManagementDao.searchAndGetAll(new ReportScheduleManagementSearchRequest(), Pageable.unpaged());

        assertFalse(result.isEmpty());
        verify(reportScheduleManagementRepository, times(1)).findAll(any(Specification.class), any(Pageable.class));
    }

    @Test
    void testUpdate_ShouldUpdateNonNullFields() {
        when(reportScheduleManagementRepository.findById(scheduleId)).thenReturn(Optional.of(reportScheduleEntity));
        when(reportScheduleManagementRepository.save(any())).thenReturn(reportScheduleEntity);

        ReportScheduleManagementUpdateRequest updateRequest = new ReportScheduleManagementUpdateRequest();
        updateRequest.setFormat("PDF");

        assertDoesNotThrow(() -> reportScheduleManagementDao.update(String.valueOf(scheduleId), updateRequest));

        assertEquals(ReportFormat.PDF, reportScheduleEntity.getFormat());
        verify(reportScheduleManagementRepository, times(1)).save(any());
    }

    @Test
    void testUpdate_ShouldThrowException_WhenScheduleNotFound() {
        when(reportScheduleManagementRepository.findById(scheduleId)).thenReturn(Optional.empty());

        ReportScheduleManagementUpdateRequest updateRequest = new ReportScheduleManagementUpdateRequest();

        Exception exception = assertThrows(ReportingException.class, () -> reportScheduleManagementDao.update(String.valueOf(scheduleId), updateRequest));

        assertTrue(exception.getMessage().contains(ErrorConstants.SCHEDULE_REQUEST_ID));
    }

    @Test
    void testCancelScheduler_ShouldCancelReportSchedule() {
        when(reportScheduleManagementRepository.findById(scheduleId)).thenReturn(Optional.of(reportScheduleEntity));
        when(reportScheduleManagementRepository.save(any())).thenReturn(reportScheduleEntity);

        assertDoesNotThrow(() -> reportScheduleManagementDao.cancelScheduler(scheduleId, CancelScheduleRequest.builder().remarks("cancelled").build()));

        assertEquals(ReportScheduledStatus.CANCELLED, reportScheduleEntity.getStatus());
        verify(reportScheduleManagementRepository, times(1)).save(any());
    }

    @Test
    void testCancelScheduler_ShouldThrowException_WhenScheduleNotFound() {
        when(reportScheduleManagementRepository.findById(scheduleId)).thenReturn(Optional.empty());

        Exception exception = assertThrows(ReportingException.class, () -> reportScheduleManagementDao.cancelScheduler(scheduleId, CancelScheduleRequest.builder().remarks("cancelled").build()));

        assertTrue(exception.getMessage().contains(ErrorConstants.SCHEDULE_REQUEST_ID));
    }

    @Test
    void testFindByStatusAndNextScheduleExecutionTime_ShouldReturnMatchingReports() {
        when(reportScheduleManagementRepository.findByStatusAndNextScheduleExecutionTime(any(), anyLong()))
                .thenReturn(List.of(reportScheduleEntity));

        List<ReportScheduleManagement> result = reportScheduleManagementDao.findByStatusAndNextScheduleExecutionTime(123456789L);

        assertFalse(result.isEmpty());
        verify(reportScheduleManagementRepository, times(1)).findByStatusAndNextScheduleExecutionTime(any(), anyLong());
    }
}