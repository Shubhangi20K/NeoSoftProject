package com.epay.reporting.dao;

import com.epay.reporting.entity.view.RefundSummaryReport;
import com.epay.reporting.entity.view.SettlementSummaryReport;
import com.epay.reporting.entity.view.TransactionDailySummaryReport;
import com.epay.reporting.repository.view.TransactionSummaryRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class TransactionSummaryDaoTest {

    @Mock
    private TransactionSummaryRepository transactionSummaryRepository;

    @Mock
    private RefundSummaryDao refundSummaryDao;

    @InjectMocks
    private TransactionSummaryDao transactionSummaryDao;

    @BeforeEach
    void setUp() {
        // This will set up the mocks before each test case.
    }

    @Test
    void testGetTransactionSummary() {
        String merchantId = "12345";
        TransactionDailySummaryReport report = TransactionDailySummaryReport.builder()
                .totalTransactionCount(100L)
                .totalAmount(BigDecimal.valueOf(1000.00))
                .transactionDate("2025-02-15")
                .build();
        when(transactionSummaryRepository.getCurrentTransactionSummary(merchantId))
                .thenReturn(Arrays.asList(report));

        List<TransactionDailySummaryReport> result = transactionSummaryDao.getTransactionSummary(merchantId);

        assertEquals(1, result.size());
        assertEquals(100L, result.get(0).getTotalTransactionCount());
        assertEquals(BigDecimal.valueOf(1000.00), result.get(0).getTotalAmount());
        assertEquals("2025-02-15", result.get(0).getTransactionDate());
    }

    @Test
    void testGetDailySettlementSummary() {
        String merchantId = "12345";
        SettlementSummaryReport report = SettlementSummaryReport.builder()
                .todaySettlement(BigDecimal.valueOf(500.00))
                .build();
        when(transactionSummaryRepository.getCurrentSettlementSummary(merchantId))
                .thenReturn(Arrays.asList(report));

        List<SettlementSummaryReport> result = transactionSummaryDao.getDailySettlementSummary(merchantId);

        assertEquals(1, result.size());
        assertEquals(BigDecimal.valueOf(500.00), result.get(0).getTodaySettlement());
    }

    @Test
    void testGetDailyRefundSummary() {
        String merchantId = "12345";
        RefundSummaryReport report = RefundSummaryReport.builder()
                .refundCount(5)
                .totalAvailableAmt(BigDecimal.valueOf(1000.00))
                .totalRefundAmt(BigDecimal.valueOf(500.00))
                .createdDate("2025-02-15")
                .build();
        when(refundSummaryDao.getDailyRefundSummary(merchantId))
                .thenReturn(Arrays.asList(report));

        List<RefundSummaryReport> result = transactionSummaryDao.getDailyRefundSummary(merchantId);

        assertEquals(1, result.size());
        assertEquals(5, result.get(0).getRefundCount());
        assertEquals(BigDecimal.valueOf(1000.00), result.get(0).getTotalAvailableAmt());
        assertEquals(BigDecimal.valueOf(500.00), result.get(0).getTotalRefundAmt());
        assertEquals("2025-02-15", result.get(0).getCreatedDate());
    }
}
