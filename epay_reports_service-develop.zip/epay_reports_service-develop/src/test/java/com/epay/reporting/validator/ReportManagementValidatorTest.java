package com.epay.reporting.validator;

import com.epay.reporting.dao.ReportManagementDao;
import com.epay.reporting.model.request.DownloadRequest;
import com.epay.reporting.model.request.ReportManagementRequest;
import com.epay.reporting.util.enums.Report;
import com.epay.reporting.util.enums.ReportFormat;
import com.epay.reporting.util.enums.ReportStatus;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ReportManagementValidatorTest {
    @InjectMocks
    ReportManagementValidator reportManagementValidator;
    @Mock
    MIdValidator mIdValidator;

    private ReportManagementRequest reportManagementRequest;
    @Mock
    private  ReportManagementDao reportManagementDao;


    @BeforeEach
    void setUp() {
        reportManagementRequest = ReportManagementRequest.builder().report(Report.ORDER.name()).mId("1000003").durationFromDate(1735669800000L).durationToDate(1736977085881L).format(ReportFormat.CSV.name()).build();
    }

    @Test
    void validateRequest() {
        assertNotNull(reportManagementRequest.getMId());
        assertDoesNotThrow(() -> mIdValidator.validateActiveMId(reportManagementRequest.getMId()));
        assertDoesNotThrow(() -> reportManagementValidator.validateRequest(reportManagementRequest));
    }

    @Test
    void validateSearchRequest() {
        assertNotNull(reportManagementRequest.getMId());
        assertDoesNotThrow(() -> mIdValidator.validateActiveMId(reportManagementRequest.getMId()));
        assertDoesNotThrow(() -> reportManagementValidator.validateSearchRequest(reportManagementRequest));
    }

    @Test
    void testValidateDownloadRequest(){ 
        DownloadRequest downloadRequest=new DownloadRequest();
        downloadRequest.setFilePath("/abc");
        String mId = "1234567";
        doNothing().when(mIdValidator).validateMIdAccess(mId);
        when(reportManagementDao.isReportExistsByMIdAndFilePathAndStatus(mId, downloadRequest.getFilePath(), ReportStatus.GENERATED)).thenReturn(true);
        reportManagementValidator.validateDownloadRequest(mId,downloadRequest);
        verify(reportManagementDao,times(1)).isReportExistsByMIdAndFilePathAndStatus(mId, downloadRequest.getFilePath(), ReportStatus.GENERATED);
    }

}