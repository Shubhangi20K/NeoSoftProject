package com.epay.reporting.service;

import com.epay.reporting.dao.InvoiceDao;
import com.epay.reporting.exception.ReportingException;
import com.epay.reporting.exception.ValidationException;
import com.epay.reporting.model.response.ReportingResponse;
import com.epay.reporting.util.enums.Report;
import com.epay.reporting.util.enums.ReportFormat;
import com.epay.reporting.util.file.model.FileModel;
import com.epay.reporting.validator.InvoiceValidator;
import com.epay.reporting.validator.MIdValidator;
import jakarta.servlet.http.HttpServletResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.epay.reporting.util.ErrorConstants.NOT_FOUND_ERROR_CODE;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
@ExtendWith(MockitoExtension.class)
class InvoiceServiceTest {

    @InjectMocks
    private InvoiceService invoiceService;

    @Mock
    private InvoiceDao invoiceDao;

    @Mock
    private FileGeneratorService fileGeneratorService;

    @Mock
    private MIdValidator mIdValidator;

    @Mock
    private InvoiceValidator invoiceValidator;

    @Mock
    private HttpServletResponse response;

    String mId = "12345";
    List<String> reportDates = List.of("Jan-2025");
    Map<String, Object> feesInvoiceData;

    @BeforeEach
    void setUp() {
        feesInvoiceData=new HashMap<>();
    }

    @Test
    void testGenerateMerchantFeesInvoice_Success_SingleFile() {
        feesInvoiceData.put("report", "Feb-2025");

        when(invoiceDao.getFeesInvoiceData(mId, reportDates)).thenReturn(List.of(feesInvoiceData));

        ReportingResponse<String> responseLocal = invoiceService.generateMerchantFeesInvoice(mId, reportDates, this.response);

        assertNotNull(responseLocal);
        assertEquals(1, responseLocal.getStatus());
        verify(mIdValidator, times(1)).validateActiveMId(mId);
        verify(fileGeneratorService, times(1)).downloadFile(any(), eq(ReportFormat.PDF), eq(Report.FEES_INVOICE), eq(mId), any(FileModel.class));
    }

    @Test
    void testGenerateMerchantFeesInvoice_Success_ZipFile() {

        feesInvoiceData.put("report", "Feb-2025");
        feesInvoiceData.put("report2", "Jan-2025");

        when(invoiceDao.getFeesInvoiceData(mId, reportDates)).thenReturn(List.of(feesInvoiceData, feesInvoiceData));

        ReportingResponse<String> responseLocal = invoiceService.generateMerchantFeesInvoice(mId, reportDates, this.response);

        assertNotNull(responseLocal);
    }


    @Test
    void testGenerateMerchantFeesInvoice_NoDataFound() {
        when(invoiceDao.getFeesInvoiceData(mId, reportDates)).thenReturn(Collections.emptyList());
        var ex = assertThrows(ReportingException.class, () -> invoiceService.generateMerchantFeesInvoice(mId, reportDates, this.response));
        assertEquals(NOT_FOUND_ERROR_CODE, ex.getErrorCode());
    }

    @Test
    void testGenerateMerchantFeesInvoice_ReportingException() {
        doThrow(new ReportingException("VALIDATION_ERROR", "Invalid MID")).when(mIdValidator).validateActiveMId(mId);
        assertThrows(ReportingException.class, () -> invoiceService.generateMerchantFeesInvoice(mId, reportDates, this.response));
    }
    @Test
    void testGenerateMerchantFeesInvoice_ValidationException() {
        doThrow(new ValidationException("VALIDATION_ERROR", "Invalid MID")).when(mIdValidator).validateActiveMId(mId);
        assertThrows(ValidationException.class, () -> invoiceService.generateMerchantFeesInvoice(mId, reportDates, this.response));
    }

}