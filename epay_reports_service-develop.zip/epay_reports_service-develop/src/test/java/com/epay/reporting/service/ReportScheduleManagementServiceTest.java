package com.epay.reporting.service;

import com.epay.reporting.dao.ReportScheduleManagementDao;
import com.epay.reporting.dto.ReportScheduleManagementDto;
import com.epay.reporting.entity.view.RecentTransactionReport;
import com.epay.reporting.mapper.ReportScheduleManagementMapper;
import com.epay.reporting.model.request.CancelScheduleRequest;
import com.epay.reporting.model.request.ReportScheduleManagementRequest;
import com.epay.reporting.model.request.ReportScheduleManagementSearchRequest;
import com.epay.reporting.model.request.ReportScheduleManagementUpdateRequest;
import com.epay.reporting.model.response.ReportScheduleManagementResponse;
import com.epay.reporting.model.response.ReportingResponse;
import com.epay.reporting.util.ReportingConstant;
import com.epay.reporting.util.enums.Frequency;
import com.epay.reporting.util.enums.Report;
import com.epay.reporting.util.enums.ReportFormat;
import com.epay.reporting.util.enums.ReportScheduledStatus;
import com.epay.reporting.validator.ReportScheduleManagementValidator;
import com.sbi.epay.logging.utility.LoggerUtility;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import java.util.Collections;
import java.util.List;
import java.util.UUID;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class ReportScheduleManagementServiceTest {

    @InjectMocks
    private ReportScheduleManagementService reportScheduleManagementService;

    @Mock
    private ReportScheduleManagementDao reportScheduleManagementDao;

    @Mock
    private ReportScheduleManagementMapper reportScheduleManagementMapper;

    @Mock
    private ReportScheduleManagementValidator reportScheduleManagementValidator;

    @Mock
    private LoggerUtility log;

    private ReportScheduleManagementRequest reportScheduleManagementRequest;
    private ReportScheduleManagementSearchRequest searchRequest;
    private Page<ReportScheduleManagementDto> reportScheduleManagementDtoPage;
    private ReportScheduleManagementUpdateRequest reportScheduleManagementUpdateRequest;
    @BeforeEach
    void setUp() {
        reportScheduleManagementRequest = ReportScheduleManagementRequest.builder()
                .report("Report1")
                .mId("Merchant1")
                .frequency("DAILY")
                .format("PDF")
                .scheduleExecutionTime("2025-02-15T10:00:00")
                .build();

        searchRequest = ReportScheduleManagementSearchRequest.builder()
                .report("Report1")
                .mId("Merchant1")
                .frequency("DAILY")
                .format("PDF")
                .build();


    }




    @Test
    void testCancelScheduler() {
        UUID scheduleId = UUID.randomUUID();
        doNothing().when(reportScheduleManagementDao).cancelScheduler(scheduleId, CancelScheduleRequest.builder().remarks("cancelled").build());

        ReportingResponse<String> response = reportScheduleManagementService.cancelScheduler(String.valueOf(scheduleId), CancelScheduleRequest.builder().remarks("cancelled").build());

        assertNotNull(response);
        assertTrue(response.getData().contains(ReportingConstant.SCHEDULER_CANCELED));
    }

    @Test
    void testExecuteReportBySchedule() {
        doNothing().when(reportScheduleManagementDao).executeReportBySchedule();

        reportScheduleManagementService.executeReportBySchedule();

        verify(reportScheduleManagementDao, times(1)).executeReportBySchedule();
    }
    @Test
    void testSearchAndGetAll(){
        Pageable pageable = PageRequest.of(0, 10);
        List<ReportScheduleManagementDto> scheduleManagementDtos = List.of(ReportScheduleManagementDto.builder().report(Report.REFUNDS).build());
        List<ReportScheduleManagementResponse> reportManagementResponses =List.of(ReportScheduleManagementResponse.builder().report(Report.REFUNDS).build());
        Page<ReportScheduleManagementDto> reportManagementDTOs = new PageImpl<>(scheduleManagementDtos, PageRequest.of(0, 10), 2);
        doNothing().when(reportScheduleManagementValidator).validateRequest(searchRequest);
        when(reportScheduleManagementMapper.mapDtoListToResponseList(reportManagementDTOs.getContent())).thenReturn(reportManagementResponses);
        when(reportScheduleManagementDao.searchAndGetAll(searchRequest, pageable)).thenReturn(reportManagementDTOs);
        ReportingResponse<ReportScheduleManagementResponse> response = reportScheduleManagementService.searchAndGetAll(searchRequest, pageable);
        assertNotNull(response);
        assertEquals(Report.REFUNDS,response.getData().getFirst().getReport());
    }

    @Test
    void testSave(){
        ReportScheduleManagementDto scheduleManagementDtos = ReportScheduleManagementDto.builder().report(Report.REFUNDS).build();
        doNothing().when(reportScheduleManagementValidator).validateRequest(reportScheduleManagementRequest);
when(reportScheduleManagementMapper.mapRequestToDto(reportScheduleManagementRequest)).thenReturn(scheduleManagementDtos);
doNothing().when(reportScheduleManagementDao).save(scheduleManagementDtos);
        ReportingResponse<String> response = reportScheduleManagementService.save(reportScheduleManagementRequest);
        assertEquals(ReportingConstant.RESPONSE_SUCCESS,response.getStatus());
    }
    @Test
    void testUpdateScheduleManagement(){
        String uuid= String.valueOf(UUID.randomUUID());
        doNothing().when(reportScheduleManagementDao).update(uuid,reportScheduleManagementUpdateRequest);

        ReportingResponse<String> response = reportScheduleManagementService.updateScheduleManagement(uuid,reportScheduleManagementUpdateRequest);
        assertEquals(ReportingConstant.UPDATED_SUCCESSFULLY,response.getData().getFirst());
    }




}
