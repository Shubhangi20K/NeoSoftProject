package com.epay.reporting.service;

import com.epay.reporting.util.enums.Report;
import com.epay.reporting.util.file.generator.FileGenerator;
import com.epay.reporting.util.file.generator.ZipFileGenerator;
import com.epay.reporting.util.file.model.FileModel;
import jakarta.servlet.http.HttpServletResponse;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Map;

import static com.epay.reporting.util.enums.ReportFormat.CSV;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class FileGeneratorServiceTest {

    @InjectMocks
    FileGeneratorService fileGeneratorService;

    @Mock
    FileGenerator fileGenerator;

    @Mock
    HttpServletResponse response;

    @Mock
    ZipFileGenerator zipFileGenerator;

    @Test
    void testDownloadFile() {
        String mid = "XYZ123";
        FileModel fileModel = mock(FileModel.class);
        fileModel.setReportMonth("12");
        doNothing().when(fileGenerator).downloadFile(response, CSV, Report.ORDER, mid, fileModel);
        fileGeneratorService.downloadFile(response, CSV, Report.ORDER, mid, fileModel);

        verify(fileGenerator, times(1)).downloadFile(response, CSV, Report.ORDER, mid, fileModel);

    }

    @Test
    void testZipGenerateFile() {
        String mid = "XYZ123";
        FileModel fileModel1 = mock(FileModel.class);
        FileModel fileModel2 = mock(FileModel.class);
        fileModel1.setReportMonth("12");
        fileModel2.setReportMonth("14");
        List<FileModel> fileModelList = List.of(fileModel1, fileModel2);
        doNothing().when(zipFileGenerator).generateZipFile(response, CSV, Report.ORDER, mid, fileModelList);
        fileGeneratorService.generateZipFile(response, CSV, Report.ORDER, mid, fileModelList);
        verify(zipFileGenerator, times(1)).generateZipFile(response, CSV, Report.ORDER, mid, fileModelList);
    }

    @Test
    void testBuildFileModel() {
        List<Object> list = List.of("Rahul");
        List<List<Object>> fileData = List.of(list);
        FileModel fileModel2 = new FileModel() {
            @Override
            public void setReportMonth(String reportMonth) {
                super.setReportMonth(reportMonth);
            }
        };
        fileModel2.setReportMonth("OCT");
        when(fileGenerator.buildFileModel(CSV, List.of("header"), fileData, Map.of("headers", java.util.List.of("header"), "rows", fileData))).thenReturn(fileModel2);
        FileModel fileModel = fileGeneratorService.buildFileModel(CSV, List.of("header"), fileData, Map.of("headers", List.of("header"), "rows", fileData));
        verify(fileGenerator, times(1)).buildFileModel(CSV, List.of("header"), fileData, Map.of("headers", java.util.List.of("header"), "rows", fileData));
        assertEquals("OCT", fileModel.getReportMonth());
    }


}