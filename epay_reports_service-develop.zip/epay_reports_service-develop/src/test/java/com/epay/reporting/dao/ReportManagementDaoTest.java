package com.epay.reporting.dao;

import com.epay.reporting.dto.ReportManagementDto;
import com.epay.reporting.entity.ReportManagement;
import com.epay.reporting.etl.producer.ReportGenerationProducer;
import com.epay.reporting.exception.ReportingException;
import com.epay.reporting.mapper.ReportManagementMapper;
import com.epay.reporting.model.request.ReportManagementRequest;
import com.epay.reporting.repository.ReportManagementRepository;
import com.epay.reporting.util.enums.Report;
import com.epay.reporting.util.enums.ReportStatus;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;

import java.text.MessageFormat;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static com.epay.reporting.util.ErrorConstants.NOT_FOUND_ERROR_MESSAGE;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class ReportManagementDaoTest {
    @InjectMocks
    ReportManagementDao reportManagementDao;

    @Mock
    private ReportManagementRepository reportManagementRepository;
    @Mock
    private ReportManagementMapper mapper;
    @Mock
    private ReportMasterDao reportMasterDao;
    @Mock
    private ReportGenerationProducer reportGenerationProducer;
    UUID reportId;
    ReportManagement reportManagement;

    ReportManagementRequest reportManagementRequest;
    ReportManagementDto reportManagementDto;
    ReportStatus status ;
    String remarks = "Generation successful";
    String filePath = "path/to/generated/report";
String mId="mid";

    @BeforeEach
    void setUp() {
        reportId = UUID.randomUUID();
        reportManagement = ReportManagement.builder().id(reportId).reportId(reportId).mId( mId).build();
        reportManagementRequest = ReportManagementRequest.builder().report(Report.REFUNDS.getName()).mId( mId).build();
        reportManagementDto = ReportManagementDto.builder().report(Report.REFUNDS).reportId(reportId).status(ReportStatus.TO_BE_GENERATE).mId( mId).build();
        status = ReportStatus.GENERATED;

    }

    @Test
    void testSaveReportManagement() {
        when(reportMasterDao.getReportIdByName(reportManagementDto.getReport())).thenReturn(reportId);

        when(mapper.mapDtoToEntity(reportManagementDto)).thenReturn(reportManagement);
        when(reportManagementRepository.save(reportManagement)).thenReturn(reportManagement);

        reportManagementDao.saveReportManagement(reportManagementDto);

        verify(reportManagementRepository, times(1)).save(reportManagement);
    }

    @Test
    void testSaveAll() {

        List<ReportManagement> reportManagementList = Arrays.asList(reportManagement, reportManagement);
        when(reportManagementRepository.saveAll(reportManagementList)).thenReturn(reportManagementList);
        when(reportMasterDao.getReportNameById(reportManagement.getReportId())).thenReturn(Report.REFUNDS);
        reportManagementDao.saveAll(reportManagementList);
        verify(reportManagementRepository, times(1)).saveAll(reportManagementList);

    }


    @Test
    void testSearchAndGetReportManagement() {

        Pageable pageable = PageRequest.of(0, 10);

        when(reportMasterDao.getReportIdByName(Report.REFUNDS))
                .thenReturn(reportId);

        ReportManagement reportManagement = new ReportManagement();
        reportManagement.setId(reportId);

        when(reportManagementRepository.findAll(any(Specification.class), eq(pageable)))
                .thenReturn(new PageImpl<>(List.of(reportManagement)));

        ReportManagementDto reportManagementDto = new ReportManagementDto();
        when(mapper.mapEntityToDto(reportManagement)).thenReturn(reportManagementDto);

        Page<ReportManagementDto> result = reportManagementDao.searchAndGetReportManagement(reportManagementRequest, pageable);

        assertNotNull(result);
        assertEquals(1, result.getTotalElements());
        verify(reportMasterDao).getReportIdByName(Report.REFUNDS);
        verify(reportManagementRepository).findAll(any(Specification.class), eq(pageable));
    }

    @Test
    void testUpdateReportStatus() {

        when(reportManagementRepository.findByIdAndStatusIn(eq(reportId), anyList()))
                .thenReturn(Optional.of(reportManagement));

        when(mapper.mapEntityToDto(reportManagement)).thenReturn(reportManagementDto);

        ReportManagementDto result = reportManagementDao.updateReportStatus(reportId, status);

        assertNotNull(result);
        assertEquals(status, reportManagement.getStatus());
        verify(reportManagementRepository).save(reportManagement);
    }


    @Test
    void testUpdateReportStatus_ThrowsException_WhenReportNotFound() {
        when(reportManagementRepository.findByIdAndStatusIn(eq(reportId), anyList()))
                .thenReturn(Optional.empty());

        ReportingException thrown = assertThrows(ReportingException.class, () -> {
            reportManagementDao.updateReportStatus(reportId, status);
        });

        assertEquals(MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, "Report"), thrown.getMessage());
    }

    @Test
    void testUpdateStatusAndRemarks() {

        reportManagement.setRemarks("Initial remarks");

        when(reportManagementRepository.findByIdAndStatusIn(eq(reportId), anyList()))
                .thenReturn(Optional.of(reportManagement));

        reportManagementDao.updateStatusAndRemarks(reportId, status, remarks);

        assertEquals(status, reportManagement.getStatus());
        assertEquals(remarks, reportManagement.getRemarks());
        verify(reportManagementRepository).save(reportManagement);
    }


    @Test
    void testUpdateStatusAndFilePath() {

        when(reportManagementRepository.findByIdAndStatusIn(eq(reportId), anyList()))
                .thenReturn(Optional.of(reportManagement));

        reportManagementDao.updateStatusAndFilePath(reportId, status, filePath);

        assertEquals(status, reportManagement.getStatus());
        assertEquals(filePath, reportManagement.getFilePath());
        verify(reportManagementRepository).save(reportManagement);
    }


    @Test
    void testIsReportExistsByMIdAndFilePathAndStatus() {
        when(reportManagementRepository.existsBymIdAndFilePathAndStatus( mId, filePath, ReportStatus.GENERATION_STARTED)).thenReturn(true);
        boolean existsByMIdAndFilePathAndStatus = reportManagementDao.isReportExistsByMIdAndFilePathAndStatus( mId, filePath, ReportStatus.GENERATION_STARTED);
        assertTrue(existsByMIdAndFilePathAndStatus);
    }

    @Test
    void testGetReportManagement() {
        when(reportManagementRepository.findBymIdAndFilePathAndStatus( mId,  filePath, ReportStatus.GENERATION_STARTED)).thenReturn(reportManagement);

        when(mapper.mapEntityToDto(reportManagement)).thenReturn(reportManagementDto);

        ReportManagementDto management = reportManagementDao.getReportManagement( mId,  filePath, ReportStatus.GENERATION_STARTED);

        assertEquals( mId, management.getMId());
    }


    @Test
    void testUpdateStatusAndFilePath_WhenReportNotFound_ShouldNotThrowException() {

        when(reportManagementRepository.findByIdAndStatusIn(eq(reportId), anyList()))
                .thenReturn(Optional.empty());
        assertDoesNotThrow(() ->
                reportManagementDao.updateStatusAndFilePath(reportId, status, filePath)
        );
    }


    @Test
    void testUpdateStatusAndRemarks_WhenReportNotFound_ShouldNotThrowException() {
        when(reportManagementRepository.findByIdAndStatusIn(eq(reportId), anyList()))
                .thenReturn(Optional.empty());
        assertDoesNotThrow(() ->
                reportManagementDao.updateStatusAndRemarks(reportId, status, remarks)
        );
    }


}
