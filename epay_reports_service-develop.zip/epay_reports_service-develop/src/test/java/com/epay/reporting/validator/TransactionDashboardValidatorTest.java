package com.epay.reporting.validator;

import com.epay.reporting.exception.ValidationException;
import com.epay.reporting.model.request.RecentTransactionRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static com.epay.reporting.util.ErrorConstants.INVALID_ERROR_CODE;
import static com.epay.reporting.util.ErrorConstants.REQUIRED_ERROR_CODE;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;

@ExtendWith(MockitoExtension.class)
class TransactionDashboardValidatorTest {
    @Mock
    private MIdValidator mIdValidator;

    @InjectMocks
    private TransactionDashboardValidator transactionDashboardValidator;


    private String VALID_MID = "1234567";

    private RecentTransactionRequest validRequest;
    private RecentTransactionRequest invalidRequest;

    @BeforeEach
    void setUp() {
        validRequest = new RecentTransactionRequest();
        validRequest.setFrequency("DAILY");
        validRequest.setFromDate("02-Jan-2024");
        validRequest.setToDate("02-Jan-2025");
        invalidRequest = new RecentTransactionRequest();
    }

    @Test
    void testValidateRequest_ValidMidSuccess() {
        doNothing().when(mIdValidator).validateActiveMId(VALID_MID);
        assertDoesNotThrow(() -> transactionDashboardValidator.validateRequest(VALID_MID, validRequest));
    }

    @Test
    void testValidateRequest_Failure_InvalidMId() {
        VALID_MID = "123456";
        doThrow(new ValidationException(INVALID_ERROR_CODE, "Invalid Merchant ID")).when(mIdValidator).validateActiveMId(VALID_MID);
        ValidationException exception = assertThrows(ValidationException.class, () -> transactionDashboardValidator.validateRequest(VALID_MID, validRequest));
        assertEquals("Invalid Merchant ID", exception.getMessage());
    }
    @Test
    void testValidateRequest_Failure_MissingValue() {
        ValidationException exception = assertThrows(ValidationException.class, () -> transactionDashboardValidator.validateRequest(VALID_MID,invalidRequest));
        assertEquals(REQUIRED_ERROR_CODE, exception.getErrorMessages().getFirst().getErrorCode());
    }
    }
