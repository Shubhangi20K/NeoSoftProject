package com.epay.reporting.service;

import com.epay.reporting.dao.TransactionSummaryDao;
import com.epay.reporting.entity.view.RefundSummaryReport;
import com.epay.reporting.entity.view.SettlementSummaryReport;
import com.epay.reporting.entity.view.TransactionDailySummaryReport;
import com.epay.reporting.model.response.ReportingResponse;
import com.epay.reporting.validator.MIdValidator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import java.math.BigDecimal;
import java.util.Collections;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class TransactionDailySummaryServiceTest {

    @Mock
    private TransactionSummaryDao transactionSummaryDao;

    @Mock
    private MIdValidator mIdValidator;

    @InjectMocks
    private TransactionDailySummaryService transactionDailySummaryService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetDailyTransactionSummary() {
        String mId = "12345";
        TransactionDailySummaryReport report = TransactionDailySummaryReport.builder().totalTransactionCount(10L).totalAmount(BigDecimal.valueOf(1000)).transactionDate("2025-02-15").build();

        when(transactionSummaryDao.getTransactionSummary(mId)).thenReturn(Collections.singletonList(report));

        ReportingResponse<TransactionDailySummaryReport> response = transactionDailySummaryService.getDailyTransactionSummary(mId);

        assertNotNull(response);
        assertEquals(1, response.getData().size());
        assertEquals(report, response.getData().getFirst());
        verify(transactionSummaryDao, times(1)).getTransactionSummary(mId);
    }

    @Test
    void testGetSettlementDailySummary() {
        String mId = "12345";
        SettlementSummaryReport settlementReport = SettlementSummaryReport.builder().todaySettlement(BigDecimal.valueOf(500)).pastSettlement(BigDecimal.valueOf(200)).build();

        when(transactionSummaryDao.getDailySettlementSummary(mId)).thenReturn(Collections.singletonList(settlementReport));

        ReportingResponse<SettlementSummaryReport> response = transactionDailySummaryService.getSettlementDailySummary(mId);

        assertNotNull(response);
        assertEquals(1, response.getData().size());
        assertEquals(settlementReport, response.getData().getFirst());
        verify(transactionSummaryDao, times(1)).getDailySettlementSummary(mId);
    }

    @Test
    void testGetDailyRefundSummary() {
        String mId = "12345";
        RefundSummaryReport refundReport = RefundSummaryReport.builder().refundCount(5).totalAvailableAmt(BigDecimal.valueOf(300)).totalRefundAmt(BigDecimal.valueOf(150)).createdDate("2025-02-15").build();

        when(transactionSummaryDao.getDailyRefundSummary(mId)).thenReturn(Collections.singletonList(refundReport));

        ReportingResponse<RefundSummaryReport> response = transactionDailySummaryService.getDailyRefundSummary(mId);

        assertNotNull(response);
        assertEquals(1, response.getData().size());
        assertEquals(refundReport, response.getData().getFirst());
        verify(transactionSummaryDao, times(1)).getDailyRefundSummary(mId);
    }

    // Test case for invalid Merchant ID (simulating exception from MIdValidator)
    @Test
    void testGetDailyTransactionSummaryInvalidMId() {
        String invalidMId = "invalid123";

        doThrow(new IllegalArgumentException("Invalid Merchant ID")).when(mIdValidator).validateMIdAccess(invalidMId);

        Exception exception = assertThrows(IllegalArgumentException.class, () -> transactionDailySummaryService.getDailyTransactionSummary(invalidMId));

        assertEquals("Invalid Merchant ID", exception.getMessage());
        verify(mIdValidator, times(1)).validateMIdAccess(invalidMId);
    }

    // Test case for empty data returned by DAO
    @Test
    void testGetDailyTransactionSummaryEmptyData() {
        String mId = "12345";

        when(transactionSummaryDao.getTransactionSummary(mId)).thenReturn(Collections.emptyList());

        ReportingResponse<TransactionDailySummaryReport> response = transactionDailySummaryService.getDailyTransactionSummary(mId);

        assertNotNull(response);
        assertTrue(response.getData().isEmpty(), "The data should be empty");
        verify(transactionSummaryDao, times(1)).getTransactionSummary(mId);
    }

    // Test case for DAO throwing an exception
    @Test
    void testGetDailyTransactionSummaryDaoException() {
        String mId = "12345";

        when(transactionSummaryDao.getTransactionSummary(mId)).thenThrow(new RuntimeException("Database error"));

        RuntimeException exception = assertThrows(RuntimeException.class, () -> transactionDailySummaryService.getDailyTransactionSummary(mId));

        assertEquals("Database error", exception.getMessage());
        verify(transactionSummaryDao, times(1)).getTransactionSummary(mId);
    }

    // Test case for empty data in the Settlement Summary
    @Test
    void testGetSettlementDailySummaryEmptyData() {
        String mId = "12345";

        when(transactionSummaryDao.getDailySettlementSummary(mId)).thenReturn(Collections.emptyList());

        ReportingResponse<SettlementSummaryReport> response = transactionDailySummaryService.getSettlementDailySummary(mId);

        assertNotNull(response);
        assertTrue(response.getData().isEmpty(), "The data should be empty");
        verify(transactionSummaryDao, times(1)).getDailySettlementSummary(mId);
    }

    // Test case for empty data in the Refund Summary
    @Test
    void testGetDailyRefundSummaryEmptyData() {
        String mId = "12345";

        when(transactionSummaryDao.getDailyRefundSummary(mId)).thenReturn(Collections.emptyList());

        ReportingResponse<RefundSummaryReport> response = transactionDailySummaryService.getDailyRefundSummary(mId);

        assertNotNull(response);
        assertTrue(response.getData().isEmpty(), "The data should be empty");
        verify(transactionSummaryDao, times(1)).getDailyRefundSummary(mId);
    }
}
