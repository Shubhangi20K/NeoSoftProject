# Changelog

Release specific changes to this project will be documented in this file.

___

## History
| Version | Release date |  
|---------|--------------|
| 0.0.1   | June 26,2025 |


## [0.0.1] - 2025-02-26


## Added
- Report: Fees invoices(#2)
- Phase2-Reports|Dashboard|Transaction|Trends(#5)
- Phase2-Reports|Dashboard|Transaction|Transaction Summary(#6)
- ReportService-Get-Report Name(#7)
- Report|Invoices|Transaction Fee Invoices(#8)
- Reports|File Formatter - PDF|XLS|CSV(#9)
- Reports|Dashboard|Transaction|Transaction Summary-Failure(#10)
- Phase 2- Notifications - Alert - Master Creation(#11)
- Add xls and csv generation util(#12)
- Transation Report - Get Transaction Report From View(#13)
- Get All Report Request(#14)
- Reports|Order Report|Generate Report from Order View(#15)
- Report request creation(#16)
- RefundReportAPI(#17)
- Report scheduler(#18)
- AWS: Upload file to S3(#19)
- Kafka Producer and Consumer Implementation(#20)
- Endpoint to download generated report(#21)
- Schedule management update(#22)
- Cancel scheduler(#23)
- Phase-2|Report|TestCase|Get Transaction Report from View(#24)
- S3 Implementation to store report files(#25)
- Junit Test Case(#26)
- Update Security JWT URL in Property File(#27)
- Enable Hibernate Batch Processing for Optimized Performance(#28)
- Swagger Implementation for Reporting Service(#29)
- Add Logging in ReportScheduleManagementDao and ReportManagementDao(#31)
- Add Logger and Method/Class Descriptions for Scheduler, Controller, Service, DAO, and Utils(#33)
- EPAY_Report_Service_Class_And_Method_Definition(#34)
- Build.gradle - Update dependencies(#35)
- create a scheduler for report management(#36)
- Send Alert For Generated Report(#37)
- Update merchant_fees_report.html to match frontend-provided template(#38)
- Create Gst invoice(#39)
- New API and View to get Recent Transaction(#40)
- API : To Get Transaction summary and Settlement data(#41)
- API : Download recent transaction csv(#42)
- Epay ReportService TestCases(#43)
- Bank Review Comments(#44)
- Test Cases For Report(#45)
- Test cases - Invoice functionality(#48)
- Test cases - Report management service(#49)
- Test cases - TransactionDashboard(#50)
- Test cases - ReportManagementController(#51)
- Test cases - ReportScheduleManagementController(#52)
- Test cases - ReportScheduleManagementValidator(#53)
- add @valid validation in report service(#54)
- Logger |Report| Added logger in ReportingExceptionHandler(#55)
- send paymode in Transaction Paymode Report response(#56)
- Bank Feedback(#57)
- Provide Hourly option too along with Daily and Monthly for Recent Transaction data(#59)
- add view for sit(#60)
- update error code(#61)
- Key ID to be fetched and displayed in Keys section(#62)
- Zip for GST and Fee is not getting opened for multiple months(#63)
- Add remark 'No record found for the selection.' if report has no record(#70)
- Make scheduleExecutionDate as not mandatory field for DAILY report schedule management(#71)
- Update Merchant PUT endpoint method and its path(#76)
- Report format - Error message correction(#77)
- Update Merchant PUT endpoint method and its path(#79)
- Allow "-" and ".' in branch name(#80)
- ER Service | Mis Report Upload in s3 and Download from s3(#81)
- Report Service - Add Frequency Validation in Transaction Report Download(#82)
- Report validations(#103)
- add date validation for fromdate and toDate(#104)
- Report summary date validation(#105)
- Updated Kafka producer config, now no need to create each env. KafkaProducer<Env>Settings(#107)


### Changed
- Replace application.properties to application.yml(#32)
- modify gstInvoice conversion(#47)
- Refactor error code and message(#64)
- Data not coming in sorted order for transaction trends api(#65)
- Getting FailureReason as Integer value instead of String in Transaction Summary API(#68)
- Changes in refund report view(#69)
- ErrorConstant GENERIC_ERROR_MESSAGE changes(#78)
### Removed



### Fixed

- Refund header mismatch bug(#30)
- QA Observations MEK encryption bug(#46)
- Fix transaction recent daily report data(#58)
- Fix dependency vulnerability||build.gradle(#66)
- Fix correlation-id issue(#67)
- Fix Report Schedule Management put api(#72)
- Bug fixes for getDailyRefundSummary(#73)
- Bug fixes for report services(#74)
- QA bugs(#75)
- Report schedule management search defects(#83)
- Report schedule management cancel id(#84)
- Report Service Report Management Bugs Fixes(#85)
- Report Service Trends Validation(#86)
- report service bug(#87)
- Epay Report Service - Bug Fixes(#88)
- Report management Search Fixes(#89)
- Report Service Recent And Download Transaction Bug Fixes(#90)
- Getting zip file for downloading one month GSTinvoice(#91)
- Epay Report Service - Report Schedule Management Search Bugs Fixes(#92)
- SIT-report bug fix(#93)
- Reporting Transaction Summary Mid Sit fixes(#94)
- Report Service - Report Schedule Management Cancel Bug Fixes(#95)
- Unable to generate fees invoice pdf(#96)
- Epay Report Service - Fix Fortify Issue(#98)
- Report management Date fixes(#99)
- SIT Report Token Issues(#100)
- add report month and fix duplicate pdf(#102)





