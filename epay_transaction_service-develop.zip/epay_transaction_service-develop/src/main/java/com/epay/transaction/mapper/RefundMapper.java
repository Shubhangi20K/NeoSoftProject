package com.epay.transaction.mapper;

import com.epay.transaction.dto.BulkRefundBookingDto;
import com.epay.transaction.dto.MerchantPaymentOrderDto;
import com.epay.transaction.dto.RefundBookingDto;
import com.epay.transaction.entity.BulkRefundBooking;
import com.epay.transaction.entity.RefundBooking;
import com.epay.transaction.model.request.RefundBookRequest;
import com.epay.transaction.model.response.RefundResponse;
import com.epay.transaction.util.DateTimeUtils;
import com.epay.transaction.util.enums.RefundStatus;
import com.epay.transaction.util.enums.TransactionStatus;
import org.apache.commons.lang3.StringUtils;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;
import org.springframework.data.domain.Page;

import java.util.List;

@Mapper(builder = @Builder(disableBuilder = true), componentModel = "spring", imports = DateTimeUtils.class)
public interface RefundMapper {

    /**
     * Map refund booking dto to refund details response
     *
     * @param refundBookingDto RefundBookingDto
     * @return RefundDetailResponse
     */
    @Mapping(source = "createdDate", target = "requestTime")
    RefundResponse dtoToResponse(RefundBookingDto refundBookingDto);

    /**
     * Map list of refund booking dto to list refund details response
     *
     * @param refundBookingDtoList List<RefundBookingDto>
     * @return List<RefundDetailResponse>
     */
    List<RefundResponse> dtoToResponse(List<RefundBookingDto> refundBookingDtoList);

    /**
     * Map refund booking dto to refund booking entity
     *
     * @param refundBookingDto RefundBookingDto
     * @return RefundBooking
     */
    @Mapping(target = "id", ignore = true)
    @Mapping(source = "arrnNumber", target = "arrnNum")
    @Mapping(source = "atrnNumber", target = "atrnNum")
    RefundBooking dtoToEntity(RefundBookingDto refundBookingDto);

    /**
     * Map refund booking entity to refund booking dto
     *
     * @param refundBooking RefundBooking
     * @return RefundBookingDto
     */
    @Mapping(source = "arrnNum", target = "arrnNumber")
    @Mapping(source = "atrnNum", target = "atrnNumber")
    RefundBookingDto entityToDto(RefundBooking refundBooking);

    /**
     * Map pageable of refund booking entity to pageable of refund booking dto
     *
     * @param refundBookingPage Page<RefundBooking>
     * @return Page<RefundBookingDto>
     */
    default Page<RefundBookingDto> entityToDto(Page<RefundBooking> refundBookingPage) {
        return refundBookingPage.map(this::entityToDto);
    }

    /**
     * Map bulk refund booking entity to bulk refund booking dto
     *
     * @param bulkRefundBooking BulkRefundBooking
     * @return BulkRefundBookingDto
     */
    BulkRefundBookingDto mapEntityToDto(BulkRefundBooking bulkRefundBooking);

    /**
     * Creating RefundResponse object from RefundBookingDto & MerchantPaymentOrderDto object.
     *
     * @param refundBookingDto        RefundBookingDto
     * @param merchantPaymentOrderDto MerchantPaymentOrderDto
     * @return RefundResponse
     */
    @Mapping(target = "arrnNumber", source = "refundBookingDto.arrnNumber")
    @Mapping(target = "sbiOrderRefNumber", source = "refundBookingDto.sbiOrderRefNumber")
    @Mapping(target = "atrnNumber", source = "refundBookingDto.atrnNumber")
    @Mapping(target = "refundAmount", source = "refundBookingDto.refundAmount")
    @Mapping(target = "refundType", source = "refundBookingDto.refundType")
    @Mapping(target = "refundStatus", source = "refundBookingDto.refundStatus")
    @Mapping(target = "requestTime", source = "refundBookingDto.createdDate")
    @Mapping(target = "refundAvailableAmount", source = "merchantPaymentOrderDto.availableRefundAmount")
    RefundResponse mapToRefundResponse(RefundBookingDto refundBookingDto, MerchantPaymentOrderDto merchantPaymentOrderDto);

    /**
     * Creating RefundBookingDto object from RefundBookRequest & TransactionDto object.
     *
     * @param refundBookRequest       RefundBookRequest
     * @param merchantPaymentOrderDto TransactionDto
     * @return RefundBookingDto
     */
    @Mapping(target = "arrnNumber", ignore = true)
    @Mapping(target = "sbiOrderRefNumber", source = "merchantPaymentOrderDto.sbiOrderRefNumber")
    @Mapping(target = "refundStatus", source = "merchantPaymentOrderDto.transactionStatus", qualifiedByName = "convertTxnStatusToRefundStatus")
    @Mapping(target = "refundType", source = "refundBookRequest.refundType")
    @Mapping(target = "refundAmount", source = "refundBookRequest.refundAmount")
    @Mapping(target = "atrnNumber", source = "merchantPaymentOrderDto.atrnNumber")
    @Mapping(target = "remark", source = "refundBookRequest.remark")
    @Mapping(target = "MId", source = "merchantPaymentOrderDto.MId")
    RefundBookingDto mapToRefundBookingDto(RefundBookRequest refundBookRequest, MerchantPaymentOrderDto merchantPaymentOrderDto);

    /**
     * Convert transaction status to refund status
     *
     * @param transactionStatus TransactionStatus
     * @return String
     */
    @Named("convertTxnStatusToRefundStatus")
    default String convertTxnStatusToRefundStatus(TransactionStatus transactionStatus) {
        return StringUtils.equalsIgnoreCase(transactionStatus.name(), TransactionStatus.SETTLED.name()) ? RefundStatus.REFUND_BOOKED.name() : RefundStatus.CANCELLATION_BOOKED.name();
    }

    /**
     * Map refund booking entity to refund booking dto
     *
     * @param refundBookings List<RefundBooking>
     * @return List<RefundBookingDto>
     */
    List<RefundBookingDto> entityToDto(List<RefundBooking> refundBookings);
}