package com.epay.transaction.controller;


import com.epay.transaction.model.request.EncryptedRequest;
import com.epay.transaction.model.response.EncryptedResponse;
import com.epay.transaction.model.response.TransactionResponse;
import com.epay.transaction.service.SbiEisService;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 *  Class Name: SbiEisController
 * <p>
 *  Description: Provide Eis Services
 * <p>
 * Copyright (c) [2024] [State Bank of India]
 * All rights reserved.
 * <p>
 * Author:@V0000001(Shilpa Kothre)
 * Version:1.0
 */

@RestController
@AllArgsConstructor
@RequestMapping("/eis")
public class SbiEisController {

    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private final SbiEisService sbiEisService;
    /**
     * This API is used to validate gstIn number from eis-service
     *
     * @param encryptedRequest EncryptedRequest
     * @return TransactionResponse<String>
     */
    @PostMapping("/validate-gstn")
    @PreAuthorize("hasAnyRole('TRANSACTION')")
    public TransactionResponse<EncryptedResponse> verifyGSTInNumber(@Valid @RequestBody EncryptedRequest encryptedRequest) {
        logger.info("GST Validation are in processing started");
        return sbiEisService.verifyGSTInNumber(encryptedRequest);
    }

    /**
     * This API is used to validate ecom card number from eis-service
     *
     * @param encryptedRequest EncryptedRequest
     * @return TransactionResponse<String>
     */
    @PostMapping("/validate-ecom")
    @PreAuthorize("hasAnyRole('TRANSACTION')")
    public TransactionResponse<EncryptedResponse> verifyCardEComFlag(@Valid @RequestBody EncryptedRequest encryptedRequest) {
        logger.info("Card Validation.");
        return sbiEisService.verifyCardEComFlag(encryptedRequest);

    }

}
