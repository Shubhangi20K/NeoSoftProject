package com.epay.transaction.externalservice.response.eis.ecom;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class GSTResponse implements Serializable {
    @JsonProperty("RESPONSE_STATUS")
    private String responseStatus;
    @JsonProperty("ERROR_DESCRIPTION")
    private String errorDescription;
    @JsonProperty("ERROR_CODE")
    private String errorCode;
    @JsonProperty("RESPONSE_DESCRIPTION")
    private String responseDecription;
    @JsonProperty("GSTIN_DETAILS")
    private GstinDetails gstinDetails;

}
