package com.epay.transaction.repository;

import com.epay.transaction.entity.EisApiHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EisApiHistoryRepository extends JpaRepository<EisApiHistory, String> {
}
