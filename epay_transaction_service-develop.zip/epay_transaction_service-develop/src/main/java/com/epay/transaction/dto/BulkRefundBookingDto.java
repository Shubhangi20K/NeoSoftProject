package com.epay.transaction.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Class Name:BulkRefundBookingDto
 * *
 * Description: This class serves as a Data Transfer Object (DTO) for managing bulk refund booking
 * *
 * Author:V1019439(Rahul Yadav)
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class BulkRefundBookingDto {
    private String bulkId;
    private Integer totalRecords;
    private Integer validRecords;
    private Integer invalidRecords;
    private String bulkRefundStatus;
    private String remark;
    private Long updatedDate;
}
