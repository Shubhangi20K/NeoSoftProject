package com.epay.transaction.externalservice.response.eis.ecom;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class EisEComResponse {

    @JsonProperty("ChannelDetails")
    public List<ChannelDetail> channelDetails;
    @JsonProperty("ResponseCode")
    public String responseCode;

}
