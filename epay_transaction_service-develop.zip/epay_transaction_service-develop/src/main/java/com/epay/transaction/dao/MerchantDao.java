package com.epay.transaction.dao;

import com.epay.transaction.exceptions.TransactionException;
import com.epay.transaction.exceptions.ValidationException;
import com.epay.transaction.externalservice.MerchantServicesClient;
import com.epay.transaction.externalservice.request.merchant.UserValidationRequest;
import com.epay.transaction.externalservice.response.merchant.MerchantThemeResponse;
import com.epay.transaction.model.response.TransactionResponse;
import com.epay.transaction.util.TransactionConstant;
import com.sbi.epay.authentication.exception.EPayAuthenticationException;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class MerchantDao {
    private final MerchantServicesClient merchantServicesClient;

    public boolean validateMerchantToken(String token) {
        try {
            return merchantServicesClient.validateMerchantToken(token).getStatus() == TransactionConstant.RESPONSE_SUCCESS;
        } catch (ValidationException e) {
            throw new EPayAuthenticationException(e.getErrorMessages().getFirst().getErrorMessage());
        } catch (TransactionException e) {
            throw new EPayAuthenticationException(e.getErrorMessage());
        }
    }

    public boolean validateMerchantUser(UserValidationRequest userValidationRequest) {
        try {
            return merchantServicesClient.validateMerchantUser(userValidationRequest).getStatus() == TransactionConstant.RESPONSE_SUCCESS;
        } catch (ValidationException e) {
            throw new EPayAuthenticationException(e.getErrorMessages().getFirst().getErrorMessage());
        } catch (TransactionException e) {
            throw new EPayAuthenticationException(e.getErrorMessage());
        }
    }

    public MerchantThemeResponse getMerchantTheme(String mId) {
        TransactionResponse<MerchantThemeResponse> response = merchantServicesClient.getMerchantPaymentTheme(mId);
        if (TransactionConstant.RESPONSE_SUCCESS == response.getStatus() && CollectionUtils.isNotEmpty(response.getData()) && CollectionUtils.isEmpty(response.getErrors())) {
            return response.getData().getFirst();
        } else if (CollectionUtils.isNotEmpty(response.getErrors())) {
            throw new TransactionException(response.getErrors());
        }
        throw new ValidationException(response.getErrors());
    }
}
