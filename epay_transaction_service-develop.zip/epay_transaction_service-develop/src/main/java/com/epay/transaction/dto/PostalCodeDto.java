package com.epay.transaction.dto;
import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * Class Name: PostalCodeDetailsDto
 * *
 * Description: PostalCodeDto class is to transfer the data.
 * *
 * Author: (Shital S)
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Data
@AllArgsConstructor
public class PostalCodeDto {
    private String postalCode;
    private String cityName;
    private String countryCode;
    private String stateName;
}