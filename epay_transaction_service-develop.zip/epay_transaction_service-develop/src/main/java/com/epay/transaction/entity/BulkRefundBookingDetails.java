package com.epay.transaction.entity;

import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.SuperBuilder;
import java.util.UUID;

/**
 * Class Name:BulkRefundBookingDetails
 * *
 * Description:
 * *
 * Author:Nirmal Gurjar
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
@Table(name = "BULK_REFUND_BOOKING_DTLS")
public class BulkRefundBookingDetails extends AuditEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;
    private String bulkId;
    private Integer rowNumber;
    private String refundStatus;
    private String remark;

    private String refundType;
    private String merchantOrderId;
    private String atrnNum;
    private String refundAmount;
    private String refundCurrency;
    private String comments;

}
