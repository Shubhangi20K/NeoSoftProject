package com.epay.transaction.util.enums;

/**
 *
 *  Copyright (c) [2024] [State Bank of India]
 *  All rights reserved.
 * <p>
 *  Author:@V0000001(Shilpa Kothre)
 *  Version:1.0
 *
 */

public enum TokenStatus {
    NOT_GENERATED,ACTIVE,INACTIVE,EXPIRED
}
