package com.epay.transaction.externalservice.response.eis.gst;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
    public class EISGstResponse {

    @JsonProperty("RESPONSE")
    private String encryptedResponse;

    @JsonProperty("ERROR_CODE")
    private String errorCode;

    @JsonProperty("ERROR_DESCRIPTION")
    private String errorDescription;

    @JsonProperty("RESPONSE_STATUS")
    private String responseStatus;

    @JsonProperty("DIGI_SIGN")
    private String digiSign;

    @JsonProperty("REQUEST_REFERENCE_NUMBER")
    private String requestReferenceNumber;

    @JsonProperty("RESPONSE_DATE")
    private String responseDate;


}
