package com.epay.transaction.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.UUID;

/**
 * Class Name:RefundAdjustedListener
 * <p>
 * Description:  Dto Class
 * <p>
 * Copyright (c) [2025] [State Bank of India]
 * All rights reserved.
 * <p>
 * Author:@V0000001(Shilpa Kothre)
 * Version:1.0
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class RefundAdjustedDto {

    List<String> arrnList;
    UUID payoutId;

}
