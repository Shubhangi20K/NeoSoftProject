package com.epay.transaction.mapper;

import com.epay.transaction.externalservice.request.admin.AdminPricingRequest;
import com.epay.transaction.model.request.MerchantPricingRequest;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;

@Mapper(builder = @Builder(disableBuilder = true), componentModel = "spring")
public interface PricingMapper {

    AdminPricingRequest mapToAdminRequest(MerchantPricingRequest merchantPricingRequest);
}