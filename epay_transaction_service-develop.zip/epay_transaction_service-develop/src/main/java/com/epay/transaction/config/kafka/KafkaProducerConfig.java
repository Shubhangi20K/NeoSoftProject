package com.epay.transaction.config.kafka;

import com.epay.transaction.util.TransactionUtil;
import lombok.RequiredArgsConstructor;
import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.config.SslConfigs;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Class Name: KafkaProducerConfig
 * *
 * Description: This is parent for kafka config class.
 * *
 * Author: Gireesh M
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Configuration
@RequiredArgsConstructor
public class KafkaProducerConfig {

    private final KafkaProducerSettings kafkaProducerSettings;

    /**
     * Create Kafka template to publish String message on transaction topic(s).
     * @return KafkaTemplate<String, String>
     */
    @Bean
    public KafkaTemplate<String, String> stringKafkaTemplate() {
        return new KafkaTemplate<>(stringProducerFactory());
    }

    private ProducerFactory<String, String> stringProducerFactory() {
        return new DefaultKafkaProducerFactory<>(getProducerConfigs());
    }

    /**
     * Creating Kafka config map
     * @return Map
     */
    private Map<String, Object> getProducerConfigs() {
        Map<String, Object> props = new HashMap<>();

        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, kafkaProducerSettings.getBootstrapServers());
        props.put(ProducerConfig.ACKS_CONFIG, kafkaProducerSettings.getAcks());
        props.put(ProducerConfig.RETRIES_CONFIG, kafkaProducerSettings.getRetries());
        props.put(ProducerConfig.BATCH_SIZE_CONFIG, kafkaProducerSettings.getBatchSize());
        props.put(ProducerConfig.LINGER_MS_CONFIG, kafkaProducerSettings.getLingerMs());
        props.put(ProducerConfig.BUFFER_MEMORY_CONFIG, kafkaProducerSettings.getBufferMemory());
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        if(kafkaProducerSettings.isSslConfigProvided()) {
            props.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, kafkaProducerSettings.getSecurityProtocol());
            props.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, TransactionUtil.getAbsolutePath(kafkaProducerSettings.getTrustLocation()));
            props.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, kafkaProducerSettings.getTrustPassword());
            props.put(SslConfigs.SSL_TRUSTSTORE_TYPE_CONFIG, kafkaProducerSettings.getTrustType());
            props.put(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG, TransactionUtil.getAbsolutePath(kafkaProducerSettings.getKeyLocation()));
            props.put(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG, kafkaProducerSettings.getKeyPassword());
            props.put(SslConfigs.SSL_KEYSTORE_TYPE_CONFIG, kafkaProducerSettings.getKeyType());
        }
        props.put(ProducerConfig.CLIENT_ID_CONFIG,  "transaction-producer-" + UUID.randomUUID());

        return props;
    }
}
