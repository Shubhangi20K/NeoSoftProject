package com.epay.transaction.util.dcms.eis;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import java.io.*;
import java.nio.charset.StandardCharsets;

/**
 * Class Name:DCMSEISEncoderUtil
 * *
 * Description:
 * *
 * Author:V1014352(Ranjan Kumar)
 * <p>
 * Copyright (c) 2025 [State Bank of INdia]
 * All right reserved
 * *
 * Version:1.0
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class DCMSEISEncoderUtil {
    private static final int bytesPerLine = 57;
    private static final char[] pem_array = new char[]{'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '+', '/'};
    private static final int bytesPerAtom = 3;
    private static PrintStream pStream;

    private static void encodeBufferPrefix(OutputStream aStream)  {
        pStream = new PrintStream(aStream);
    }

    private static void encodeLineSuffix()  {
        pStream.println();
    }

    private static int readFully(InputStream in, byte[] buffer) throws IOException {
        for (int i = 0; i < buffer.length; ++i) {
            int q = in.read();
            if (q == -1) {
                return i;
            }

            buffer[i] = (byte) q;
        }

        return buffer.length;
    }

    public static void encode(InputStream inStream, OutputStream outStream) throws IOException {
        byte[] tmpbuffer = new byte[bytesPerLine];
        encodeBufferPrefix(outStream);

        while (true) {
            int numBytes = readFully(inStream, tmpbuffer);
            if (numBytes == 0) {
                break;
            }

            for (int j = 0; j < numBytes; j += bytesPerAtom) {
                if (j + bytesPerAtom <= numBytes) {
                    encodeAtom(outStream, tmpbuffer, j, bytesPerAtom);
                } else {
                    encodeAtom(outStream, tmpbuffer, j, numBytes - j);
                }
            }

            if (numBytes < bytesPerLine) {
                break;
            }

            encodeLineSuffix();
        }

    }


    public static String encode(byte[] aBuffer) {
        ByteArrayOutputStream outStream = new ByteArrayOutputStream();
        ByteArrayInputStream inStream = new ByteArrayInputStream(aBuffer);
        try {
            encode(inStream, outStream);
            return outStream.toString(StandardCharsets.ISO_8859_1);
        } catch (Exception e) {
            throw new Error("CharacterEncoder.encode internal error");
        }
    }


    private static void encodeAtom(OutputStream outStream, byte[] data, int offset, int len) throws IOException {
        byte a;
        if (len == 1) {
            a = data[offset];
            byte b = 0;
            outStream.write(pem_array[a >>> 2 & 63]);
            outStream.write(pem_array[(a << 4 & 48) + (b >>> 4 & 15)]);
            outStream.write(61);
            outStream.write(61);
        } else {
            byte b;
            if (len == 2) {
                a = data[offset];
                b = data[offset + 1];
                byte c = 0;
                outStream.write(pem_array[a >>> 2 & 63]);
                outStream.write(pem_array[(a << 4 & 48) + (b >>> 4 & 15)]);
                outStream.write(pem_array[(b << 2 & 60) + (c >>> 6 & 3)]);
                outStream.write(61);
            } else {
                a = data[offset];
                b = data[offset + 1];
                byte c = data[offset + 2];
                outStream.write(pem_array[a >>> 2 & 63]);
                outStream.write(pem_array[(a << 4 & 48) + (b >>> 4 & 15)]);
                outStream.write(pem_array[(b << 2 & 60) + (c >>> 6 & 3)]);
                outStream.write(pem_array[c & 63]);
            }
        }

    }
}
