package com.epay.transaction.externalservice.request.eis.ecom;

import com.epay.transaction.util.TransactionConstant;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class EISEComPayloadRequest {


    @JsonProperty("ActionType")
    @Builder.Default
    private String actionType = TransactionConstant.ACTION_TYPE;

    @JsonProperty("BankCode")
    @Builder.Default
    private String bankCode = TransactionConstant.CLIENT_Id;

    @JsonProperty("SourceId")
    @Builder.Default
    private String sourceId = TransactionConstant.EIS_SOURCE_ID;

    @JsonProperty("CardNumber")
    private String cardNumber;


}