package com.epay.transaction.util.file.generator;

import com.epay.transaction.util.enums.Report;
import com.epay.transaction.util.enums.ReportFormat;
import com.epay.transaction.util.file.model.CSVFileModel;
import com.epay.transaction.util.file.model.ExcelFileModel;
import com.epay.transaction.util.file.model.FileModel;
import com.epay.transaction.util.file.model.PdfFileModel;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.Objects;

@Service
@RequiredArgsConstructor
public class FileGenerator {
    private static final LoggerUtility logger = LoggerFactoryUtility.getLogger(FileGenerator.class);


    /**
     * This method handles the downloading of files based on the requested format.
     * Depending on the requested format (CSV, XLS, PDF), it invokes the respective generator
     * to create the file and send it as a response to the client.
     *
     * @param response The HTTP response object used to send the file to the client.
     * @param reportFormat The format of the report (CSV, XLS, or PDF).
     * @param report The report details containing the report name and template name.
     * @param mId The unique identifier for the report.
     * @param fileModel The file model containing the report data.
     */
    public void downloadFile(HttpServletResponse response, ReportFormat reportFormat, Report report, String mId, FileModel fileModel) {
        logger.info("Download requested for report format: {}, report: {}, mId: {}", reportFormat, report.getName(), mId);
        if (Objects.requireNonNull(reportFormat) == ReportFormat.CSV) {
            CSVFileModel csvFileModel = (CSVFileModel) fileModel;
            CSVGenerator.downloadCsvFile(response, report.getName(), mId, csvFileModel.getHeaders(), csvFileModel.getFileData());
            logger.debug("CSV file generation complete for report: {}", report.getName());
        } else {
            logger.error("Unsupported report format: {}", reportFormat);
            throw new IllegalArgumentException("Requested File Formatter not supported");
        }
    }

    /**
     * This method builds the appropriate file model based on the requested report format
     * and the provided data (headers, fileData, pdfFileData).
     *
     * @param reportFormat The format of the report (CSV, XLS, or PDF).
     * @param header The headers for the report (used in CSV and Excel formats).
     * @param fileData The data for the report (used in CSV and Excel formats).
     * @param pdfFileData The data for the PDF report (used in PDF format).
     * @return A FileModel representing the data to be used for generating the report.
     */
    public FileModel buildFileModel(ReportFormat reportFormat, List<String> header, List<List<Object>> fileData, Map<String, Object> pdfFileData) {
        logger.info("Building file model for report format: {}", reportFormat);
        return switch (reportFormat) {
            case CSV -> CSVFileModel.builder().headers(header).fileData(fileData).build();
            case XLS -> ExcelFileModel.builder().headers(header).fileData(fileData).build();
            case PDF -> PdfFileModel.builder().fileData(pdfFileData).build();
            case null -> CSVFileModel.builder().headers(header).fileData(fileData).build();
        };
    }
}
