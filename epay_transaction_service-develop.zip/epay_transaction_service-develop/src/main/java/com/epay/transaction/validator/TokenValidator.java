package com.epay.transaction.validator;

import com.epay.transaction.exceptions.ValidationException;
import com.epay.transaction.util.TransactionUtil;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Arrays;

import static com.epay.transaction.util.TransactionConstant.ORDER_HASH_LENGTH;
import static com.epay.transaction.util.TransactionConstant.ORDER_REFERENCE_NUMBER_REGEX;
import static com.epay.transaction.util.TransactionErrorConstants.*;
import static org.apache.commons.lang3.ObjectUtils.isEmpty;
import static org.apache.commons.lang3.StringUtils.equalsIgnoreCase;
import static com.epay.transaction.util.TransactionConstant.MERCHANT_API_KEY_ID;
import static com.epay.transaction.util.TransactionConstant.MERCHANT_API_KEY_SCRT;

/**
 * Class Name: TokenValidator
 * *
 * Description: Validates token generation request .
 * *
 * Author: NIRMAL GURJAR
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Component
@RequiredArgsConstructor
public class TokenValidator extends BaseValidator {

    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());

    public void validateBusinessUrl(String businessUrlInHeader, String configuredBusinessUrls) {
        logger.info("Business url validation started for businessUrlInHeader : {}", businessUrlInHeader);
        String domainInHeader = TransactionUtil.getDomain(businessUrlInHeader);
        if (isEmpty(businessUrlInHeader) || isEmpty(configuredBusinessUrls) || Arrays.stream(configuredBusinessUrls.split(",")).noneMatch(businessUrl -> equalsIgnoreCase(domainInHeader, TransactionUtil.getDomain(businessUrl)))) {
            logger.error("Invalid business url:{}", businessUrlInHeader);
            throw new ValidationException(INVALID_ERROR_CODE, MessageFormat.format(INVALID_ERROR_MESSAGE, "Token generation request", "Valid business url not found."));
        }
        logger.info("Business url validation completed");
    }

    /**
     * Method name : validateOrderHash
     * Description : this method validates orderHash i.e. check leading trailing space ,length and validates fields value using regex
     * @param orderHash : String
     */
    public void validateOrderHash(String orderHash) {
        logger.info("Inside validateFieldLengthAndFormat for orderHash: {}", orderHash);
        errorDtoList = new ArrayList<>();
        checkForLeadingTrailingAndSingleSpace(orderHash, ORDER_HASH);
        throwIfErrors();
        validateFieldLength(orderHash, ORDER_HASH_LENGTH, ORDER_HASH);
        throwIfErrors();
        validateFieldWithRegex(orderHash, ORDER_REFERENCE_NUMBER_REGEX, ORDER_HASH, INVALID_ORDER_HASH_REASON);
        throwIfErrors();
    }

    public void validateTokenRequest(String merchantApiKeyId, String merchantApiKeySecret) {
        logger.info("Token validation start");
        errorDtoList = new ArrayList<>();
        checkMandatoryField(merchantApiKeyId, MERCHANT_API_KEY_ID);
        checkMandatoryField(merchantApiKeySecret, MERCHANT_API_KEY_SCRT);
        throwIfErrors();
    }
}