package com.epay.transaction.repository.event.audit;


import com.epay.transaction.entity.event.audit.EventSendLog;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

/**
 * Class Name: EventSendLogRepository
 * <p>
 * Description: interface for  event send logs data persistence and retrieval in a database.
 * <p>
 * Copyright (c) [2024] [State Bank of India]
 * All rights reserved.
 * <p>
 * Author:@V0000001(Shilpa Kothre)
 * Version:1.0
 */
public interface EventSendLogRepository extends JpaRepository<EventSendLog, UUID> {
}
