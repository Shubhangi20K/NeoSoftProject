package com.epay.transaction.externalservice.response.payment;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Class Name:PaymentQRResponse
 * *
 * Description:
 * *
 * Author:V1014352(Ranjan Kumar)
 * <p>
 * Copyright (c) 2025 [State Bank of INdia]
 * All right reserved
 * *
 * Version:1.0
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PaymentQRResponse {
    private String finalQrString;
    private String timeIntervalApplicable;
    private String atrn;
}
