package com.epay.transaction.controller;

import com.epay.transaction.model.request.EncryptedRequest;
import com.epay.transaction.model.response.EncryptedResponse;
import com.epay.transaction.model.response.TransactionResponse;
import com.epay.transaction.service.SbiUPIService;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
/**
 * Class Name:SbiUPIController
 * *
 * Description:
 * *
 * Author:V1018841(Saurabh Mahto)
 * <p>
 * Copyright (c) 2025 [State Bank of INdia]
 * All right reserved
 * *
 * Version:1.0
 */
@RestController
@RequiredArgsConstructor
@Validated
@RequestMapping("/upi/sbi")
public class SbiUPIController {
    private final SbiUPIService sbiUPIService;
    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    /**
     * This endpoint validates a UPI Virtual Payment Address (VPA) payment request
     *
     * @param request Encrypted String
     * @return an Encrypted response
     */

    @PostMapping("/validate-vpa")
    @Operation(summary = "PayMode Verification VPA")
    @PreAuthorize("hasAnyRole('TRANSACTION')")
    public TransactionResponse<EncryptedResponse> validateUpiVPAPayment(@Valid @RequestBody EncryptedRequest request) {
        logger.info("Initiated VPA request:");
        return sbiUPIService.validateUpiVPAPayment(request);
    }

    /**
     * This endpoint retrieves the status of a UPI payment
     *
     * @param request Encrypted String
     * @return Encrypted response
     */
    @PostMapping("/txn/status")
    @PreAuthorize("hasAnyRole('TRANSACTION')")
    @Operation(summary = "Check Payment MerchantOrderPayment Status")
    public TransactionResponse<EncryptedResponse> getStatusEnquiry(@Valid @RequestBody EncryptedRequest request) {
        logger.info("Initiated transaction status request:");
        return sbiUPIService.getStatusEnquiry(request);
    }


}
