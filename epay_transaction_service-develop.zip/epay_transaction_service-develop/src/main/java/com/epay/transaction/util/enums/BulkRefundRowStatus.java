package com.epay.transaction.util.enums;

import com.epay.transaction.exceptions.TransactionException;

import java.text.MessageFormat;
import java.util.Arrays;

import static com.epay.transaction.util.TransactionErrorConstants.INVALID_ERROR_CODE_NO_REASON;
import static com.epay.transaction.util.TransactionErrorConstants.INVALID_ERROR_MESSAGE_NO_REASON;

public enum BulkRefundRowStatus {
    SUCCESS, FAILED, ALL;
    public static BulkRefundRowStatus getBulkRefundRowStatus(String bulkRefundRowStatus) {
        return Arrays.stream(values()).filter(p -> p.name().equalsIgnoreCase(bulkRefundRowStatus)).findFirst().orElseThrow(() -> new TransactionException(INVALID_ERROR_CODE_NO_REASON, MessageFormat.format(INVALID_ERROR_MESSAGE_NO_REASON, "Bulk refund row status", bulkRefundRowStatus)));
    }
}
