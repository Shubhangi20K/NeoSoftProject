package com.epay.transaction.util;

import com.sbi.epay.authentication.model.EPayPrincipal;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.springframework.security.core.context.SecurityContextHolder;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class EPayIdentityUtil {

    public static EPayPrincipal getUserPrincipal() {
        return (EPayPrincipal) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
    }

}
