package com.epay.transaction.externalservice.response.payment;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PaymentUPIStatusResponse {
    private String mId;
    private String merchantOrderRefNumber;
    private String sbiOrderRefNumber;
    private BigDecimal orderAmount;
    private BigDecimal debitAmount;
    private String atrn;
    private String status;
    private String description;
    private String cinNumber;
    private String otherDetails;
    private String bankName;
    private String bankTraceNumber;
    private String bankCode;
    private String customerId;
    private Integer orderRetryCount;
}
