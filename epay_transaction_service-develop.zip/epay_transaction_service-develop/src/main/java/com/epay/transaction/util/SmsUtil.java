package com.epay.transaction.util;

import com.epay.transaction.exceptions.TransactionException;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import java.text.MessageFormat;

import static com.epay.transaction.util.TransactionConstant.REQUEST_TYPE_FAILURE;
import static com.epay.transaction.util.TransactionConstant.REQUEST_TYPE_SUCCESS;

/**
 * Class Name:SmsUtil
 * *
 * Description: This class is used for generated transaction notification for sms
 * *
 * Author:Gireesh M
 * <p>
 * Copyright (c) 2025 [State Bank of india]
 * All right reserved
 * *
 * Version:1.0
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class SmsUtil {

    public static final String TRANSACTION_SUCCESS_SMS = "Dear Customer, Transaction of {0} {1} on {2} at {3} on {4} has been successfully processed through SBIePay.";

    public static final String TRANSACTION_FAILURE_SMS = "Dear Customer, Transaction of {0} {1} on {2} at {3} on {4} through SBIePay has been declined.";

    public static String getSMSTemplate(String requestType) {
        return switch (requestType) {
            case REQUEST_TYPE_SUCCESS -> TRANSACTION_SUCCESS_SMS;
            case REQUEST_TYPE_FAILURE -> TRANSACTION_FAILURE_SMS;
            default -> throw new TransactionException(TransactionErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(TransactionErrorConstants.INVALID_ERROR_MESSAGE, "SMS type", "The given sms type is not present."));
        };
    }
}
