package com.epay.transaction.externalservice.response.admin;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * Class Name: MerchantIfscCodeResponse
 * *
 * Description: MerchantIfscCodeResponse to get admin service response
 * *
 * Author: (Shital s)
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@AllArgsConstructor
@Data
public class MerchantIfscCodeResponse {
    private String bankId;
    private String bankName;
    private String branchName;
    private String branchAddress;
    private String city;
    private String state;
}