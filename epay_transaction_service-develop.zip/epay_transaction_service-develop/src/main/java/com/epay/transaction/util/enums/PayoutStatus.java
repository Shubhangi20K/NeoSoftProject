package com.epay.transaction.util.enums;

import com.epay.transaction.exceptions.TransactionException;

import java.text.MessageFormat;
import java.util.Arrays;

import static com.epay.transaction.util.TransactionErrorConstants.INVALID_ERROR_CODE_NO_REASON;
import static com.epay.transaction.util.TransactionErrorConstants.INVALID_ERROR_MESSAGE_NO_REASON;
/**
 * Enum Name:PayoutStatus
 * *
 * Description:
 * *
 * Author:V0000001(Shilpa Kothre)
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
public enum PayoutStatus {

    SUCCESS,FAILED,IN_PROCESS,PENDING;

    public static PayoutStatus getPayoutStatus(String payoutStatus) {
        return Arrays.stream(values()).filter(p -> p.name().equalsIgnoreCase(payoutStatus)).findFirst().orElseThrow(() -> new TransactionException(INVALID_ERROR_CODE_NO_REASON, MessageFormat.format(INVALID_ERROR_MESSAGE_NO_REASON, "payout status", payoutStatus)));
    }
}
