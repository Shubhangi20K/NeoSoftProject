package com.epay.transaction.service;

import com.epay.transaction.dao.ErrorLogDao;
import com.epay.transaction.dao.MerchantPricingDao;
import com.epay.transaction.dao.OrderDao;
import com.epay.transaction.dto.MerchantFeeDto;
import com.epay.transaction.dto.MerchantPricingDto;
import com.epay.transaction.dto.OrderDto;
import com.epay.transaction.exceptions.ValidationException;
import com.epay.transaction.externalservice.response.admin.MerchantPricingResponse;
import com.epay.transaction.model.request.EncryptedRequest;
import com.epay.transaction.model.request.MerchantPricingRequest;
import com.epay.transaction.model.response.EncryptedResponse;
import com.epay.transaction.model.response.TransactionResponse;
import com.epay.transaction.util.EPayIdentityUtil;
import com.epay.transaction.util.TransactionConstant;
import com.epay.transaction.util.TransactionErrorConstants;
import com.epay.transaction.util.enums.EntityType;
import com.epay.transaction.util.enums.FailureReason;
import com.epay.transaction.validator.MerchantPricingValidator;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.text.MessageFormat;
import java.util.List;

import static com.epay.transaction.util.EncryptionDecryptionUtil.encryptValue;
import static com.epay.transaction.util.PricingUtil.calculateFee;
import static com.epay.transaction.util.TransactionUtil.buildRequestByEncryptRequest;
import static com.epay.transaction.util.TransactionUtil.toJson;

/**
 * Class Name: PricingController
 * *
 * Description: service class for pricing calculation
 * *
 * Author: NIRMAL GURJAR
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */

@Service
@RequiredArgsConstructor
public class MerchantPricingService {

    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());

    private final MerchantPricingDao merchantPricingDao;
    private final MerchantPricingValidator merchantPricingValidator;
    private final ErrorLogDao errorLogDao;
    private final OrderDao orderDao;

    /**
     * Method name:calculatePricingEncrypted
     * Description: This method handles the pricing calculation for an encrypted request. It follows these steps:
     * 1. Decrypts the incoming encrypted request to extract pricing information.
     * 2. Converts the decrypted data into a `MerchantPricingRequest` object.
     * 3. Calls the pricing service to calculate the pricing.
     * 4. Encrypts the response and returns it in the form of an `EncryptedResponse`.
     *
     * @param request The encrypted request containing the pricing data to be decrypted and processed.
     * @return TransactionResponse<EncryptedResponse> The encrypted response containing the calculated pricing data.
     */

    public TransactionResponse<EncryptedResponse> calculatePricingEncrypted(EncryptedRequest request) {

        logger.info("Decrypting the encrypted request:{}", request);
        String aesKey = merchantPricingDao.getEncryptedAESKey();
        // Step 1: Decrypt the incoming request and Convert into MerchantPricingRequest object
        logger.info("converting decrypted request to MerchantPricingRequest ");
        MerchantPricingRequest merchantPricingRequest = buildRequestByEncryptRequest(request.getEncryptedRequest(), aesKey, MerchantPricingRequest.class);

        // Step 2: validates UnrecognisedFields i.e Mid ,Atrn ,postAmout
        merchantPricingValidator.validateUnrecognisedFields(merchantPricingRequest);

        // Step 3: Call merchant pricing
        logger.info("calling pricing service");
        MerchantFeeDto merchantFeeDto = calculatePricing(merchantPricingRequest);

        // Step 4: Encrypt the response
        EncryptedResponse encryptedResponse = EncryptedResponse.builder().encryptedResponse(encryptValue(aesKey, toJson(merchantFeeDto))).build();
        logger.info("Encrypted Response :{}", encryptedResponse);

        return TransactionResponse.<EncryptedResponse>builder().data(List.of(encryptedResponse)).status(TransactionConstant.RESPONSE_SUCCESS).build();
    }

    /**
     * Method Name:calculatePricing
     * Description:This method calculates the pricing for a merchant based on the provided merchant pricing request.
     * It performs the following steps:
     * 1. Sets the Merchant ID (MId) to the pricing request.
     * 2. Validates the provided merchant pricing request using the merchant pricing validator.
     * 3. Retrieves the valid merchant pricing structure from the Admin Service.
     * 4. Calculates the fee using the fetched pricing structure and merchant request details.
     * 5. Saves the calculated pricing information into the database if the ATRN is provided.
     * 6. Returns the merchant fee response containing the calculated pricing.
     *
     * @param merchantPricingRequest The merchant pricing request containing the necessary details to calculate the fee.
     * @return MerchantFeeDto The response containing the calculated pricing information.
     */
    public MerchantFeeDto calculatePricing(MerchantPricingRequest merchantPricingRequest) {

        logger.info("Inside calculatePricing for merchantPricingRequest: {}", merchantPricingRequest);

        //Step 1: Set MId To Merchant Pricing Request
        merchantPricingRequest.setMId(EPayIdentityUtil.getUserPrincipal().getMId());

        //Step 2: Validate Merchant pricing request
        merchantPricingValidator.validatePricingRequest(merchantPricingRequest);
        logger.info("Validating merchant pricing request.");

        //Step 3: Fetching Pricing Structure from Admin Service
        MerchantPricingResponse pricingStructure = merchantPricingDao.getValidMerchantPricingStructure(merchantPricingRequest);
        logger.info("Fetching Merchant pricing done from Admin Service");

        //Step 5: Calculate total fee and set fee in MerchantPricingDto
        MerchantPricingDto merchantPricingDto = calculateFee(pricingStructure, merchantPricingRequest);
        logger.info("Bearable amount calculation done");

        //Step 7: Save pricing info into pricing table
        checkAtrnAndSavePricingInfo(merchantPricingRequest, merchantPricingDto, pricingStructure);
        logger.info("ATRN is checked and if atrn is passed then pricing info saved in db");

        return buildMerchantFeeResponse(merchantPricingRequest, merchantPricingDto);
    }

    /**
     * method name:buildMerchantFeeResponse
     * Description:This method builds and returns a `MerchantFeeDto` object based on the provided `MerchantPricingRequest` and `MerchantPricingDto` details.
     *
     * @param merchantPricingRequest The merchant pricing request containing transaction details and merchant-specific information.
     * @param merchantPricingDto The merchant pricing DTO containing calculated fee information for the merchant.
     * @return MerchantFeeDto The constructed merchant fee response containing all pricing and fee-related details.
     */
    private MerchantFeeDto buildMerchantFeeResponse(MerchantPricingRequest merchantPricingRequest, MerchantPricingDto merchantPricingDto) {
        logger.info("Building Merchant Fee response.");
        return MerchantFeeDto.builder().mId(merchantPricingRequest.getMId()).gtwMapsId(merchantPricingRequest.getGtwMapsId()).payModeCode(merchantPricingRequest.getPayModeCode()).payProcType(merchantPricingRequest.getPayProcType()).merchPostedAmt(merchantPricingRequest.getTransactionAmount()).atrn(merchantPricingRequest.getAtrn()).merchantFeeAbs(merchantPricingDto.getMerchantFeeAbs()).otherFeeAbs(merchantPricingDto.getOtherFeeAbs()).gtwFeeAbs(merchantPricingDto.getGtwFeeAbs()).aggServiceFeeAbs(merchantPricingDto.getAggServiceFeeAb()).postAmount(merchantPricingDto.getPostAmount()).customerBearableAmt(merchantPricingDto.getCustomerBearableAmt()).customerBearableServiceTax(merchantPricingDto.getCustomerBearableServiceTax()).merchantBearableAmt(merchantPricingDto.getMerchantBearableAmt()).merchantBearableServiceTax(merchantPricingDto.getMerchantBearableServiceTax()).build();
    }

    /**
     * method name:checkAtrnAndSavePricingInfo
     * Description: This method checks if the ATRN is provided in the `MerchantPricingRequest`
     * and validates the calculated pricing against the provided post amount. If the pricing matches, it saves the pricing info
     * into the database.
     *
     * @param merchantPricingRequest The merchant pricing request containing transaction details and ATRN.
     * @param merchantPricingDto The DTO containing the calculated pricing details for the transaction.
     * @param pricingStructure The pricing structure used to calculate the fees and amounts for the transaction.
     */
    private void checkAtrnAndSavePricingInfo(MerchantPricingRequest merchantPricingRequest, MerchantPricingDto merchantPricingDto, MerchantPricingResponse pricingStructure) {

        //Step 1 : Check if ATRN is passed
        if (StringUtils.isNotEmpty(merchantPricingRequest.getAtrn())) {
            logger.info("Validating atrn and saving pricing info.");
            //Step 2: Match calculated pricing with post amount
            if (merchantPricingDto.getPostAmount().compareTo(merchantPricingRequest.getPostAmount()) != 0) {
                logger.debug("Pricing miss match error for ATRN :{}", merchantPricingRequest.getAtrn());
                OrderDto orderDto= orderDao.getOrderBySbiOrderRefNumber(EPayIdentityUtil.getUserPrincipal().getMId(), EPayIdentityUtil.getUserPrincipal().getOrderRef());
                errorLogDao.logCustomerError(EPayIdentityUtil.getUserPrincipal().getMId(), EntityType.PAYMENT,merchantPricingRequest.getAtrn(), orderDto.getOrderRefNumber(),EPayIdentityUtil.getUserPrincipal().getOrderRef(),orderDto.getPaymentMode(),TransactionErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(TransactionErrorConstants.INVALID_ERROR_MESSAGE, "Pricing info", "merchPostedAmount does not match"));
                throw new ValidationException(TransactionErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(TransactionErrorConstants.INVALID_ERROR_MESSAGE, "Pricing info", "merchPostedAmount does not match"));
            }
            //Step 3: Save pricing info
            merchantPricingDao.saveMerchantOrderPricing(merchantPricingRequest, merchantPricingDto, pricingStructure);
            logger.info("Merchant Order Hybrid Fee saved successfully.");
        }
    }


}
