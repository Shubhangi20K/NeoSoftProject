package com.epay.transaction.dao;

import com.epay.transaction.dto.EisApiHistoryDto;
import com.epay.transaction.entity.EisApiHistory;
import com.epay.transaction.exceptions.TransactionException;
import com.epay.transaction.externalservice.EISServicesClient;
import com.epay.transaction.externalservice.response.eis.ecom.ChannelDetail;
import com.epay.transaction.externalservice.response.eis.ecom.EISResponse;
import com.epay.transaction.externalservice.response.eis.ecom.GSTResponse;
import com.epay.transaction.mapper.EisApiHistoryMapper;
import com.epay.transaction.model.response.TransactionResponse;
import com.epay.transaction.repository.EisApiHistoryRepository;
import com.epay.transaction.util.TransactionConstant;
import com.epay.transaction.util.TransactionErrorConstants;
import com.sbi.epay.authentication.providers.EPayTokenProvider;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.text.MessageFormat;
import java.util.List;

import static com.epay.transaction.util.TransactionErrorConstants.GSTIN;

/**
 *  Class Name: SbiEisDao
 * <p>
 *  Description: Provide Eis data
 * <p>
 * Copyright (c) [2024] [State Bank of India]
 * All rights reserved.
 * <p>
 * Author:@V0000001(Shilpa Kothre)
 * Version:1.0
 */
@Component
@RequiredArgsConstructor
public class SbiEisDao {

    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private final EISServicesClient eisServicesClient;
    private final KmsDao kmsDao;
    private final EPayTokenProvider ePayTokenProvider;
    private final TokenDao tokenDao;
    private final EisApiHistoryRepository eisApiHistoryRepository;
    private final EisApiHistoryMapper eisApiHistoryMapper;


    /**
     * Retrieves DCMS details for the given eis Ecom request.
     *
     * @return Encrypted response containing DCMS details.
     */

    public TransactionResponse<ChannelDetail> getDCMSEISEComInfo(String aesKey, String eisEncryptionKey, String eisEComRequest) {
        EISResponse eisResponse = eisServicesClient.getCardEComFlag(aesKey, eisEncryptionKey, eisEComRequest);
        logger.info("EISEcomResponse : {}", eisResponse);
        if (StringUtils.isEmpty(eisResponse.getErrorCode())) {
            if (ObjectUtils.isNotEmpty(eisResponse.getEisEComResponse())) {
                for (ChannelDetail channelDetail : eisResponse.getEisEComResponse().getChannelDetails()) {
                    if ("ECOM".equalsIgnoreCase(channelDetail.getCId())) {
                        logger.info("channelDetail : {}", channelDetail);
                        return TransactionResponse.<ChannelDetail>builder().data(List.of(channelDetail)).status(TransactionConstant.RESPONSE_SUCCESS).build();
                    }
                }
            }
            return TransactionResponse.<ChannelDetail>builder().data(List.of()).status(TransactionConstant.RESPONSE_SUCCESS).build();
        }
        throw new TransactionException(eisResponse.getErrorCode(), eisResponse.getErrorDescription());
    }

    /**
     * Retrieves GSTIN details for the given GST number request.
     *
     * @return Encrypted response containing GSTIN details.
     */
    public GSTResponse verifyGSTInNumber(String aesKey, String eisEncryptionKey, String eisGstRequest, String gstNumber) {
        GSTResponse eisGstResponse = eisServicesClient.getGstInDetails(aesKey, eisEncryptionKey, eisGstRequest, gstNumber);
        logger.info("EISGstResponse : {} for gstNumber : {}", eisGstResponse, gstNumber);
        if (StringUtils.isEmpty(eisGstResponse.getErrorCode()) ) {
            if (ObjectUtils.isNotEmpty(eisGstResponse.getGstinDetails())) {
                return eisGstResponse;
            }
            return eisGstResponse;
        }
        throw new TransactionException(TransactionErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(TransactionErrorConstants.INVALID_JSTIN_ERROR_MESSAGE,GSTIN));
    }




    /**
     * Method name:getEncryptedAESKey
     * Description:Retrieves the encrypted AES key used for encryption/decryption operations.
     * <p>
     * This method fetches the AES encryption key from the database using the current token provided by the
     * ePayTokenProvider.
     *
     * @return The encrypted AES key as a string.
     */
    public String getEncryptedAESKey() {
        logger.info("Fetching the encrypted AES key using the current token.");
        return tokenDao.getEncryptionAESKey(ePayTokenProvider.getToken());
    }

    /**
     * Method name : getMerchantMek
     * Description : Fetches MEK from Key management Service
     *
     * @return a String
     */
    public String getMerchantMek() {
        return kmsDao.getMerchantMekKey();
    }

    public EisApiHistoryDto saveEisHistory(EisApiHistoryDto eisApiHistoryDto) {
        EisApiHistory eisApiHistory = eisApiHistoryMapper.dtoToEntity(eisApiHistoryDto);
        return eisApiHistoryMapper.entityToDto(eisApiHistoryRepository.save(eisApiHistory));
    }
}
