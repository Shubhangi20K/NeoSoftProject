package com.epay.transaction.entity.event.audit;


import jakarta.persistence.*;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.SuperBuilder;

import java.util.UUID;

/**
 * Class Name: EventSendLog
 * <p>
 * Description: saving send logs
 * <p>
 * Copyright (c) [2025] [State Bank of India]
 * All rights reserved.
 * <p>
 * Author:@V0000001(Shilpa Kothre)
 * Version:1.0
 */

@EqualsAndHashCode(callSuper = true)
@Entity(name = "EVENT_SEND_LOG")
@SuperBuilder
@Data
public class EventSendLog extends BaseEvent {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(columnDefinition = "RAW(16)")
    private UUID eslId;
}
