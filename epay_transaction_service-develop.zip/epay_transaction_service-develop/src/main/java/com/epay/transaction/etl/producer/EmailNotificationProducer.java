package com.epay.transaction.etl.producer;

import com.epay.transaction.dto.TransactionEmailDto;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

/**
 * Class Name: EmailNotificationProducer
 * *
 * Description: The implementation is for produce email related data to topic.
 * *
 * Author: Gireesh M
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Component
@RequiredArgsConstructor
public class EmailNotificationProducer extends TransactionProducer<TransactionEmailDto> {

    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    private final ObjectMapper objectMapper;

    /**
     * @param requestType String
     * @param routingKey  String
     * @param emailDto    TransactionEmailDto
     */
    @Override
    public void publish(String requestType, String routingKey, TransactionEmailDto emailDto) {
        try {
            log.debug("Email notification published for requestType : {}, routingKey : {} and value : {}", requestType, routingKey, emailDto);
            kafkaMessagePublisher.publish(topics.getEmailTopic(), getRoutingKey("email", requestType, routingKey), objectMapper.writeValueAsString(emailDto));
        } catch (Exception e) {
            log.error("Error in publish Email message, TransactionEmailDto {}", emailDto, e.getMessage());
        }
    }
}
