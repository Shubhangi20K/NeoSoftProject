package com.epay.transaction.controller;

import com.epay.transaction.model.response.EncryptedResponse;
import com.epay.transaction.model.response.TransactionResponse;
import com.epay.transaction.service.BookingService;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import io.swagger.v3.oas.annotations.Operation;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

/**
 * Class Name: BookingController
 * *
 * Description: Order booking for given OrderHash.
 * *
 * Author: V1018212
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@RestController
@RequiredArgsConstructor
@RequestMapping("/booking")
public class BookingController {

    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private final BookingService bookingService;

    /**
     * Method name : transactionBooking
     * Description : Transaction booking for given OrderHash.
     * @param orderHash : is a String type
     * @return : object of TransactionResponse
     */
    
    @PostMapping(value = "/{orderHash}")
    @Operation(summary = "Merchant Transaction Booking for given OrderHash")
    @PreAuthorize("hasAnyRole('TRANSACTION')")
    public TransactionResponse<EncryptedResponse> transactionBooking(@PathVariable("orderHash") String orderHash) {
        logger.info("MerchantOrderPayment Booking is called : orderHash {}", orderHash);
        return bookingService.transactionBooking(orderHash);
    }
}
