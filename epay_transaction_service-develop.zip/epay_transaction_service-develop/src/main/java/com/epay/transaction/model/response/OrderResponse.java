package com.epay.transaction.model.response;

import com.epay.transaction.util.enums.OrderStatus;
import com.epay.transaction.util.enums.PaymentStatus;
import com.epay.transaction.util.enums.TransactionRefundStatus;
import com.epay.transaction.util.enums.TransactionStatus;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.math.BigDecimal;

/**
 * Class Name: MerchantOrderResponseDTO
 * *
 * Description:
 * *
 * Author: V1017903(bhushan wadekar)
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Data
@RequiredArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class OrderResponse {
    private String orderRefNumber;
    private String sbiOrderRefNumber;
    private String atrnNumber;
    private String bankReferenceNumber;
    private Long transactionDate;
    private BigDecimal orderAmount;
    private BigDecimal transactionAmount;
    private BigDecimal availableRefundAmount;
    private PaymentStatus paymentStatus;
    private TransactionStatus transactionStatus;
    private TransactionRefundStatus refundStatus;
    private OrderStatus orderStatus;

}
