package com.epay.transaction.externalservice.response.payment;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonPropertyOrder
public class PaymentUPIVpaCollectGatewayResponse implements Serializable {
    private PaymentUPIVpaCollectResponse apiResp;
    private Integer  orderRetryCount;

}
