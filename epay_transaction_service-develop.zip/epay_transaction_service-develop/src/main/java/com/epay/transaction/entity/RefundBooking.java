package com.epay.transaction.entity;

import com.epay.transaction.util.TransactionUtil;
import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;
import java.util.UUID;

/**
 * Class Name:RefundBooking
 * *
 * Description:
 * *
 * Author:Nirmal Gurjar
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
@EqualsAndHashCode(callSuper = true)
@Getter
@Setter
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "REFUND_BOOKING")
public class RefundBooking extends AuditEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;
    @Column(name = "MERCHANT_ID")
    private String mId;
    private String sbiOrderRefNumber;
    private String arrnNum;
    private String atrnNum;
    private BigDecimal refundAmount;
    private String refundType;
    private String refundStatus;
    private String remark;
    private String refundAdjusted;
    private UUID payoutId;
    private Integer refundRetry;

    /**
     * custom generator, do not remove it
     */
    @PrePersist
    protected void generatedARRN() {
        this.arrnNum = TransactionUtil.createArrnNumber(mId, atrnNum.substring(0,2));
    }


}
