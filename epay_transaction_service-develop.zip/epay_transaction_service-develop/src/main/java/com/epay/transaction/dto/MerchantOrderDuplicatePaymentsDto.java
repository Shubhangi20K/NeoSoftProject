package com.epay.transaction.dto;


import com.epay.transaction.util.enums.PaymentStatus;
import com.epay.transaction.util.enums.SettlementStatus;
import lombok.*;

import java.math.BigDecimal;
import java.util.UUID;

/**
 * Class Name:MerchantOrderDuplicatePaymentsDto
 * *
 * Description:
 * *
 * Author:V00000001(Shilpa Kothre)
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class MerchantOrderDuplicatePaymentsDto {

    private UUID rfdId;
    private UUID rfId;
    private int rowNumber;
    private String atrnNumber;
    private BigDecimal debitAmount;
    private String bankReferenceNumber;
    private PaymentStatus paymentStatus;
    private SettlementStatus settlementStatus;
    private String remark;
    private Long createdDate;
    private Long updatedDate;
    private String createdBy;
    private String updatedBy;
    private String mId;
}
