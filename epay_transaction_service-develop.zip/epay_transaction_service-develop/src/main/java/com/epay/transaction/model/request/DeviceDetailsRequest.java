package com.epay.transaction.model.request;


import lombok.*;

/**
 * Class Name:DeviceDetailsRequest
 * *
 * Description:
 * *
 * Author:Shubhangi Kurelay
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */

@Data
public class DeviceDetailsRequest {
    private String clientIp;
    private String browser;
    private String os;
    private String screenWidth;
    private String screenHeight;
    private String colorDepth;
    private String availableWidth;
    private String availableHeight;
    private String language;
    private String userAgent;
}
