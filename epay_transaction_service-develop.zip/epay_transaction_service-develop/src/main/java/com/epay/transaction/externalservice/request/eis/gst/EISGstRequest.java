package com.epay.transaction.externalservice.request.eis.gst;

import com.epay.transaction.util.TransactionConstant;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class EISGstRequest {

    @JsonProperty("GSTIN")
    private String gstIn;

    @JsonProperty("REQUEST_REFERENCE_NUMBER")
    private String requestReferenceNumber;

    @JsonProperty("SOURCE_ID")
    @Builder.Default
    private String sourceId = TransactionConstant.SOURCE_ID_EY;
}
