package com.epay.transaction.util;

import lombok.experimental.UtilityClass;

import java.nio.ByteBuffer;
import java.util.UUID;

/**
 *  Class Name:JdbcQueryUtility
 *  Description: Utility Class for jdbc methods
 * Copyright (c) [2025] [State Bank of India]
 * All rights reserved.
 * Author:@V0000001(Shilpa Kothre)
 * Version:1.0
 */
@UtilityClass
public class JdbcQueryUtility {

 public static String DVP_MERCHANT_PAYMENT_ORDER_UPDATE= """
            UPDATE MERCHANT_ORDER_PAYMENTS SET
                PAYMENT_STATUS = :paymentStatus, TRANSACTION_STATUS = :transactionStatus, REFUND_STATUS = :refundStatus, SETTLEMENT_STATUS = :settlementStatus, SETTLEMENT_TIME = :settlementTime,
                BANK_REFERENCE_NUMBER = CASE WHEN BANK_REFERENCE_NUMBER = :bankReferenceNumber THEN BANK_REFERENCE_NUMBER ELSE :bankReferenceNumber END,
                OLD_BANK_REFERENCE_NUMBER = CASE WHEN BANK_REFERENCE_NUMBER = :bankReferenceNumber THEN NULL ELSE BANK_REFERENCE_NUMBER END,
                RF_ID = :rfId WHERE ATRN_NUM = :atrnNum
            """;

    public static String NDVP_MERCHANT_PAYMENT_ORDER_UPDATE= """
            UPDATE MERCHANT_ORDER_PAYMENTS SET PAYMENT_STATUS = :paymentStatus, TRANSACTION_STATUS = :transactionStatus, SETTLEMENT_STATUS = :settlementStatus,SETTLEMENT_TIME = :settlementTime,
                BANK_REFERENCE_NUMBER = CASE WHEN BANK_REFERENCE_NUMBER = :bankReferenceNumber THEN BANK_REFERENCE_NUMBER ELSE :bankReferenceNumber END,
                OLD_BANK_REFERENCE_NUMBER = CASE WHEN BANK_REFERENCE_NUMBER = :bankReferenceNumber THEN NULL ELSE BANK_REFERENCE_NUMBER END,
                RF_ID = :rfId WHERE ATRN_NUM = :atrnNum
            """;

    public static String MERCHANT_PAYMENT_ORDER_UPDATE= """
            UPDATE MERCHANT_ORDER_PAYMENTS SET
                BANK_REFERENCE_NUMBER = CASE WHEN BANK_REFERENCE_NUMBER = :bankReferenceNumber THEN BANK_REFERENCE_NUMBER ELSE :bankReferenceNumber END,
                SETTLEMENT_STATUS = :settlementStatus, SETTLEMENT_TIME = :settlementTime, RF_ID = :rfId,
                OLD_BANK_REFERENCE_NUMBER = CASE WHEN BANK_REFERENCE_NUMBER = :bankReferenceNumber THEN NULL ELSE BANK_REFERENCE_NUMBER END
            WHERE ATRN_NUM = :atrnNum
            """;

    public static byte[] uuidToBytes(UUID uuid) {
        ByteBuffer buffer = ByteBuffer.wrap(new byte[16]);
        buffer.putLong(uuid.getMostSignificantBits());
        buffer.putLong(uuid.getLeastSignificantBits());
        return buffer.array();
    }

    public static UUID bytesToUUID(byte[] bytes) {
        ByteBuffer buffer = ByteBuffer.wrap(bytes);
        long high = buffer.getLong();
        long low = buffer.getLong();
        return new UUID(high, low);
    }


}
