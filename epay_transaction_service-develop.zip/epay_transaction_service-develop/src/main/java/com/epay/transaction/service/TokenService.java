package com.epay.transaction.service;

import com.epay.transaction.config.TransactionConfig;
import com.epay.transaction.dao.TokenDao;
import com.epay.transaction.dto.DeviceDetailsDto;
import com.epay.transaction.dto.OrderDto;
import com.epay.transaction.dto.TokenDto;
import com.epay.transaction.entity.Token;
import com.epay.transaction.exceptions.TransactionException;
import com.epay.transaction.externalservice.response.admin.MerchantInfoResponse;
import com.epay.transaction.model.request.DeviceDetailsRequest;
import com.epay.transaction.model.response.TransactionResponse;
import com.epay.transaction.model.response.TransactionTokenResponse;
import com.epay.transaction.util.DateTimeUtils;
import com.epay.transaction.util.EncryptionDecryptionUtil;
import com.epay.transaction.util.TransactionConstant;
import com.epay.transaction.util.TransactionErrorConstants;
import com.epay.transaction.util.enums.TokenStatus;
import com.epay.transaction.validator.TokenValidator;
import com.sbi.epay.authentication.model.AccessTokenRequest;
import com.sbi.epay.authentication.model.TransactionTokenRequest;
import com.sbi.epay.authentication.service.AuthenticationService;
import com.sbi.epay.authentication.util.enums.TokenType;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.text.MessageFormat;
import java.util.List;
import java.util.Optional;

import static com.epay.transaction.util.TransactionErrorConstants.ATTEMPT_EXPIRED_ERROR_CODE;
import static com.epay.transaction.util.TransactionErrorConstants.ATTEMPT_EXPIRED_ERROR_MESSAGE;
/**
 * class name : TokenService
 * Description : Token Generation Service
 * Copyright (c) [2024] [State Bank of India]
 * All rights reserved.
 * <p>
 * Author:@V0000001(Shilpa Kothre)
 * Version:1.0
 */
@RequiredArgsConstructor
@Service
public class TokenService {

    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private final TokenDao tokenDao;
    private final AuthenticationService authenticationService;
    private final TransactionConfig transactionConfig;
    private final TokenValidator tokenValidator;

    private TokenDto buildAccessToken(AccessTokenRequest tokenRequest, String token) {
        return TokenDto.builder().generatedToken(token).isTokenValid(true).tokenType(tokenRequest.getTokenType()).tokenExpiryTime(tokenRequest.getExpirationTime()).mId(tokenRequest.getMId()).status(TokenStatus.ACTIVE).build();
    }

    private DeviceDetailsDto buildTransactionDeviceInfoDto(String orderHash, DeviceDetailsRequest deviceDetailsRequest) {
        return DeviceDetailsDto.builder().clientIp(deviceDetailsRequest.getClientIp()).orderHash(orderHash).deviceDetails(deviceDetailsRequest.toString().getBytes(StandardCharsets.UTF_8)).build();
    }

    private TokenDto buildTransactionToken(TransactionTokenRequest tokenRequest, String token, String orderHash) {
        return TokenDto.builder().generatedToken(token).isTokenValid(true).tokenType(tokenRequest.getTokenType()).tokenExpiryTime(tokenRequest.getExpirationTime()).mId(tokenRequest.getMId()).aesKey(EncryptionDecryptionUtil.keyGenerator()).orderHash(orderHash).status(TokenStatus.ACTIVE).build();
    }

    /**
     * Method name : generateAccessToken
     * Description : Creates the Access Token
     *
     * @param merchantApiKeyId      : ApiKeyId for Merchant
     * @param merchantApiKeySecret: ApiKeySecret for Merchant
     * @return String of AccessToken
     */
    public TransactionResponse<String> generateAccessToken(String merchantApiKeyId, String merchantApiKeySecret) {
        logger.info("Access Token Request with merchantApiKeyId and merchantApiKeySecret");
        logger.debug("Access Token Request with merchantApiKeyId {}", merchantApiKeyId);
        tokenValidator.validateTokenRequest(merchantApiKeyId, merchantApiKeySecret);
        logger.info("access token validation done.");
        String mId = tokenDao.getMIdByKeyIdAndSecret(merchantApiKeyId, merchantApiKeySecret);
        logger.info("Request for MerchantInfo for mId {}", mId);
        MerchantInfoResponse merchantDto = tokenDao.getMerchantByMId(mId);
        logger.debug("Received merchantDto {} for build Access token", merchantDto);
        String token = generatingAccessToken(merchantDto, merchantApiKeyId, merchantApiKeySecret);
        return TransactionResponse.<String>builder().data(List.of(token)).status(TransactionConstant.RESPONSE_SUCCESS).build();
    }

    /**
     * Method name : generateTransactionToken
     * Description : Creates the Transaction Token
     *
     * @param orderHash             : Defines Unique Order
     * @param deviceDetailsRequest: Object of deviceDetailsRequest
     * @return object of TransactionTokenResponse
     */

    public TransactionResponse<TransactionTokenResponse> generateTransactionToken(String businessUrl, String orderHash, DeviceDetailsRequest deviceDetailsRequest, String clientIp) {
        logger.info("Starting transaction token generation request for orderHash {}", orderHash);
        tokenValidator.validateOrderHash(orderHash);
        //Step 1 : Save Device Details
        if (ObjectUtils.isNotEmpty(deviceDetailsRequest)) {
            logger.debug("Going to save device details, deviceDetails: {} and client ip: {}", deviceDetailsRequest, clientIp);
            deviceDetailsRequest.setClientIp(clientIp);
            tokenDao.saveTransactionRequestedDeviceInfo(buildTransactionDeviceInfoDto(orderHash, deviceDetailsRequest));
        }

        //Step 2 : validate If Token is already create for Given Order Hash
        logger.info("Fetching Existing Valid token by orderHash");
        tokenDao.validatedTokenByOrderHash(orderHash);

        //Step 3 : Get Merchant Order By Order Hash
        OrderDto orderDto = tokenDao.getMerchantOrderByOrderHash(orderHash);
        logger.debug("Received details of merchant order, orderDto: {}", orderDto);

        //Step 4 : Get Merchant By MID For Token Expiration Time
        MerchantInfoResponse merchantDto = tokenDao.getMerchantByMId(orderDto.getMId());
        logger.debug("Received details of Merchant, merchantDto: {}", merchantDto);

        //Step 5 : Validate Business url passed in x-referrer header
        tokenValidator.validateBusinessUrl(businessUrl, merchantDto.getMerchantBusinessUrl());
        logger.debug("Business url:{} validated for mId: {}", businessUrl, merchantDto.getMId());

        //Step 6 : Token Generation
        TransactionTokenResponse transactionTokenResponse = generatingTransactionToken(orderDto, merchantDto.getTransactionTokenExpiryTime());
        logger.info("Completed transaction token generation request for orderHash {0}", orderHash);

        logger.debug("Received transaction token response: {}", transactionTokenResponse);

        return TransactionResponse.<TransactionTokenResponse>builder().data(List.of(transactionTokenResponse)).status(TransactionConstant.RESPONSE_SUCCESS).build();
    }

    /**
     * Method name : invalidateToken
     * Description : Invalidate active Token
     *
     * @return String of Invalidated token
     */

    public TransactionResponse<String> invalidateToken(String token) {
        logger.info("Starting process to invalidate the token.");
        token = token.substring("bearer ".length()).trim();
        tokenDao.invalidateToken(token);
        logger.info("Token Invalidated successfully.");
        return TransactionResponse.<String>builder().data(List.of(TransactionConstant.TOKEN_INVALIDATED)).status(TransactionConstant.RESPONSE_SUCCESS).build();
    }

    /**
     * Method name : markTokenExpired
     * Description : setting Token Inactive
     */
    public void markTokenExpired() {
        tokenDao.markTokenExpired();
    }

    /**
     * Method name : generatingAccessToken
     *
     * @param merchantDto          MerchantInfoResponse
     * @param merchantApiKeyId     String
     * @param merchantApiKeySecret String
     * @return Token String
     */
    private String generatingAccessToken(MerchantInfoResponse merchantDto, String merchantApiKeyId, String merchantApiKeySecret) {
        logger.info("GeneratingAccessToken start");
        Optional<TokenDto> tokenDto = tokenDao.getActiveAccessTokenByMId(merchantDto.getMId());
        if (tokenDto.isPresent()) {
            logger.info("Token is already present");
            long timeDiff = tokenDto.get().getTokenExpiryTime() - System.currentTimeMillis();
            if (transactionConfig.getTokenRegenerationTime() < timeDiff) {
                logger.info("Generating new token");
                return tokenDto.get().getGeneratedToken();
            }
        } else {
            logger.info("No active token found for mId: {}", merchantDto.getMId());
        }
        logger.info("Not found Existing token");
        AccessTokenRequest tokenRequest = buildAccessTokenRequest(merchantDto, merchantApiKeyId, merchantApiKeySecret);
        String token = authenticationService.generateAccessToken(tokenRequest);
        logger.info("Getting New token", token);
        TokenDto tokenDto1 = buildAccessToken(tokenRequest, token);
        logger.info("Saving token", tokenDto1);
        tokenDao.saveToken(tokenDto1);
        return token;
    }

    /**
     * Method name : generatingTransactionToken
     *
     * @param orderDto           OrderDto
     * @param transactionTokenExpiryTime Long
     * @return TransactionTokenResponse
     */
    private TransactionTokenResponse generatingTransactionToken(OrderDto orderDto, Long transactionTokenExpiryTime) {
        TransactionTokenRequest tokenRequest = buildTransactionTokenRequest(orderDto, transactionTokenExpiryTime);
        logger.info("Generating transaction token");
        String token = authenticationService.generateTransactionToken(tokenRequest);
        logger.info("Updating token details after generating token");
        TokenDto tokenDto = buildTransactionToken(tokenRequest, token, orderDto.getOrderHash());
        tokenDao.saveToken(tokenDto);
        logger.info("Updated token details after generating token");
        return TransactionTokenResponse.builder().token(token).hval(tokenDto.getAesKey()).build();
    }

    /**
     * Building Access TokenRequest
     *
     * @param merchantDto      : MerchantInfoResponse
     * @param merchantApiKeyId : String
     * @return AccessTokenRequest
     */
    private AccessTokenRequest buildAccessTokenRequest(MerchantInfoResponse merchantDto, String merchantApiKeyId, String merchantApiKeySecret) {
        logger.info("Building Access token Request");
        if (ObjectUtils.isNotEmpty(merchantDto.getAccessTokenExpiryTime()) && merchantDto.getAccessTokenExpiryTime() > 0) {
            AccessTokenRequest accessTokenRequest = new AccessTokenRequest();
            accessTokenRequest.setUsername(merchantDto.getMId());
            accessTokenRequest.setMId(merchantDto.getMId());
            accessTokenRequest.setApiKey(merchantApiKeyId);
            accessTokenRequest.setSecretKey(merchantApiKeySecret);
            accessTokenRequest.setTokenType(TokenType.ACCESS);
            accessTokenRequest.setRoles(List.of(accessTokenRequest.getTokenType().toString()));
            accessTokenRequest.setExpirationTime(DateTimeUtils.getCurrentTimeInMills() + (merchantDto.getAccessTokenExpiryTime() * 60000));
            return accessTokenRequest;
        }
        throw new TransactionException(TransactionErrorConstants.NOT_FOUND_ERROR_CODE, MessageFormat.format(TransactionErrorConstants.NOT_FOUND_ERROR_MESSAGE, TransactionErrorConstants.TOKEN_EXPIRATION_TIME));
    }

    /**
     * Method name : buildTransactionTokenRequest
     * Description : generating transaction token request
     *
     * @param orderDto OrderDto
     * @param expiryTime       Long
     * @return TransactionTokenRequest
     */
    private TransactionTokenRequest buildTransactionTokenRequest(OrderDto orderDto, Long expiryTime) {
        logger.info("Building Transaction token Request");
        if (ObjectUtils.isNotEmpty(expiryTime) || expiryTime > 0) {
            TransactionTokenRequest transactionTokenRequest = new TransactionTokenRequest();
            transactionTokenRequest.setUsername(orderDto.getOrderHash());
            transactionTokenRequest.setTokenType(TokenType.TRANSACTION);
            transactionTokenRequest.setMId(orderDto.getMId());
            transactionTokenRequest.setSbiOrderReferenceNumber(orderDto.getSbiOrderRefNumber());
            transactionTokenRequest.setRoles(List.of(transactionTokenRequest.getTokenType().toString()));
            transactionTokenRequest.setExpirationTime(DateTimeUtils.addMinutes(expiryTime.intValue()));
            return transactionTokenRequest;
        }
        throw new TransactionException(TransactionErrorConstants.NOT_FOUND_ERROR_CODE, MessageFormat.format(TransactionErrorConstants.NOT_FOUND_ERROR_MESSAGE, TransactionErrorConstants.TOKEN_EXPIRATION_TIME));
    }


}
