package com.epay.transaction.validator;

import com.epay.transaction.model.request.TransactionUpdateRequest;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.ArrayList;

import static com.epay.transaction.util.TransactionConstant.*;
import static com.epay.transaction.util.TransactionErrorConstants.ATRN;
import static com.epay.transaction.util.TransactionErrorConstants.REASON;

/**
 * Class Name: PaymentValidator
 * *
 * Description: Validates Payment Validator details .
 * *
 * Author: Shubhangi kurelay
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Component
@RequiredArgsConstructor
public class PaymentValidator extends BaseValidator {

    /**
     * Validates the transaction update request for order update.
     * @param transactionUpdateRequest the request object containing transaction update data
     */
    public void validatePaymentRequest(TransactionUpdateRequest transactionUpdateRequest) {
        errorDtoList = new ArrayList<>();
        validateMandatoryFields(transactionUpdateRequest);
        validateLeadingTrailingSpacesAndSingleSpace(transactionUpdateRequest);
        validateFieldsValue(transactionUpdateRequest);
        validateSpacialCharacter(transactionUpdateRequest);
        throwIfErrors();
    }
    /**
     * Validates special characters in the fields using regex.
     * @param transactionUpdateRequest the request object containing transaction update data
     */
    protected void validateSpacialCharacter(TransactionUpdateRequest transactionUpdateRequest) {
        validateFieldWithRegex(transactionUpdateRequest.getAtrn(), ATRN_ARRN_REGEX, ATRN, "Invalid Atrn format");
        validateFieldWithRegex(transactionUpdateRequest.getFailReason(), ALPHABET_CHARS_REGEX, REASON, "Invalid failreason format");
        throwIfErrors();
    }

    /**
     * Validates that mandatory fields are not null or empty.
     * @param transactionUpdateRequest the request object containing transaction update data
     */
    private void validateMandatoryFields(TransactionUpdateRequest transactionUpdateRequest) {
        checkMandatoryField(transactionUpdateRequest.getAtrn(), ATRN);
        checkMandatoryField(transactionUpdateRequest.getFailReason(), REASON);
        throwIfErrors();
    }
    /**
     * Validates that there are no leading/trailing spaces and only single spaces between words.
     * @param transactionUpdateRequest the request object containing transaction update data
     */
    private void validateLeadingTrailingSpacesAndSingleSpace(TransactionUpdateRequest transactionUpdateRequest) {
        checkForLeadingTrailingAndSingleSpace(transactionUpdateRequest.getAtrn(), ATRN);
        checkForLeadingTrailingAndSingleSpace(transactionUpdateRequest.getFailReason(), REASON);
        throwIfErrors();
    }

    /**
     * Validates the field lengths based on allowed constraints.
     * @param transactionUpdateRequest the request object containing transaction update data
     */
    private void validateFieldsValue(TransactionUpdateRequest transactionUpdateRequest) {
        validateFixedFieldLength(transactionUpdateRequest.getAtrn(), ATRN_ARRN_LENGTH, ATRN);
        validateFieldLength(transactionUpdateRequest.getFailReason(), REASON_LENGTH, REASON);
        throwIfErrors();
    }

}