package com.epay.transaction.controller;

import com.epay.transaction.model.request.EncryptedRequest;
import com.epay.transaction.model.response.EncryptedResponse;
import com.epay.transaction.model.response.TransactionResponse;
import com.epay.transaction.service.MerchantPricingService;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Class Name: PricingController
 * *
 * Description: controller class for pricing calculation
 * *
 * Author: NIRMAL GURJAR
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */

@RestController
@RequiredArgsConstructor
@RequestMapping("/pricing")
public class PricingController {

    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private final MerchantPricingService merchantPricingService;


    /**
     * Method name: calculatePricing
     * Description:This method handles the calculation of pricing based on the provided encrypted request. The method accepts
     * an encrypted request containing pricing information, decrypts it, calculates the pricing, and returns the
     * result as an encrypted response.
     *
     * @param encryptedRequest The encrypted request containing the pricing data to be processed.
     * @return TransactionResponse<EncryptedResponse> The encrypted response containing the calculated pricing data.
     */

    @PostMapping
    @Operation(summary = "Pricing  Calculation")
    @PreAuthorize("hasAnyRole('TRANSACTION')")
    public TransactionResponse<EncryptedResponse> calculatePricing(@Valid @RequestBody EncryptedRequest encryptedRequest) {
        logger.info("Request received for calculate price : {}", encryptedRequest);
        return merchantPricingService.calculatePricingEncrypted(encryptedRequest);

    }
}
