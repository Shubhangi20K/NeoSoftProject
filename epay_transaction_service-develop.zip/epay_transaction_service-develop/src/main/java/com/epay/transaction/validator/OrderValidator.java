package com.epay.transaction.validator;

import com.epay.transaction.config.TransactionConfig;
import com.epay.transaction.dao.AdminDao;
import com.epay.transaction.dao.CustomerDao;
import com.epay.transaction.dao.ErrorLogDao;
import com.epay.transaction.dao.OrderDao;
import com.epay.transaction.dto.OrderDto;
import com.epay.transaction.dto.MultiAccountDto;
import com.epay.transaction.dto.OrderStatusDto;
import com.epay.transaction.exceptions.TransactionException;
import com.epay.transaction.exceptions.ValidationException;
import com.epay.transaction.externalservice.response.admin.MerchantIfscCodeResponse;
import com.epay.transaction.externalservice.response.admin.MerchantInfoResponse;
import com.epay.transaction.model.request.MerchantOrderPaymentSearchRequest;
import com.epay.transaction.model.request.OrderUpdateRequest;
import com.epay.transaction.util.EPayIdentityUtil;
import com.epay.transaction.util.TransactionErrorConstants;
import com.epay.transaction.util.enums.*;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.EnumUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.text.MessageFormat;
import java.util.*;

import static com.epay.transaction.util.TransactionConstant.*;
import static com.epay.transaction.util.TransactionConstant.ATRN;
import static com.epay.transaction.util.TransactionConstant.ORDER_AMOUNT;
import static com.epay.transaction.util.TransactionConstant.ORDER_REF_NUMBER;
import static com.epay.transaction.util.TransactionConstant.ORDER_STATUS;
import static com.epay.transaction.util.TransactionConstant.PAYMENT_STATUS;
import static com.epay.transaction.util.TransactionConstant.REFUND_STATUS;
import static com.epay.transaction.util.TransactionConstant.SBIORDER_REFERENCE_NUMBER_STATUS;
import static com.epay.transaction.util.TransactionConstant.STATUS;
import static com.epay.transaction.util.TransactionConstant.TRANSACTION_STATUS;
import static com.epay.transaction.util.TransactionErrorConstants.*;
import static com.epay.transaction.util.TransactionErrorConstants.INVALID_SBIORDER_REFERENCE_REASON;
import static com.epay.transaction.util.enums.OrderStatus.*;

/**
 * Class Name: OrderValidator
 * *
 * Description: Validates Order Validator for create and update request.
 * *
 * Author: V1018212
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Component
@RequiredArgsConstructor
public class OrderValidator extends BaseValidator {
    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());

    private final CustomerDao customerDao;
    private final OrderDao orderDao;
    private final AdminDao adminDao;
    private final ObjectMapper objectMapper;
    private final TransactionConfig transactionConfig;
    private final ErrorLogDao errorLogDao;

    /**
     * Method name : validateOrderRequest
     * Description : Validates merchant order creation request details
     *
     * @param orderDto : Object of OrderDto
     */
    public void validateOrderRequest(OrderDto orderDto, String numberOfAttemptsApplicable, String numberOfAttempts) {
        logger.info("Order validation started for {}", orderDto);
        errorDtoList = new ArrayList<>();
        validateMandatoryFields(orderDto);
        validateLeadingTrailingSpaces(orderDto);
        validateFieldsValue(orderDto);
        validateThirdPartyDetails(orderDto.getThirdPartyDetails());
        //Validating with DAO
        validateExistsByOrderRefNumber(orderDto.getMId(), orderDto.getOrderRefNumber(), numberOfAttemptsApplicable, numberOfAttempts);
        validateCurrency(orderDto);
        validateExistsByCustomerId(orderDto, orderDto.getMId());
        validateMultiAccount(orderDto);

        logger.debug("Merchant Order field validation completed ");
    }

    /**
     * Method name : validateMandatoryFields
     * Description : Validates mandatory fields of merchant order creation request
     *
     * @param orderDto : an object of OrderDto
     */
    private void validateMandatoryFields(OrderDto orderDto) {
        checkMandatoryField(orderDto.getMId(), MID);
        checkMandatoryField(orderDto.getCurrencyCode(), CURRENCY_CODE);
        checkMandatoryField(orderDto.getOrderRefNumber(), ORDER_REF_NUMBER);
        checkMandatoryField(orderDto.getReturnUrl(), RETURN_URL);
        checkMandatoryField(orderDto.getOrderAmount(), ORDER_AMOUNT);
        throwIfErrors();
    }

    /**
     * Method name : validateLeadingTrailingSpaces
     * Description : Validates leading and trailing spaces of values from merchant order creation request
     *
     * @param orderDto : an object of OrderDto
     */
    private void validateLeadingTrailingSpaces(OrderDto orderDto) {
        checkForLeadingTrailingAndSingleSpace(orderDto.getOrderRefNumber(), FIELD_ORDER_REF_NUMBER);
        checkForLeadingTrailingAndSingleSpace(orderDto.getReturnUrl(), RETURN_URL);
        checkForLeadingTrailingAndSingleSpace(orderDto.getCurrencyCode(), CURRENCY_CODE);
        checkForLeadingTrailingAndSingleSpace(orderDto.getPaymentMode(), PAYMODE);
        throwIfErrors();
    }

    /**
     * Method name : validateFieldValue
     * Description : Validates fields length of merchant order creation request
     *
     * @param orderDto : an object of OrderDto
     */
    private void validateFieldsValue(OrderDto orderDto) {
        logger.info("validateFieldsValue starts");
        validateFieldLength(orderDto.getOrderRefNumber(), ORDER_REF_LENGTH, FIELD_ORDER_REF_NUMBER);
        validateFieldWithRegex(orderDto.getOrderRefNumber(), ORDER_REFERENCE_NUMBER_REGEX, FIELD_ORDER_REF_NUMBER, INCORRECT_FORMAT);
        validateFieldWithRegex(orderDto.getReturnUrl(), URL_REGEX, RETURN_URL, INCORRECT_FORMAT);
        validateFieldLength(orderDto.getReturnUrl(), RETURN_URL_LENGTH, RETURN_URL);
        validateFieldLength(orderDto.getPaymentMode(), PAYMODE_LENGTH, PAYMODE);
        validateFieldLength(orderDto.getCurrencyCode(), CURRENCY_CODE_LENGTH, CURRENCY_CODE);
        validateFieldWithRegex(orderDto.getPaymentMode(), INVALID_SPECIAL_CHAR_REGEX, PAYMODE, INCORRECT_FORMAT);
        validateOrderAmount(orderDto);
        validateExpiry(orderDto);
        validatePaymode(orderDto.getPaymentMode());
        validateCustomerId(orderDto.getCustomerId());
        throwIfErrors();
        logger.info("validateFieldsValue end");
    }

    /**
     * Method name : validateFieldValue
     * Description : Validates order amount of merchant order creation request
     *
     * @param orderDto : an object of OrderDto
     */
    private void validateOrderAmount(OrderDto orderDto) {
        validateAmount(orderDto.getOrderAmount(), ORDER_AMOUNT);
        BigDecimal thresholdAmount = adminDao.getMerchantRFCDetails(orderDto.getMId()).getThresholdAmount();
        if (orderDto.getOrderAmount().compareTo(thresholdAmount) >= 0) {
            logger.info("validateOrderRequest, Validate Order threshold amount: {}", thresholdAmount);
            addError(INVALID_ERROR_CODE, MessageFormat.format(INVALID_ERROR_MESSAGE, ORDER_AMOUNT, "Amount is greater than threshold amount."));
        }
        throwIfErrors();
    }

    /**
     * Method name : validateCustomerId
     * Description : Validates customer id
     *
     * @param customerId : String
     */
    public void validateCustomerId(String customerId) {
        logger.info("Validating customer id: {}", customerId);
        errorDtoList = new ArrayList<>();
        validateFixedFieldLength(customerId, CUSTOMER_ID_LENGTH, FIELD_CUSTOMER_ID);
        throwIfErrors();
        checkForLeadingTrailingAndSingleSpace(customerId, FIELD_CUSTOMER_ID);
        throwIfErrors();
        validateFieldWithRegex(customerId, CUSTOMER_ID_REGEX, FIELD_CUSTOMER_ID, INCORRECT_FORMAT);
        throwIfErrors();
    }

    /**
     * Method name : validateExpiry
     * Description : Validates merchant order expiry
     *
     * @param orderDto : an object of OrderDto
     */
    private void validateExpiry(OrderDto orderDto) {
        if (ObjectUtils.isNotEmpty(orderDto.getExpiry())) {
            if (orderDto.getExpiry() <= 0) {
                addError(INVALID_ERROR_CODE, MessageFormat.format(INVALID_ERROR_MESSAGE, ORDER_EXPIRY, ORDER_EXPIRY_GREATER_THAN_ZERO));
            } else if (orderDto.getExpiry() > 30) {
                addError(LIMIT_EXCEED_ERROR_CODE, MessageFormat.format(LIMIT_EXCEED_ERROR_MESSAGE, ORDER));
            }
        }
        throwIfErrors();
    }

    /**
     * Method name : validateCurrency
     * Description : Validates currency of merchant order creation request
     *
     * @param orderDto : an object of OrderDto
     */
    private void validateCurrency(OrderDto orderDto) {
        errorDtoList = new ArrayList<>();
        boolean isValidCurrency = adminDao.isValidCurrencyCode(orderDto.getMId(), orderDto.getCurrencyCode());
        if (!isValidCurrency) {
            addError(TransactionErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(TransactionErrorConstants.INVALID_ERROR_MESSAGE, CURRENCY_CODE, INCORRECT_FORMAT));
        }
        throwIfErrors();
    }

    /**
     * Method name : validateExistsByCustomerId
     * Description : Validates currency of merchant order creation request
     *
     * @param orderDto : an object of OrderDto
     */
    private void validateExistsByCustomerId(OrderDto orderDto, String mId) {
        if (ObjectUtils.isNotEmpty(orderDto.getCustomerId()) && Boolean.FALSE.equals(customerDao.existsByCustomerId(orderDto.getCustomerId(), mId))) {
            addError("Merchant CustomerId", TransactionErrorConstants.NOT_FOUND_ERROR_CODE, TransactionErrorConstants.NOT_FOUND_ERROR_MESSAGE);
        }
        logger.info("Order's Customer validation completed");
        throwIfErrors();
    }

    /**
     * Method name : validateExistsByOrderRefNumber
     * Description : Validates merchant order creation request using orderRefNumber
     *
     * @param orderRefNumber : is a String type
     */
    private void validateExistsByOrderRefNumber(String mId, String orderRefNumber, String numberOfAttemptsApplicable, String numberOfAttempts) {
        if (!(ATTEMPTS_APPLICABLE.equalsIgnoreCase(numberOfAttemptsApplicable) && orderDao.getSbiOrderRefNumberCountByOrderRefNumber(mId, orderRefNumber) < Integer.parseInt(numberOfAttempts))) {
            addError(TransactionErrorConstants.ATTEMPT_EXCEEDED_ERROR_CODE, MessageFormat.format(ATTEMPT_EXCEEDED_ERROR_MESSAGE, "Order"));
        }
        throwIfErrors();
    }

    /**
     * Method name : validateMultiAccount
     * Description : Validates merchant order creation request for multi account
     *
     * @param orderDto : an object of OrderDto
     */
    private void validateMultiAccount(OrderDto orderDto) {
        if (ObjectUtils.isNotEmpty(orderDto.getMultiAccounts())) {
            //Validate Multi-account flag is enabled
            errorDtoList = new ArrayList<>();
            //Convert input json node to list of MultiAccountDto
            List<MultiAccountDto> multiAccountDetails = getMultiAccountDtos(orderDto);
            if (CollectionUtils.isNotEmpty(multiAccountDetails)) {
                if (!isMerchantMultiAccountFlagEnabled(orderDto.getMId())) {
                    logger.info("Merchant Multi-Account flat is not enable");
                    throw new TransactionException(INVALID_ERROR_CODE, MessageFormat.format(INVALID_ERROR_MESSAGE, REQUEST_PARAMETER, MULTI_ACCOUNT_NOT_ENABLED));
                }
                BigDecimal totalMultiAccountAmount = verifyAccountAndGetTotalAmount(orderDto, multiAccountDetails);
                if (orderDto.getOrderAmount().compareTo(totalMultiAccountAmount) != 0) {
                    addError(INVALID_ERROR_CODE, MessageFormat.format(INVALID_ERROR_MESSAGE, "Multi Account Total Amount", "Order amount and multiAccount amount mismatch."));
                    throwIfErrors();
                }
            }
        }
    }

    /**
     * Method name : verifyAccountAndGetTotalAmount
     * Description : Validates accounts of merchant order creation request
     *
     * @param orderDto            : an object of OrderDto
     * @param multiAccountDetails : a List of MultiAccountDto
     * @return : total amount of type BigDecimal
     */
    private BigDecimal verifyAccountAndGetTotalAmount(OrderDto orderDto, List<MultiAccountDto> multiAccountDetails) {
        logger.info("verifyAccountAndGetTotalAmount starts");
        Set<String> merchantMultiAccountDetails = new HashSet<>(adminDao.getMerchantMultiAccount(orderDto.getMId()));
        BigDecimal totalMultiAccountAmount = new BigDecimal(0);
        for (MultiAccountDto multiAccountDto : multiAccountDetails) {
            if (merchantMultiAccountDetails.contains(multiAccountDto.getAccountIdentifier())) {
                totalMultiAccountAmount = totalMultiAccountAmount.add(multiAccountDto.getAmount());
            } else {
                logger.info("validateOrderRequest, Validate  multi account: {}", multiAccountDetails);
                addError(INVALID_ERROR_CODE, MessageFormat.format(INVALID_ERROR_MESSAGE, TransactionErrorConstants.MULTI_ACCOUNT, INVALID_MULTIACCOUNT_IDENTIFIER));
                throwIfErrors();
            }
        }
        logger.info("verifyAccountAndGetTotalAmount end");
        return totalMultiAccountAmount;
    }

    /**
     * Method name : getMultiAccountDtos
     * Description : Validates accounts of merchant order creation request
     *
     * @param orderDto : an object of OrderDto
     * @return : List of MultiAccountDto
     */
    private List<MultiAccountDto> getMultiAccountDtos(OrderDto orderDto) {
        List<MultiAccountDto> multiAccountDetails = new ArrayList<>();
        Iterator<JsonNode> iterator = orderDto.getMultiAccounts().elements();
        while (iterator.hasNext()) {
            JsonNode fieldName = iterator.next();
            MultiAccountDto multiAccountDto = objectMapper.convertValue(fieldName, MultiAccountDto.class);
            validateFieldLength(multiAccountDto.getAccountIdentifier(), ACCOUNT_IDENTIFIER_LENGTH, ACCOUNT_IDENTIFIER);
            validateAmount(multiAccountDto.getAmount(), MULTI_ACCOUNT_AMOUNT);
            validateMultiAccountAmount(multiAccountDto.getAmount());
            multiAccountDetails.add(multiAccountDto);
        }
        return multiAccountDetails;
    }

    /**
     * Validation of order status
     *
     * @param orderUpdateRequest orderUpdateRequest
     */
    public void validateUpdateOrderRequest(OrderUpdateRequest orderUpdateRequest) {
        errorDtoList = new ArrayList<>();
        checkMandatoryFields(orderUpdateRequest);
        checkLeadingTrailingSpace(orderUpdateRequest);
        validateFieldsLength(orderUpdateRequest);
        validateFieldsValues(orderUpdateRequest);
        validateOrderStatus(orderUpdateRequest.getStatus());
        throwIfErrors();
    }

    /**
     * Method name : validateFieldsValues
     * Description : Validates fields values for order update status request
     * @param orderUpdateRequest : Object of OrderUpdateRequest
     */
    private void validateFieldsValues(OrderUpdateRequest orderUpdateRequest) {
        validateFieldWithRegex((orderUpdateRequest.getOrderRefNumber()), ORDER_REFERENCE_NUMBER_REGEX, ORDER_REF_NUMBER_MESSAGE, INCORRECT_FORMAT);
        validateFieldWithRegex((orderUpdateRequest.getSbiOrderRefNumber()), ORDER_REFERENCE_NUMBER_REGEX, SBI_ORDER_REF_NUMBER_MESSAGE, INCORRECT_FORMAT);
        throwIfErrors();
    }

    /**
     * Method name : validateFieldsLength
     * Description : Validates fields length for order update status request
     * @param orderUpdateRequest : Object of OrderUpdateRequest
     */
    private void validateFieldsLength(OrderUpdateRequest orderUpdateRequest) {
        validateFieldLength(orderUpdateRequest.getOrderRefNumber(), ORDER_REF_LENGTH, ORDER_REF_NUMBER_MESSAGE);
        validateFieldLength(orderUpdateRequest.getSbiOrderRefNumber(), SBI_ORDER_REF_LENGTH, SBI_ORDER_REF_NUMBER_MESSAGE);
        validateFieldLength(orderUpdateRequest.getStatus(), STATUS_LENGTH, STATUS);
        throwIfErrors();
    }

    /**
     * Method name : checkMandatoryFields
     * Description : Validates mandatory fields of order update status request
     * @param orderUpdateRequest : Object of OrderUpdateRequest
     */
    private void checkMandatoryFields(OrderUpdateRequest orderUpdateRequest) {
        errorDtoList.clear();
        checkMandatoryField(orderUpdateRequest.getOrderRefNumber(), ORDER_REF_NUMBER);
        checkMandatoryField(orderUpdateRequest.getSbiOrderRefNumber(), SBI_ORDER_REF_NUMBER);
        checkMandatoryField(orderUpdateRequest.getStatus(), STATUS);
        throwIfErrors();
    }

    /**
     * Method name : checkLeadingTrailingSpace
     * Description : Validates leading and trailing spaces of order update status request
     * @param orderUpdateRequest : Object of OrderUpdateRequest
     */
    private void checkLeadingTrailingSpace(OrderUpdateRequest orderUpdateRequest) {
        checkForLeadingTrailingAndSingleSpace(orderUpdateRequest.getStatus(), STATUS);
        throwIfErrors();
    }

    /**
     * Method name : validateOrderStatus
     * Description : Validates order status of update status request
     * @param orderStatus : String
     */
    private void validateOrderStatus(String orderStatus) {
        if (StringUtils.isNotBlank(orderStatus) && !EnumUtils.isValidEnum(OrderStatus.class, orderStatus)) {
            errorLogDao.logCustomerError(null, EntityType.ORDER, null,null,null,null,INVALID_ERROR_CODE_NO_REASON, MessageFormat.format(INVALID_ERROR_MESSAGE_NO_REASON, "Order Status", orderStatus));
            throw new ValidationException(INVALID_ERROR_CODE_NO_REASON, MessageFormat.format(INVALID_ERROR_MESSAGE_NO_REASON, "Order Status", orderStatus));
        }
    }

    /**
     * Validating the new status with current status. and also validating current status.
     *
     * @param currentStatus Status from DB
     * @param newStatus     Status from Request
     */
    public void validateStatus(OrderStatus currentStatus, String newStatus) {
        if (CREATED.equals(currentStatus)) {
            if (!StringUtils.equalsAny(newStatus, ATTEMPTED.name(), EXPIRED.name())) {
                throw new TransactionException(INVALID_STATUS_CODE, INVALID_STATUS_MESSAGE);
            }
        } else if (ATTEMPTED.equals(currentStatus)) {
            if (!StringUtils.equalsAny(newStatus, FAILED.name(), PAID.name(), EXPIRED.name())) {
                throw new TransactionException(INVALID_STATUS_CODE, INVALID_STATUS_MESSAGE);
            }
        } else if (StringUtils.equalsAny(currentStatus.name(), FAILED.name(), PAID.name(), EXPIRED.name())) {
            throw new TransactionException(INVALID_STATUS_CODE, INVALID_STATUS_MESSAGE);
        }
    }

    /**
     * Check if the merchant multi-account flag is enabled
     *
     * @param mId String
     * @return boolean
     */
    private boolean isMerchantMultiAccountFlagEnabled(String mId) {
        MerchantInfoResponse merchantInfoDTO = getActiveMerchantById(mId);
        logger.debug("currencyStatus :{}", merchantInfoDTO.getMerchantMultiAccountFlag());
        return !merchantInfoDTO.getMerchantMultiAccountFlag().isEmpty() && merchantInfoDTO.getMerchantMultiAccountFlag().equals(FLAG_Y);
    }

    /**
     * Method name : isOrderAlreadyPaid
     * Description : check if order is already paid
     * @param orderDto : an object of OrderDto
     */
    public void isOrderAlreadyPaid(OrderDto orderDto) {
        if (orderDao.isOrderStatusPaid(orderDto.getMId(), orderDto.getOrderRefNumber())) {
            errorLogDao.logCustomerError(orderDto.getMId(), EntityType.ORDER, null,null,null,null,INVALID_TXN_STATUS_CODE, INVALID_TXN_STATUS_MESSAGE);
            throw new TransactionException(INVALID_TXN_STATUS_CODE, INVALID_TXN_STATUS_MESSAGE);
        }
    }


    /**
     * Fetch active merchant info by mId
     *
     * @param mId String
     * @return MerchantInfo
     */
    private MerchantInfoResponse getActiveMerchantById(String mId) {
        logger.info("Inside getActiveMerchantById for mId: {}", mId);
        MerchantInfoResponse response = adminDao.getMerchantByMId(mId);
        if (!StringUtils.equalsIgnoreCase(FLAG_Y, response.getIsActive())) {
            throw new TransactionException(NOT_FOUND_ERROR_CODE, MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, VALID_MERCHANT));
        }
        logger.debug("merchantDto Details {} ", response);
        return response;
    }

    /**
     * Method name : isOrderAlreadyPaid
     * Description : check if order is already paid
     * @param thirdPartyDetails
     */
    private void validateThirdPartyDetails(JsonNode thirdPartyDetails) {
        if (ObjectUtils.isNotEmpty(thirdPartyDetails) && !thirdPartyDetails.isEmpty()) {
            String ifscCode = thirdPartyDetails.has(IFSC) ? thirdPartyDetails.get(IFSC).asText() : StringUtils.EMPTY;
            String accountNode = thirdPartyDetails.has(ACCOUNT) ? thirdPartyDetails.get(ACCOUNT).asText() : StringUtils.EMPTY;
            checkMandatoryTPDFields(ifscCode, accountNode);
            validateFieldLength(ifscCode, IFSC_CODE_LENGTH, IFSC);
            validateFieldLength(accountNode, ifscCode.startsWith(SBIN) ? SBI_ACCOUNT_NUMBER_LENGTH : OTHER_ACCOUNT_NUMBER_LENGTH, ACCOUNT);
            checkForLeadingTrailingAndSingleSpaceForTPV(ifscCode, accountNode);
            fieldRegExForTPV(ifscCode, accountNode);
            validateIfscCode(ifscCode);
        }
    }

    /**
     * Validating given ifsc and/or account are null or empty
     *
     * @param ifscNode    String
     * @param accountNode String
     */
    private void checkMandatoryTPDFields(String ifscNode, String accountNode) {
        checkMandatoryField(ifscNode, IFSC);
        checkMandatoryField(accountNode, ACCOUNT);
    }

    private void fieldRegExForTPV(String ifscNode, String accountNode) {
        validateFieldWithRegex(ifscNode, IFSC_REGEX, IFSC, "Incorrect ifsc code");
        validateFieldWithRegex(accountNode, ACCOUNT_REGEX, ACCOUNT, "Incorrect account Number");
        throwIfErrors();
    }

    private void checkForLeadingTrailingAndSingleSpaceForTPV(String ifscNode, String accountNode) {
        checkForLeadingTrailingAndSingleSpace(ifscNode, IFSC);
        checkForLeadingTrailingAndSingleSpace(accountNode, ACCOUNT);
        throwIfErrors();
    }

    /**
     * This method is used to validate order reference number and order amount.
     *
     * @param orderStatusDto transaction verification dto.
     */
    public void validateOrderStatusDto(OrderStatusDto orderStatusDto) {
        errorDtoList = new ArrayList<>();
        logger.info("validatePaymentStatusRequest, Validate Payment Status Verification request object Started.");
        checkMandatoryField(orderStatusDto.getOrderAmount(), ORDER_AMOUNT);
        validateOrderSearchInputRequirement(orderStatusDto.getOrderRefNumber(), orderStatusDto.getSbiOrderRefNumber(), orderStatusDto.getAtrnNumber());
        checkForLeadingTrailingAndSingleSpace(orderStatusDto);
        validateFieldLength(orderStatusDto);
        validateFieldsValueForOrderStatus(orderStatusDto);
        validateAmount(orderStatusDto.getOrderAmount(), ORDER_AMOUNT);
        throwIfErrors();
    }

    /**
     * Method name : validateFieldsValueForOrderStatus
     * Description : Validates fields values of order update status request
     * @param orderStatusDto : Object of OrderStatusDto
     */
    private void validateFieldsValueForOrderStatus(OrderStatusDto orderStatusDto) {
        logger.info("Inside validate Fields values for order status");
        validateFieldWithRegex(orderStatusDto.getAtrnNumber(), ATRN_ARRN_REGEX, ATRN, INVALID_ATRN_REASON);
        validateFieldWithRegex(orderStatusDto.getOrderRefNumber(), ORDER_REFERENCE_NUMBER_REGEX, ORDER_REF_NUMBER, INVALID_ORDER_REF_REASON);
        validateFieldWithRegex(orderStatusDto.getSbiOrderRefNumber(), ORDER_REFERENCE_NUMBER_REGEX, SBI_ORDER_REF_NUMBER, INVALID_ORDER_REF_REASON);
        throwIfErrors();
    }

    private void validateOrderSearchInputRequirement(String orderRefNumber, String sbiOrderRefNumber, String atrnNumber){
        if(StringUtils.isAllEmpty(orderRefNumber, sbiOrderRefNumber, atrnNumber)){
            addError(StringUtils.joinWith(", ",ORDER_REF_NUMBER, SBI_ORDER_REF_NUMBER, ATRN)
                    , TransactionErrorConstants.MANDATORY_ERROR_CODE, ONE_MANDATORY_ERROR);
        }
    }

    /**
     * Method name : validate IFSC code
     * Description : Validates postal code creation request for customer
     *
     * @param ifsc : ifsc code
     */
    private void validateIfscCode(String ifsc) {
        MerchantIfscCodeResponse response = adminDao.getIfscCodeDetails(ifsc);
        if (response.getState().isEmpty()) {
            throw new TransactionException(NOT_FOUND_ERROR_CODE, MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, VALID_PINCODE));
        }
        logger.debug("merchantDto Details {} ", response);
    }

    /**
     * Validate field length for order status dto
     *
     * @param orderStatusDto OrderStatusDto
     */
    private void validateFieldLength(OrderStatusDto orderStatusDto) {
        logger.info("Inside validateFieldLength");
        validateFieldLength(orderStatusDto.getOrderRefNumber(), ORDER_REF_LENGTH, ORDER_REF_NUMBER);
        validateFieldLength(orderStatusDto.getSbiOrderRefNumber(), ORDER_REF_LENGTH, SBI_ORDER_REF_NUMBER);
        validateFixedFieldLength(orderStatusDto.getAtrnNumber(), ATRN_ARRN_LENGTH, ATRN);
        throwIfErrors();
    }

    /**
     * Validate  field values for leading trailing space for order status dto
     *
     * @param orderStatusDto OrderStatusDto
     */
    private void checkForLeadingTrailingAndSingleSpace(OrderStatusDto orderStatusDto) {
        logger.info("Inside checkForLeadingAndSingleSpace");
        checkForLeadingTrailingAndSingleSpace(orderStatusDto.getOrderRefNumber(), ORDER_REF_NUMBER);
        checkForLeadingTrailingAndSingleSpace(orderStatusDto.getSbiOrderRefNumber(), SBI_ORDER_REF_NUMBER);
        checkForLeadingTrailingAndSingleSpace(orderStatusDto.getAtrnNumber(), ATRN);
        throwIfErrors();
    }

    private void validatePaymode(String paymode) {
        //validate payMode
        if (StringUtils.isNotEmpty(paymode)) {
            PayMode.getPayMode(paymode);
        }
    }


    /**
     * Method name : validateMultiAccountAmount
     * Description : Validates  Multi Account amount of merchant order creation request
     *
     * @param multiAccountAmount : an object of Multi Account
     */
    private void validateMultiAccountAmount(BigDecimal multiAccountAmount) {
        if (multiAccountAmount.compareTo(BigDecimal.ZERO) <= 0) {
            logger.info("validateOrderRequest, Validate Order multi account amount: {}", multiAccountAmount);
            addError(INVALID_ERROR_CODE, MessageFormat.format(INVALID_ERROR_MESSAGE, MULTI_ACCOUNT_AMOUNT, "Amount needs to be greater than 0."));
        } else if (multiAccountAmount.scale() > 2) {
            logger.info("validateOrderRequest, Validating up to 2 decimal point of multi account amount : {}", multiAccountAmount);
            addError(INVALID_ERROR_CODE, MessageFormat.format(INVALID_ERROR_MESSAGE, MULTI_ACCOUNT_AMOUNT, "Validating up to 2 decimal point"));
        }
        throwIfErrors();
    }

    public void validateMerchantOrderPaymentsRequest(MerchantOrderPaymentSearchRequest merchantOrderPaymentSearchRequest, String mId, Pageable pageable, boolean isDownload) {
        errorDtoList = new ArrayList<>();
        logger.info("Inside validateMerchantOrderPaymentsRequest");
        checkMandatoryFieldCount(merchantOrderPaymentSearchRequest);
        checkForLeadingTrailingAndSingleSpaceForOrderPaymentsRequest(merchantOrderPaymentSearchRequest, mId);
        validateFieldLengthAndFormatOfMerchantOrderPaymentsRequest(merchantOrderPaymentSearchRequest);
        validateOrderStatus(merchantOrderPaymentSearchRequest.getOrderStatus());
        validateRefundStatus(merchantOrderPaymentSearchRequest.getRefundStatus());
        validatePaymentStatus(merchantOrderPaymentSearchRequest.getPaymentStatus());
        validateTransactionStatus(merchantOrderPaymentSearchRequest.getTransactionStatus());
        validatePageSize(pageable, isDownload ? transactionConfig.getReportPageSize() : MAX_PAGE_SIZE);
        validateMid(mId);
        validateReportDates(merchantOrderPaymentSearchRequest.getFromDate(), merchantOrderPaymentSearchRequest.getToDate());
    }

    /**
     * Method name : checkMandatoryFieldCount
     * Description : Validates mandatory fields of MerchantOrderPaymentsRequest
     * @param merchantOrderPaymentSearchRequest : Object of MerchantOrderPaymentSearchRequest
     */
    private void checkMandatoryFieldCount(MerchantOrderPaymentSearchRequest merchantOrderPaymentSearchRequest) {

        logger.info("checking mandatory field count starts");
        mandatoryFields = new ArrayList<>();
        this.mandatoryCount = 0;
        countAndAddMandatoryField(merchantOrderPaymentSearchRequest.getFromDate(), FROM_DATE);
        countAndAddMandatoryField(merchantOrderPaymentSearchRequest.getToDate(), TO_DATE);
        countAndAddMandatoryField(merchantOrderPaymentSearchRequest.getOrderRefNumber(), FIELD_ORDER_REF_NUMBER);
        countAndAddMandatoryField(merchantOrderPaymentSearchRequest.getBankRefNumber(), BANK_REF_NUMBER);
        countAndAddMandatoryField(merchantOrderPaymentSearchRequest.getSbiOrderRefNumber(), SBIORDER_REFERENCE_NUMBER_STATUS );
        countAndAddMandatoryField(merchantOrderPaymentSearchRequest.getAtrn(), ATRN);
        checkMandatoryFieldCount();
        throwIfErrors();
        logger.info("checking mandatory field count ends");
    }

    private void validatePageSize(Pageable pageable, int maxPageSize) {
        if (pageable.getPageSize() > maxPageSize) {
            errorLogDao.logCustomerError(null, EntityType.ORDER, null,null,null,null,INVALID_ERROR_CODE_NO_REASON, MessageFormat.format(INVALID_ERRORPAGE_MESSAGE, "Page size", maxPageSize));
            throw new ValidationException(INVALID_ERROR_CODE_NO_REASON, MessageFormat.format(INVALID_ERRORPAGE_MESSAGE, "Page size", maxPageSize));
        }
    }

    private void validateMid(String mId) {
        logger.debug("Request Validation start for {}", mId);
        errorDtoList = new ArrayList<>();
        checkMandatoryField(mId, MID);
        throwIfErrors();
        checkForLeadingTrailingAndSingleSpace(mId, MID);
        throwIfErrors();
        validateFixedFieldLength(mId, MID_LENGTH, MID);
        throwIfErrors();
        validateFieldWithRegex(mId, ALLOWED_DIGIT_REGEX, MID, INVALID_FORMAT);
        throwIfErrors();
        validateActiveMid(mId);
        logger.debug("Request Validation end for {}", mId);
    }

    /**
     * Method name : validateRefundStatus
     * Description : Validates Refund Status
     * @param refundStatus : String
     */
    private void validateRefundStatus(String refundStatus) {
        if (StringUtils.isNotBlank(refundStatus) && !EnumUtils.isValidEnum(TransactionRefundStatus.class, refundStatus)) {
            logger.error("Invalid refund status: {}", refundStatus);
            errorLogDao.logCustomerError(null, EntityType.ORDER, null,null,null,null,INVALID_ERROR_CODE_NO_REASON, MessageFormat.format(INVALID_ERROR_MESSAGE_NO_REASON, "Refund Status", refundStatus));
            throw new ValidationException(INVALID_ERROR_CODE_NO_REASON, MessageFormat.format(INVALID_ERROR_MESSAGE_NO_REASON, "Refund Status", refundStatus));
        }
    }

    /**
     * Method name : validatePaymentStatus
     * Description : Validates payment Status
     * @param paymentStatus : String
     */
    private void validatePaymentStatus(String paymentStatus) {
        if (StringUtils.isNotBlank(paymentStatus) && !PaymentStatus.isValid(paymentStatus)) {
            logger.error("Invalid payment status: {}", paymentStatus);
            errorLogDao.logCustomerError(null, EntityType.ORDER, null,null,null,null,INVALID_ERROR_CODE_NO_REASON, MessageFormat.format(INVALID_ERROR_MESSAGE_NO_REASON, "Payment Status", paymentStatus));
            throw new ValidationException(INVALID_ERROR_CODE_NO_REASON, MessageFormat.format(INVALID_ERROR_MESSAGE_NO_REASON, "Payment Status", paymentStatus));
        }
    }

    /**
     * Method name : validateTransactionStatus
     * Description : Validates transaction Status
     * @param transactionStatus : String
     */
    private void validateTransactionStatus(String transactionStatus) {
        if (StringUtils.isNotBlank(transactionStatus) && !TransactionStatus.isValid(transactionStatus)) {
            logger.error("Invalid Transaction status: {}", transactionStatus);
            errorLogDao.logCustomerError(null, EntityType.ORDER, null,null,null,null,INVALID_ERROR_CODE_NO_REASON, MessageFormat.format(INVALID_ERROR_MESSAGE_NO_REASON, "Transaction Status", transactionStatus));
            throw new ValidationException(INVALID_ERROR_CODE_NO_REASON, MessageFormat.format(INVALID_ERROR_MESSAGE_NO_REASON, "Transaction Status", transactionStatus));
        }
    }

    /**
     * Method name : validateFieldLengthAndFormatOfMerchantOrderPaymentsRequest
     * Description : Validates mandatory fields of MerchantOrderPaymentSearchRequest
     * @param merchantOrderPaymentSearchRequest : Object of MerchantOrderPaymentSearchRequest
     */
    private void validateFieldLengthAndFormatOfMerchantOrderPaymentsRequest(MerchantOrderPaymentSearchRequest merchantOrderPaymentSearchRequest) {
        logger.info(" validateFieldLengthAndFormatOfMerchantOrderPaymentsRequest start");
        validateFieldLength(merchantOrderPaymentSearchRequest.getOrderRefNumber(), ORDER_REF_LENGTH, ORDER_REF_NUMBER);
        validateFieldWithRegex(merchantOrderPaymentSearchRequest.getOrderRefNumber(), ORDER_REFERENCE_NUMBER_REGEX, ORDER_REF_NUMBER, INVALID_ORDER_REF_REASON);
        validateFieldLength(merchantOrderPaymentSearchRequest.getAtrn(), ATRN_ARRN_LENGTH, ATRN);
        validateFieldWithRegex(merchantOrderPaymentSearchRequest.getAtrn(), ATRN_ARRN_REGEX, ATRN, INVALID_ATRN_REASON);
        validateFieldWithRegex(merchantOrderPaymentSearchRequest.getTransactionStatus(), TRANSACTION_STATUS_REGEX, TRANSACTION_STATUS, INVALID_TRANSACTION_STATUS_REASON);
        validateFieldWithRegex(merchantOrderPaymentSearchRequest.getOrderStatus(), ORDER_STATUS_REGEX, ORDER_STATUS, INVALID_ORDER_STATUS_REASON);
        validateFieldWithRegex(merchantOrderPaymentSearchRequest.getBankRefNumber(), BANK_REFERENCE_NUMBER_REGEX, BANK_REF_NUMBER, INVALID_BANK_REF_REASON);
        validateFieldLength(merchantOrderPaymentSearchRequest.getTransactionStatus(), STATUS_LENGTH, TRANSACTION_STATUS);
        validateFieldLength(merchantOrderPaymentSearchRequest.getBankRefNumber(), BANK_REFERENCE_LENGTH, BANK_REF_NUMBER);
        validateFieldLength(merchantOrderPaymentSearchRequest.getOrderStatus(), ORDER_STATUS_LENGTH, ORDER_STATUS);
        validateFieldWithRegex(merchantOrderPaymentSearchRequest.getRefundStatus(), REFUND_STATUS_REGEX, REFUND_STATUS, INVALID_REUND_STATUS_REASON);
        validateFieldWithRegex(merchantOrderPaymentSearchRequest.getPaymentStatus(), PAYMENT_STATUS_REGEX, PAYMENT_STATUS, INVALID_PAYMENT_STATUS_REASON);
        validateFieldLength(merchantOrderPaymentSearchRequest.getRefundStatus(), REFUND_STATUS_LENGTH, REFUND_STATUS);
        validateFieldLength(merchantOrderPaymentSearchRequest.getPaymentStatus(), PAYMENT_STATUS_LENGTH, PAYMENT_STATUS);
        validateFieldWithRegex(merchantOrderPaymentSearchRequest.getSbiOrderRefNumber(), SBIORDER_REFERENCE_NUMBER_REGEX, SBIORDER_REFERENCE_NUMBER_STATUS, INVALID_SBIORDER_REFERENCE_REASON);
        validateFieldLength(merchantOrderPaymentSearchRequest.getSbiOrderRefNumber(), SBIORDER_REFERENCE_NUMBER_LENGTH, SBIORDER_REFERENCE_NUMBER_STATUS);
        throwIfErrors();
        logger.info(" validateFieldLengthAndFormatOfMerchantOrderPaymentsRequest end");
    }

    /**
     * Method name : checkForLeadingTrailingAndSingleSpaceForOrderPaymentsRequest
     * Description : Validates leading and trailing spaces of MerchantOrderPaymentsRequest
     * @param merchantOrderPaymentSearchRequest : Object of MerchantOrderPaymentSearchRequest
     */
    private void checkForLeadingTrailingAndSingleSpaceForOrderPaymentsRequest(MerchantOrderPaymentSearchRequest merchantOrderPaymentSearchRequest, String mId) {
        logger.info("Validating checkForLeadingTrailingAndSingleSpace");
        checkForLeadingTrailingAndSingleSpace(merchantOrderPaymentSearchRequest.getSbiOrderRefNumber(), SBI_ORDER_REF_NUMBER);
        checkForLeadingTrailingAndSingleSpace(merchantOrderPaymentSearchRequest.getOrderRefNumber(), ORDER_REF_NUMBER);
        checkForLeadingTrailingAndSingleSpace(merchantOrderPaymentSearchRequest.getAtrn(), ATRN);
        checkForLeadingTrailingAndSingleSpace(merchantOrderPaymentSearchRequest.getBankRefNumber(), BANK_REF_NUMBER);
        checkForLeadingTrailingAndSingleSpace(merchantOrderPaymentSearchRequest.getTransactionStatus(), TRANSACTION_STATUS);
        checkForLeadingTrailingAndSingleSpace(merchantOrderPaymentSearchRequest.getOrderStatus(), ORDER_STATUS);
        checkForLeadingTrailingAndSingleSpace(merchantOrderPaymentSearchRequest.getRefundStatus(), REFUND_STATUS);
        checkForLeadingTrailingAndSingleSpace(merchantOrderPaymentSearchRequest.getPaymentStatus(), PAYMENT_STATUS);
        checkForLeadingTrailingAndSingleSpace(mId, MID);
        throwIfErrors();
        logger.info("checkForLeadingTrailingAndSingleSpace validation completed");
    }

    /**
     * validate active merchant id
     *
     * @param mId String
     *
     */
    private void validateActiveMid(String mId) {
        logger.info("Inside getActiveMerchantById for mId: {}", mId);
        MerchantInfoResponse response = adminDao.getMerchantByMId(mId);
        if (!StringUtils.equalsIgnoreCase(FLAG_Y, response.getIsActive())) {
            logger.info("The mId is InActive for mId: {}", mId);
            throw new TransactionException(NOT_FOUND_ERROR_CODE, MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, VALID_MERCHANT));
        }
    }
}