package com.epay.transaction.validator;

import com.epay.transaction.dto.ErrorDto;
import com.epay.transaction.exceptions.ValidationException;
import com.epay.transaction.util.DateTimeUtils;
import com.epay.transaction.util.TransactionErrorConstants;
import com.epay.transaction.util.TransactionConstant;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.EnumUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.math.BigDecimal;
import java.text.MessageFormat;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.regex.Pattern;

import static com.epay.transaction.util.TransactionConstant.*;
import static com.epay.transaction.util.TransactionErrorConstants.*;

/**
 * Class Name:BaseValidator
 * *
 * Description: BaseValidator is a base class for all validators, providing common functionality
 * for storing and managing validation errors.
 * *
 * Author: Bhoopendra Rajput
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
public class BaseValidator {
    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    List<ErrorDto> errorDtoList;
    int mandatoryCount = 0;
    List<String> mandatoryFields;

    /**
     * Check mandatory field
     *
     * @param value     String
     * @param fieldName String
     */
    protected void checkMandatoryField(String value, String fieldName) {
        if (StringUtils.isEmpty(value) || StringUtils.equals(value, "null") || StringUtils.isAllBlank(value)) {
            addError(fieldName, TransactionErrorConstants.MANDATORY_ERROR_CODE, TransactionErrorConstants.MANDATORY_ERROR_MESSAGE);
        }
    }

    /**
     * countMandatoryField
     *
     * @param value     object
     *
     */
    protected void countAndAddMandatoryField(Object value, String fieldName) {

        if (ObjectUtils.isNotEmpty(value)) {
            this.mandatoryCount++;
        }
        mandatoryFields.add(fieldName);
    }

    /**
     * Check checkMandatoryFieldCount
     */
    protected void checkMandatoryFieldCount() {
        if (this.mandatoryCount < 1) {
            addError(MessageFormat.format(ONE_MANDATORY_ERROR, mandatoryFields.toString()), TransactionErrorConstants.MANDATORY_ERROR_CODE, TransactionErrorConstants.MANDATORY_ERROR_MESSAGE);
        }
    }

    /**
     * Check mandatory field
     *
     * @param value     UUID
     * @param fieldName String
     */
    protected void checkMandatoryField(Object value, String fieldName) {
        if (ObjectUtils.isEmpty(value)) {
            addError(fieldName, TransactionErrorConstants.MANDATORY_ERROR_CODE, TransactionErrorConstants.MANDATORY_ERROR_MESSAGE);
        }
    }

    /**
     * Check mandatory collection
     *
     * @param collection Collection
     * @param fieldName  String
     */
    protected void checkMandatoryCollection(Collection<?> collection, String fieldName) {
        if (CollectionUtils.isEmpty(collection)) {
            addError(fieldName, TransactionErrorConstants.MANDATORY_ERROR_CODE, TransactionErrorConstants.MANDATORY_ERROR_MESSAGE);
        }
    }

    /**
     * Check mandatary fields
     *
     * @param fieldName String
     * @param values    String...
     */
    protected void checkMandatoryFields(String fieldName, String... values) {
        boolean allEmpty = Arrays.stream(values).allMatch(StringUtils::isEmpty);
        if (allEmpty) {
            addError(fieldName, TransactionErrorConstants.MANDATORY_ERROR_CODE, TransactionErrorConstants.MANDATORY_ERROR_MESSAGE);
        }
    }

    /**
     * Check mandatory date field
     *
     * @param date      Long
     * @param fieldName String
     */
    protected void checkMandatoryDateField(Long date, String fieldName) {
        if (ObjectUtils.isEmpty(date) || date < 0) {
            addError(fieldName, MANDATORY_ERROR_CODE, MANDATORY_ERROR_MESSAGE);
        }
    }

    protected void validateFieldLength(String value, int maxLength, String fieldName) {
        if (StringUtils.isNotEmpty(value) && value.length() > maxLength) {
            logger.info("field {} exceeds maxLength {}", fieldName, maxLength);
            addError(EXCEED_LENGTH_ERROR_CODE, EXCEED_LENGTH_ERROR_MESSAGE, fieldName, maxLength);
        }
    }

    protected void validateFixedFieldLength(String value, int maxLength, String fieldName) {
        if (StringUtils.isNotEmpty(value) && value.length() != maxLength) {
            logger.info("field {} exceeds maxLength {}", fieldName, maxLength);
            addError(FIXED_LENGTH_ERROR_CODE, FIXED_LENGTH_ERROR_MESSAGE, fieldName, maxLength);
        }
    }

    protected void validateFieldWithRegex(String value, int maxLength, String regex, String fieldName, String message) {
        if (StringUtils.isNotEmpty(value) && (value.length() > maxLength || validate(value, regex))) {
            addError(fieldName, INVALID_ERROR_CODE, message + " " + maxLength);
        }
    }

    protected void validateFieldWithRegex(String value, String regex, String fieldName, String reason) {
        if (StringUtils.isNotEmpty(value) && validate(value, regex)) {
            addError(fieldName, INVALID_ERROR_CODE, MessageFormat.format(INVALID_ERROR_MESSAGE, fieldName, reason));
        }
    }

    /**
     * Validate if given
     *
     * @param enumName  String
     * @param fieldName String
     * @param enumClass Class
     * @param <E>       Enum Class Name
     */
    protected <E extends Enum<E>> void validateFieldValue(String enumName, String fieldName, Class<E> enumClass) {
        if (StringUtils.isNotEmpty(enumName) && !EnumUtils.isValidEnum(enumClass, enumName)) {
            addError(INVALID_ERROR_CODE, INVALID_ERROR_MESSAGE, fieldName, VALID_VALUES_ARE + EnumUtils.getEnumList(enumClass).stream().map(Enum::name).toList());
        }
    }

    /**
     * validate given field value from given list.
     *
     * @param value       String
     * @param validValues List of values
     * @param fieldName   String
     */
    protected void validateFieldValue(String value, List<String> validValues, String fieldName, String reason) {
        boolean isValid = validValues.stream().anyMatch(validValue -> validValue.equalsIgnoreCase(value));
        if (!isValid) {
            addError(fieldName, INVALID_ERROR_CODE, MessageFormat.format(INVALID_ERROR_MESSAGE, fieldName, reason));
        }
    }

    protected void addError(String fieldName, String errorCode, String errorMessage) {
        errorDtoList.add(ErrorDto.builder().errorCode(errorCode).errorMessage(MessageFormat.format(errorMessage, fieldName)).build());
    }

    protected void addError(String errorCode, String errorMessage, Object... fieldNames) {
        errorDtoList.add(ErrorDto.builder().errorCode(errorCode).errorMessage(MessageFormat.format(errorMessage, fieldNames)).build());
    }

    protected void throwIfErrors() {
        if (CollectionUtils.isNotEmpty(errorDtoList)) {
            throw new ValidationException(errorDtoList);
        }
    }

    protected boolean validate(String value, String regex) {
        return !Pattern.matches(regex, value);
    }

    protected void checkForLeadingTrailingAndSingleSpace(String value, String fieldName) {
        logger.debug("checking for Leading and Trailing space for field {} and value {}", fieldName, value);
        if (StringUtils.isNotEmpty(value) && !value.equals(value.trim())) {
            addError(fieldName, WHITESPACE_ERROR_CODE, TransactionErrorConstants.WHITESPACE_ERROR_MESSAGE);
        }
    }

    /**
     * Validate amount(BigDecimal) length before and after decimal as per configuration
     * @param amount    BigDecimal
     * @param fieldName String
     */
    protected void validateAmount(BigDecimal amount, String fieldName) {
        if (amount.signum() <= 0) {
            addError(fieldName, INVALID_ERROR_CODE, MessageFormat.format(INVALID_ERROR_MESSAGE, fieldName, AMOUNT_GREATER_THAN_ZERO));
        } else if (amount.scale() > AMOUNT_LENGTH_AFTER_DECIMAL) {
            logger.info("field {} amount {} exceeds {} decimal point.", fieldName, amount, AMOUNT_LENGTH_AFTER_DECIMAL);
            addError(EXCEED_LENGTH_ERROR_CODE, MessageFormat.format(EXCEED_LENGTH_ERROR_MESSAGE, fieldName + AMOUNT_DECIMAL_MESSAGE, AMOUNT_LENGTH_AFTER_DECIMAL));
        } else if (StringUtils.isNotEmpty(amount.toString()) && (amount.precision() - amount.scale()) > AMOUNT_LENGTH) {
            logger.info("field {} exceeds maxLength {}", fieldName, AMOUNT_LENGTH);
            addError(EXCEED_LENGTH_ERROR_CODE, EXCEED_LENGTH_ERROR_MESSAGE, fieldName + AMOUNT_BEFORE_DECIMAL_MESSAGE, AMOUNT_LENGTH);
        } else {
            validateFieldWithRegex(amount.toString(), TransactionConstant.AMOUNT_LENGTH_REGEX, fieldName, INCORRECT_FORMAT);
        }
        throwIfErrors();
    }

    protected void checkAllCaps(String value, String field) {
        if (!value.matches(CAPS_REGEX)) {
            addError(field, TransactionErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(TransactionErrorConstants.INVALID_ERROR_MESSAGE, field, SMALL_LETTERS_NOT_ALLOWED));
        }
    }

    /**
     * Check mandatory field
     *
     * @param file     MultipartFile
     * @param fieldName String
     */
    protected void checkFilePresentOrNot(MultipartFile file, String fieldName) {
        if (ObjectUtils.isEmpty(file) || file.isEmpty()) {
            addError(fieldName, TransactionErrorConstants.MANDATORY_ERROR_CODE, TransactionErrorConstants.MANDATORY_ERROR_MESSAGE);
        }
    }
    /**
     * Check mandatory field
     *
     * @param file     MultipartFile
     * @param fileType String []
     */
    protected void checkFileFormat(MultipartFile file, String[] fileType) {
        if (!StringUtils.containsAnyIgnoreCase(file.getContentType(), fileType)) {
            addError(TransactionErrorConstants.MANDATORY_ERROR_CODE, TransactionErrorConstants.UNSUPPORTED_FILE_TYPE);
        }
    }

    /**
     * Check mandatory field
     *
     * @param fileSize  MultipartFile
     * @param confgSize Long
     */
    protected void checkFileMaxSize(MultipartFile fileSize, Long confgSize) {
        if (confgSize < fileSize.getSize()) {
            logger.debug("field {} exceeds maxLength {}", fileSize.getOriginalFilename(), confgSize);
            addError(EXCEED_LENGTH_ERROR_CODE, EXCEED_LENGTH_ERROR_MESSAGE, BULK_REFUND_FILE, confgSize);
        }
    }

    protected void validateFieldValue(String value, List<String> validValues, String fieldName) {
        boolean isValid = validValues.stream().anyMatch(validValue -> validValue.equals(value));
        if (!isValid) {
            addError(fieldName,INVALID_ENUM_ERROR_CODE,INVALID_ENUM_ERROR_MESSAGE);
        }
    }

    protected void validateReportDates(Long fromDate, Long toDate) {

        logger.info("Validating from and to date starts");

        //Step-1: If both from and to date not present, no need to validate
        if (ObjectUtils.isEmpty(fromDate) && ObjectUtils.isEmpty(toDate)) {
            return;
        }

        //Step-2: If any one date present then both fields should be mandatory
        checkMandatoryDateField(fromDate, FROM_DATE);
        checkMandatoryDateField(toDate, TO_DATE);
        throwIfErrors();

        //Step-3: Future from date
        if (fromDate > DateTimeUtils.endOfDayMillis()) {
            addError(FROM_DATE, INVALID_ERROR_CODE, MessageFormat.format(INVALID_ERROR_MESSAGE, FROM_DATE, FUTURE_DATE_ERROR));
            throwIfErrors();
        }

        //Step-4: From date within 1 year
        if (DateTimeUtils.calculateDaysBetween(DateTimeUtils.endOfDayMillis(), fromDate) > ALLOWED_FROM_DATE_DIFF) {
            addError(FROM_DATE, INVALID_ERROR_CODE, MessageFormat.format(INVALID_ERROR_MESSAGE, FROM_DATE, PAST_DATE_12M_ERROR));
            throwIfErrors();
        }

        //Step-5: Future to date
        if (toDate > DateTimeUtils.endOfDayMillis()) {
            addError(TO_DATE, INVALID_ERROR_CODE, MessageFormat.format(INVALID_ERROR_MESSAGE, TO_DATE, FUTURE_DATE_ERROR));
            throwIfErrors();
        }

        //Step-6: From date can not be more than to date
        if (fromDate > toDate) {
            addError(FROM_DATE, INVALID_ERROR_CODE, MessageFormat.format(INVALID_ERROR_MESSAGE, FROM_DATE, FROM_TO_DATE_ERROR));
            throwIfErrors();
        }

        //Step-6: From-To date difference more than 1 month
        if (DateTimeUtils.calculateDaysBetween(fromDate, toDate) > ALLOWED_FROM_TO_DATE_DIFF) {
            addError(FROM_DATE, INVALID_ERROR_CODE, MessageFormat.format(INVALID_ERROR_MESSAGE, FROM_DATE, DATE_DIFF_1M_ERROR));
            throwIfErrors();
        }

        logger.info("Validating from and to date ends");
    }

}