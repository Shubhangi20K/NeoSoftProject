package com.epay.transaction.entity;

import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.util.UUID;

@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Builder
@Table(name = "EIS_API_HISTORY")
public class EisApiHistory extends AuditEntity{

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;
    @Column(name = "MERCHANT_ID")
    private String mId;
    private String sbiOrderRefNumber;
    private String gstIn;
    private String email;
    private String requestType;
    private String requestJson;
    private String responseJson;
}
