package com.epay.transaction.externalservice.response.admin;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;


@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.USE_DEFAULTS)
@JsonFormat(with = JsonFormat.Feature.ACCEPT_CASE_INSENSITIVE_PROPERTIES)
public class MerchantVvlResponse {
    @JsonProperty("mId")
    private String mId;
    private String payModeCode;
    private BigDecimal annualTxnAmountLimit;
    private BigDecimal dailyTxnAmountLimit;
    private BigDecimal weeklyTxnAmountLimit;
    private BigDecimal monthlyTxnAmountLimit;
    private BigDecimal quarterlyTxnAmountLimit;
    private BigDecimal maxTxnLimit;
    private BigDecimal halfYearlyTxnAmountLimit;
    private BigDecimal minTxnLimit;
}
