package com.epay.transaction.etl.producer;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.UUID;

/**
 * Class Name: RefundBookingDetailsProducer
 * *
 * Description: The implementation is for produce bulk refund related data to topic.
 * *
 * Author: V1019439(Rahul Yadav)
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Component
@RequiredArgsConstructor
public class RefundBookingDetailsProducer extends TransactionProducer<UUID> {
    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    private final ObjectMapper objectMapper;

    /**
     * @param requestType String
     * @param routingKey  String
     * @param bulkRefundBookingDetails    BulkRefundBookingDetails
     */
    @Override
    public void publish(String requestType, String routingKey, UUID bulkRefundBookingDetails) {
        try {
            log.debug("Bulk refund published for requestType : {}, routingKey : {} and value : {}", requestType, routingKey, bulkRefundBookingDetails);
            kafkaMessagePublisher.publish(topics.getProcessBookingDetailsTopic(), getRoutingKey("bulkId", requestType, routingKey), objectMapper.writeValueAsString(bulkRefundBookingDetails));
        } catch (Exception e) {
            log.error("Error in publish bulk message, BulkRefundBookingDto {}", bulkRefundBookingDetails, e.getMessage());
        }
    }
}
