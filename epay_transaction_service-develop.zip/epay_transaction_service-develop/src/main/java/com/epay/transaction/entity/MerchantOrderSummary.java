package com.epay.transaction.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.GenerationType;
import jakarta.persistence.GeneratedValue;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;
import java.util.UUID;

/**
 * Class Name:MerchantOrderSummary
 * *
 * Description:
 * *
 * Author:Nirmal Gurjar
 * <p>
 * Copyright (c) 2024 [State Bank of INdia]
 * All right reserved
 * *
 * Version:1.0
 */
@EqualsAndHashCode(callSuper = true)
@Getter
@Setter
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "MERCHANT_ORDER_SUMMARY")
public class MerchantOrderSummary extends AuditEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(nullable = false, updatable = false)
    private UUID id;
    @Column(name = "MERCHANT_ID")
    private String mId;

    private String paymodeCode;
    private Long lastTxnBookingDate;

    private BigDecimal dailyTxnAmount;
    private BigDecimal weeklyTxnAmount;
    private BigDecimal monthlyTxnAmount;
    private BigDecimal quarterlyTxnAmount;
    private BigDecimal halfYearlyTxnAmount;
    private BigDecimal annuallyTxnAmount;

}
