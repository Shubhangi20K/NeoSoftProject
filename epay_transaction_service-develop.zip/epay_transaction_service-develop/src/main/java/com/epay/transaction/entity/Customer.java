package com.epay.transaction.entity;

import com.epay.transaction.util.enums.CustomerStatus;
import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.util.UUID;

/**
 * Class Name: CustomerController
 * *
 * Description: Customer creation for given Merchant.
 * *
 * Author: V1018400 (Ranjan Kumar)
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */

@EqualsAndHashCode(callSuper = true)
@Getter
@Setter
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "MERCHANT_CUSTOMER")
public class Customer extends AuditEntity {

    @Id
    @Column(nullable = false, updatable = false, unique = true)
    private String customerId;
    @Column(name = "MERCHANT_ID")
    private String mId;
    private String customerName;
    private String email;
    private String phoneNumber;
    private String gstIn;
    private String gstInAddress;
    private String address1;
    private String address2;
    private String city;
    private String state;
    private String country;
    @Column(name = "PINCODE")
    private String pinCode;
    @Enumerated(EnumType.STRING)
    private CustomerStatus status;

    /**
     * custom generator, do not remove it
     */
    @PrePersist
    protected void createCustomerId() {
        this.customerId = UUID.randomUUID().toString().toUpperCase().replace("-", "").substring(0, 20);
    }

}