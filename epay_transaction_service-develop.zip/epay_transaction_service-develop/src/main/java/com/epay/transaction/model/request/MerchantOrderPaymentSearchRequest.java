package com.epay.transaction.model.request;

import com.epay.transaction.util.enums.OrderStatus;
import com.epay.transaction.util.enums.PaymentStatus;
import com.epay.transaction.util.enums.TransactionRefundStatus;
import com.epay.transaction.util.enums.TransactionStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Class Name: MerchantOrderPaymentSearchRequest
 * *
 * Description:
 * *
 * Author: V1017903(bhushan wadekar)
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MerchantOrderPaymentSearchRequest {
    private Long fromDate;
    private Long toDate;
    private String orderRefNumber;
    private String atrn;
    private String bankRefNumber;
    private String transactionStatus;
    private String orderStatus;
    private String refundStatus;
    private String paymentStatus;
    private String sbiOrderRefNumber;
}
