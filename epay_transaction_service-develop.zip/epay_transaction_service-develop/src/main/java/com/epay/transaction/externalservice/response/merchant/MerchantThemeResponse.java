package com.epay.transaction.externalservice.response.merchant;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import java.io.Serializable;

/**
 * Class Name: MerchantThemeResponse
 * *
 * Description: This dto class contains details related to Payment Page Theme request.
 * It includes merchant Id, primary colour, secondary colour, logo, module, default time.
 * *
 * Author: Bhoopendra Rajput
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Builder
@Data
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class MerchantThemeResponse implements Serializable {
    @JsonProperty("mId")
    private String mId;
    private String primaryColor;
    private String secondaryColor;
    private String logo;
    private String module;
    private boolean defaultTheme;
}