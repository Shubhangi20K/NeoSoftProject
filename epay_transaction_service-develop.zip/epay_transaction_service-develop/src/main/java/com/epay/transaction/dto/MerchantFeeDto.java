package com.epay.transaction.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

@AllArgsConstructor
@Data
@Builder
public class MerchantFeeDto implements Serializable {

    @JsonProperty("mId")
    private String mId;
    private BigDecimal merchPostedAmt;
    private String payModeCode;
    private String gtwMapsId;
    private String payProcType;
    private String atrn;

    private BigDecimal merchantFeeAbs;
    private BigDecimal otherFeeAbs;
    private BigDecimal gtwFeeAbs;
    private BigDecimal aggServiceFeeAbs;

    private BigDecimal postAmount;
    private BigDecimal customerBearableAmt;
    private BigDecimal customerBearableServiceTax;
    private BigDecimal merchantBearableAmt;
    private BigDecimal merchantBearableServiceTax;

}
