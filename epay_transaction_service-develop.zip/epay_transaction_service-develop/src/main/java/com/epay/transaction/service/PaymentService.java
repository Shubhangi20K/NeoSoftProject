package com.epay.transaction.service;

import com.epay.transaction.dao.MerchantOrderPaymentDao;
import com.epay.transaction.dto.SettlementStatusDto;
import com.epay.transaction.entity.MerchantOrderPayment;
import com.epay.transaction.model.request.EncryptedRequest;
import com.epay.transaction.model.request.TransactionUpdateRequest;
import com.epay.transaction.model.response.EncryptedResponse;
import com.epay.transaction.model.response.TransactionResponse;
import com.epay.transaction.model.response.TransactionUpdateStatusResponse;
import com.epay.transaction.util.TransactionConstant;
import com.epay.transaction.util.TransactionUtil;
import com.epay.transaction.validator.PaymentValidator;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.Collections;
import java.util.List;

import static com.epay.transaction.util.EncryptionDecryptionUtil.encryptValue;
import static com.epay.transaction.util.TransactionErrorConstants.MERCHANT_ORDER_PAYMENT_STATUS_FAILED;

/**
 * Class Name: PaymentService
 * *
 * Description:This services class use for updateTransactionFail
 * *
 * Author: V1018400 (Bhushan Wedekar)
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@RequiredArgsConstructor
@Service
public class PaymentService {
   private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());

    private final MerchantOrderPaymentDao merchantOrderPaymentDao;
    private final PaymentValidator paymentValidator;

    /**
     * Method name:markTransactionStatusFail
     * Description:Marks a merchant order payment status as "failed" based on the provided encrypted request.
     * <p>
     * This method decrypts the incoming request, processes the failure status for the relevant merchant order payment,
     * and returns a response indicating the success of the operation.
     *
     * @param encryptedRequest The encrypted request containing the details needed to mark the payment status as failed.
     * @return A response indicating the success of marking the payment status as failed.
     */
    public TransactionResponse<EncryptedResponse> updateTransactionFail(EncryptedRequest encryptedRequest) {
        logger.info("Marking merchant order payment status as failed for request: {}", encryptedRequest);
        String aesKey = merchantOrderPaymentDao.getEncryptedAESKey();
        TransactionUpdateRequest transactionUpdateRequest = TransactionUtil.buildRequestByEncryptRequest(encryptedRequest.getEncryptedRequest(), aesKey, TransactionUpdateRequest.class);
        paymentValidator.validatePaymentRequest(transactionUpdateRequest);
        merchantOrderPaymentDao.updateTransactionFail(transactionUpdateRequest.getAtrn(), transactionUpdateRequest.getFailReason());
        //Fetch Order retry count
        Integer retryCount = merchantOrderPaymentDao.getMerchantOrder().getOrderRetryCount();
        logger.info("Fetched Order retry count: {} ", retryCount);

        //Build response object with status message and remaining retry count from Order
        TransactionUpdateStatusResponse transactionUpdateStatusResponse = TransactionUpdateStatusResponse.builder()
                .statusMessage(MERCHANT_ORDER_PAYMENT_STATUS_FAILED)
                .orderRetryCount(retryCount).build();

        EncryptedResponse response= EncryptedResponse.builder().encryptedResponse(encryptValue(aesKey, TransactionUtil.toJson(transactionUpdateStatusResponse))).build();
        logger.info("Merchant order payment status marked as failed successfully.");
        return TransactionResponse.<EncryptedResponse>builder().data(Collections.singletonList(response)).status(TransactionConstant.RESPONSE_SUCCESS).build();
    }

    /**
     * Method name:getMerchantPaymentDetails
     * Description:get a merchant order payment by atrn on the provided encrypted request.
     * <p>
     * This method decrypts the incoming request, processes get a merchant order payment for the relevant merchant order payment,
     * and returns a response indicating the success of the operation.
     *
     * @param encryptedRequest The encrypted request containing the details needed to get a merchant order payment details.
     * @return object of TransactionResponse
     */
    public TransactionResponse<EncryptedResponse>   getMerchantOrderPaymentDetails(EncryptedRequest encryptedRequest) {
        logger.info("get merchant order payment details by atrn {}", encryptedRequest);
        String aesKey = merchantOrderPaymentDao.getEncryptedAESKey();
        logger.info("Fetch aesKey request start {}",aesKey);
        String  sbiReferenceNumber = TransactionUtil.buildRequestByEncryptRequest(encryptedRequest.getEncryptedRequest(), aesKey, String.class);
        logger.info("decrypt encryptedRequest using aesKey {}",sbiReferenceNumber);
        List<MerchantOrderPayment> merchantPaymentOrder=merchantOrderPaymentDao.findBySbiOrderRefNumber(sbiReferenceNumber);

        logger.debug("fetch MerchantPaymentOrderDto{} ",merchantPaymentOrder);
        String mek = merchantOrderPaymentDao.getMerchantMek();
        logger.info("get mek");
        EncryptedResponse encryptedResponse= EncryptedResponse.builder().encryptedResponse(encryptValue(mek, TransactionUtil.toJson(merchantPaymentOrder))).build();

        return TransactionResponse.<EncryptedResponse>builder().data(List.of(encryptedResponse)).status(1).count(1L).build();
    }

}