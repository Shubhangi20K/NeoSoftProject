package com.epay.transaction.service;

import com.epay.transaction.util.enums.Report;
import com.epay.transaction.util.enums.ReportFormat;
import com.epay.transaction.util.file.generator.FileGenerator;
import com.epay.transaction.util.file.model.FileModel;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
/**
 * Class Name:FileGeneratorService
 * *
 * Description: This class is used for generate file
 * *
 * Author:V1014352
 * <p>
 * Copyright (c) 2024 [State Bank of india]
 * All right reserved
 * *
 * Version:1.0
 */
@Service
@RequiredArgsConstructor
public class FileGeneratorService {

    public final FileGenerator fileGenerator;
    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());


    /**
     * Initiates the file download process for a specific report and format.
     * This method delegates the task of downloading the file to the `FileGenerator` service,
     * which handles the actual file creation and response streaming for the client.
     * @param response The HTTP response object used to send the file content to the client.
     * @param reportFormat The format of the report (e.g., CSV, XLS, PDF).
     * @param report The report object containing the data to be included in the generated file.
     * @param mId The merchant ID associated with the report.
     * @param fileModel The model containing the necessary data and configurations for the file generation.
     */
    public void downloadFile(HttpServletResponse response, ReportFormat reportFormat, Report report, String mId, FileModel fileModel) {
        log.info("Started downloadFile for reportFormat: {}, report: {},mId: {},fileModel: {}", reportFormat, report.getName(),mId,fileModel);
        fileGenerator.downloadFile(response, reportFormat, report, mId, fileModel);
    }

    /**
     * Builds a file model based on the provided report format and file data.
     * This method prepares the file model containing the header, data, and additional information
     * required for generating a report in the desired format. It can be used for different formats
     * like CSV, PDF, etc.
     *
     * @param reportFormat The format of the report (e.g., CSV, PDF).
     * @param header The list of headers for the report.
     * @param fileData The data to be included in the report.
     * @param pdfFileData Additional data for generating PDF reports.
     * @return FileModel The generated file model containing the necessary data for file generation.
     */
    public FileModel buildFileModel(ReportFormat reportFormat, List<String> header, List<List<Object>> fileData, Map<String, Object> pdfFileData) {
        log.debug("Started buildFileModel for reportFormat: {}, header: {}, fileData: {}, pdfFileData: {}", reportFormat, header, fileData, pdfFileData);
        return fileGenerator.buildFileModel(reportFormat, header, fileData, pdfFileData);
    }
}
