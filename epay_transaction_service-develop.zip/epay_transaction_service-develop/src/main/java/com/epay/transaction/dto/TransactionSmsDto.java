package com.epay.transaction.dto;

import com.epay.transaction.util.enums.NotificationEntityType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;


/**
 * Class Name: TransactionSmsDto
 * *
 * Description: Data transfer of type SMS.
 * *
 * Author: Gireesh M
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TransactionSmsDto {
    private UUID entityId;
    private NotificationEntityType entityType;
    private String requestType;
    private String mobileNumber;
    private String message;
}
