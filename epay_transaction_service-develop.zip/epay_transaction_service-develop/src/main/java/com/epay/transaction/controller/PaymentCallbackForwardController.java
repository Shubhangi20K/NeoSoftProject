package com.epay.transaction.controller;

import com.epay.transaction.model.request.EncryptedRequest;
import com.epay.transaction.model.request.PaymentCallBackRequest;
import com.epay.transaction.model.response.EncryptedResponse;
import com.epay.transaction.model.response.TransactionResponse;
import com.epay.transaction.service.PaymentCallbackForwardService;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.view.RedirectView;

/**
 * Class Name:PaymentCallbackForwardController
 * *
 * Description:
 * *
 * Author:V1014352(Ranjan Kumar)
 * <p>
 * Copyright (c) 2025 [State Bank of India
 * All right reserved
 * *
 * Version:1.0
 */
@RestController
@RequiredArgsConstructor
@Tag(name = "SBI INB Payment Callback APIs")
public class PaymentCallbackForwardController {
    private final PaymentCallbackForwardService paymentCallbackForwardService;
    LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());

    /**
     * Processing  callback response
     * @param paymentCallBackRequest :
     * @return object of TransactionResponse
     */
    @PostMapping("/callback")
    @Operation(summary = "SBI  Web Response and Double Verification API", description = "This API is used for Capture Web Response and Double Verification call to Bank.")
    public String processInbCallbackResponse(@Valid @RequestBody PaymentCallBackRequest paymentCallBackRequest) {
        logger.info(" SBI Payment callback is called.");
        logger.debug("Input {}: ", paymentCallBackRequest);
        return paymentCallbackForwardService.processCallbackResponse(paymentCallBackRequest);
    }



    /**
     * Processing ruapy otp callback response.
     * @param encryptedRequest EncryptedRequest
     * @return TransactionResponse
     */
    @PostMapping("/cards/sbi/rupay/verify-otp")
    @Operation(summary = "Card Payment Rupay Otp verification API", description = "This API is used for card Rupay Otp Verification.")
    public TransactionResponse<EncryptedResponse> processCardRupayOtpResponsePayload(@Valid @RequestBody EncryptedRequest encryptedRequest) {
        logger.info("Rupay OTP Verification API is called, encryptedRequest: {}", encryptedRequest);
        return paymentCallbackForwardService.processCardRupayOtpResponsePayload(encryptedRequest);
    }

    /**
     * Processing rupay resendotp callback response
     * @param encryptedRequest EncryptedRequest
     * @return object of TransactionResponse
     */
    @PostMapping("/cards/sbi/rupay/resend-otp")
    @Operation(summary = "RUPAY Resend OTP API", description = "This API is used to Resend OTP.")
    public TransactionResponse<EncryptedResponse> rupayRecentOtpResponse(@Valid @RequestBody EncryptedRequest encryptedRequest) {
        logger.info("Rupay Resend OTP API is called, encryptedRequest : {}", encryptedRequest);
        return paymentCallbackForwardService.getRupayCardCallBackResentOtpResponse(encryptedRequest);
    }


}
