package com.epay.transaction.externalservice.request.eis.ecom;

/*
 *
 *  Copyright (c) [2024] [State Bank of India]
 *  All rights reserved.
 *  Author:@V0000001(Shubhangi Kurelay)
 *  Version:1.0
 *
 */

import com.epay.transaction.util.TransactionConstant;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class EISEComRequest {

    @JsonProperty("SOURCE_ID")
    @Builder.Default
    private String sourceId = TransactionConstant.SOURCE_ID_EY;

    @JsonProperty("DESTINATION")
    @Builder.Default
    private String destination = TransactionConstant.DESTINATION;

    @JsonProperty("TXN_TYPE")
    @Builder.Default
    private String txnType = TransactionConstant.TXT_TYPE;

    @JsonProperty("TXN_SUB_TYPE")
    @Builder.Default
    private String txnSubType = TransactionConstant.TXN_SUB_TYPE;

    @JsonProperty("REQUEST_REFERENCE_NUMBER")
    private String requestReferenceNumber;

    @JsonProperty("EIS_PAYLOAD")
    private EISEComPayloadRequest eisPayload;

    @Override
    public String toString() {
        return "DCMSEnquiry [REQUEST_REFERENCE_NUMBER=" + requestReferenceNumber + ", SOURCE_ID=" + sourceId + ", DESTINATION=" + destination + ", TXN_TYPE=" + txnType + ", TXN_SUB_TYPE=" + txnSubType + ", EIS_PAYLOAD=" + eisPayload + "]";
    }

}
