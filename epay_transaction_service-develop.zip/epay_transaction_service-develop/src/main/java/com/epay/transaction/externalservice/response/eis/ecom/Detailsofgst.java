package com.epay.transaction.externalservice.response.eis.ecom;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Detailsofgst {
    @JsonProperty("GSTINSEARCHID")
    public int gstinsearchid;
    @JsonProperty("GSTIN")
    public String gstin;
    @JsonProperty("LEGAL_NAME")
    public String legalName;
    @JsonProperty("CONSTITUTION")
    public String constitution;
    @JsonProperty("ACTIVE_STATUS")
    public String activeStatus;
    @JsonProperty("STATE_JURI")
    public String stateJuri;
    @JsonProperty("CENTER_JURI")
    public String centerJuri;
    @JsonProperty("REGISTRATION_DATE")
    public String registrationDate;
    @JsonProperty("CANCELLATION_DATE")
    public Object cancellationDate;
    @JsonProperty("CREATED_DATE")
    public String createdDate;
    @JsonProperty("NBA")
    public String nBA;
    @JsonProperty("TAX_PAYER_TYPE")
    public String taxPayerType;
    @JsonProperty("CALL_COUNT")
    public int callCount;
    @JsonProperty("FP")
    public Object fP;
    @JsonProperty("FILE_DATA")
    public String fileData;
    @JsonProperty("TRADE_NAME")
    public String tradeName;
    @JsonProperty("ADDRESS")
    public ArrayList address;
    @JsonProperty("PRINCIPAL_ADDRESS")
    public PrincipalAddress principalAddress;
    @JsonProperty("PREFERENCEJSON")
    public String preferencejson;


}
