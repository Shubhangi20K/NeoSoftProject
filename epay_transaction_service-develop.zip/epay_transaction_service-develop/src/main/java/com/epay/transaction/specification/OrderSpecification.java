package com.epay.transaction.specification;

import com.epay.transaction.dto.OrderStatusDto;
import com.epay.transaction.entity.Order;
import com.epay.transaction.entity.MerchantOrderPayment;
import jakarta.persistence.criteria.*;
import lombok.experimental.UtilityClass;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.util.StringUtils;

import java.math.BigDecimal;

/**
 * class name : OrderSpecification
 * Description : Order specification for dynamic search related queries left join on payment
 * Copyright (c) [2025] [State Bank of India]
 * All rights reserved.
 * <p>
 * Author: NIRMAL GURJAR
 * Version:1.0
 */

@UtilityClass
public class OrderSpecification {

    public static Specification<Order> searchOrder(String mId, OrderStatusDto orderStatusDto) {

        return (root, query, criteriaBuilder) -> {

            Predicate predicate = criteriaBuilder.conjunction();
            predicate = criteriaBuilder.and(predicate, getMidPredicate(root, criteriaBuilder, mId));

            Fetch<Order, MerchantOrderPayment> paymentFetch = root.fetch("merchantOrderPayments", JoinType.LEFT);
            Join<Order, MerchantOrderPayment> orderJoin = (Join<Order, MerchantOrderPayment>) paymentFetch;

            if (StringUtils.hasText(orderStatusDto.getOrderRefNumber())) {
                predicate = criteriaBuilder.and(predicate, getOrderRefNumberPredicate(root, criteriaBuilder, orderStatusDto.getOrderRefNumber()));
            }

            if (StringUtils.hasText(orderStatusDto.getSbiOrderRefNumber())) {
                predicate = criteriaBuilder.and(predicate, getSbiOrderRefNumberPredicate(root, criteriaBuilder, orderStatusDto.getSbiOrderRefNumber()));
            }

            if (ObjectUtils.isNotEmpty(orderStatusDto.getOrderAmount())) {
                predicate = criteriaBuilder.and(predicate, getOrderAmountPredicate(root, criteriaBuilder, orderStatusDto.getOrderAmount()));
            }

            if (StringUtils.hasText(orderStatusDto.getAtrnNumber())) {
                predicate = criteriaBuilder.and(predicate, getAtrnPredicate(orderJoin, criteriaBuilder, orderStatusDto.getAtrnNumber()));
            }

            return predicate;
        };
    }

    private static Predicate getMidPredicate(Root<Order> root, CriteriaBuilder criteriaBuilder, String mId) {
        return criteriaBuilder.equal(root.get("mId"), mId);
    }

    private static Predicate getOrderRefNumberPredicate(Root<Order> root, CriteriaBuilder criteriaBuilder, String orderRefNumber) {
        return criteriaBuilder.equal(root.get("orderRefNumber"), orderRefNumber);
    }

    private static Predicate getSbiOrderRefNumberPredicate(Root<Order> root, CriteriaBuilder criteriaBuilder, String sbiOrderRefNumber) {
        return criteriaBuilder.equal(root.get("sbiOrderRefNumber"), sbiOrderRefNumber);
    }

    private static Predicate getOrderAmountPredicate(Root<Order> root, CriteriaBuilder criteriaBuilder, BigDecimal orderAmount) {
        return criteriaBuilder.equal(root.get("orderAmount"), orderAmount);
    }

    private static Predicate getAtrnPredicate(Join<Order, MerchantOrderPayment> payementJoin, CriteriaBuilder criteriaBuilder, String atrn) {
        return criteriaBuilder.equal(payementJoin.get("atrnNumber"), atrn);
    }
}