package com.epay.transaction.externalservice;

import com.epay.transaction.client.ApiClient;
import com.epay.transaction.externalservice.request.payment.*;
import com.epay.transaction.externalservice.response.payment.PaymentFinalResponse;
import com.epay.transaction.externalservice.response.payment.RupaySeamlessResponse;
import com.epay.transaction.model.response.TransactionResponse;
import com.epay.transaction.util.TransactionConstant;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import org.springframework.core.ParameterizedTypeReference;

import java.net.URLEncoder;


import java.util.HashMap;
import java.util.Map;

/**
 * Class Name:PaymentCallBackServicesClient
 * *
 * Description:
 * *
 * Author:V1014352(Ranjan Kumar)
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
public class PaymentCallBackServicesClient extends ApiClient {
    LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());

    /**
     * @param baseUrl    String
     * @param corsOrigin String
     */
    public PaymentCallBackServicesClient(String baseUrl, String corsOrigin) {
        super(baseUrl, corsOrigin);
    }


    /**
     * @param paymentRequestResendCard PaymentRequestResendCard
     * @return TransactionResponse
     */
    public TransactionResponse<RupaySeamlessResponse> getRupayCardCallBackResentOtpResponse(PaymentRequestResendCard paymentRequestResendCard) {
        return post(TransactionConstant.CALBACK_RUPAY_RESENT_OTP_ENDPOINT, paymentRequestResendCard, new ParameterizedTypeReference<>() {
        });
    }

    /**
     * @param paymentRequestVerifyCard PaymentRequestVerifyCard
     * @return TransactionResponse
     */
    public TransactionResponse<RupaySeamlessResponse> getRupayCardCallBackVerifyOtpResponse(PaymentRequestVerifyCard paymentRequestVerifyCard) {
        return post(TransactionConstant.CALBACK_RUPAY_VERIFY_OTP_ENDPOINT, paymentRequestVerifyCard, new ParameterizedTypeReference<>() {
        });
    }


}

