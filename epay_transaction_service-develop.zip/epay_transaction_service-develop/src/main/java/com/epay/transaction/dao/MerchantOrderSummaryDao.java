package com.epay.transaction.dao;

import com.epay.transaction.entity.MerchantOrderSummary;
import com.epay.transaction.repository.MerchantOrderSummaryRepository;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Class Name: MerchantPaymodeDao
 * *
 * Description: dao for paymode
 * *
 * Author: Nirmal Gurjar
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */

@Component
@AllArgsConstructor
public class MerchantOrderSummaryDao {

    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());

    private final MerchantOrderSummaryRepository merchantOrderSummaryRepository;

    /**
     * To Get the Merchant Order Summery By Mid and PayModeCode.
     *
     * @param mId : String
     * @param payModeCode : String
     * @return List Of Merchant Order Summery.
     */
    public List<MerchantOrderSummary> getMerchantOrderSummary(String mId, String payModeCode) {
        logger.info("Finding data from merchant order summery repo with : {], {}", mId, payModeCode);
        return merchantOrderSummaryRepository.findBymIdAndPaymodeCode(mId, payModeCode);
    }
}
