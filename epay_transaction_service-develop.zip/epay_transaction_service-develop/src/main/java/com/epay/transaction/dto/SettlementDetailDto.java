package com.epay.transaction.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

/**
 *  Class Name:SettlementDetailDto
 *  Copyright (c) [2025] [State Bank of India]
 *  All rights reserved.
 *  Author:@V0000001(Shilpa Kothre)
 *  Version:1.0
 *
 */

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SettlementDetailDto {

    private String atrn;
    private String status;
    private BigDecimal refundAdjusted;
    private BigDecimal chargeBackAdjusted;
    private BigDecimal txnPayout;

}
