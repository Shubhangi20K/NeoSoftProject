package com.epay.transaction.dto;


import com.epay.transaction.util.enums.PayoutStatus;
import com.epay.transaction.util.enums.ReconStatus;
import com.epay.transaction.util.enums.SettlementStatus;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.UUID;

/**
 * Class Name:ReconFileData
 * *
 * Description:
 * *
 * Author:@V0000001(Shilpa Kothre)
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ReconDataDetailsDto {

    private UUID rfdId;
    private UUID rfId;
    private int rowNumber;
    private String mId;
    @JsonProperty("atrnNum")
    private String atrnNumber;
    @JsonProperty("transactionAmount")
    private BigDecimal debitAmount;
    @JsonProperty("bankRefNumber")
    private String bankReferenceNumber;
    private ReconStatus reconStatus;
    private SettlementStatus settlementStatus;
    private PayoutStatus payoutStatus;
    private String remark;
    private Long createdDate;
    private Long updatedDate;

}
