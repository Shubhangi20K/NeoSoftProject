package com.epay.transaction.externalservice.request.admin;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


/**
 * Class Name: CurrencyRequest
 * *
 * Description: CurrencyRequest entity class
 * *
 * Author: (Shital suryawanshi)
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class CurrencyRequest {

    @JsonProperty("mId")
    private String mId;
    private String currencyCode;

}
