package com.epay.transaction.util.enums;

import com.epay.transaction.exceptions.TransactionException;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.text.MessageFormat;
import java.util.Arrays;

import static com.epay.transaction.util.TransactionErrorConstants.INVALID_ERROR_CODE_NO_REASON;
import static com.epay.transaction.util.TransactionErrorConstants.INVALID_ERROR_MESSAGE_NO_REASON;

/**
 * Copyright (c) [2025] [State Bank of India]
 * All rights reserved.
 * <p>
 * Author: Bhoopendra Rajput
 * <p>
 * Version:1.0
 */
@Getter
@AllArgsConstructor
public enum FailureReason {
    BUSINESS("Business"),
    TECHNICAL("Technical"),
    CUSTOMER("Customer");

    private final String label;

    public static FailureReason getFailureReason(String label) {
        return Arrays.stream(values()).filter(p -> p.getLabel().equalsIgnoreCase(label)).findFirst().orElseThrow(() -> new TransactionException(INVALID_ERROR_CODE_NO_REASON, MessageFormat.format(INVALID_ERROR_MESSAGE_NO_REASON, "Failure Reason", label)));
    }
}
