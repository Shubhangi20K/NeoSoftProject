package com.epay.transaction.repository;

import com.epay.transaction.entity.MerchantOrderDuplicatePayments;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.UUID;

/**
 * Class Name:MerchantOrderDuplicatePaymentsRepository
 * Description: MerchantOrderDuplicatePaymentsRepository class for manage duplicate payment related data persistence and retrieval in a database.
 * Author:V0000001(shilpa kothre)
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * Version:1.0
 */
@Repository
public interface MerchantOrderDuplicatePaymentsRepository extends JpaRepository<MerchantOrderDuplicatePayments, UUID> {
}
