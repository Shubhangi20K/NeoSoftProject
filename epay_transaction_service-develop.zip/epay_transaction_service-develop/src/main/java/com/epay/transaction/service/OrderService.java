package com.epay.transaction.service;


import com.epay.transaction.config.TransactionConfig;
import com.epay.transaction.dao.OrderDao;
import com.epay.transaction.dao.MerchantOrderPaymentDao;
import com.epay.transaction.dto.OrderDto;
import com.epay.transaction.dto.OrderStatusDto;
import com.epay.transaction.externalservice.AdminServicesClient;
import com.epay.transaction.externalservice.response.admin.MerchantInfoResponse;
import com.epay.transaction.model.request.EncryptedRequest;
import com.epay.transaction.model.request.MerchantOrderPaymentSearchRequest;
import com.epay.transaction.model.request.OrderUpdateRequest;
import com.epay.transaction.model.response.OrderResponse;
import com.epay.transaction.model.response.TransactionResponse;
import com.epay.transaction.model.response.OrderStatusResponse;
import com.epay.transaction.util.*;
import com.epay.transaction.util.enums.OrderStatus;
import com.epay.transaction.util.enums.Report;
import com.epay.transaction.util.enums.ReportFormat;
import com.epay.transaction.util.file.model.FileModel;
import com.epay.transaction.validator.OrderValidator;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Map;

import static com.epay.transaction.util.DateTimeUtils.convertToReportDate;
import static com.epay.transaction.util.TransactionConstant.ORDER_STATUS_UPDATED;
import static com.epay.transaction.util.TransactionConstant.RESPONSE_SUCCESS;
import static com.epay.transaction.util.TransactionConstant.CREATED_DATE;
import static com.epay.transaction.util.TransactionUtil.buildRequestByEncryptRequest;


/**
 * Class Name: OrderService
 * *
 * Description: OrderService class for carrying out order request business logic and encapsulating the application's order functionality.
 * *
 * Author: V1012904(Shital suryawanshi)
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */

@Service
@RequiredArgsConstructor
public class OrderService {
    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private static final List<String> ORDER_PAYMENT_REPORT_HEADER = List.of("Order Ref Number", "SBI Order Ref Number", "Atrn Number", "Bank Ref Number", "Transaction Date", "Order Amount", "Transaction Amount", "Payment Status", "Transaction Status", "Refund Status");
    private final OrderDao orderDao;
    private final OrderValidator orderValidator;
    private final TransactionConfig transactionConfig;
    private final AdminServicesClient adminServicesClient;
    private final MerchantOrderPaymentDao merchantOrderPaymentDao;
    private final FileGeneratorService fileGeneratorService;

    /**
     * Method name : createMerchantOrder
     * Description : Creates Merchant Order
     *
     * @param encryptedRequest encrypted String
     * @return object of TransactionResponse
     */
    public TransactionResponse<String> createMerchantOrder(EncryptedRequest encryptedRequest) {
        logger.debug("Going to process create Order Request : {}", encryptedRequest);
        //Step 1 : Get Merchant MEK
        logger.info("Create Merchant Order MEK request start");
        String mek = orderDao.getMerchantMek();
        logger.info("Create Merchant Order MEK request end");
        //Step 2 : Encrypt order request to OrderDto
        OrderDto orderDto = buildRequestByEncryptRequest(encryptedRequest.getEncryptedRequest(), mek, OrderDto.class);
        logger.debug("build OrderDto{} ", orderDto);
        //Step 3: Get MerchantInfo from Admin service
        TransactionResponse<MerchantInfoResponse> merchantInfoResponse =adminServicesClient.getMerchantInfoByMId(EPayIdentityUtil.getUserPrincipal().getMId());
        orderDto.setMId(EPayIdentityUtil.getUserPrincipal().getMId());
        //Step 4: validate Merchant order for Paid Status
        orderValidator.isOrderAlreadyPaid(orderDto);
        //Step 5: Validate order request
        orderValidator.validateOrderRequest(orderDto, merchantInfoResponse.getData().getFirst().getNumberOfAttemptsApplicable(),merchantInfoResponse.getData().getFirst().getNumberOfAttempts());
        setOrderExpiry(orderDto);
        //Step 9: Set order retry count
        orderDto.setOrderRetryCount(transactionConfig.getOrderRetryCount());
        //Step 7 : Set Order Response And save into order table
        orderDto = orderDao.createMerchantOrder(orderDto);
        //Step 8 : Create order response
        logger.info("Merchant Order creation completed");
        return TransactionResponse.<String>builder().data(List.of(EncryptionDecryptionUtil.encryptValue(mek, TransactionUtil.toJson(orderDto)))).status(TransactionConstant.RESPONSE_SUCCESS).build();
    }

    /**
     * Method name : getMerchantOrderBySbiOrderRefNumber
     * Description : Gives the merchant order based on sbiOrderRefNumber
     * @param sbiOrderRefNumber is a String
     * @return object of TransactionResponse
     */
    public TransactionResponse<String> getMerchantOrderBySbiOrderRefNumber(String sbiOrderRefNumber) {
        //Step 1 : Get Merchant MEK
        logger.info("Fetch customer MEK request start");
        String mek = orderDao.getMerchantMek();
        logger.info("Fetch customer MEK request end");
        //Step 2 : Find OrderDto by sbiOrderRefNumber
        OrderDto orderDto = orderDao.getOrderBySbiOrderRefNumber(EPayIdentityUtil.getUserPrincipal().getMId(), sbiOrderRefNumber);
        logger.debug("Fetched merchant order By sbiOrderRefNumber merchantOrder: {}", orderDto);
        //Step 3 : Build OrderResponse
        logger.info("Fetched merchant order using orderRefNumber ended");
        return TransactionResponse.<String>builder().data(List.of(EncryptionDecryptionUtil.encryptValue(mek, TransactionUtil.toJson(orderDto)))).status(TransactionConstant.RESPONSE_SUCCESS).build();
    }

    /**
     * Method name : updateOrderStatus
     * Description : updates the merchant order based on orderUpdateRequest
     * @param orderUpdateRequest an object of OrderUpdateRequest
     * @return object of TransactionResponse
     */
    public TransactionResponse<String> updateOrderStatus(OrderUpdateRequest orderUpdateRequest) {
        orderValidator.validateUpdateOrderRequest(orderUpdateRequest);
        OrderDto orderDto = orderDao.getMerchantOrderByOrderRefAndSbiOrderRefNumber(EPayIdentityUtil.getUserPrincipal().getMId(), orderUpdateRequest.getOrderRefNumber(), orderUpdateRequest.getSbiOrderRefNumber());
        orderValidator.validateStatus(orderDto.getStatus(), orderUpdateRequest.getStatus());
        orderDto.setStatus(OrderStatus.getOrderStatus(orderUpdateRequest.getStatus()));
        orderDao.updateOrderStatus(orderDto);
        logger.info("Order status updated");
        return TransactionResponse.<String>builder().data(List.of(ORDER_STATUS_UPDATED)).status(TransactionConstant.RESPONSE_SUCCESS).build();
    }

    /**
     * Method name : setOrderExpiry
     * Description : sets Merchant Order Expiry
     * @param orderDto an object of OrderDto
     */
    private void setOrderExpiry(OrderDto orderDto) {
        logger.info("Set merchant order expiry start");
        if (!ObjectUtils.isEmpty(orderDto.getExpiry())) {
            orderDto.setExpiry(System.currentTimeMillis() + orderDto.getExpiry() * 60000);
        } else {
            logger.info("Set merchant order expiry start from Admin Service");
            MerchantInfoResponse merchantDto = orderDao.getMerchantByMId(orderDto.getMId());
            orderDto.setExpiry(DateTimeUtils.addMinutes(merchantDto.getOrderExpiryTime().intValue()));
            logger.info("Set merchant order expiry end from Admin Service");
        }
    }

    /**
     * Method name:getMerchantOrderPayments
     * Description: This method is responsible for fetching and returning the merchant's order payment information based on the provided
     * Merchant ID (`mId`) and search criteria (`merchantOrderPaymentSearchRequest`). It validates the Merchant ID, retrieves
     * the transactions, and builds a response with the transaction data along with pagination information.
     *
     * @param mId                         The Merchant ID for which the transaction data is to be fetched.
     * @param merchantOrderPaymentSearchRequest The request containing search criteria for filtering the transactions.
     * @param pageable                    The pagination information, such as page number and size.
     * @return TransactionResponse<OrderResponse>  A response containing the transaction data, total count, and other relevant information.
     */
    public TransactionResponse<OrderResponse> getMerchantOrderPayments(String mId, MerchantOrderPaymentSearchRequest merchantOrderPaymentSearchRequest, Pageable pageable, boolean isDownload) {
        // Step 1 : Validate Mid and merchantOrderPaymentSearchRequest
        logger.debug("Started Transaction validation for mid: {}, merchantOrderPaymentSearchRequest : {}", mId, merchantOrderPaymentSearchRequest);
        orderValidator.validateMerchantOrderPaymentsRequest(merchantOrderPaymentSearchRequest,mId,pageable, isDownload);

        // Step 2 : Get All Transaction Info based on mid and request
        Page<OrderResponse> transactionResponse = merchantOrderPaymentDao.findBySpecification(mId, merchantOrderPaymentSearchRequest, pageable);
        logger.info("Returning list of transactions {}", transactionResponse.getContent());
        // Step 4 : Building the response
        return TransactionResponse.<OrderResponse>builder().status(RESPONSE_SUCCESS).data(transactionResponse.getContent()).count(transactionResponse.stream().count()).total(transactionResponse.getTotalElements()).build();
    }


    /**
     * Method name:downloadMerchantOrderPaymentReport
     * Description:This method is responsible for generating and downloading a report of merchant order payments based on the provided
     * Merchant ID (`mId`) and search criteria (`merchantOrderPaymentSearchRequest`). It validates the search request,
     * fetches the transactions, formats the data into a report, and returns the generated report as a downloadable CSV.
     *
     * @param response                        The HTTP response object used to stream the report data.
     * @param mId                             The Merchant ID for which the report is being generated.
     * @param merchantOrderPaymentSearchRequest The request containing the search criteria for filtering transactions.
     */
    public void downloadMerchantOrderPaymentReport(HttpServletResponse response, String mId, MerchantOrderPaymentSearchRequest merchantOrderPaymentSearchRequest) {
        // Step 1 : Validate Mid
        logger.debug("Started Transaction validation for mid: {}, merchantOrderPaymentSearchRequest : {}", mId, merchantOrderPaymentSearchRequest);
        Pageable pageable = PageRequest.of(0, transactionConfig.getReportPageSize(), Sort.by(CREATED_DATE).descending());
        // Step 2 : Get All Transaction Info based on mid and request
        TransactionResponse<OrderResponse> transactionResponse = getMerchantOrderPayments(mId, merchantOrderPaymentSearchRequest, pageable, true);
        // Step 3 : Build file data for CSV
        List<List<Object>> fileData = transactionResponse.getData().stream().map(this::convertToListOfObject).toList();
        logger.info("Building report for merchant ID: {} with transaction data", mId);
        // Step 4 : Build the report
        buildReport(mId, fileData, response);
    }


    /**
     * Method name:convertToListOfObject
     * Description:Converts a OrderResponse object into a list of objects, where each object corresponds to a specific field
     * of the response, to be used for report generation or other purposes.
     *
     * @param orderResponse The OrderResponse object containing order and transaction details.
     * @return A list of objects representing the order's data, suitable for report generation.
     */
    protected List<Object> convertToListOfObject(OrderResponse orderResponse) {
        logger.debug("Converting OrderResponse to list of objects: {}", orderResponse);
        return List.of(StringUtils.isEmpty(orderResponse.getOrderRefNumber()) ? "-" : orderResponse.getOrderRefNumber(), StringUtils.isEmpty(orderResponse.getSbiOrderRefNumber()) ? "-" : orderResponse.getSbiOrderRefNumber(), StringUtils.isEmpty(orderResponse.getAtrnNumber()) ? "-" : orderResponse.getAtrnNumber(), StringUtils.isEmpty(orderResponse.getBankReferenceNumber()) ? "-" : orderResponse.getBankReferenceNumber(), ObjectUtils.isEmpty(orderResponse.getTransactionDate()) ? "-" : convertToReportDate(orderResponse.getTransactionDate()), ObjectUtils.isEmpty(orderResponse.getOrderAmount()) ? 0.00 : orderResponse.getOrderAmount(), ObjectUtils.isEmpty(orderResponse.getTransactionAmount()) ? 0.00 : orderResponse.getTransactionAmount(), ObjectUtils.isEmpty(orderResponse.getPaymentStatus()) ? "-" : orderResponse.getPaymentStatus().name(), ObjectUtils.isEmpty(orderResponse.getTransactionStatus()) ? "-" : orderResponse.getTransactionStatus().name(), ObjectUtils.isEmpty(orderResponse.getRefundStatus()) ? "-" : orderResponse.getRefundStatus().name());
    }


    /**
     * Method name:buildReport
     * Description:Builds and generates a report file in CSV format based on the provided data, then sends the file as a response
     * to the client for download.
     *
     * @param mId The merchant ID associated with the report.
     * @param fileData The data to be included in the report (list of rows).
     * @param response The HttpServletResponse object used to send the generated file to the client.
     */
    private void buildReport(String mId, List<List<Object>> fileData, HttpServletResponse response) {
        FileModel fileModel = fileGeneratorService.buildFileModel(ReportFormat.CSV, ORDER_PAYMENT_REPORT_HEADER, fileData, Map.of("headers", OrderService.ORDER_PAYMENT_REPORT_HEADER, "rows", fileData));
        logger.info("File model created, generating file for GST Invoice.");
        fileGeneratorService.downloadFile(response, ReportFormat.CSV, Report.TRANSACTION, mId, fileModel);
    }

    /**
     * This method is used get the order status containing order and payment info.
     *
     * @param encryptedRequest encrypted request
     * @return  order and payment info response with encrypted string.
     */
    public TransactionResponse<String> getOrderStatus(String encryptedRequest) {
        //Step-1: Calling KMS service for mek.
        String mek = orderDao.getMerchantMek();
        //Step-2: Decrypting transaction verification request.
        OrderStatusDto orderStatusDto = buildRequestByEncryptRequest(encryptedRequest, mek, OrderStatusDto.class);
        logger.debug("Decrypted payment verification request : {}", orderStatusDto);
        //Step-3: Validating Order reference Number and Order Amount.
        logger.info("ValidatingOrder reference Number and Order Amount.");
        orderValidator.validateOrderStatusDto(orderStatusDto);
        //Step-4: Getting OrderStatusResponse from search request
        List<OrderStatusResponse> orderStatusResponseList = orderDao.findByOrderStatusDto(EPayIdentityUtil.getUserPrincipal().getMId(), orderStatusDto);
        logger.info("Got orderStatusResponseList size : {}", orderStatusResponseList.size());
       //step-5: Return encrypted response
        return TransactionResponse.<String>builder().status(RESPONSE_SUCCESS).data(List.of(EncryptionDecryptionUtil.encryptValue(mek, TransactionUtil.toJson(orderStatusResponseList)))).build();
    }

}


