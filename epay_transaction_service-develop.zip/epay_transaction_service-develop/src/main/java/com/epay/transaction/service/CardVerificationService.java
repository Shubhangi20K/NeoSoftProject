package com.epay.transaction.service;

import com.epay.transaction.dao.CardVerificationDao;
import com.epay.transaction.externalservice.request.admin.BinCheckRequest;
import com.epay.transaction.externalservice.response.admin.BinCheckResponse;
import com.epay.transaction.model.request.EncryptedRequest;
import com.epay.transaction.model.response.EncryptedResponse;
import com.epay.transaction.model.response.TransactionResponse;
import com.epay.transaction.util.TransactionConstant;
import com.epay.transaction.util.TransactionUtil;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.Collections;
import static com.epay.transaction.util.EncryptionDecryptionUtil.encryptValue;
import static com.epay.transaction.util.TransactionUtil.buildRequestByEncryptRequest;

/**
 * Class Name: CardVerificationService
 * *
 * Description:
 * *
 * Author: V1018217
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Service
@RequiredArgsConstructor
public class CardVerificationService {
    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private final CardVerificationDao cardVerificationDao;

    /**
     * This method is being used to check bin-check status calling api endpoint from admin-service.
     *
     * @param request encrypted String of binCheck
     * @return Encrypted Response
     */

    public TransactionResponse<EncryptedResponse> validateBin(EncryptedRequest request) {
        logger.info("Started to fetch binCheck.");
        String aesKey = cardVerificationDao.getEncryptionAesKey();
        BinCheckRequest binCheckRequest = buildRequestByEncryptRequest(request.getEncryptedRequest(), aesKey, BinCheckRequest.class);
        BinCheckResponse binCheckResponse = cardVerificationDao.validateBin(binCheckRequest);
        EncryptedResponse response = EncryptedResponse.builder().encryptedResponse(encryptValue(aesKey, TransactionUtil.toJson(binCheckResponse))).build();
        logger.info("Completed fetch binCheck.");
        return TransactionResponse.<EncryptedResponse>builder().data(Collections.singletonList(response)).status(TransactionConstant.RESPONSE_SUCCESS).build();
    }




}
