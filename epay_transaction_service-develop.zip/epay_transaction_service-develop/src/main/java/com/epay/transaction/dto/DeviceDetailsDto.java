package com.epay.transaction.dto;

import lombok.*;

/**
 * Class Name:DeviceDetailsDto
 * *
 * Description:
 * *
 * Author:Shubhangi Kurelay
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DeviceDetailsDto {
    private String orderHash;
    private String clientIp;
    private Long createdDate;
    private byte[] deviceDetails;
}
