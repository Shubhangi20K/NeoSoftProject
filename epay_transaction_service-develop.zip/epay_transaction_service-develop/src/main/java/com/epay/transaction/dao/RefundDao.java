package com.epay.transaction.dao;

import com.epay.transaction.dto.BulkRefundBookingDto;
import com.epay.transaction.dto.MerchantPaymentOrderDto;
import com.epay.transaction.dto.RefundBookingDto;
import com.epay.transaction.entity.BulkRefundBooking;
import com.epay.transaction.entity.BulkRefundBookingDetails;
import com.epay.transaction.entity.RefundBooking;
import com.epay.transaction.exceptions.TransactionException;
import com.epay.transaction.exceptions.ValidationException;
import com.epay.transaction.mapper.RefundMapper;
import com.epay.transaction.model.request.RefundSearchRequest;
import com.epay.transaction.model.response.RefundResponse;
import com.epay.transaction.repository.BulkRefundDetailsRepository;
import com.epay.transaction.repository.BulkRefundRepository;
import com.epay.transaction.repository.RefundRepository;
import com.epay.transaction.specification.RefundBookingSpecification;
import com.epay.transaction.util.EPayIdentityUtil;
import com.epay.transaction.util.TransactionUtil;
import com.epay.transaction.util.enums.*;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.text.MessageFormat;
import java.util.List;
import java.util.UUID;

import static com.epay.transaction.util.TransactionErrorConstants.*;


/**
 * Class Name:RefundDao
 * *
 * Description:
 * *
 * Author:NIRMAL GURJAR
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
@Component
@RequiredArgsConstructor
public class RefundDao {

    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private final RefundRepository refundRepository;
    private final RefundMapper refundMapper;
    private final MerchantOrderPaymentDao merchantOrderPaymentDao;
    private final BulkRefundRepository bulkRefundRepository;
    private final BulkRefundDetailsRepository bulkRefundDetailsRepository;
    private final KmsDao kmsDao;
    private final ErrorLogDao errorLogDao;

    /**
     * Saves a new refund booking record and updates the corresponding merchant payment order.
     *
     * @param refundBookingDto        DTO containing refund booking details
     * @param merchantPaymentOrderDto DTO containing merchant payment order details
     * @return {@link RefundResponse} containing the saved refund and updated merchant order details
     */
    @Transactional
    public RefundResponse saveRefundBooking(RefundBookingDto refundBookingDto, MerchantPaymentOrderDto merchantPaymentOrderDto) {

        logger.info("Saving refund booking - ARRN: {}", refundBookingDto.getArrnNumber());
        RefundBooking refundBooking = refundRepository.save(refundMapper.dtoToEntity(refundBookingDto));
        refundBookingDto = refundMapper.entityToDto(refundBooking);

        logger.info("Updating merchant payment order after refund - ARRN: {}", refundBookingDto.getArrnNumber());
        merchantPaymentOrderDto = updateMerchantPayment(refundBookingDto, merchantPaymentOrderDto);

        return refundMapper.mapToRefundResponse(refundBookingDto, merchantPaymentOrderDto);
    }



    /**
     * Updates the merchant payment order based on the refund booking details.
     *
     * @param refundBookingDto        DTO containing refund booking details
     * @param merchantPaymentOrderDto DTO containing merchant payment order details
     * @return {@link MerchantPaymentOrderDto} updated merchant payment order details
     */
    public MerchantPaymentOrderDto updateMerchantPayment(RefundBookingDto refundBookingDto, MerchantPaymentOrderDto merchantPaymentOrderDto) {
        logger.info("Updating merchant payment - ARRN: {}", refundBookingDto.getArrnNumber());
        merchantPaymentOrderDto.setAvailableRefundAmount(merchantPaymentOrderDto.getAvailableRefundAmount().subtract(refundBookingDto.getRefundAmount()));
        merchantPaymentOrderDto.setRefundStatus(merchantPaymentOrderDto.getAvailableRefundAmount().compareTo(BigDecimal.ZERO) > 0 ? TransactionRefundStatus.PARTIAL_REFUND_BOOKED : TransactionRefundStatus.FULL_REFUND_BOOKED);
        return merchantOrderPaymentDao.save(merchantPaymentOrderDto);
    }

    /**
     * Retrieves a merchant payment order by ATRN number.
     *
     * @param atrnNumber The ATRN number of the merchant payment order
     * @return {@link MerchantPaymentOrderDto} containing payment order details
     */

    public MerchantPaymentOrderDto findByAtrnNumber(String mId, String atrnNumber) {
        logger.info("Fetching merchant payment order - ATRN: {}", atrnNumber);
        return merchantOrderPaymentDao.findByAtrnNumber(mId, atrnNumber);
    }


    /**
     * Searches for refund bookings based on the provided search criteria.
     *
     * @param refundSearchRequest The search request containing filter parameters
     * @param pageable            Pagination details
     * @return {@link Page} of {@link RefundBookingDto} containing search results
     */
    public Page<RefundBookingDto> searchRefundBookingRequest(RefundSearchRequest refundSearchRequest, Pageable pageable) {
        logger.info("Searching refund bookings - Merchant ID: {}", refundSearchRequest.getMId());
        Specification<RefundBooking> specification = RefundBookingSpecification.searchRefund(refundSearchRequest);
        Page<RefundBooking> refundBookingPage = refundRepository.findAll(specification, pageable);
        return refundMapper.entityToDto(refundBookingPage);
    }

    /**
     * Get bulk refund details for requested parameters
     *
     * @return Page<BulkRefundBookingDto>
     */
    public Page<BulkRefundBookingDto> getBulkRefundBooking(String mId, Pageable pageable) {
        logger.info("inside searchBulkRefundBooking for mId: {}", mId);
        Page<BulkRefundBooking> bulkRefundBookingPage = bulkRefundRepository.findByMerchantId(mId, pageable);
        return bulkRefundBookingPage.map(refundMapper::mapEntityToDto);
    }


    public BulkRefundBooking saveBulkRefundBooking(BulkRefundBooking bulkRefundBooking) {
        return bulkRefundRepository.save(bulkRefundBooking);
    }

    public void saveBulkRefundBookingDetails(BulkRefundBookingDetails bulkRefundBookingDetails) {
        bulkRefundDetailsRepository.save(bulkRefundBookingDetails);
    }

    /**
     * Get bulk refund details for requested parameters
     *
     * @return List<BulkRefundBookingDetails>
     */
    public List<BulkRefundBookingDetails> getBulkRefundByBulkIdAndRefundStatus(String bulkId, String refundStatus) {
        List<BulkRefundBookingDetails> bulkRefundBookingDetailsList = BulkRefundRowStatus.ALL.name().equals(refundStatus) ? bulkRefundDetailsRepository.findByBulkId(bulkId) : bulkRefundDetailsRepository.findByBulkIdAndRefundStatus(bulkId, refundStatus);

        if (bulkRefundBookingDetailsList == null || bulkRefundBookingDetailsList.isEmpty()) {
            {
                errorLogDao.logCustomerError(EPayIdentityUtil.getUserPrincipal().getMId(), EntityType.REFUND, null, null, null, null, NOT_FOUND_ERROR_CODE, MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, "Data"));
                throw new TransactionException(NOT_FOUND_ERROR_CODE, MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, "Data"));
            }
        }
        return bulkRefundBookingDetailsList;
    }

    /**
     * Get bulk refund details for requested parameters
     *
     * @return BulkRefundBookingDetails
     */
    public BulkRefundBookingDetails saveBulkRefundBookingDetailsForRow(BulkRefundBookingDetails bulkRefundBookingDetails) {
        return bulkRefundDetailsRepository.save(bulkRefundBookingDetails);
    }

    public BulkRefundBookingDetails findBulkRefundBookingDetailsById(UUID detailsId) {
        return bulkRefundDetailsRepository.findById(detailsId).orElseThrow(() -> new ValidationException(NOT_FOUND_ERROR_CODE, MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, REFUND_BOOKING_DETAIL)));
    }

    public List<BulkRefundBookingDetails> findAllByBulkId(String bulkId) {
        return bulkRefundDetailsRepository.findByBulkId(bulkId);
    }

    public BulkRefundBooking findByBulkId(String bulkId) {
        return bulkRefundRepository.findByBulkId(bulkId);
    }


    public Object[] getProcessedAndFailedCounts(String bulkId) {
        return bulkRefundDetailsRepository.getProcessedAndFailedCounts(bulkId);
    }

    /**
     * Method name : getMerchantMek
     * Description : Fetches MEK from Key management Service
     *
     * @return a String
     */
    public String getMerchantMek() {
        return kmsDao.getMerchantMekKey();
    }

    /**
     * Searches for refund bookings based on the provided search criteria.
     *
     * @param refundSearchRequest The search request containing filter parameters
     */
    public List<RefundBookingDto> downloadRefundBookingRequest(RefundSearchRequest refundSearchRequest) {
        logger.info("Searching refund bookings - Merchant ID: {}", refundSearchRequest.getMId());
        Specification<RefundBooking> specification = RefundBookingSpecification.searchRefund(refundSearchRequest);
        List<RefundBooking> refundBookings = refundRepository.findAll(specification);
        return refundMapper.entityToDto(refundBookings);
    }


    /**
     * Updates the merchant payment order based on the refund booking details.
     *
     * @param merchantPaymentOrderDto DTO containing merchant payment order details
     * @return {@link MerchantPaymentOrderDto} updated merchant payment order details
     */
    public MerchantPaymentOrderDto updateMerchantPayment(MerchantPaymentOrderDto merchantPaymentOrderDto) {
        logger.info("Updating merchant payment - ATRN: {} {}", merchantPaymentOrderDto.getAtrnNumber());
        return merchantOrderPaymentDao.save(merchantPaymentOrderDto);
    }

    /**
     * Saves a new refund booking record and updates the corresponding merchant payment order.
     *
     * @param refundBookingDto DTO containing refund booking details
     */
    @Transactional
    public void saveRefundBooking(RefundBookingDto refundBookingDto) {
        logger.info("Saving refund booking - ATRN: {}", refundBookingDto.getAtrnNumber());
        RefundBooking refundBooking = refundRepository.save(refundMapper.dtoToEntity(refundBookingDto));
        logger.info("Updating merchant payment order after refund - ARRN: {}", refundBooking.getArrnNum());

    }


    public void saveDvpRefundBooking(MerchantPaymentOrderDto merchantPaymentOrderDto) {
        refundRepository.save(buildDvpRefundBooking(merchantPaymentOrderDto));
    }


    private RefundBooking buildDvpRefundBooking(MerchantPaymentOrderDto m) {
        return RefundBooking.builder().mId(m.getMId()).sbiOrderRefNumber(m.getSbiOrderRefNumber()).atrnNum(m.getAtrnNumber()).arrnNum(TransactionUtil.createArrnNumber(m.getMId(), m.getAtrnNumber().substring(0, 2))).refundAmount(m.getDebitAmount()).refundType(RefundType.FULL.name()).refundStatus(RefundStatus.CANCELLATION_BOOKED.name()).remark("DVP Refund Booking").refundAdjusted("Y").refundRetry(3).build();
    }

    public void saveDuplicateRefundBooking(MerchantPaymentOrderDto merchantPaymentOrderDto) {
        refundRepository.save(buildDuplicateRefundBooking(merchantPaymentOrderDto));
    }


    private RefundBooking buildDuplicateRefundBooking(MerchantPaymentOrderDto m) {
        return RefundBooking.builder().mId(m.getMId()).sbiOrderRefNumber(m.getSbiOrderRefNumber()).atrnNum(m.getAtrnNumber()).arrnNum(TransactionUtil.createArrnNumber(m.getMId(), m.getAtrnNumber().substring(0, 2))).refundAmount(m.getDebitAmount()).refundType(RefundType.FULL.name()).refundStatus(RefundStatus.CANCELLATION_BOOKED.name()).remark("Duplicate Atrn Refund Booking").refundAdjusted("Y").refundRetry(3).build();
    }

    /**
     * updating refund adjust status by ATRN number.
     *
     * @param arrns The ARRN number of refund booking
     * @return void
     */

    public void updateRefundAdjustStatus(UUID payoutId, List<String> arrns) {
        logger.info("updating refund adjusted for - ARRN: {}", arrns.toArray());
        refundRepository.updateRefundAdjustStatus(payoutId, arrns);
    }
}