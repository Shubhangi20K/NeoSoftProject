package com.epay.transaction.model.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import static com.epay.transaction.util.TransactionErrorConstants.ENCRYPTED_REQUEST_IS_REQUIRED;

@Setter
@Getter
@Data
public class TransactionVerificationRequest {
    @NotBlank(message = ENCRYPTED_REQUEST_IS_REQUIRED)
    private String encryptRequest;
}
