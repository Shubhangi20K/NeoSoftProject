package com.epay.transaction.validator;

import com.epay.transaction.config.TransactionConfig;
import com.epay.transaction.dao.AdminDao;
import com.epay.transaction.dao.ErrorLogDao;
import com.epay.transaction.dao.RefundDao;
import com.epay.transaction.dto.MerchantPaymentOrderDto;
import com.epay.transaction.entity.BulkRefundBooking;
import com.epay.transaction.entity.BulkRefundBookingDetails;
import com.epay.transaction.exceptions.TransactionException;
import com.epay.transaction.exceptions.ValidationException;
import com.epay.transaction.externalservice.response.admin.MerchantInfoResponse;
import com.epay.transaction.model.request.RefundBookRequest;
import com.epay.transaction.model.request.RefundSearchRequest;
import com.epay.transaction.util.DateTimeUtils;
import com.epay.transaction.util.EPayIdentityUtil;
import com.epay.transaction.util.TransactionConstant;
import com.epay.transaction.util.enums.*;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import java.math.BigDecimal;
import java.text.MessageFormat;
import java.util.*;

import static com.epay.transaction.util.TransactionConstant.*;
import static com.epay.transaction.util.TransactionConstant.ATRN;
import static com.epay.transaction.util.TransactionConstant.REFUND_STATUS;
import static com.epay.transaction.util.TransactionErrorConstants.*;

/**
 * Class Name: RefundValidator
 * *
 * Description: Validator class for refund booking and searching
 * *
 * Author: NIRMAL GURJAR
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Component
@RequiredArgsConstructor
public class RefundValidator extends BaseValidator {

    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private final TransactionConfig transactionConfig;
    private final AdminDao adminDao;
    private final RefundDao refundDao;
    private final ErrorLogDao errorLogDao;

    /**
     * Validate business rules for refund booking
     *
     * @param refundBookRequest       RefundBookRequest
     * @param merchantPaymentOrderDto refundBookRequest
     */
    public void validateBusinessRules(RefundBookRequest refundBookRequest, MerchantPaymentOrderDto merchantPaymentOrderDto) {
        logger.info("Inside validateBusinessRules for atrn: {}", refundBookRequest.getAtrnNumber());

        //Step-1: Check merchant is enabled for refund booking
        MerchantInfoResponse merchantInfoResponse = adminDao.getMerchantByMId(merchantPaymentOrderDto.getMId());
        if(!StringUtils.equalsIgnoreCase(TransactionConstant.FLAG_Y, merchantInfoResponse.getIsRefundApplicable())){
            logger.debug("Invalid refund applicable flag : {}", merchantInfoResponse.getIsRefundApplicable());
            throw new TransactionException(INVALID_ERROR_CODE, MessageFormat.format(INVALID_ERROR_MESSAGE, REFUND_BOOK_REQUEST, MERCHANT_REFUND_FLAG_NOT_ENABLED));
        }

        //Step-2: Check if refund booking window is expired
        if(merchantInfoResponse.getRefundWindowDays() > 0 && merchantInfoResponse.getRefundWindowDays() < DateTimeUtils.calculateDaysBetween(DateTimeUtils.getCurrentTimeInMills(), merchantPaymentOrderDto.getCreatedDate())){
            logger.debug("Refund window expired for allowed days : {}", merchantInfoResponse.getRefundWindowDays());
            throw new TransactionException(INVALID_ERROR_CODE, MessageFormat.format(INVALID_ERROR_MESSAGE, REFUND_BOOK_REQUEST, MERCHANT_REFUND_WINDOW_EXPIRED));
        }

        //Step-3: Check transaction status should be only SUCCESS/SETTLED
        if (!TransactionStatus.SUCCESS.equals(merchantPaymentOrderDto.getTransactionStatus()) && !TransactionStatus.SETTLED.equals(merchantPaymentOrderDto.getTransactionStatus())) {
            logger.debug("Invalid transaction status: {}", merchantPaymentOrderDto.getTransactionStatus());
            throw new TransactionException(INVALID_ERROR_CODE, MessageFormat.format(INVALID_ERROR_MESSAGE, MERCHANT_ORDER_PAYMENT_STATUS, MERCHANT_ORDR_PAYMENT_ST_NOT_VALID_AGAINST_ATRN));
        }

        //Step-4: check if it is first refund request, then update available refund amount
        if (ObjectUtils.isEmpty(merchantPaymentOrderDto.getRefundStatus())) {
            logger.debug("First refund request for atrn: {}", refundBookRequest.getAtrnNumber());
            merchantPaymentOrderDto.setAvailableRefundAmount(merchantPaymentOrderDto.getOrderAmount());
        }

        //Step-5: Check amount should not be more than available refund amount
        if (ObjectUtils.isEmpty(merchantPaymentOrderDto.getAvailableRefundAmount()) || merchantPaymentOrderDto.getAvailableRefundAmount().compareTo(refundBookRequest.getRefundAmount()) < 0) {
            logger.debug("Available refund amount is less than requested amount");
            throw new TransactionException(INVALID_ERROR_CODE, MessageFormat.format(INVALID_ERROR_MESSAGE, REFUND_AMOUNT, REFUND_AMNT_MORE_THAN_AVAILABLE_AMNT_ERR_MSG));
        }

        //Step-6: Validate and get refund type throws exception if invalid refund type is passed
        RefundType refundType = RefundType.getRefundType(refundBookRequest.getRefundType());

        //Step-7: If refund type is full then match the amount with full available refund amount
        if (RefundType.FULL.equals(refundType) && merchantPaymentOrderDto.getAvailableRefundAmount().compareTo(refundBookRequest.getRefundAmount()) != 0) {
            logger.debug("Available refund amount does not match with requested amount for full refund request type");
            throw new TransactionException(INVALID_ERROR_CODE, MessageFormat.format(INVALID_ERROR_MESSAGE, REFUND_AMOUNT, FULL_REFUND_AMOUNT_MIS_MATCH));
        }

        //Step-8: If refund type is partial then match the amount with full available refund amount
        if (RefundType.PARTIAL.equals(refundType) && merchantPaymentOrderDto.getAvailableRefundAmount().compareTo(refundBookRequest.getRefundAmount()) == 0) {
            logger.debug("Request amount should be less than available refund amount for partial refund request type");
            throw new TransactionException(INVALID_ERROR_CODE, MessageFormat.format(INVALID_ERROR_MESSAGE, REFUND_AMOUNT, "Refund amount should be less than available refund amount for partial refund request type."));
        }
    }

    /**
     * Validate refund book request for basic validations
     *
     * @param refundBookRequest RefundBookRequest
     */
    public void validateRefundRequest(RefundBookRequest refundBookRequest) {
        errorDtoList = new ArrayList<>();
        logger.info("validation started for refundBookRequest : {}", refundBookRequest);
        validateMandatoryFields(refundBookRequest);
        logger.info("mandatory fields validation completed for refundBookRequest");
        validateLeadingTrailingSpaces(refundBookRequest);
        logger.info("leading and trailing space fields validation completed for refundBookRequest");
        validateFieldsLength(refundBookRequest);
        logger.info("fields length validation completed for refundBookRequest");
        validateFieldsValue(refundBookRequest);
        logger.info("fields value validation completed for refundBookRequest");
    }

    /**
     * Validate fields length for refund book request
     *
     * @param refundBookRequest RefundBookRequest
     */
    private void validateFieldsLength(RefundBookRequest refundBookRequest) {
        validateFixedFieldLength(refundBookRequest.getMId(), MID_LENGTH, MID);
        throwIfErrors();
    }

    /**
     * Validate mandatory fields for refund book request
     *
     * @param refundBookRequest RefundBookRequest
     */
    protected void validateMandatoryFields(RefundBookRequest refundBookRequest) {
        logger.info("Validating mandatory fields for refund search request: {}", refundBookRequest);
        checkMandatoryField(refundBookRequest.getRefundType(), REFUND_TYPE);
        checkMandatoryField(refundBookRequest.getRefundAmount(), REFUND_AMOUNT);
        checkMandatoryField(refundBookRequest.getAtrnNumber(), ATRN);
        checkMandatoryField(refundBookRequest.getMId(), MID);
        throwIfErrors();
    }

    /**
     * Validate fields value for refund book request
     *
     * @param refundBookRequest RefundBookRequest
     */
    protected void validateFieldsValue(RefundBookRequest refundBookRequest) {
        logger.info("Inside validateFieldsValue for atrn: {}", refundBookRequest.getAtrnNumber());
        validateAtrn(refundBookRequest.getAtrnNumber());

        validateRemark(refundBookRequest.getRemark());
        validateAmount(refundBookRequest.getRefundAmount(), REFUND_AMOUNT);
        validateFieldLength(refundBookRequest.getRefundType(), TransactionConstant.REFUND_TYPE_LENGTH, REFUND_TYPE);
        throwIfErrors();
        validateFieldWithRegex(refundBookRequest.getRefundType(), CAPS_REGEX, REFUND_TYPE, INVALID_REFUND_TYPE_REASON);
        throwIfErrors();
        RefundType.getRefundType(refundBookRequest.getRefundType());
        throwIfErrors();
        validateFieldWithRegex(refundBookRequest.getMId(), ALLOWED_DIGIT_REGEX, MID,  INCORRECT_FORMAT);
        throwIfErrors();

    }

    /**
     * Method name : validateLeadingAndTraling
     * Description : Validates leading and Traling spaces from refund book request
     * @param refundBookRequest : Object of RefundBookRequest
     */
    private void validateLeadingTrailingSpaces(RefundBookRequest refundBookRequest) {
        checkForLeadingTrailingAndSingleSpace(refundBookRequest.getAtrnNumber(),ATRN);
        checkForLeadingTrailingAndSingleSpace(refundBookRequest.getRefundType(),REFUND_TYPE );
        checkForLeadingTrailingAndSingleSpace(refundBookRequest.getMId(), MID);
        throwIfErrors();
    }

    /**
     * Validate comment for refund book request
     *
     * @param comment String
     */
    protected void validateRemark(String comment) {
        validateFieldLength(comment, COMMENT_LENGTH, REMARK);
        throwIfErrors();
        validateFieldWithRegex(comment, COMMENT_REGEX, REMARK, INVALID_REMARK_REASON);
        throwIfErrors();
    }

    /**
     * Validate atrn for refund book request
     *
     * @param atrn String
     */
    protected void validateAtrn(String atrn) {
        validateFixedFieldLength(atrn, TransactionConstant.ATRN_ARRN_LENGTH, ATRN);
        throwIfErrors();
        validateFieldWithRegex(atrn, ATRN_ARRN_REGEX, ATRN, INVALID_ATRN_REASON);
        throwIfErrors();
    }

    /**
     * Validate refund search request
     *
     * @param refundSearchRequest RefundSearchRequest
     */
    public void validateRefundSearchRequest(RefundSearchRequest refundSearchRequest) {
        logger.info("Inside validateRefundDetailRequest for mid: {}", refundSearchRequest.getMId());
        errorDtoList = new ArrayList<>();
        validateMandatoryFields(refundSearchRequest);
        checkMandatoryFieldCount(refundSearchRequest);
        validateFieldsValue(refundSearchRequest);
        validateReportDates(refundSearchRequest.getFrom(), refundSearchRequest.getTo());
    }

    /**
     * check mandatory field count for refund search request
     *
     * @param refundSearchRequest RefundSearchRequest
     */
    private void checkMandatoryFieldCount(RefundSearchRequest refundSearchRequest) {
        logger.info("checking mandatory field count starts");
        mandatoryFields = new ArrayList<>();
        this.mandatoryCount = 0;
        countAndAddMandatoryField(refundSearchRequest.getFrom(), FROM_DATE);
        countAndAddMandatoryField(refundSearchRequest.getTo(), TO_DATE);
        countAndAddMandatoryField(refundSearchRequest.getAtrnNumber(), ATRN);
        countAndAddMandatoryField(refundSearchRequest.getArrnNumber(), ARRN);
        countAndAddMandatoryField(refundSearchRequest.getSbiOrderRefNumber(), SBIORDER_REFERENCE_NUMBER_STATUS );
        checkMandatoryFieldCount();
        throwIfErrors();
        logger.info("checking mandatory field count ends");
    }

    /**
     * Validate mandatory fields for refund search request
     *
     * @param refundSearchRequest RefundSearchRequest
     */
    protected void validateMandatoryFields(RefundSearchRequest refundSearchRequest) {
        logger.info("Inside refundDetailRequest for refundSearchRequest: {}", refundSearchRequest);
        checkMandatoryField(refundSearchRequest.getMId(), MID);
        throwIfErrors();
    }

    /**
     * Validate  field values for refund search request
     *
     * @param refundSearchRequest RefundSearchRequest
     */
    protected void validateFieldsValue(RefundSearchRequest refundSearchRequest) {

        logger.info("Inside validateFieldsValue for mid: {}", refundSearchRequest.getMId());
        checkForLeadingTrailingAndSingleSpace(refundSearchRequest);
        validateFieldLengthAndFormat(refundSearchRequest);
        validateEnums(refundSearchRequest);
        validateActiveMid(refundSearchRequest.getMId());
    }

    private void validateFieldLengthAndFormat(RefundSearchRequest refundSearchRequest) {

        logger.info("Inside validateFieldLengthAndFormat for mid: {}", refundSearchRequest.getMId());

        validateFixedFieldLength(refundSearchRequest.getAtrnNumber(), TransactionConstant.ATRN_ARRN_LENGTH, ATRN);
        throwIfErrors();
        validateFieldWithRegex(refundSearchRequest.getAtrnNumber(), ATRN_ARRN_REGEX, ATRN, INVALID_ATRN_REASON);
        throwIfErrors();
        validateFixedFieldLength(refundSearchRequest.getArrnNumber(), TransactionConstant.ATRN_ARRN_LENGTH, ARRN);
        throwIfErrors();
        validateFieldWithRegex(refundSearchRequest.getArrnNumber(), ATRN_ARRN_REGEX, ARRN, INVALID_ARRN_REASON);
        throwIfErrors();
        validateFieldLength(refundSearchRequest.getSbiOrderRefNumber(), ORDER_REF_LENGTH, SBI_ORDER_REF_NUMBER);
        throwIfErrors();
        validateFieldWithRegex(refundSearchRequest.getSbiOrderRefNumber(), ORDER_REFERENCE_NUMBER_REGEX, SBI_ORDER_REF_NUMBER, INVALID_ORDER_REF_REASON);
        throwIfErrors();
    }

    private void validateEnums(RefundSearchRequest refundSearchRequest) {

        logger.info("Inside validateEnums for mid: {}", refundSearchRequest.getMId());

        //Step-1: validate refund type
        if(StringUtils.isNotEmpty(refundSearchRequest.getRefundType())){
            RefundType.getRefundType(refundSearchRequest.getRefundType());
        }

        //Step-2:  validate refund status
        if(StringUtils.isNotEmpty(refundSearchRequest.getRefundStatus())){
            RefundStatus.getRefundStatus(refundSearchRequest.getRefundStatus());
        }
    }

    /**
     * Validate  field values for leading trailing space for refund search request
     *
     * @param refundSearchRequest RefundSearchRequest
     */
    private void checkForLeadingTrailingAndSingleSpace(RefundSearchRequest refundSearchRequest) {

        logger.info("Inside checkForLeadingAndSingleSpace for mid: {}", refundSearchRequest.getMId());

        checkForLeadingTrailingAndSingleSpace(refundSearchRequest.getAtrnNumber(),"atrnNumber");
        checkForLeadingTrailingAndSingleSpace(refundSearchRequest.getArrnNumber(),"arrnNumber");
        checkForLeadingTrailingAndSingleSpace( refundSearchRequest.getSbiOrderRefNumber(),"sbiOrderRefNumber");
        checkForLeadingTrailingAndSingleSpace(refundSearchRequest.getRefundStatus(),"refundStatus");
        checkForLeadingTrailingAndSingleSpace(refundSearchRequest.getRefundType(),"refundType");
        checkForLeadingTrailingAndSingleSpace(refundSearchRequest.getMId(),"mId");

        throwIfErrors();
    }

    /**
     * Validate bulk refund upload request
     *
     * @param mId            Merchant Id
     * @param file Multipart File
     */
    public void validateBulkRefundUploadRequest(String mId, MultipartFile file) {
        validateMid(mId);
        validateBulkRefundFile(file);
    }

    private void validateBulkRefundFile(MultipartFile file) {
        errorDtoList = new ArrayList<>();
        checkFilePresentOrNot(file, BULK_REFUND_FILE);
        throwIfErrors();
        validateFieldLength(file.getOriginalFilename(), BULK_REFUND_FILE_NAME_MAX_LENGTH, BULK_REFUND_FILE);
        throwIfErrors();
        validateFieldWithRegex(file.getOriginalFilename(), BULK_REFUND_FILE_NAME_REGEX, BULK_REFUND_FILE,  INCORRECT_FORMAT);
        throwIfErrors();
        checkFileFormat(file,BULK_REFUND_FILE_TYPES);
        throwIfErrors();
        checkFileMaxSize(file,transactionConfig.getBulkRefundFileMaxSize());
        throwIfErrors();
    }

    /**
     * Validate BulkRefund headers.
     *
     * @param csvFile List<String[]>
     * Return String of error
     */
    public String validateBulkRefundHeader(List<String[]> csvFile, String mId) {

        logger.info("Validate bulk refund header for mId: {}", mId);

        if (ObjectUtils.isEmpty(csvFile) || ObjectUtils.isEmpty(csvFile.getFirst())) {
            logger.debug("Valid file for mId: {}", mId);
            return "Invalid file, headers not available";
        }

        String[] requiredHeaders = BULK_REFUND_HEADERS.split(",");

        for (int i = 0; i < requiredHeaders.length; i++) {

            if (i >= csvFile.getFirst().length || !csvFile.getFirst()[i].equalsIgnoreCase(requiredHeaders[i])) {

                logger.debug("Invalid file for mId: {}, error: {} ", mId, requiredHeaders[i] + " not found in " + (i + 1) + " column.");
                return requiredHeaders[i] + " not found in " + (i + 1) + " column.";
            }

        }

        return null;

    }

    public void validateRefundRequest(BulkRefundBookingDetails bulkRefundBookingDetails) {
        errorDtoList = new ArrayList<>();
        logger.info("validation started for bulkRefundBookingDetails : {}", bulkRefundBookingDetails);
        validateMandatoryFields(bulkRefundBookingDetails);
        validateLeadingTrailingSpaces(bulkRefundBookingDetails);
        validateFieldsValue(bulkRefundBookingDetails);
    }
    protected void validateMandatoryFields(BulkRefundBookingDetails bulkRefundBookingDetails) {
        logger.info("Validating mandatory fields for refund search request: {}", bulkRefundBookingDetails);
        checkMandatoryField(bulkRefundBookingDetails.getRefundType(), REFUND_TYPE);
        checkMandatoryField(bulkRefundBookingDetails.getRefundAmount(), REFUND_AMOUNT);
        checkMandatoryField(bulkRefundBookingDetails.getAtrnNum(), ATRN);
        checkMandatoryField(bulkRefundBookingDetails.getMerchantOrderId(), MID);
        checkMandatoryField(bulkRefundBookingDetails.getRefundCurrency(), CURRENCY_CODE);
        throwIfErrors();
    }
    private void validateLeadingTrailingSpaces(BulkRefundBookingDetails bulkRefundBookingDetails) {
        checkForLeadingTrailingAndSingleSpace(bulkRefundBookingDetails.getAtrnNum(),ATRN);
        checkForLeadingTrailingAndSingleSpace(bulkRefundBookingDetails.getRemark(),REMARK );
        checkForLeadingTrailingAndSingleSpace(bulkRefundBookingDetails.getRefundType(),REFUND_TYPE );
        checkForLeadingTrailingAndSingleSpace(bulkRefundBookingDetails.getRefundCurrency(), CURRENCY_CODE);
        throwIfErrors();
    }
    protected void validateFieldsValue(BulkRefundBookingDetails bulkRefundBookingDetails) {
        logger.info("Inside validateFieldsValue for atrn: {}", bulkRefundBookingDetails.getAtrnNum());
        validateMerchantOderIdAndRefundCurrency(bulkRefundBookingDetails);
        validateAtrn(bulkRefundBookingDetails.getAtrnNum());
        validateRemark(bulkRefundBookingDetails.getRemark());
        validateAmount(new BigDecimal(bulkRefundBookingDetails.getRefundAmount()), REFUND_AMOUNT);
        RefundType.getRefundType(bulkRefundBookingDetails.getRefundType());
    }

    private void validateMerchantOderIdAndRefundCurrency(BulkRefundBookingDetails bulkRefundBookingDetails) {
        BulkRefundBooking bulkRefundBooking = refundDao.findByBulkId(bulkRefundBookingDetails.getBulkId());
        MerchantPaymentOrderDto merchantPaymentOrderDto = refundDao.findByAtrnNumber(bulkRefundBooking.getMerchantId() ,bulkRefundBookingDetails.getAtrnNum());
        if(!StringUtils.equalsIgnoreCase(bulkRefundBookingDetails.getMerchantOrderId(), merchantPaymentOrderDto.getOrderRefNumber())){
            logger.debug("Invalid MerchantOrderId {}", bulkRefundBookingDetails.getMerchantOrderId());
            throw new TransactionException(INVALID_ERROR_CODE, MessageFormat.format(INVALID_ERROR_MESSAGE, MERCHANT_ORDER_ID, INCORRECT_FORMAT));
        }
        if(!StringUtils.equalsIgnoreCase(bulkRefundBookingDetails.getRefundCurrency(), merchantPaymentOrderDto.getCurrencyCode())){
            logger.debug("Invalid currency {}", bulkRefundBookingDetails.getRefundCurrency());
            throw new TransactionException(INVALID_ERROR_CODE, MessageFormat.format(INVALID_ERROR_MESSAGE, REFUND_CURRENCY, INCORRECT_FORMAT));
        }
    }

    /**
     * validates the MId.
     *
     * @param mId The request containing mId.
     * @throws ValidationException if any validation fails.
     */
    public void validateMid(String mId) {
        logger.debug("Request Validation start for {}", mId);
        errorDtoList = new ArrayList<>();
        checkMandatoryField(mId, MID);
        throwIfErrors();
        checkForLeadingTrailingAndSingleSpace(mId, MID);
        throwIfErrors();
        validateFixedFieldLength(mId, MID_LENGTH, MID);
        throwIfErrors();
        validateFieldWithRegex(mId, ALLOWED_DIGIT_REGEX, MID, INVALID_FORMAT);
        throwIfErrors();
        validateActiveMid(mId);
        logger.debug("Request Validation end for {}", mId);
    }
    /**
     * validate active merchant id
     *
     * @param mId String
     *
     */
    private void validateActiveMid(String mId) {
        logger.info("Inside getActiveMerchantById for mId: {}", mId);
        MerchantInfoResponse response = adminDao.getMerchantByMId(mId);
        if (!StringUtils.equalsIgnoreCase(FLAG_Y, response.getIsActive())) {
            logger.info("The mId is InActive for mId: {}", mId);
            errorLogDao.logCustomerError(mId, EntityType.REFUND,null,null,null,null, NOT_FOUND_ERROR_CODE, MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, VALID_MERCHANT));
            throw new TransactionException(NOT_FOUND_ERROR_CODE, MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, VALID_MERCHANT));
        }
    }
    /**
     * Validates field values
     * @param bulkId String.
     * @param status String.
     */
    public void validateDownloadBulkRefund(String bulkId, String status) {
        errorDtoList = new ArrayList<>();
        logger.info("Mandatory fields validating started for bulkId: {} and status: {}", bulkId,status);
        checkMandatoryField(bulkId,BULK_ID);
        checkMandatoryField(status,REFUND_STATUS);
        logger.info("Mandatory fields validating end for bulkId: {} and status: {}", bulkId,status);
        throwIfErrors();
        logger.info("Leading and trailing fields validating started for bulkId: {} and status: {}", bulkId,status);
        checkForLeadingTrailingAndSingleSpace(bulkId,BULK_ID);
        checkForLeadingTrailingAndSingleSpace(status,REFUND_STATUS);
        logger.info("Leading and trailing fields validating end for bulkId: {} and status: {}", bulkId,status);
        throwIfErrors();
        logger.info("Validating field value started for bulkId: {} and status: {}", bulkId,status);
        validateFieldValue(bulkId,status);
        logger.info("Validating field value end for bulkId: {} and status: {}", bulkId,status);
        throwIfErrors();
        logger.info("Validating RefundStatus ENUM started for status: {}",status);
        validateFieldValue(status, Arrays.stream(BulkRefundRowStatus.values()).map(Enum::name).toList(), REFUND_STATUS);
        logger.info("Validating RefundStatus ENUM end for status: {}",status);
        throwIfErrors();
    }
    /**
     * Validates field values
     * @param bulkId String.
     * @param status String.
     */
    void validateFieldValue(String bulkId, String status) {
        validateFieldLength(bulkId, BULK_ID_MAX_LENGTH, BULK_ID);
        validateFieldWithRegex(bulkId, ALLOWED_DIGIT_REGEX,BULK_ID, INVALID_FORMAT);
        validateFieldLength(status, REFUND_STATUS_MAX_LENGTH, REFUND_STATUS);
        validateFieldWithRegex(status, REFUND_STATUS_REGEX,REFUND_STATUS, INVALID_FORMAT);
    }
}