package com.epay.transaction.dao;

import com.epay.transaction.config.TransactionConfig;
import com.epay.transaction.exceptions.TransactionException;
import com.epay.transaction.externalservice.KmsServicesClient;
import com.epay.transaction.externalservice.response.kms.KMSEncryptionKeysResponse;
import com.epay.transaction.model.response.TransactionResponse;
import com.epay.transaction.util.EPayIdentityUtil;
import com.epay.transaction.util.TransactionErrorConstants;
import com.epay.transaction.util.TransactionConstant;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Component;

import java.text.MessageFormat;

import static com.epay.transaction.util.EncryptionDecryptionUtil.decryptValue;

@Component
@RequiredArgsConstructor
public class KmsDao {

    private final KmsServicesClient kmsServicesClient;
    private final TransactionConfig transactionConfig;
    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());

    public String getMIdByKeyIdAndSecret(String merchantApiKeyId, String merchantApiKeySecret){
        logger.info("Request For Validating merchantApiKeyId and merchantApiKeySecret");
        TransactionResponse<String> kmsResponse =  kmsServicesClient.validateAPIKeyIdAndSecret(merchantApiKeyId, merchantApiKeySecret);
        if(TransactionConstant.RESPONSE_SUCCESS == kmsResponse.getStatus() && CollectionUtils.isNotEmpty(kmsResponse.getData())) {
            return kmsResponse.getData().getFirst();
        }else if(CollectionUtils.isNotEmpty(kmsResponse.getErrors())){
            throw new TransactionException(kmsResponse.getErrors());
        }
        logger.debug("KMS service not responding");
        throw new TransactionException(TransactionErrorConstants.NOT_FOUND_ERROR_CODE, MessageFormat.format(TransactionErrorConstants.NOT_FOUND_ERROR_MESSAGE, "Valid ID Secret"));
    }

    public String getMerchantMekKey() {
        KMSEncryptionKeysResponse encryptionKeysResponse = getEncryptionKeys();
        String kek = decryptValue(encryptionKeysResponse.getAek(), encryptionKeysResponse.getKek());
        return decryptValue(kek, encryptionKeysResponse.getMek());
    }

    private KMSEncryptionKeysResponse getEncryptionKeys() {
        TransactionResponse<KMSEncryptionKeysResponse> kmsResponse =  kmsServicesClient.getEncryptionKeys(EPayIdentityUtil.getUserPrincipal().getMId());
        if(TransactionConstant.RESPONSE_SUCCESS == kmsResponse.getStatus() && CollectionUtils.isNotEmpty(kmsResponse.getData())) {
            KMSEncryptionKeysResponse encryptionKeyResponse = kmsResponse.getData().getFirst();
            encryptionKeyResponse.setAek(transactionConfig.getAek());
            return encryptionKeyResponse;
        }else if(CollectionUtils.isNotEmpty(kmsResponse.getErrors())){
            throw new TransactionException(kmsResponse.getErrors());
        }
        throw new TransactionException(TransactionErrorConstants.NOT_FOUND_ERROR_CODE, MessageFormat.format(TransactionErrorConstants.NOT_FOUND_ERROR_MESSAGE, "Merchant Encryption Keys"));
    }


}
