package com.epay.transaction.dao;

import com.epay.transaction.exceptions.TransactionException;
import com.epay.transaction.exceptions.ValidationException;
import com.epay.transaction.externalservice.AdminServicesClient;
import com.epay.transaction.externalservice.request.admin.BinCheckRequest;
import com.epay.transaction.externalservice.request.admin.CurrencyRequest;
import com.epay.transaction.externalservice.response.admin.*;
import com.epay.transaction.mapper.PricingMapper;
import com.epay.transaction.model.request.MerchantPricingRequest;
import com.epay.transaction.model.response.TransactionResponse;
import com.epay.transaction.util.EPayIdentityUtil;
import com.epay.transaction.util.TransactionConstant;
import com.epay.transaction.util.enums.EntityType;
import com.fasterxml.jackson.databind.JsonNode;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.stereotype.Component;

import java.text.MessageFormat;
import java.util.List;

import static com.epay.transaction.util.TransactionErrorConstants.NOT_FOUND_ERROR_CODE;
import static com.epay.transaction.util.TransactionErrorConstants.NOT_FOUND_ERROR_MESSAGE;


@Component
@RequiredArgsConstructor
public class AdminDao {
    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private final AdminServicesClient adminServicesClient;
    private final ErrorLogDao errorLogDao;
    private final PricingMapper pricingMapper;
    /**
     * Getting Merchant Information Using mId
     *
     * @param mId String
     * @return MerchantInfoResponse
     */
    public MerchantInfoResponse getMerchantByMId(String mId) {
        logger.info("Fetching Merchant Information for mId: {}", mId);
        TransactionResponse<MerchantInfoResponse> response = adminServicesClient.getMerchantInfoByMId(mId);
        if (TransactionConstant.RESPONSE_SUCCESS == response.getStatus() && CollectionUtils.isNotEmpty(response.getData())) {
            logger.info("Successfully retrieved MerchantInfoResponse for mId: {}", mId);
            return response.getData().getFirst();
        } else if(CollectionUtils.isNotEmpty(response.getErrors())){
            throw new TransactionException(response.getErrors());
        }
        logger.error("Error in getMerchantByMId {} - Errors: {}", mId, response.getErrors());
       errorLogDao.logCustomerError(
                mId,
                EntityType.CUSTOMER,null,null,null,null,
                NOT_FOUND_ERROR_CODE,MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, "MId")
        );
        throw new TransactionException(NOT_FOUND_ERROR_CODE, MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, "MId"));
    }

    /**
     * Validates if the given currency code is valid for the merchant.
     *
     * @param mId          Merchant ID
     * @param currencyCode Currency Code
     * @return true if valid, false otherwise
     */
    public boolean isValidCurrencyCode(String mId, String currencyCode) {
        logger.info("Validating currency code: {} for Merchant ID: {}", currencyCode, mId);
        CurrencyRequest currencyRequest = CurrencyRequest.builder().mId(mId).currencyCode(currencyCode).build();
        TransactionResponse<?> response = adminServicesClient.getCurrencyValidate(currencyRequest);
        return TransactionConstant.RESPONSE_SUCCESS == response.getStatus();
    }

    /**
     * Validating channel bank with gateway map id.
     * @param gatewayMapId String
     * @param channelBank String
     * @return boolean validate status
     */
    public boolean isValidChannelBank(String gatewayMapId, String channelBank) {
        TransactionResponse<?> response = adminServicesClient.getChannelBankValidate(gatewayMapId, channelBank);
        if (TransactionConstant.RESPONSE_FAILURE == response.getStatus()) {
            logger.error("Error from adminServicesClient isValidChannelBank gatewayMapId:{} - Errors: {}", gatewayMapId, response.getErrors());
        }else if(CollectionUtils.isNotEmpty(response.getErrors())){
            throw new TransactionException(response.getErrors());
        }
        return TransactionConstant.RESPONSE_SUCCESS == response.getStatus();
    }
    public MerchantRfcResponse getMerchantRFCDetails(String mId) {
        logger.info("Fetching RFC details for mId: {}", mId);
        TransactionResponse<MerchantRfcResponse> response = adminServicesClient.getMerchantRFCInfo(mId);
        if (TransactionConstant.RESPONSE_SUCCESS == response.getStatus() && CollectionUtils.isNotEmpty(response.getData())) {
            logger.info("Successfully retrieved MerchantRfcResponse for mId: {}", mId);
            return response.getData().getFirst();
        } else if(CollectionUtils.isNotEmpty(response.getErrors())){
            throw new TransactionException(response.getErrors());
        }
        logger.error("Error in getMerchantRFCDetails {} - Errors: {}", mId, response.getErrors());
        errorLogDao.logCustomerError(
                mId,
                EntityType.CUSTOMER,null,null,null,null,
                NOT_FOUND_ERROR_CODE,MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, "MerchantRFCDetails")
        );
        throw new TransactionException(NOT_FOUND_ERROR_CODE, MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, "MerchantRFCDetails"));
    }

    /**
     * Retrieves multiple account details for a given merchant.
     *
     * @param mId Merchant ID
     * @return List containing account details
     */
    public List<String> getMerchantMultiAccount(String mId) {
        logger.info("Fetching multiple account details for mId: {}", mId);
        TransactionResponse<String> response = adminServicesClient.getMultiAccountDetailsApi(mId);
        if (TransactionConstant.RESPONSE_SUCCESS == response.getStatus() && CollectionUtils.isNotEmpty(response.getData())) {
            logger.info("Successfully retrieved multiple accounts for mId: {}", mId);
            return response.getData();
        }else if(CollectionUtils.isNotEmpty(response.getErrors())){
            throw new TransactionException(response.getErrors());
        }
        logger.error("Error in getMerchantMultiAccount {} - Errors: {}", mId, response.getErrors());
        errorLogDao.logCustomerError(
                mId,
                EntityType.ORDER,null,null,null,null,
                NOT_FOUND_ERROR_CODE,
                MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, "Merchant Account"));
        throw new TransactionException(NOT_FOUND_ERROR_CODE, MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, "Merchant Account"));
    }

    /**
     * Fetches available payment modes for a given merchant.
     *
     * @param mId Merchant ID
     * @return JsonNode containing payment modes
     */
    public JsonNode getMerchantPayModes(String mId) {
        logger.info("Fetching pay modes for mId: {}", mId);
        TransactionResponse<JsonNode> response = adminServicesClient.getMerchantPayModeInfo(mId);
        if (TransactionConstant.RESPONSE_SUCCESS == response.getStatus() && CollectionUtils.isNotEmpty(response.getData())) {
            logger.info("Successfully retrieved pay modes for mId: {}", mId);
            return response.getData().getFirst().get("payModes");
        }else if(CollectionUtils.isNotEmpty(response.getErrors())){
            throw new TransactionException(response.getErrors());
        }
        logger.error("Error in getMerchantPayModes {} - Errors: {}", mId, response.getErrors());
        errorLogDao.logCustomerError(
                mId,
                EntityType.BOOKING,null,null,null,null,
                NOT_FOUND_ERROR_CODE,
                MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, "MerchantRFCDetails"));
        throw new TransactionException(NOT_FOUND_ERROR_CODE, MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, "MerchantRFCDetails"));
    }

    /**
     * Retrieves Merchant Volume Velocity (VVL) details.
     *
     * @param mId Merchant ID
     * @return List of MerchantVvlResponse
     */
    public List<MerchantVvlResponse> getMerchantVVLDetails(String mId) {
        logger.info("Fetching Merchant VVL details for mId: {}", mId);
        TransactionResponse<MerchantVvlResponse> response = adminServicesClient.geVvlDetails(mId);
        if (TransactionConstant.RESPONSE_SUCCESS == response.getStatus() && CollectionUtils.isNotEmpty(response.getData())) {
            logger.info("Successfully retrieved VVL details for mId: {}", mId);
            return response.getData();
        } else if(CollectionUtils.isNotEmpty(response.getErrors())){
            throw new TransactionException(response.getErrors());
        }
        logger.error("Error in getMerchantVVLDetails {} - Errors: {}", mId, response.getErrors());
        errorLogDao.logCustomerError(
                mId,
                EntityType.PAYMENT,null,null,null,null,
                NOT_FOUND_ERROR_CODE,
                MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, "MerchantVVLDetails"));
        throw new TransactionException(NOT_FOUND_ERROR_CODE, MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, "MerchantVVLDetails"));
    }

    /**
     * Fetches Gateway Configuration Details for a given merchant and gateway mapping ID.
     *
     * @param mId          Merchant ID
     * @param gateWayMapId Gateway Mapping ID
     * @return GatewayConfigDetailsResponse
     */
    public GatewayConfigDetailsResponse getGatewayConfigDetails(String mId, String gateWayMapId,String payMode) {
        logger.info("Fetching Gateway Config Details for mId: {} and gateWayMapId: {}", mId, gateWayMapId);TransactionResponse<GatewayConfigDetailsResponse> response = adminServicesClient.getGatewayConfigDetails(mId, gateWayMapId);
        if (TransactionConstant.RESPONSE_SUCCESS == response.getStatus() && CollectionUtils.isNotEmpty(response.getData())) {
            logger.info("Successfully retrieved Gateway Config Details for mId: {}", mId);
            return response.getData().getFirst();
        }else if(CollectionUtils.isNotEmpty(response.getErrors())){
            throw new TransactionException(response.getErrors());
        }
        logger.error("Error in getGatewayConfigDetails {} - Errors: {}", mId, response.getErrors());
        errorLogDao.logTechnicalError(
                mId,
                EntityType.PAYMENT,null,null,null,payMode,
                NOT_FOUND_ERROR_CODE,
                MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, "GatewayConfigDetails"));
        throw new TransactionException(NOT_FOUND_ERROR_CODE, MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, "GatewayConfigDetails"));
    }

    /**
     * Retrieves the valid merchant pricing structure.
     *
     * @param merchantPricingRequest MerchantPricingRequest object
     * @return MerchantPricingResponse
     */
    public MerchantPricingResponse getValidMerchantPricingStructure(MerchantPricingRequest merchantPricingRequest) {
        logger.info("Fetching valid Merchant Pricing Structure for request: {}", merchantPricingRequest);
        TransactionResponse<MerchantPricingResponse> response = adminServicesClient.getMerchantPricingStructure(pricingMapper.mapToAdminRequest(merchantPricingRequest));
        if (TransactionConstant.RESPONSE_SUCCESS == response.getStatus() && CollectionUtils.isNotEmpty(response.getData())) {
            MerchantPricingResponse merchantPricingResponse = response.getData().getFirst();
            if (ObjectUtils.isEmpty(merchantPricingResponse.getFeeProcessingFlag()) || !merchantPricingResponse.getFeeProcessingFlag().equals(TransactionConstant.TRANSACTION_PROCESSING_FLAG_HYBRID)) {
                logger.error("Invalid fee processing flag for MerchantPricingResponse: {}", merchantPricingResponse);
                errorLogDao.logCustomerError(
                        EPayIdentityUtil.getUserPrincipal().getMId(),
                        EntityType.PAYMENT,null,null,null,null,
                        NOT_FOUND_ERROR_CODE,
                        MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, "Hybrid transaction processing flag"));
                throw new ValidationException(NOT_FOUND_ERROR_CODE, MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, "Hybrid transaction processing flag"));
            }
            if (ObjectUtils.isEmpty(merchantPricingResponse.getBearableComponent()) || !(merchantPricingResponse.getBearableComponent().equalsIgnoreCase(TransactionConstant.BEARABLE_COMPONENT_FEE) || merchantPricingResponse.getBearableComponent().equalsIgnoreCase(TransactionConstant.BEARABLE_COMPONENT_AMOUNT))) {
                logger.info("Bearable component validation failed for MerchantPricingResponse: {}", merchantPricingResponse);
                errorLogDao.logCustomerError(
                        EPayIdentityUtil.getUserPrincipal().getMId(),
                        EntityType.PAYMENT,null,null,null,null,
                        NOT_FOUND_ERROR_CODE,
                        MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, "Valid bearable compound"));
                throw new ValidationException(NOT_FOUND_ERROR_CODE, MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, "Valid bearable compound"));
            }
            logger.info("Successfully retrieved Merchant Pricing Structure: {}", merchantPricingResponse);
            return merchantPricingResponse;
        }else if(CollectionUtils.isNotEmpty(response.getErrors())){
            throw new TransactionException(response.getErrors());
        }
        logger.error("Error in getMerchantPricingStructure - Errors: {}", response.getErrors());
        errorLogDao.logCustomerError(
                EPayIdentityUtil.getUserPrincipal().getMId(),
                EntityType.PAYMENT,null,null,null,null,
                NOT_FOUND_ERROR_CODE,
                MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, "Merchant Pricing information"));
        throw new TransactionException(NOT_FOUND_ERROR_CODE, MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, "Merchant Pricing information"));
    }

    /**
     * Retrieves BIN check response for a given BIN check request.
     *
     * @param binCheckRequest BinCheckRequest object
     * @return BinCheckResponse
     */
    public BinCheckResponse getBinCheckResponse(BinCheckRequest binCheckRequest) {
        logger.info("Fetching Bin Check Response for request: {}", binCheckRequest);
        TransactionResponse<BinCheckResponse> response = adminServicesClient.binCheckRequest(binCheckRequest);

        if (TransactionConstant.RESPONSE_SUCCESS == response.getStatus() && CollectionUtils.isNotEmpty(response.getData())) {
            logger.info("Successfully retrieved Bin Check Response.");
            return response.getData().getFirst();
        }else if(CollectionUtils.isNotEmpty(response.getErrors())){
            throw new TransactionException(response.getErrors());
        }
        logger.error("Error in getBinCheckResponse - Errors: {}", response.getErrors());
        errorLogDao.logTechnicalError(
                EPayIdentityUtil.getUserPrincipal().getMId(),
                EntityType.PAYMENT,null,null,null,null,
                NOT_FOUND_ERROR_CODE,
                MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, "CardBinCheck"));
        throw new TransactionException(NOT_FOUND_ERROR_CODE, MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, "CardBinCheck"));
    }


    /**
     * Retrieves postal code details for a postal code.
     *
     * @param postalCode postal code
     * @return postal code details
     */
    public MerchantPostalCodeResponse getPostalCodeDetails(String postalCode) {
        logger.info("Fetching postal code detail  for postal code : {}", postalCode);
        TransactionResponse<MerchantPostalCodeResponse> response = adminServicesClient.getPostalCodeDetails(postalCode);
        if (TransactionConstant.RESPONSE_SUCCESS == response.getStatus() && CollectionUtils.isNotEmpty(response.getData())) {
            logger.info("Successfully retrieved postal code detail for postalCode: {}", postalCode);
            return response.getData().getFirst();
        } else if (CollectionUtils.isNotEmpty(response.getErrors())) {
            throw new TransactionException(response.getErrors());
        }
        logger.error("Error in retrieved postal code detail {} - Errors: {}", postalCode, response.getErrors());
        throw new TransactionException(NOT_FOUND_ERROR_CODE, MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, "Postal code details"));
    }


    /**
     * Retrieves postal code details for a postal code.
     *
     * @param ifsc ifsc code
     * @return ifsc code details
     */
    public MerchantIfscCodeResponse getIfscCodeDetails(String ifsc) {
        logger.info("Fetching ifsc code detail  for postal code : {}", ifsc);
        TransactionResponse<MerchantIfscCodeResponse> response = adminServicesClient.getIfscCodeDetails(ifsc);
        if (TransactionConstant.RESPONSE_SUCCESS == response.getStatus() && CollectionUtils.isNotEmpty(response.getData())) {
            logger.info("Successfully retrieved ifsc code detail for ifsc: {}", ifsc);
            return response.getData().getFirst();
        } else if (CollectionUtils.isNotEmpty(response.getErrors())) {
            throw new TransactionException(response.getErrors());
        }
        logger.error("Error in retrieved ifsc code detail {} - Errors: {}", ifsc, response.getErrors());
        throw new TransactionException(NOT_FOUND_ERROR_CODE, MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, "Ifsc code details"));
    }

}
