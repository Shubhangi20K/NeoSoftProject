package com.epay.transaction.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ReconDataDto {

    private String atrnNum;
    private String bankRefNumber;
    private String rfId;
    private String rfdId;
}
