package com.epay.transaction.util.enums;

import com.epay.transaction.exceptions.TransactionException;
import com.epay.transaction.util.TransactionErrorConstants;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.text.MessageFormat;
import java.util.Arrays;

@Getter
@AllArgsConstructor
public enum NotificationType {
    EMAIL, SMS, BOTH;

    public static NotificationType getType(String notificationType) {
        return Arrays.stream(values())
                .filter(n -> n.name().equalsIgnoreCase(notificationType))
                .findFirst()
                .orElseThrow(() ->
                        new TransactionException(TransactionErrorConstants.INVALID_ERROR_CODE_NO_REASON,
                                MessageFormat.format(TransactionErrorConstants.INVALID_ERROR_MESSAGE_NO_REASON, "NotificationType '"+notificationType+"'"))
                );
    }
}
