package com.epay.transaction.externalservice.response.admin;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

/**
 * Class Name:MerchantNotificationViewResponse
 * *
 * Description: This class has merchant notification.
 * *
 * Author:Gireesh M
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
@Data
@Builder
public class MerchantNotificationResponse {
    @JsonProperty("mId")
    private String mId;
    private String emailAlertMerchant;
    private String emailAlertCustomer;
    private String smsAlertMerchant;
    private String smsAlertCustomer;
    private String communicationEmail;
    private String mobileNo;
    private String merchPushResponseFlag;
    private String merchPushResponseUrl;
    private String businessName;
    private String brandName;
}
