package com.epay.transaction.config.listener;

import com.epay.transaction.entity.AuditRevisionEntity;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.envers.RevisionEntity;
import org.hibernate.envers.RevisionListener;

import java.util.concurrent.atomic.AtomicReference;

@RevisionEntity
public class AuditRevisionListener implements RevisionListener {
    private static final AtomicReference<String> ENTITY_NAME_HOLDER = new AtomicReference<>();

    public static String getEntityName() {
        return ENTITY_NAME_HOLDER.get();
    }

    public static void setEntityName(String entityName) {
        ENTITY_NAME_HOLDER.set(entityName);
    }

    public static void clear() {
        ENTITY_NAME_HOLDER.set(StringUtils.EMPTY);
    }

    @Override
    public void newRevision(Object revisionEntity) {
        AuditRevisionEntity auditRevisionEntity = (AuditRevisionEntity) revisionEntity;
        auditRevisionEntity.setEntityClassName(getEntityName());
    }
}