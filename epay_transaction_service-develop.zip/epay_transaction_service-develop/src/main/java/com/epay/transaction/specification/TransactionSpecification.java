package com.epay.transaction.specification;

import com.epay.transaction.entity.Order;
import com.epay.transaction.entity.MerchantOrderPayment;
import com.epay.transaction.model.request.MerchantOrderPaymentSearchRequest;
import com.epay.transaction.util.enums.*;
import jakarta.persistence.criteria.*;
import lombok.experimental.UtilityClass;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.util.StringUtils;

@UtilityClass
public class TransactionSpecification {

    public static Specification<MerchantOrderPayment> searchTransaction(String mId, MerchantOrderPaymentSearchRequest merchantOrderPaymentSearchRequest) {

        return (root, query, criteriaBuilder) -> {

            Predicate predicate = criteriaBuilder.conjunction();
            predicate = criteriaBuilder.and(predicate, getMidPredicate(root, criteriaBuilder, mId));

            Join<MerchantOrderPayment, Order> orderJoin = root.join("order", JoinType.INNER);

            if (StringUtils.hasText(merchantOrderPaymentSearchRequest.getAtrn())) {
                predicate = criteriaBuilder.and(predicate, getAtrnPredicate(root, criteriaBuilder, merchantOrderPaymentSearchRequest.getAtrn()));
            }

            if (StringUtils.hasText(merchantOrderPaymentSearchRequest.getOrderRefNumber())) {
                predicate = criteriaBuilder.and(predicate, getOrderRefNumberPredicate(root, criteriaBuilder, merchantOrderPaymentSearchRequest.getOrderRefNumber()));
            }

            if (ObjectUtils.isNotEmpty(merchantOrderPaymentSearchRequest.getOrderStatus())) {
                predicate = criteriaBuilder.and(predicate, getOrderStatusPredicate(orderJoin, criteriaBuilder, merchantOrderPaymentSearchRequest.getOrderStatus()));
            }

            if (StringUtils.hasText(merchantOrderPaymentSearchRequest.getBankRefNumber())) {
                predicate = criteriaBuilder.and(predicate, getBankRefNumberPredicate(root, criteriaBuilder, merchantOrderPaymentSearchRequest.getBankRefNumber()));
            }

            if (ObjectUtils.isNotEmpty(merchantOrderPaymentSearchRequest.getRefundStatus())) {
                predicate = criteriaBuilder.and(predicate, getRefundStatusPredicate(root, criteriaBuilder, merchantOrderPaymentSearchRequest.getRefundStatus()));
            }

            if (ObjectUtils.isNotEmpty(merchantOrderPaymentSearchRequest.getTransactionStatus())) {
                predicate = criteriaBuilder.and(predicate, getTransactionStatusPredicate(root, criteriaBuilder, merchantOrderPaymentSearchRequest.getTransactionStatus()));
            }

            if (ObjectUtils.isNotEmpty(merchantOrderPaymentSearchRequest.getPaymentStatus())) {
                predicate = criteriaBuilder.and(predicate, getPaymentStatusPredicate(root, criteriaBuilder, merchantOrderPaymentSearchRequest.getPaymentStatus()));
            }

            if (ObjectUtils.isNotEmpty(merchantOrderPaymentSearchRequest.getFromDate())) {
                predicate = criteriaBuilder.and(predicate, getFromDatePredicate(root, criteriaBuilder, merchantOrderPaymentSearchRequest.getFromDate()));
            }

            if (ObjectUtils.isNotEmpty(merchantOrderPaymentSearchRequest.getToDate())) {
                predicate = criteriaBuilder.and(predicate, getToDatePredicate(root, criteriaBuilder, merchantOrderPaymentSearchRequest.getToDate()));
            }

            if (ObjectUtils.isNotEmpty(merchantOrderPaymentSearchRequest.getSbiOrderRefNumber())) {
                predicate = criteriaBuilder.and(predicate, getSbiOrderRefNumberPredicate(root, criteriaBuilder, merchantOrderPaymentSearchRequest.getSbiOrderRefNumber()));
            }

            return predicate;
        };
    }

    private static Predicate getMidPredicate(Root<MerchantOrderPayment> root, CriteriaBuilder criteriaBuilder, String mId) {
        return criteriaBuilder.equal(root.get("mId"), mId);
    }

    private static Predicate getAtrnPredicate(Root<MerchantOrderPayment> root, CriteriaBuilder criteriaBuilder, String atrnNumber) {
        return criteriaBuilder.equal(root.get("atrnNumber"), atrnNumber);
    }

    private static Predicate getOrderRefNumberPredicate(Root<MerchantOrderPayment> root, CriteriaBuilder criteriaBuilder, String orderRefNumber) {
        return criteriaBuilder.equal(root.get("orderRefNumber"), orderRefNumber);
    }

    private static Predicate getBankRefNumberPredicate(Root<MerchantOrderPayment> root, CriteriaBuilder criteriaBuilder, String bankRefNumber) {
        return criteriaBuilder.equal(root.get("bankReferenceNumber"), bankRefNumber);
    }

    private static Predicate getPaymentStatusPredicate(Root<MerchantOrderPayment> root, CriteriaBuilder criteriaBuilder, String status) {
        return criteriaBuilder.equal(root.get("paymentStatus"), status);
    }

    private static Predicate getOrderStatusPredicate(Join<MerchantOrderPayment, Order> orderJoin, CriteriaBuilder criteriaBuilder, String status) {
        return criteriaBuilder.equal(orderJoin.get("status"), status);
    }

    private static Predicate getTransactionStatusPredicate(Root<MerchantOrderPayment> root, CriteriaBuilder criteriaBuilder, String status) {
        return criteriaBuilder.equal(root.get("transactionStatus"), status);
    }

    private static Predicate getRefundStatusPredicate(Root<MerchantOrderPayment> root, CriteriaBuilder criteriaBuilder, String status) {
        return criteriaBuilder.equal(root.get("refundStatus"), status);
    }

    private static Predicate getFromDatePredicate(Root<MerchantOrderPayment> root, CriteriaBuilder criteriaBuilder, Long fromDate) {
        return criteriaBuilder.greaterThanOrEqualTo(root.get("createdDate"), fromDate);
    }

    private static Predicate getToDatePredicate(Root<MerchantOrderPayment> root, CriteriaBuilder criteriaBuilder, Long toDate) {
        return criteriaBuilder.lessThanOrEqualTo(root.get("createdDate"), toDate);
    }

    private static Predicate getSbiOrderRefNumberPredicate(Root<MerchantOrderPayment> root, CriteriaBuilder criteriaBuilder, String sbiOrderRefNumber) {
        return criteriaBuilder.equal(root.get("sbiOrderRefNumber"), sbiOrderRefNumber);
    }

}