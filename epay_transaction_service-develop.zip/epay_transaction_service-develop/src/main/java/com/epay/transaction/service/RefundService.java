package com.epay.transaction.service;

import com.epay.transaction.dao.ErrorLogDao;
import com.epay.transaction.dao.RefundDao;
import com.epay.transaction.dto.BulkRefundBookingDto;
import com.epay.transaction.dto.ErrorDto;
import com.epay.transaction.dto.MerchantPaymentOrderDto;
import com.epay.transaction.dto.RefundBookingDto;
import com.epay.transaction.entity.BulkRefundBooking;
import com.epay.transaction.entity.BulkRefundBookingDetails;
import com.epay.transaction.etl.producer.BulkRefundProducer;
import com.epay.transaction.etl.producer.RefundBookingDetailsProducer;
import com.epay.transaction.exceptions.TransactionException;
import com.epay.transaction.exceptions.ValidationException;
import com.epay.transaction.externalservice.S3Service;
import com.epay.transaction.mapper.RefundMapper;
import com.epay.transaction.model.request.EncryptedRequest;
import com.epay.transaction.model.request.RefundBookRequest;
import com.epay.transaction.model.request.RefundSearchRequest;
import com.epay.transaction.model.response.EncryptedResponse;
import com.epay.transaction.model.response.RefundResponse;
import com.epay.transaction.model.response.TransactionResponse;
import com.epay.transaction.util.DateTimeUtils;
import com.epay.transaction.util.EPayIdentityUtil;
import com.epay.transaction.util.TransactionConstant;
import com.epay.transaction.util.TransactionErrorConstants;
import com.epay.transaction.util.enums.BulkRefundRowStatus;
import com.epay.transaction.util.enums.BulkRefundStatus;
import com.epay.transaction.util.enums.EntityType;
import com.epay.transaction.util.enums.RefundStatus;
import com.epay.transaction.util.file.generator.CSVGenerator;
import com.epay.transaction.validator.RefundValidator;
import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvException;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import software.amazon.awssdk.core.ResponseBytes;

import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

import static com.epay.transaction.util.EncryptionDecryptionUtil.encryptValue;
import static com.epay.transaction.util.TransactionConstant.BULK_REFUND_HEADERS;
import static com.epay.transaction.util.TransactionErrorConstants.*;
import static com.epay.transaction.util.TransactionUtil.buildRequestByEncryptRequest;
import static com.epay.transaction.util.TransactionUtil.toJson;

/**
 * Class Name:RefundService
 * *
 * Description: Service for refund booking, refund searching and refund related requests by merchant.
 * This class provides methods for refund booking, refund status, refund searching and bulk refund booking.
 * *
 * Author:Nirmal Gurjar
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
@Service
@RequiredArgsConstructor
public class RefundService {

    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private final RefundMapper refundMapper;
    private final RefundValidator refundValidator;
    private final RefundDao refundDao;
    private final S3Service s3Service;
    protected static final List<String> BULK_REFUND_HEADER_LIST =List.of("Refund Type", "Merchant Order ID", "ATRN", "Refund Amount", "Refund Currency", "Comments","Refund Status","Remark");
    protected static final List<String> REFUND_BOOKINGS_HEADER_LIST =List.of("SBIePay Order ID", "ATRN", "ARRN", "Refund Initiation Date", "Refund Amount", "Refund Process Date", "Refund Type", "Refund Status");
    private final RefundBookingDetailsProducer refundBookingDetailsProducer;
    private final BulkRefundProducer bulkRefundProducer;
    private final ErrorLogDao errorLogDao;

    /**
     * Book refund for a ATRN and requested parameters in encrypted request
     *
     * @param request EncryptedRequest
     * @return TransactionResponse with EncryptedResponse
     */
    public TransactionResponse<EncryptedResponse> bookRefund(EncryptedRequest request) {

        //Step 1 : Get Merchant MEK
        logger.info("Create Merchant Order MEK request start");
        String mek = refundDao.getMerchantMek();

        //Step 2 : Decrypt request to RefundBookRequest
        logger.info("Create refund book request from encrypted request");
        RefundBookRequest refundBookRequest = buildRequestByEncryptRequest(request.getEncryptedRequest(), mek, RefundBookRequest.class);

        //Step 3 : Validate and Set mId from access token
        setValidMId(refundBookRequest);

        // Step 4: Call refund booking
        logger.info("calling book refund service");
        RefundResponse refundResponse = bookRefund(refundBookRequest);

        // Step 5: Encrypt the response
        EncryptedResponse encryptedResponse = EncryptedResponse.builder().encryptedResponse(encryptValue(mek, toJson(refundResponse))).build();
        logger.info("Encrypted Response :{}", encryptedResponse);

        return TransactionResponse.<EncryptedResponse>builder().data(List.of(encryptedResponse)).status(TransactionConstant.RESPONSE_SUCCESS).build();
    }

    private static void setValidMId(RefundBookRequest refundBookRequest) {
        if(StringUtils.isNotEmpty(refundBookRequest.getMId())){
            throw new ValidationException(INVALID_ERROR_CODE, MessageFormat.format(INVALID_ERROR_MESSAGE,"Request object", "Unrecognised field: 'mId'"));
        }
        refundBookRequest.setMId(EPayIdentityUtil.getUserPrincipal().getMId());
    }

    /**
     * Book refund for a ATRN and requested parameters
     *
     * @param refundBookRequest RefundBookRequest
     * @return TransactionResponse with RefundResponse
     */
    public TransactionResponse<RefundResponse> bookRefundWithResponse(RefundBookRequest refundBookRequest) {
        return TransactionResponse.<RefundResponse>builder().status(TransactionConstant.RESPONSE_SUCCESS).data(List.of(bookRefund(refundBookRequest))).build();
    }


    /**
     * Book refund for a ATRN and requested parameters
     *
     * @param refundBookRequest RefundBookRequest
     * @return RefundResponse
     */
    public RefundResponse bookRefund(RefundBookRequest refundBookRequest) {
        logger.info("Book Refund Request for refundBookRequest {} ", refundBookRequest);
        //Step-1: Validate refund request
        refundValidator.validateRefundRequest(refundBookRequest);
        logger.debug("refundBookRequest validated for atrn: {}", refundBookRequest.getAtrnNumber());

        //Step-2: Get transaction details
        MerchantPaymentOrderDto merchantPaymentOrderDto = refundDao.findByAtrnNumber(refundBookRequest.getMId() ,refundBookRequest.getAtrnNumber());
        logger.debug("fetch merchantPaymentOrderDto for refund atrn: {}", refundBookRequest.getAtrnNumber());

        //Step-3: Perform business validation
        refundValidator.validateBusinessRules(refundBookRequest, merchantPaymentOrderDto);
        logger.debug("refundBookRequest business rule validated for atrn: {}", refundBookRequest.getAtrnNumber());

        //Step-4: Build and save refund booking dto
        RefundBookingDto refundBookingDto = refundMapper.mapToRefundBookingDto(refundBookRequest, merchantPaymentOrderDto);
        RefundResponse refundResponse = refundDao.saveRefundBooking(refundBookingDto, merchantPaymentOrderDto);
        logger.debug("refundBookRequest saved for atrn: {}", refundBookRequest.getAtrnNumber());

        //Step-5: Return refund response
        return refundResponse;
    }

    /**
     * Search refund details status for requested parameters
     *
     * @param encryptedRequest RefundSearchRequest
     * @return TransactionResponse with encrypted RefundDetailResponse
     */
    public TransactionResponse<String> getRefundBookingSearchResponse(String encryptedRequest, Pageable pageable) {

        //Step 1 : Get Merchant MEK
        logger.info("Create Merchant Order MEK request start");
        String mek = refundDao.getMerchantMek();

        //Step 2 : Decrypt request to refundSearchRequest
        logger.info("Create refund book request from encrypted request");
        RefundSearchRequest refundSearchRequest = buildRequestByEncryptRequest(encryptedRequest, mek, RefundSearchRequest.class);

        //Step 3: Set mId from access token
        setValidMId(refundSearchRequest);

        // Step 3: Call search refund booking
        logger.info("calling search refund booking service");
        Page<RefundBookingDto> refundBookingDtoPage = searchRefundBookings(refundSearchRequest, pageable);

        // Step 4: Encrypt the response list
        List<RefundResponse> encryptedResponseList = refundMapper.dtoToResponse(refundBookingDtoPage.getContent());
        logger.info("Encrypted Response size :{}", encryptedResponseList.size());

        // Step 5: return the response list
        return TransactionResponse.<String>builder().data(List.of(encryptValue(mek,toJson(encryptedResponseList)))).status(TransactionConstant.RESPONSE_SUCCESS).total(refundBookingDtoPage.getTotalElements()).count((long) refundBookingDtoPage.getContent().size()).build();
    }

    private void setValidMId(RefundSearchRequest refundSearchRequest) {
        if(StringUtils.isNotEmpty(refundSearchRequest.getMId())){
            errorLogDao.logCustomerError(refundSearchRequest.getMId(), EntityType.REFUND,null,null,null,null, INVALID_ERROR_CODE, MessageFormat.format(INVALID_ERROR_MESSAGE,"Request object", "Unrecognised field: 'mId'"));
            throw new ValidationException(INVALID_ERROR_CODE, MessageFormat.format(INVALID_ERROR_MESSAGE,"Request object", "Unrecognised field: 'mId'"));
        }
        refundSearchRequest.setMId(EPayIdentityUtil.getUserPrincipal().getMId());
    }

    /**
     * Search refund details status for requested parameters
     *
     * @param refundSearchRequest RefundSearchRequest
     * @return TransactionResponse with RefundDetailResponse
     */
    public TransactionResponse<RefundResponse> getRefundBookingSearchResponse(RefundSearchRequest refundSearchRequest, Pageable pageable){
        Page<RefundBookingDto> refundBookingDtoPage =  searchRefundBookings(refundSearchRequest,  pageable);
        return TransactionResponse.<RefundResponse>builder().data(refundMapper.dtoToResponse(refundBookingDtoPage.getContent())).status(TransactionConstant.RESPONSE_SUCCESS).total(refundBookingDtoPage.getTotalElements()).count((long) refundBookingDtoPage.getContent().size()).build();
    }

    /**
     * Search refund details status for requested parameters
     *
     * @param refundSearchRequest RefundSearchRequest
     * @return TransactionResponse with RefundDetailResponse
     */
    public Page<RefundBookingDto> searchRefundBookings(RefundSearchRequest refundSearchRequest, Pageable pageable) {

        logger.info("Get refund request received for refundDetailRequest: {}", refundSearchRequest);

        //Step-1: Validate refund search request
        refundValidator.validateRefundSearchRequest(refundSearchRequest);

        //Step-2: Search refund request in db for requested parameters
        return refundDao.searchRefundBookingRequest(refundSearchRequest, pageable);
    }

    /**
     * Validate bulk refund request, upload bulk refund CSV on S3
     *
     * @param mId String Merchant ID
     * @param bulkRefundFile Multipart bulk upload CSV
     * @return TransactionResponse of status
     */
    public TransactionResponse<String> uploadBulkRefund(String mId, MultipartFile bulkRefundFile) {

        logger.info("uploadBulkRefund invoked for mId: {}", mId);

        //Step-1: Validate bulk refund file
        refundValidator.validateBulkRefundUploadRequest(mId, bulkRefundFile);
        logger.info("Bulk upload request validated for mId: {}", mId);

        //Step-2: Upload bulk upload on s3
        String filePath = s3Service.uploadFile(bulkRefundFile);
        logger.info("Bulk refund file uploaded at :{} for mId: {}", filePath, mId);

        //Step-3: Build bulk refund booking
        BulkRefundBooking bulkRefundBooking = buildBulkRefundBooking(mId, bulkRefundFile, filePath);

        //Step-4: Save bulk refund booking
        bulkRefundBooking = refundDao.saveBulkRefundBooking(bulkRefundBooking);
        logger.info("Bulk refund request saved for mId: {}", filePath, mId);

        //Step-5: Process bulk refund
        bulkRefundProducer.publish("BULK_REFUND",bulkRefundBooking.getBulkId(), bulkRefundBooking.getBulkId());

        return TransactionResponse.<String>builder().status(TransactionConstant.RESPONSE_SUCCESS).data(List.of(bulkRefundBooking.getBulkId())).total(1L).build();
    }

    /**
     * Builds bulk refund booking from mId, bulkRefundFile and filePath
     * @param mId String
     * @param bulkRefundFile MultipartFile
     * @param filePath String
     * @return BulkRefundBooking
     */
    private static BulkRefundBooking buildBulkRefundBooking(String mId, MultipartFile bulkRefundFile, String filePath) {

        return BulkRefundBooking.builder()
                .bulkRefundStatus(BulkRefundStatus.IN_QUEUE.name())
                .fileName(bulkRefundFile.getName())
                .filePath(filePath)
                .merchantId(mId)
                .createdBy(TransactionConstant.BULK_REFUND_SERVICE)
                .createdDate(DateTimeUtils.getCurrentTimeInMills())
                .build();
    }

    /**
     * Process bulk refund request, takes up uploaded bulk CSV file from s3 and process refund booking row by row
     *
     * @param bulkId String Bulk id ref id against which csv file was uploaded
     */
    public void processBulkRefund(String bulkId) {

        logger.info("ProcessBulkRefund received for bulkId: {}", bulkId);

        //Step-1: Get bulk refund booking
        BulkRefundBooking bulkRefundBooking = refundDao.findByBulkId(bulkId);
        logger.info("Got bulkRefundBooking: {} for bulkId: {}", bulkRefundBooking , bulkId);

        //Step-2: Update processing status
        updateProcessingStatus(bulkRefundBooking);

        //Step-3: Read CSV file from s3 service
        List<String[]> refundData = readCsvFile(bulkRefundBooking.getFilePath());
        logger.info("Got csvFile size : {} for bulkId: {}", refundData.size() , bulkId);

        //Step-4: Validate Headers
        String headerError = refundValidator.validateBulkRefundHeader(refundData, bulkRefundBooking.getMerchantId());
        logger.info("headerError : {} for bulkId: {}", headerError , bulkId);

        //Step-5: If headers are valid then read and process refund from csv file row by row
        //With Kafka
        if (StringUtils.isEmpty(headerError)) {
            logger.info("Valid headers, headerError : {} for bulkId: {}", headerError , bulkId);
            processingRefundBooking(bulkId, refundData, bulkRefundBooking);

        } else {
            logger.info("Invalid headers, headerError : {} for bulkId: {}", headerError , bulkId);
            //Step-6: Mark this csv file as failed
            buildBulkRefundBookingWithError(bulkRefundBooking, headerError);
            //Step-7: Update bulk refund status for current bulk id
            refundDao.saveBulkRefundBooking(bulkRefundBooking);
        }
    }

    /**
     * Process CSV file row by row and save the details
     *
     * @param bulkRefundBooking BulkRefundBooking
     * @param refundData List<String[]>
     * @param bulkId String
     *
     */
    private void processingRefundBooking(String bulkId, List<String[]> refundData, BulkRefundBooking bulkRefundBooking) {
        logger.info("processingRefundBooking received for bulkId: {}", bulkId);
        int totalRecords = refundData.size() - 1;
        //Update BulkRefundBooking status (processing is async, so mark as IN_QUEUE)
        bulkRefundBooking.setTotalRecords(totalRecords);
        bulkRefundBooking.setBulkRefundStatus(BulkRefundStatus.IN_QUEUE.name());
        logger.info("BulkRefundBooking updated to IN_QUEUE for bulkId: {}", bulkId);
        refundDao.saveBulkRefundBooking(bulkRefundBooking);
        int validRecords = 0;
        // Process each row, store in DB, and send to Kafka via Producer
        for (int row = 1; row <= totalRecords; row++) {
            // Build BulkRefundBookingDetails from CSV row

            BulkRefundBookingDetails bulkRefundBookingDetails = buildBulkRefundBookingDetails(bulkId, row, refundData.get(row));
            // Save to database
            bulkRefundBookingDetails = refundDao.saveBulkRefundBookingDetailsForRow(bulkRefundBookingDetails);

            // Send the ID to Kafka using Producer
            if (StringUtils.equals(bulkRefundBookingDetails.getRefundStatus(), RefundStatus.REFUND_IN_PROCESS.name())) {
                refundBookingDetailsProducer.publish("BOOKING_DETAILS", bulkRefundBookingDetails.getId().toString(), bulkRefundBookingDetails.getId());
                validRecords++;
                logger.info("Row {} with id {} queued for async processing for bulkId: {}", row, bulkRefundBookingDetails.getId(), bulkId);
            } else {
                logger.info("Row {} invalid for bulkId: {}", row, bulkId);
            }
        }
        // If no valid records, mark as PROCESSED
        if (validRecords == 0) {
            bulkRefundBooking.setValidRecords(0);
            bulkRefundBooking.setInvalidRecords(totalRecords);
            bulkRefundBooking.setBulkRefundStatus(BulkRefundStatus.PROCESSED.name());
            bulkRefundBooking.setRemark("Invalid rows");
            refundDao.saveBulkRefundBooking(bulkRefundBooking);
            logger.info("No valid rows for bulkId: {}. Status: PROCESSED.", bulkId);
        }

    }

    /**
     * Method called by Consumer to process each row
     *
     * @param bookingDetailsId UUID
     */
    public void processBulkRefundRow(UUID bookingDetailsId) {
        logger.info("Processing BulkRefundBookingDetails id: {}", bookingDetailsId);

        // Step-1: Fetch the BulkRefundBookingDetails
        BulkRefundBookingDetails details = refundDao.findBulkRefundBookingDetailsById(bookingDetailsId);
        // Step-2: Process the refund
        TransactionResponse<RefundResponse> bulkRefundResponse = bookBulkRefund(details);

        // Step-3: Update details based on response
        if (bulkRefundResponse.getStatus() == TransactionConstant.RESPONSE_SUCCESS) {
            logger.info("Refund booked successfully for row {} and bulkId: {}", details.getRowNumber(), details.getBulkId());
            details.setRefundStatus(BulkRefundRowStatus.SUCCESS.name());
            details.setRemark("Refund Booked Successfully");
        } else {
            logger.info("Refund booking failed for row {} and bulkId: {}", details.getRowNumber(), details.getBulkId());
            details.setRefundStatus(BulkRefundRowStatus.FAILED.name());
            details.setRemark(bulkRefundResponse.getErrors().getFirst().getErrorMessage());
        }

        // Step-4: Save updated details
        refundDao.saveBulkRefundBookingDetails(details);

        // Step-5: Update BulkRefundBooking status
        // Check if all rows are processed, then update BulkRefundBooking
        checkAndUpdateBulkRefundBooking(details.getBulkId());
    }

    /**
     * Update processing status
     *
     * @param bulkRefundBooking RefundBookRequest
     *
     */
    private void updateProcessingStatus(BulkRefundBooking bulkRefundBooking) {
        bulkRefundBooking.setBulkRefundStatus(BulkRefundStatus.PROCESSING.name());
        refundDao.saveBulkRefundBooking(bulkRefundBooking);
    }

    /**
     * Book refund for refund book request if refund is booked it returns status as success else failed
     *
     * @param details BulkRefundBookingDetails
     * Returns transactionResponse of RefundBookResponse
     */
    private TransactionResponse<RefundResponse> bookBulkRefund(BulkRefundBookingDetails details) {
        logger.info("Book refund received for atrn: {}", details.getAtrnNum());
        try {
            refundValidator.validateRefundRequest(details);
            //Build RefundBookRequest from details
            RefundBookRequest refundBookRequest = buildBulkRefundBookRequest(details);

            return bookRefundWithResponse(refundBookRequest);
        } catch (ValidationException e) { //refund booking failed for the row with validation exception
            logger.error("Book refund failed for row: {}", details.getRowNumber(),e.getErrorMessages().getFirst().getErrorMessage());
            return TransactionResponse.<RefundResponse>builder().status(TransactionConstant.RESPONSE_FAILURE).errors(List.of(ErrorDto.builder().errorCode(e.getErrorMessages().getFirst().getErrorCode()).errorMessage(e.getErrorMessages().getFirst().getErrorMessage()).build())).build();
        } catch (TransactionException e) { //refund booking failed for the row with handled exception
            logger.error("Book refund failed for row: {}", details.getRowNumber(),e.getErrorMessage());
            return TransactionResponse.<RefundResponse>builder().status(TransactionConstant.RESPONSE_FAILURE).errors(List.of(ErrorDto.builder().errorCode(e.getErrorCode()).errorMessage(e.getErrorMessage()).build())).build();
        } catch (NumberFormatException e) { //refund booking failed for the row with amount error
            logger.error("Book refund failed for row: {}", details.getRowNumber(),e.getMessage());
            return TransactionResponse.<RefundResponse>builder().status(TransactionConstant.RESPONSE_FAILURE).errors(List.of(ErrorDto.builder().errorCode(TransactionErrorConstants.INVALID_ERROR_CODE).errorMessage(MessageFormat.format(INVALID_ERROR_MESSAGE,REFUND_AMOUNT,INVALID_REFUND_AMOUNT)).build())).build();
        }catch (Exception e) { //refund booking failed for the row with generic error
            logger.error("Book refund failed for row: {}", details.getRowNumber(),e.getMessage());
            return TransactionResponse.<RefundResponse>builder().status(TransactionConstant.RESPONSE_FAILURE).errors(List.of(ErrorDto.builder().errorCode(TransactionErrorConstants.INVALID_ERROR_CODE).errorMessage(MessageFormat.format(INVALID_ERROR_MESSAGE,REFUND_REQUEST,INVALID_REFUND_ERROR)).build())).build();
        }

    }
    /**
     * Helper method to Build RefundBookRequest from details
     *
     * @param details BulkRefundBookingDetails
     * @return RefundBookRequest
     */
    private RefundBookRequest buildBulkRefundBookRequest(BulkRefundBookingDetails details) {
        BulkRefundBooking bulkRefundBooking = refundDao.findByBulkId(details.getBulkId());
        return RefundBookRequest.builder()
                .mId(bulkRefundBooking.getMerchantId())
                .refundType(details.getRefundType())
                .atrnNumber(details.getAtrnNum())
                .refundAmount(new BigDecimal(details.getRefundAmount()))
                .remark(details.getComments())
                .build();
    }

    /**
     * Creates List<String[]> from CSV file uploaded on S3 for bulk refund
     *
     * @param filePath String
     * Returns List of String Array
     */
    private List<String[]> readCsvFile(String filePath) {

        logger.info("Reading csv file for filePath: {}", filePath);

        List<String[]> records;

        try {

            ResponseBytes<?> fileBytes = s3Service.readFile(filePath);
            InputStreamReader reader = new InputStreamReader(fileBytes.asInputStream());
            CSVReader csvReader = new CSVReader(reader);
            records = csvReader.readAll();

        } catch (IOException | CsvException e) {

            logger.debug("Reading csv file failed for filePath: {}", filePath);
            throw new TransactionException(TransactionErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(TransactionErrorConstants.INVALID_ERROR_MESSAGE, "CSV", " Error while reading CSV file."));

        }
        logger.debug("Reading csv file done total size : {}, for filePath: {}", records.size(), filePath);
        return records;
    }

    /**
     * Builds bulk refund booking for erroneous csv file
     */
    private static void buildBulkRefundBookingWithError(BulkRefundBooking bulkRefundBooking, String headerError) {

        bulkRefundBooking.setTotalRecords(0);
        bulkRefundBooking.setInvalidRecords(0);
        bulkRefundBooking.setValidRecords(0);
        bulkRefundBooking.setBulkRefundStatus(BulkRefundStatus.PROCESSED.name());
        bulkRefundBooking.setRemark(headerError);
    }

    /**
     * Bulk refund details status for requested parameters
     *
     * @param mId String
     * @param pageable Pageable
     *
     * @return TransactionResponse with BulkRefundBookingDto
     */
    public TransactionResponse<BulkRefundBookingDto> getBulkRefundBooking(String mId, Pageable pageable) {
        logger.info("Get bulk refund request received for mId: {}", mId);
        refundValidator.validateMid(mId);
        //Step-1: Get Bulk refund request in db for requested parameters
        Page<BulkRefundBookingDto> refundBulkBookingDtoPage = refundDao.getBulkRefundBooking(mId, pageable);

        logger.debug("Bulk Refund Response received for mId: {}", mId);

        //Step-2: Build and return the bilk refund details response
        return TransactionResponse.<BulkRefundBookingDto>builder().status(TransactionConstant.RESPONSE_SUCCESS).data(refundBulkBookingDtoPage.getContent()).count((long) refundBulkBookingDtoPage.getContent().size()).total(refundBulkBookingDtoPage.getTotalElements()).build();
    }

    /**
     * Fetching list of bulk refund user and download the file in csv format
     * @param response {@link HttpServletResponse} To set refund list as csv file content.
     * @param  bulkId String
     * @param  status String
     */
    public void downloadBulkRefund(HttpServletResponse response, String bulkId, String status) {
        logger.info("Fetching list of bulk refund for bulkId: {} and status: {}", bulkId,status);
        refundValidator.validateDownloadBulkRefund(bulkId,status);
        List<BulkRefundBookingDetails> bulkRefundBookings = refundDao.getBulkRefundByBulkIdAndRefundStatus(bulkId,status);
        logger.info("Returning list of bulk refund bookings {}", CollectionUtils.size(bulkRefundBookings));
        List<List<Object>> fileData = bulkRefundBookings.stream().map(this::convertToListOfObject).toList();
        CSVGenerator.downloadCsvFile(response, "Bulk_Refund_"+status,bulkId, BULK_REFUND_HEADER_LIST, fileData);
        logger.info("Generated CSV file containing list of bulk refund bookings");
    }
    /**
     * Converting BulkRefundBookingDetails to List of its field values.
     *
     * @param bulkRefundBookingDetails {@link BulkRefundBookingDetails}
     * @return List
     */
    protected List<Object> convertToListOfObject(BulkRefundBookingDetails bulkRefundBookingDetails) {
        List<Object> objectList = new ArrayList<>();
        objectList.add(StringUtils.isEmpty(bulkRefundBookingDetails.getRefundType()) ? StringUtils.EMPTY : bulkRefundBookingDetails.getRefundType());
        objectList.add(StringUtils.isEmpty(bulkRefundBookingDetails.getMerchantOrderId()) ? StringUtils.EMPTY : bulkRefundBookingDetails.getMerchantOrderId());
        objectList.add(StringUtils.isEmpty(bulkRefundBookingDetails.getAtrnNum()) ? StringUtils.EMPTY : bulkRefundBookingDetails.getAtrnNum());
        objectList.add(Objects.isNull(bulkRefundBookingDetails.getRefundAmount()) ? StringUtils.EMPTY : bulkRefundBookingDetails.getRefundAmount());
        objectList.add(StringUtils.isEmpty(bulkRefundBookingDetails.getRefundCurrency()) ? StringUtils.EMPTY : bulkRefundBookingDetails.getRefundCurrency());
        objectList.add(StringUtils.isEmpty(bulkRefundBookingDetails.getComments()) ? StringUtils.EMPTY : bulkRefundBookingDetails.getComments());
        objectList.add(StringUtils.isEmpty(bulkRefundBookingDetails.getRefundStatus()) ? StringUtils.EMPTY : bulkRefundBookingDetails.getRefundStatus());
        objectList.add(StringUtils.isEmpty(bulkRefundBookingDetails.getRemark()) ? StringUtils.EMPTY : bulkRefundBookingDetails.getRemark());


        return objectList;
    }
    /**
     * Helper method to build BulkRefundBookingDetails from CSV row
     *
     * @param bulkId String
     * @param rowNumber int
     * @param rowData String[]
     * @return List
     */
    private BulkRefundBookingDetails buildBulkRefundBookingDetails(String bulkId, int rowNumber, String[] rowData) {
        // Validate row data: check for null and insufficient fields
        if (ObjectUtils.isEmpty(rowData) || rowData.length < CSV_MIN_VALUES_COUNT || rowData.length!=BULK_REFUND_HEADERS.split(",").length) {
            logger.warn("Invalid row for bulkId: {}, row: {}", bulkId, rowNumber);
            return createInvalidRow(bulkId, rowNumber,MessageFormat.format(INVALID_REFUND_ROW, CSV_MIN_VALUES_COUNT));
        }

        return BulkRefundBookingDetails.builder()
                .bulkId(bulkId)
                .rowNumber(rowNumber)
                .refundStatus(RefundStatus.REFUND_IN_PROCESS.name()) // Initial status
                .refundType(rowData[0]) // Refund Type
                .merchantOrderId(rowData[1]) // Merchant Ordeid
                .atrnNum(rowData[2]) // atrn
                .refundAmount(rowData[3]) // Refund Amount
                .refundCurrency(rowData[4]) // Refund Currency
                .comments(rowData[5]) // Commentss
                .remark(RefundStatus.REFUND_IN_PROCESS.name())
                .createdDate(DateTimeUtils.getCurrentTimeInMills())
                .build();
    }
    // Helper method for invalid rows
    private BulkRefundBookingDetails createInvalidRow(String bulkId, int rowNumber, String remark) {
        return BulkRefundBookingDetails.builder()
                .bulkId(bulkId)
                .rowNumber(rowNumber)
                .refundStatus(BulkRefundRowStatus.FAILED.name())
                .remark(remark)
                .build();
    }
    /**
     * Check if all rows are processed, then update BulkRefundBooking
     *
     * @param bulkId String
     */
    private void checkAndUpdateBulkRefundBooking(String bulkId) {
        BulkRefundBooking bulkRefundBooking = refundDao.findByBulkId(bulkId);
        int totalRecords = bulkRefundBooking.getTotalRecords();
        Object[] counts = refundDao.getProcessedAndFailedCounts(bulkId);
        Object[] indexCount=(Object[]) counts[0];
        // Extract counts from the result array
        int processedCount = ((Number) indexCount[0]).intValue(); // Total processed (pass + fail)
        int passCount = ((Number) indexCount[1]).intValue();     // CANCELLATION_BOOKED
        int failCount = ((Number) indexCount[2]).intValue();     // REFUND_FAILED

        if (processedCount == totalRecords) {
            bulkRefundBooking.setValidRecords(passCount);
            bulkRefundBooking.setInvalidRecords(failCount);
            bulkRefundBooking.setRemark(failCount > 0 ? PARTIAL_PROCESS_MESSAGE : SUCCESS_PROCESS_MESSAGE);
            bulkRefundBooking.setBulkRefundStatus(BulkRefundStatus.PROCESSED.name());

            refundDao.saveBulkRefundBooking(bulkRefundBooking);
            logger.info("All rows processed, updated BulkRefundBooking: {} for bulkId: {}", bulkRefundBooking, bulkId);
        } else {
            logger.info("Not all rows processed yet for bulkId: {}. Total: {}, Processed: {} (Pass: {}, Fail: {})",
                    bulkId, totalRecords, processedCount, passCount, failCount);
        }
    }

    public void downloadRefundBookings(HttpServletResponse response,RefundSearchRequest refundSearchRequest) {

        logger.info("Get refund request received for refundDetailRequest: {}", refundSearchRequest);

        //Step-1: Validate refund search request
        refundValidator.validateRefundSearchRequest(refundSearchRequest);

        //Step-2: Search refund request in db for requested parameters
        List<RefundBookingDto> refundBookings = refundDao.downloadRefundBookingRequest(refundSearchRequest);
        logger.debug("Refund Response received for refundDetailRequest: {}", refundSearchRequest);

        List<List<Object>> fileData = refundBookings.stream().map(this::convertToListOfObject).toList();

        //Step-3: Build and return the refund bookings data
        CSVGenerator.downloadCsvFile(response, "Refund_bookings",refundSearchRequest.getMId(), REFUND_BOOKINGS_HEADER_LIST, fileData);
    }

    /**
     * Converting RefundBookingDto to List of its field values.
     *
     * @param refundBookingDto {@link RefundBookingDto}
     * @return List
     */
    protected List<Object> convertToListOfObject(RefundBookingDto refundBookingDto) {
        List<Object> objectList = new ArrayList<>();
        objectList.add(StringUtils.isEmpty(refundBookingDto.getSbiOrderRefNumber()) ? StringUtils.EMPTY : refundBookingDto.getSbiOrderRefNumber());
        objectList.add(StringUtils.isEmpty(refundBookingDto.getAtrnNumber()) ? StringUtils.EMPTY : refundBookingDto.getAtrnNumber());
        objectList.add(StringUtils.isEmpty(refundBookingDto.getArrnNumber()) ? StringUtils.EMPTY : refundBookingDto.getArrnNumber());
        objectList.add(ObjectUtils.isEmpty(refundBookingDto.getCreatedDate()) ? StringUtils.EMPTY : DateTimeUtils.getDate(refundBookingDto.getCreatedDate(), DateTimeUtils.FORMATTER_DD_MM_YYYY));
        objectList.add(Objects.isNull(refundBookingDto.getRefundAmount()) ? StringUtils.EMPTY : refundBookingDto.getRefundAmount());
        objectList.add(ObjectUtils.isEmpty(refundBookingDto.getUpdatedDate()) ? StringUtils.EMPTY : DateTimeUtils.getDate(refundBookingDto.getUpdatedDate(), DateTimeUtils.FORMATTER_DD_MM_YYYY));
        objectList.add(StringUtils.isEmpty(refundBookingDto.getRefundType()) ? StringUtils.EMPTY : refundBookingDto.getRefundType());
        objectList.add(StringUtils.isEmpty(refundBookingDto.getRefundStatus()) ? StringUtils.EMPTY : refundBookingDto.getRefundStatus());
        return objectList;
    }

}