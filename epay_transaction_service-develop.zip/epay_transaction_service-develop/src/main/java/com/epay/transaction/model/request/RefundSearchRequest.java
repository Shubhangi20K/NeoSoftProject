package com.epay.transaction.model.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RefundSearchRequest {

    @NotBlank(message = "mId is required")
    @JsonProperty("mId")
    private String mId;
    private String atrnNumber;
    private String arrnNumber;
    private String sbiOrderRefNumber;
    private String refundStatus;
    private String refundType;
    private Long from;
    private Long to;

}
