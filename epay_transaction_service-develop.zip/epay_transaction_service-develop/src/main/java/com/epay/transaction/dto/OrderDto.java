package com.epay.transaction.dto;

import com.epay.transaction.util.enums.OrderStatus;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.*;

import java.math.BigDecimal;
import java.util.UUID;

/**
 * Class Name: OrderDto
 * *
 * Description: OrderDto class for Object made to transfer to Order reposiotry.
 * *
 * Author: V1012904(Shital suryawanshi)
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */


@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@JsonIgnoreProperties({"createdBy","updatedBy","createdDate","updatedDate"})
public class OrderDto extends BaseDto {
    @JsonProperty("mId")
    private String mId;
    private String customerId;
    private String currencyCode;
    private BigDecimal orderAmount;
    private String orderRefNumber;
    private String sbiOrderRefNumber;
    private OrderStatus status;
    private JsonNode otherDetails;
    private Long expiry;
    private JsonNode multiAccounts;
    private String paymentMode;
    private String orderHash;
    private String returnUrl;
    private String transactionUrl;
    private Integer orderRetryCount;
    private JsonNode thirdPartyDetails;
}
