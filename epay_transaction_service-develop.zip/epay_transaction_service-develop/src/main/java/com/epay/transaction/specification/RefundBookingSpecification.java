package com.epay.transaction.specification;

import com.epay.transaction.entity.RefundBooking;
import com.epay.transaction.model.request.RefundSearchRequest;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import lombok.experimental.UtilityClass;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.util.StringUtils;

@UtilityClass
public class RefundBookingSpecification {

    public static Specification<RefundBooking> searchRefund(RefundSearchRequest refundSearchRequest) {

        return (root, query, criteriaBuilder) -> {

            Predicate predicate = criteriaBuilder.conjunction();
            predicate = criteriaBuilder.and(predicate, getMidPredicate(root, criteriaBuilder, refundSearchRequest.getMId()));

            if (StringUtils.hasText(refundSearchRequest.getArrnNumber())) {
                predicate = criteriaBuilder.and(predicate, getArrnPredicate(root, criteriaBuilder, refundSearchRequest.getArrnNumber()));
            }

            if (StringUtils.hasText(refundSearchRequest.getAtrnNumber())) {
                predicate = criteriaBuilder.and(predicate, getAtrnPredicate(root, criteriaBuilder, refundSearchRequest.getAtrnNumber()));
            }

            if (StringUtils.hasText(refundSearchRequest.getSbiOrderRefNumber())) {
                predicate = criteriaBuilder.and(predicate, getSbiOrderRefNumberPredicate(root, criteriaBuilder, refundSearchRequest.getSbiOrderRefNumber()));
            }

            if (StringUtils.hasText(refundSearchRequest.getRefundStatus())) {
                predicate = criteriaBuilder.and(predicate, getRefundStatusPredicate(root, criteriaBuilder, refundSearchRequest.getRefundStatus()));
            }

            if (StringUtils.hasText(refundSearchRequest.getRefundType())) {
                predicate = criteriaBuilder.and(predicate, getRefundTypePredicate(root, criteriaBuilder, refundSearchRequest.getRefundType()));
            }

            if (ObjectUtils.isNotEmpty(refundSearchRequest.getFrom())) {
                predicate = criteriaBuilder.and(predicate, getFromDatePredicate(root, criteriaBuilder, refundSearchRequest.getFrom()));
            }

            if (ObjectUtils.isNotEmpty(refundSearchRequest.getTo())) {
                predicate = criteriaBuilder.and(predicate, getToDatePredicate(root, criteriaBuilder, refundSearchRequest.getTo()));
            }

            return predicate;
        };
    }

    private static Predicate getMidPredicate(Root<RefundBooking> root, CriteriaBuilder criteriaBuilder, String mId) {
        return criteriaBuilder.equal(root.get("mId"), mId);
    }

    private static Predicate getArrnPredicate(Root<RefundBooking> root, CriteriaBuilder criteriaBuilder, String arrnNumber) {
        return criteriaBuilder.like(criteriaBuilder.lower(root.get("arrnNum")), "%" + arrnNumber.toLowerCase() + "%");
    }

    private static Predicate getAtrnPredicate(Root<RefundBooking> root, CriteriaBuilder criteriaBuilder, String atrnNumber) {
        return criteriaBuilder.like(criteriaBuilder.lower(root.get("atrnNum")), "%" + atrnNumber.toLowerCase() + "%");
    }

    private static Predicate getSbiOrderRefNumberPredicate(Root<RefundBooking> root, CriteriaBuilder criteriaBuilder, String sbiOrderRefNumber) {
        return criteriaBuilder.like(criteriaBuilder.lower(root.get("sbiOrderRefNumber")), "%" + sbiOrderRefNumber.toLowerCase() + "%");
    }

    private static Predicate getRefundTypePredicate(Root<RefundBooking> root, CriteriaBuilder criteriaBuilder, String refundType) {
        return criteriaBuilder.like(criteriaBuilder.lower(root.get("refundType")), "%" + refundType.toLowerCase() + "%");
    }

    private static Predicate getRefundStatusPredicate(Root<RefundBooking> root, CriteriaBuilder criteriaBuilder, String refundStatus) {
        return criteriaBuilder.like(criteriaBuilder.lower(root.get("refundStatus")), "%" + refundStatus.toLowerCase() + "%");
    }

    private static Predicate getFromDatePredicate(Root<RefundBooking> root, CriteriaBuilder criteriaBuilder, Long fromDate) {
        return criteriaBuilder.greaterThanOrEqualTo(root.get("createdDate"), fromDate);
    }

    private static Predicate getToDatePredicate(Root<RefundBooking> root, CriteriaBuilder criteriaBuilder, Long toDate) {
        return criteriaBuilder.lessThanOrEqualTo(root.get("createdDate"), toDate);
    }

}