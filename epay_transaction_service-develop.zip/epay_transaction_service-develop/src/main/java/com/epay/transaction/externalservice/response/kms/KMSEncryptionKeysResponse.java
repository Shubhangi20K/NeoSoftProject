package com.epay.transaction.externalservice.response.kms;

import lombok.Builder;
import lombok.Data;


/**
 * Class Name: KMSEncryptionKeysResponse
 * <p>
 * Description: This class defines the response structure for KMS encryption keys,
 * ensuring null fields are excluded during JSON serialization.
 * <p>
 * Author: V1018217
 * Copyright (c) 2024 State Bank of India
 * All rights reserved.
 * <p>
 * Version: 1.0
 */
@Data
@Builder
public class KMSEncryptionKeysResponse {
    private String mek;
    private String kek;
    private String aek;
}
