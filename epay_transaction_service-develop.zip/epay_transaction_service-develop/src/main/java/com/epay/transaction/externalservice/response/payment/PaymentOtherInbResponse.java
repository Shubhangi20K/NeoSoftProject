package com.epay.transaction.externalservice.response.payment;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

/**
 * Class Name:OtherInbDto
 * *
 * Description:
 * *
 * Author:v1018400(Ranjan Kumar)
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Builder
public class PaymentOtherInbResponse {
    private String atrn;
    private String postURL;
    @JsonProperty(value = "EncryptTrans")
    private String encryptTrans;
    @JsonProperty(value = "EncryptpaymentDetails")
    private String encryptPaymentDetails;
    private String merchIdVal;
}

