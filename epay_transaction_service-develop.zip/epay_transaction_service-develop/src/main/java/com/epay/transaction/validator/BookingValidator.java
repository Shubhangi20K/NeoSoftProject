package com.epay.transaction.validator;

import com.epay.transaction.dao.CustomerDao;
import com.epay.transaction.dao.MerchantOrderPaymentDao;
import com.epay.transaction.dto.OrderDto;
import com.epay.transaction.exceptions.TransactionException;
import com.epay.transaction.exceptions.ValidationException;
import com.epay.transaction.util.DateTimeUtils;
import com.epay.transaction.util.EPayIdentityUtil;
import com.epay.transaction.util.TransactionErrorConstants;
import com.epay.transaction.util.enums.OrderStatus;
import com.epay.transaction.util.enums.TransactionStatus;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.stereotype.Component;

import java.text.MessageFormat;
import java.util.List;

/**
 * Class Name: BookingValidator
 * *
 * Description: Validates merchant booking details .
 * *
 * Author: V1018212
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Component
@RequiredArgsConstructor
public class BookingValidator extends BaseValidator {
    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private final MerchantOrderPaymentDao merchantOrderPaymentDao;
    private final CustomerDao customerDao;

    /**
     * Method name : bookingValidation
     * Description : Validates values of transaction booking request
     * @param orderDto : Object of OrderDto
     */
    public void bookingValidation(OrderDto orderDto) {
        logger.debug("Merchant order booking validation started");
        //1: sbi order ref id validation
        if (!EPayIdentityUtil.getUserPrincipal().getOrderRef().equals(orderDto.getSbiOrderRefNumber())) {
            throw new ValidationException(TransactionErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(TransactionErrorConstants.INVALID_ERROR_MESSAGE, "Order", "Authentication failed at order verification"));
        }
        logger.info("sbiOrderRefNumber validation completed");

        //2: order expiry validation
        if (ObjectUtils.isNotEmpty(orderDto.getExpiry()) && DateTimeUtils.isPastDate(orderDto.getExpiry())) {
            throw new ValidationException(TransactionErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(TransactionErrorConstants.INVALID_ERROR_MESSAGE, "Order", "Order is Expired"));
        }
        logger.info("orderExpiry validation completed");

        //3: order paid/failed validation
        if (OrderStatus.PAID.equals(orderDto.getStatus()) || OrderStatus.FAILED.equals(orderDto.getStatus())) {
            throw new ValidationException(TransactionErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(TransactionErrorConstants.INVALID_ERROR_MESSAGE, "Order", "Order status is invalid."));
        }
        logger.info("Order paid validation completed");

        //4: order expired validation
        if (OrderStatus.EXPIRED.equals(orderDto.getStatus())) {
            throw new ValidationException(TransactionErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(TransactionErrorConstants.INVALID_ERROR_MESSAGE, "Order", "Order is Expired."));
        }
        logger.info("Order expired validation completed");

        //5: attempt limit validation
        if (OrderStatus.ATTEMPT_FAIL.equals(orderDto.getStatus())) {
            throw new ValidationException(TransactionErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(TransactionErrorConstants.INVALID_ERROR_MESSAGE, "Order", "Too many attempts. Attempt limit exceeded."));
        }
        logger.info("Attempt limit validation completed");

        //6: transaction status validation
        if (merchantOrderPaymentDao.validatedMerchantOrderPaymentForBooking(orderDto.getSbiOrderRefNumber(), List.of(TransactionStatus.BOOKED.name(), TransactionStatus.PAYMENT_INITIATION_START.name(), TransactionStatus.PAYMENT_IN_VERIFICATION.name(), TransactionStatus.PAYMENT_VERIFIED.name(), TransactionStatus.PENDING.name()))) {
            throw new ValidationException(TransactionErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(TransactionErrorConstants.INVALID_ERROR_MESSAGE, "Order State", "Duplicate request for Order."));
        }
        logger.info("Transaction status validation completed");

        //7: customer id validation
        if (ObjectUtils.isNotEmpty(orderDto.getCustomerId()) && Boolean.FALSE.equals(customerDao.existsByCustomerId(orderDto.getCustomerId(), orderDto.getMId()))) {
            throw new TransactionException(TransactionErrorConstants.NOT_FOUND_ERROR_CODE, MessageFormat.format(TransactionErrorConstants.NOT_FOUND_ERROR_MESSAGE, "Valid Customer"));
        }

        logger.info("Customer id validation completed");

        logger.debug("Order Booking Validation ends");
    }

}
