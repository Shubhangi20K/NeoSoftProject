package com.epay.transaction.externalservice.response.eis.ecom;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;


@Data
public class ChannelDetail{
    @JsonProperty("Flag")
    public String flag;
    @JsonProperty("mLimit")
    public String mLimit;
    @JsonProperty("cId")
    public String cId;
    @JsonProperty("eLimit")
    public String eLimit;
    @JsonProperty("ExpDate")
    public String expDate;

}





