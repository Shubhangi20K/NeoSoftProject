package com.epay.transaction.externalservice.request.payment;

import lombok.Builder;
import lombok.Data;

/**
 * Class Name:PaymentOtherINBReqest
 * *
 * Description:
 * *
 * Author:V1014352(Ranjan Kumar)
 * <p>
 * Copyright (c) 2025 [State Bank of INdia]
 * All right reserved
 * *
 * Version:1.0
 */
@Data
@Builder
public class PaymentOtherINBReqest {
    private String atrn;
}
