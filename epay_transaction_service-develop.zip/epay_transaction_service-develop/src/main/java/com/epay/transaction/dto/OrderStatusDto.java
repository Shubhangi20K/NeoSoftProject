package com.epay.transaction.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.math.BigDecimal;

import static com.epay.transaction.util.TransactionErrorConstants.*;

/**
 * Class Name: OrderStatusDto
 * *
 * Description:This class is used to map encrypted request to transaction verification dto.
 * Author: Gireesh M
 * Copyright (c) 2025 [State Bank of India]
 * ALl rights reserved
 * *
 * Version: 1.0
 */
@Data
@RequiredArgsConstructor
public class OrderStatusDto {
    private String orderRefNumber;
    @NotNull(message = ORDER_AMOUNT_IS_REQUIRED)
    private BigDecimal orderAmount;
    private String sbiOrderRefNumber;
    private String atrnNumber;
}
