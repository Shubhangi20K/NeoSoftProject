package com.epay.transaction.util.enums;

import com.epay.transaction.exceptions.TransactionException;

import java.text.MessageFormat;
import java.util.Arrays;

import static com.epay.transaction.util.TransactionErrorConstants.INVALID_ERROR_CODE_NO_REASON;
import static com.epay.transaction.util.TransactionErrorConstants.INVALID_ERROR_MESSAGE_NO_REASON;

public enum ReportFormat {
    CSV, XLS, PDF;

    /**
     * Returns the ReportFormat enum corresponding to the provided name (case-insensitive).
     *
     * @param name The name of the format.
     * @return Corresponding ReportFormat enum.
     */
    public static ReportFormat getName(String name) {
        return Arrays.stream(values()).filter(rt -> rt.name().equalsIgnoreCase(name)).findFirst().orElseThrow(() -> new TransactionException(INVALID_ERROR_CODE_NO_REASON, MessageFormat.format(INVALID_ERROR_MESSAGE_NO_REASON, "ReportFormat", name)));
    }
}
