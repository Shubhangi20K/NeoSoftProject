package com.epay.transaction.mapper;
/*
 * Copyright (c) [2024] [State Bank of India]
 * All rights reserved.
 * <p>
 * Author:@V0000001(Shilpa Kothre)
 * Version:1.0
 */

import com.epay.transaction.dto.OrderDto;
import com.epay.transaction.dto.OrderInfoDto;
import com.epay.transaction.dto.PaymentInfoDto;
import com.epay.transaction.entity.Order;
import com.epay.transaction.entity.MerchantOrderPayment;
import com.epay.transaction.exceptions.TransactionException;
import com.epay.transaction.model.response.OrderStatusResponse;
import com.epay.transaction.util.TransactionErrorConstants;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.lang3.ObjectUtils;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Named;

import java.text.MessageFormat;

@Mapper(builder = @Builder(disableBuilder = true), componentModel = "spring")
public interface OrderMapper {

    @Mapping(source = "multiAccounts", target = "multiAccounts", qualifiedByName = "jsonNodeToStr")
    @Mapping(source = "otherDetails", target = "otherDetails", qualifiedByName = "jsonNodeToStr")
    @Mapping(source = "thirdPartyDetails", target = "thirdPartyDetails", qualifiedByName = "jsonNodeToStr")
    Order dtoToEntity(OrderDto orderDto);

    @Mapping(source = "multiAccounts", target = "multiAccounts", qualifiedByName = "strToJsonNode")
    @Mapping(source = "otherDetails", target = "otherDetails", qualifiedByName = "strToJsonNode")
    @Mapping(source = "thirdPartyDetails", target = "thirdPartyDetails", qualifiedByName = "strToJsonNode")
    OrderDto entityToDto(Order order);

    //Map Order to OrderInfoDto
    @Mapping(source = "sbiOrderRefNumber", target = "sbiOrderId")
    @Mapping(source = "orderRefNumber", target = "merchantOrderNumber")
    @Mapping(source = "status", target = "orderStatus")
    @Mapping(source = "currencyCode", target = "currency")
    OrderInfoDto merchantOrderToOrderInfoDto(Order order);

    //Map MerchantOrderPayment to PaymentInfoDto
    @Mapping(source = "atrnNumber", target = "atrn")
    @Mapping(source = "debitAmount", target = "totalAmount")
    @Mapping(source = "channelBank", target = "bankName")
    @Mapping(source = "currencyCode", target = "processor")
    @Mapping(source = "createdDate", target = "transactionTime")
    PaymentInfoDto merchantOrderToOrderInfoDto(MerchantOrderPayment merchantOrderPayment);

    @Mapping(source = "order", target = "orderInfo")
    @Mapping(source = "order.merchantOrderPayments", target = "paymentInfo")
    OrderStatusResponse mapMerchantOrderToResponse(Order order);

    @Named("jsonNodeToStr")
    default String jsonNodeToStr(JsonNode jsonNode) {
        return ObjectUtils.isNotEmpty(jsonNode) ? jsonNode.toString() : null;
    }

    @Named("strToJsonNode")
    default JsonNode strToJsonNode(String jsonStr) {
        JsonNode jsonNode = null;
        if (ObjectUtils.isNotEmpty(jsonStr)) {
            try {
                jsonNode = new ObjectMapper().readValue(jsonStr, JsonNode.class);
            } catch (JsonProcessingException e) {
                throw new TransactionException(TransactionErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(TransactionErrorConstants.INVALID_ERROR_MESSAGE, jsonStr, "Format is not parsable"));
            }
        }
        return jsonNode;
    }

}
