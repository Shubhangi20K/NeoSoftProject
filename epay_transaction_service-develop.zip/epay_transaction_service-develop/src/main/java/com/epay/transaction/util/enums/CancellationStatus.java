package com.epay.transaction.util.enums;

public enum CancellationStatus {
}
