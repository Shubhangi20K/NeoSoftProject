package com.epay.transaction.etl.listener;

import com.epay.transaction.dto.ReconDataDto;
import com.epay.transaction.exceptions.TransactionException;
import com.epay.transaction.service.ReconSettlementService;
import com.epay.transaction.util.TransactionUtil;
import com.epay.transaction.util.enums.InterfaceType;
import com.sbi.epay.authentication.util.EPayAuthenticationConstant;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.MDC;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import java.util.UUID;

import static com.epay.transaction.util.EventMessageUtils.buildEventErrorLog;
import static com.epay.transaction.util.EventMessageUtils.buildEventReceivedLog;

/**
 * Class Name:ReconUnmatchedRecordListener
 * <p>
 * Description: Consume Unmatched records file details data from recon producer.
 * <p>
 * Copyright (c) [2025] [State Bank of India]
 * All rights reserved.
 * <p>
 * Author:@V0000001(Shilpa Kothre)
 * Version:1.0
 */
@Component
@RequiredArgsConstructor
public class ReconUnmatchedRecordListener {

    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private final ReconSettlementService reconSettlementService;
    private final ApplicationEventPublisher publisher;

    @KafkaListener(topics = "${spring.kafka.topic.transaction.recon.record.unmatched}")
    public void processingUnMatchedTransaction(ConsumerRecord<String, String> consumerRecord) {
        MDC.put(EPayAuthenticationConstant.CORRELATION_ID, String.valueOf(UUID.randomUUID()));
        MDC.put(EPayAuthenticationConstant.SCENARIO, "ReconUnmatchedRecordListener");
        MDC.put(EPayAuthenticationConstant.OPERATION, "processUnmatchedRecordDetails");
        logger.info("Received Kafka message request received for key : {} and value : {}", consumerRecord.key(), consumerRecord.value());
        try {
            publisher.publishEvent(buildEventReceivedLog(InterfaceType.TXN_RECON_RECORD_UNMATCHED_TOPIC, consumerRecord));
            ReconDataDto reconDataDTO = TransactionUtil.parseStringToObject(consumerRecord.value(), value -> ReconDataDto.builder().atrnNum(value[0]).bankRefNumber(value[1]).rfId(value[2]).rfdId(value[3]).build(), ":");
            reconSettlementService.processingUnMatchedTransaction(reconDataDTO);
        } catch (TransactionException e) {
            publisher.publishEvent(buildEventErrorLog(InterfaceType.TXN_RECON_RECORD_UNMATCHED_TOPIC, consumerRecord, e.getErrorMessage()));
            logger.error("Error during List for Unmatched Atrns  kafka listening message[key:{} and value: {}], error: {}", consumerRecord.key(), consumerRecord.value(), e.getErrorMessage());
        } catch (Exception e) {
            publisher.publishEvent(buildEventErrorLog(InterfaceType.TXN_RECON_RECORD_UNMATCHED_TOPIC, consumerRecord, e.getMessage()));
            logger.error("Error during List for Unmatched Atrns  kafka listening message[key:{} and value: {}], error: {}", consumerRecord.key(), consumerRecord.value(), e.getMessage());
        }
    }

}
