package com.epay.transaction.entity.event.audit;


import jakarta.persistence.*;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.SuperBuilder;

import java.util.UUID;

/**
 * Class Name:EventReceivedLog
 * <p>
 * Description: saving received log
 * <p>
 * Copyright (c) [2025] [State Bank of India]
 * All rights reserved.
 * <p>
 * Author:@V0000001(Shilpa Kothre)
 * Version:1.0
 */
@EqualsAndHashCode(callSuper = true)
@Entity(name = "EVENT_RECEIVED_LOG")
@SuperBuilder
@Data
public class EventReceivedLog extends BaseEvent {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(columnDefinition = "RAW(16)")
    private UUID erlId;
}
