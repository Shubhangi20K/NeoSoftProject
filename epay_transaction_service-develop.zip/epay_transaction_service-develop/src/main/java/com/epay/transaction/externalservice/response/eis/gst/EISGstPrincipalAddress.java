package com.epay.transaction.externalservice.response.eis.gst;
/*
 * Copyright (c) [2024] [State Bank of India]
 * All rights reserved.
 *
 * Author:@author Shilpa Kothre
 */

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class EISGstPrincipalAddress {

    @JsonProperty("addr")
    private Object address;

}
