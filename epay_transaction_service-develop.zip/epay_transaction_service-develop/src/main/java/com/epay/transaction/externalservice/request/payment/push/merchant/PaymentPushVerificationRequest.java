package com.epay.transaction.externalservice.request.payment.push.merchant;

import lombok.Builder;
import lombok.Data;

/**
 * Class Name: PaymentPushVerificationRequest
 * *
 * Description: The class is used to create request for merchant push verification.
 * *
 * Author: Gireesh M
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Data
@Builder
public class PaymentPushVerificationRequest {
    private String encryptedPushVerificationRequest;
}
