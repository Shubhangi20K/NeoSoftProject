package com.epay.transaction.externalservice;


import com.epay.transaction.client.ApiClient;
import com.epay.transaction.exceptions.TransactionException;
import com.epay.transaction.externalservice.response.eis.ecom.EISResponse;
import com.epay.transaction.externalservice.response.eis.ecom.GSTResponse;
import com.epay.transaction.externalservice.response.eis.gst.EISGstResponse;
import com.epay.transaction.model.response.TransactionResponse;
import com.epay.transaction.util.TransactionErrorConstants;
import com.epay.transaction.util.dcms.eis.DCMSEISEncryptionDecryptionUtil;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.MediaType;
import reactor.core.publisher.Mono;

import java.net.URI;
import java.text.MessageFormat;

/**
 * EISServicesClient is responsible for retrieves the E-commerce flag status for a given card number
 * and retrieves GST details for a given card number.
 * Copyright (c) [2024] [State Bank of India]
 * All rights reserved.
 * <p>
 * Author:@V0000001(Shubhangi Kurelay)
 * Version:1.0
 */


public class EISServicesClient extends ApiClient {
    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    @Value("${external.api.services.endpoint.dcms}")
    private String DCMS_API_ENDPOINT ;
    @Value("${external.api.services.endpoint.gst}")
    private String GST_API_ENDPOINT ;
    @Value("${external.api.services.endpoint.clientCode}")
    private String CLIENT_CODE ;
    @Value("${external.api.services.endpoint.gstin}")
    private String GSTIN ;


    private final ObjectMapper objectMapper;

    /**
     * Constructor to initialize EISServicesClient with base URL.
     *
     * @param baseUrl    Base URL of the admin service.
     * @param corsOrigin:
     */
    public EISServicesClient(String baseUrl, ObjectMapper objectMapper, String corsOrigin) {
        super(baseUrl, corsOrigin);
        this.objectMapper = objectMapper;
    }

    /**
     * Retrieves the E-commerce flag status for a given card number.
     *
     * @return a {@link TransactionResponse} containing the E-commerce flag status
     */
    public EISResponse getCardEComFlag(String aesKey, String eisEncryptionKey, String eisEComRequest) {
        logger.info("EisEComRequest uri: {}", eisEComRequest);
        URI uri = URI.create(getBaseUrl() + DCMS_API_ENDPOINT);
        logger.info("EIS uri: {}", uri);
        String eisResponseString = getWebClient().post().uri(uri)
                .header("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                .header("Accept",MediaType.APPLICATION_JSON_VALUE)
                .header("AccessToken", eisEncryptionKey).bodyValue(eisEComRequest).retrieve()
                        .onStatus(httpStatusCode -> httpStatusCode.is4xxClientError() || httpStatusCode.is5xxServerError(),
                                clientResponse -> Mono.error(new TransactionException(TransactionErrorConstants.EXTERNAL_SERVICE_ERROR_CODE, MessageFormat.format(TransactionErrorConstants.EXTERNAL_SERVICE_ERROR_MESSAGE, "EIS Service")))).bodyToMono(new ParameterizedTypeReference<String>() {
        }).block();
        return getEISEComResponse(aesKey, eisResponseString);
    }

    /**
     * Retrieves GST details for a given card number.
     *
     * @return a {@link TransactionResponse} containing the GST details
     */
    public GSTResponse getGstInDetails(String aesKey, String eisEncryptionKey, String eisGstRequest, String gstNumber) {
        logger.info("EisGstRequest: {}",eisGstRequest);
        URI uri = URI.create(getBaseUrl() + GST_API_ENDPOINT);
        logger.info("EIS uri: {}", uri);
        String eisGSTResponseString =   getWebClient().post()
                .uri(uri)
                .header("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                .header("Accept", MediaType.APPLICATION_JSON_VALUE)
                .header("AccessToken", eisEncryptionKey)
                .header("Client_code", CLIENT_CODE)
                .header("Gst_in", GSTIN)
                .bodyValue(eisGstRequest)
                .retrieve()
                .onStatus(
                        httpStatus -> httpStatus.is4xxClientError() || httpStatus.is5xxServerError(),
                        clientResponse -> clientResponse.bodyToMono(String.class).flatMap(errorBody -> {
                            logger.error("EIS Service call failed with status: {}, error body: {}",
                                    clientResponse.statusCode().value(), errorBody); // 👈 log status & body
                            return Mono.error(new TransactionException(
                                    TransactionErrorConstants.EXTERNAL_SERVICE_ERROR_CODE,
                                    MessageFormat.format(TransactionErrorConstants.EXTERNAL_SERVICE_ERROR_MESSAGE, "EIS Service")
                            ));
                        })
                )
                .bodyToMono(new ParameterizedTypeReference<String>() {})
                .block();
        logger.info("Gstin response:{}",eisGSTResponseString);
        return getEISGstResponse(aesKey, eisGSTResponseString);
    }

    private EISResponse getEISEComResponse(String aesKey, String eisResponseString) {
        try {
            EISResponse eisResponse = objectMapper.readValue(eisResponseString, EISResponse.class);
            logger.info("EISGstResponse Data :{} " + eisResponse);
            String eisDecryptedResponse = DCMSEISEncryptionDecryptionUtil.decrypt(eisResponse.getEncryptedResponse(), aesKey);
            logger.info("Decrypt Response Data : {}" + eisDecryptedResponse);
            return objectMapper.readValue(eisDecryptedResponse, EISResponse.class);
        } catch (JsonProcessingException e) {
            logger.error("Error in creating EISEComResponse {} response {}", e.getMessage(), eisResponseString);
            throw new TransactionException(TransactionErrorConstants.JSON_ERROR_CODE, MessageFormat.format(TransactionErrorConstants.JSON_ERROR_MESSAGE, eisResponseString));
        }
    }

    private GSTResponse getEISGstResponse(String aesKey, String eisGSTResponseString) {
        try {
            logger.debug("GST eisGstResponse : {},aesKey:{}", eisGSTResponseString,aesKey);
            EISGstResponse eisGstResponse = objectMapper.readValue(eisGSTResponseString, EISGstResponse.class);
            logger.info("GST eisGstResponse : {}", eisGstResponse);
            String decryptResponse = DCMSEISEncryptionDecryptionUtil.decryptgst(eisGstResponse.getEncryptedResponse(), aesKey);
            logger.info("GST decryptResponse : {}", decryptResponse);
            return objectMapper.readValue(decryptResponse, GSTResponse.class);
        } catch (JsonProcessingException e) {
            logger.error("Error in creating EISGstResponse {}  error is :{}", eisGSTResponseString,e.getMessage());
            throw new TransactionException(TransactionErrorConstants.JSON_ERROR_CODE, MessageFormat.format(TransactionErrorConstants.JSON_ERROR_MESSAGE, eisGSTResponseString));
        }
    }

}


