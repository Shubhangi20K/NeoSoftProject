package com.epay.transaction.controller;

import com.epay.transaction.dto.ReconDataDto;
import com.epay.transaction.model.request.DeviceDetailsRequest;
import com.epay.transaction.model.response.TransactionResponse;
import com.epay.transaction.model.response.TransactionTokenResponse;
import com.epay.transaction.service.ReconSettlementService;
import com.epay.transaction.service.TokenService;
import com.epay.transaction.util.TransactionUtil;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static com.epay.transaction.util.TransactionConstant.*;

/**
 *  Class Name:TokenController
 * <p>
 *  Description: Token Generation
 * <p>
 * Copyright (c) [2024] [State Bank of India]
 * All rights reserved.
 * <p>
 * Author:@V0000001(Shilpa Kothre)
 * Version:1.0
 */
@RestController
@RequiredArgsConstructor
@Validated
@RequestMapping("/token")
public class TokenController {

    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private final TokenService tokenService;
    private final ReconSettlementService reconSettlementService;

    /**
     * Method name : generateAccessToken
     * Description : Creates the Access Token
     * @param merchantApiKeyId : ApiKeyId for Merchant
     * @param merchantApiKeySecret: ApiKeySecret for Merchant
     * @return String of AccessToken
     */
    @PostMapping("/access")
    @Operation(summary = "Access Token generation API")
    public TransactionResponse<String> generateAccessToken(@RequestHeader(name = MERCHANT_API_KEY_ID, defaultValue = StringUtils.EMPTY) String merchantApiKeyId, @RequestHeader(name = MERCHANT_API_KEY_SCRT, defaultValue = StringUtils.EMPTY) String merchantApiKeySecret) {
        logger.info("Request to generate access token");
        return tokenService.generateAccessToken(merchantApiKeyId, merchantApiKeySecret);
    }

    /**
     * Method name : generateTransactionToken
     * Description : Creates the Transaction Token
     * @param orderHash : Defines Unique Order
     * @param deviceDetailsRequest: Object of deviceDetailsRequest
     * @return object of TransactionTokenResponse
     */
    @PostMapping("/txn/{orderHash}")
    @Operation(summary = "Transaction Token generation API")
    public TransactionResponse<TransactionTokenResponse> generateTransactionToken(@RequestHeader("X-Referrer") String businessUrl, HttpServletRequest request, @PathVariable("orderHash") String orderHash, @RequestBody DeviceDetailsRequest deviceDetailsRequest) {
        logger.info("Request to generate transaction token for orderHash {}", orderHash);
        return tokenService.generateTransactionToken(businessUrl, orderHash, deviceDetailsRequest, request.getRemoteAddr());
    }

    /**
     * Method name : invalidateToken
     * Description : Invalidate active Token
     * @return String of Invalidated token
     */
    @PostMapping("/invalidate")
    @Operation(summary = "API for invalidate the token")
    public TransactionResponse<String> invalidateToken(@RequestHeader("Authorization") String token) {
        logger.info("Request to Invalidate Token");
        return tokenService.invalidateToken(token);
    }

    /**
     * Validates the token to ensure it is valid. This method can be used for ensuring that
     * a token is still active and not expired during operations that require authentication.
     *
     * @return A TransactionResponse with a status indicating success or failure of token validation.
     */
    @GetMapping("/access/validate")
    @PreAuthorize("hasAnyRole('ACCESS')")
    @Operation(summary = "Access token validation", description = "Validates the access token provided in the authorization header.")
    public TransactionResponse<String> validateToken(){
        logger.info("Received request for Access Token Validation");
        return TransactionResponse.<String>builder().status(RESPONSE_SUCCESS).data(List.of("Access Token validated successfully.")).build();
    }

}
