package com.epay.transaction.externalservice;


import com.epay.transaction.client.ApiClient;
import com.epay.transaction.externalservice.request.admin.*;
import com.epay.transaction.externalservice.response.admin.*;
import com.epay.transaction.model.response.TransactionResponse;
import com.fasterxml.jackson.databind.JsonNode;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import org.springframework.core.ParameterizedTypeReference;

/**
 * Class Name: AdminServicesClient
 * *
 * AdminServicesClient is responsible for interacting with the admin service APIs
 * to fetch and validate merchant-related details.
 * Author: Shubhangi kurlay
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
public class AdminServicesClient extends ApiClient {

    public static final String GET_MULTI_ACCOUNT = "/merchant/account/";
    private static final String MERCHANT = "/merchant/";
    private static final String MERCHANT_CONFIG_DETAILS_ENDPOINT = "/merchant/gateway";
    private static final String PRICING_API_ENDPOINT = "/merchant/pricing";
    private static final String VVL_API_ENDPOINT = "/merchant/vvl/";
    private static final String BIN_CHECK_ENDPOINT = "/card/validate";
    private static final String MERCHANT_PAYMODE_ENDPOINT = "/merchant/payMode/";
    private static final String GET_RFC_DETAILS = "/merchant/rfc/";
    private static final String CURRENCY_CHK_ENDPOINT = "/merchant/validate/currency";
    private static final String MERCHANT_NOTIFICATION_ENDPOINT = "/merchant/notification/";
    private static final String CHANNEL_BANK_ENDPOINT = "/merchant/validate/channelBank";
    private static final String POSTAL_CODE_ENDPOINT = "/bank/postalcode/";
    private static final String IFSC_CODE_ENDPOINT = "/bank/";
    private static final String EMPTY_JSON = "{}";

    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());

    /**
     * Constructor to initialize AdminServicesClient with the base URL.
     *
     * @param baseUrl    API base URL
     * @param corsOrigin String
     */
    public AdminServicesClient(String baseUrl, String corsOrigin) {
        super(baseUrl, corsOrigin);
    }

    /**
     * Fetches merchant information by merchant ID.
     *
     * @param mId Merchant ID
     * @return Transaction response containing merchant information
     */
    public TransactionResponse<MerchantInfoResponse> getMerchantInfoByMId(String mId) {
        logger.info("Fetching merchant info for mId: {}", mId);
        return post(MERCHANT + mId, EMPTY_JSON, new ParameterizedTypeReference<>() {});
    }

    /**
     * Retrieves RFC (Request For Comments) details for a given merchant.
     *
     * @param mId Merchant ID
     * @return Transaction response containing merchant RFC details
     */
    public TransactionResponse<MerchantRfcResponse> getMerchantRFCInfo(String mId) {
        logger.info("Fetching RFC details for mId: {}", mId);
        return post(GET_RFC_DETAILS + mId, EMPTY_JSON, new ParameterizedTypeReference<>() {});
    }

    /**
     * Retrieves multi-account details for a given merchant.
     *
     * @param mId Merchant ID
     * @return Transaction response containing multi-account details
     */
    public TransactionResponse<String> getMultiAccountDetailsApi(String mId) {
        logger.info("Fetching multi-account details for mId: {}", mId);
        return post(GET_MULTI_ACCOUNT + mId, EMPTY_JSON, new ParameterizedTypeReference<>() {});
    }

    /**
     * Retrieves gateway configuration details for a given merchant.
     *
     * @param mId      Merchant ID
     * @param gtwMapId Gateway Map ID
     * @return Transaction response containing gateway configuration details
     */
    public TransactionResponse<GatewayConfigDetailsResponse> getGatewayConfigDetails(String mId, String gtwMapId) {
        logger.info("Fetching gateway configuration details for mId: {} and gtqMapId: {}", mId, gtwMapId);
        GatewayConfigDetailsRequest gatewayConfigDetailsRequest = GatewayConfigDetailsRequest.builder().aggGtwMapId(gtwMapId).mId(mId).build();
        return post(MERCHANT_CONFIG_DETAILS_ENDPOINT, gatewayConfigDetailsRequest, new ParameterizedTypeReference<>() {
        });
    }

    /**
     * This method is used to fetch bin-check status from admin service.
     *
     * @param request cardBin
     * @return BinCheck Response
     */

    public TransactionResponse<BinCheckResponse> binCheckRequest(BinCheckRequest request) {
        logger.info("Fetching binCheck status for card bin: {}", request);
        return post(BIN_CHECK_ENDPOINT, request, new ParameterizedTypeReference<>() {
        });
    }

    /**
     * Retrieves pay mode details for a given merchant.
     *
     * @param mId Merchant ID
     * @return Transaction response containing pay mode details
     */
    public TransactionResponse<JsonNode> getMerchantPayModeInfo(String mId) {
        logger.info("Fetching pay mode info for mId: {}", mId);
        return post(MERCHANT_PAYMODE_ENDPOINT + mId, mId, new ParameterizedTypeReference<>() {
        });
    }

    /**
     * Retrieves the merchant pricing structure from the admin service.
     *
     * @param adminPricingRequest Pricing request details
     * @return Transaction response containing merchant pricing details
     */
    public TransactionResponse<MerchantPricingResponse> getMerchantPricingStructure(AdminPricingRequest adminPricingRequest) {
        logger.info("Fetching merchant pricing structure for request: {}", adminPricingRequest);
        return post(PRICING_API_ENDPOINT, adminPricingRequest, new ParameterizedTypeReference<>() {
        });
    }

    /**
     * Fetches Volume Velocity (VVL) details for a given merchant.
     *
     * @param mId Merchant ID
     * @return Transaction response containing merchant VVL details
     */
    public TransactionResponse<MerchantVvlResponse> geVvlDetails(String mId) {
        logger.info("Fetching VVL details for mId: {}", mId);
        return post(VVL_API_ENDPOINT + mId, mId, new ParameterizedTypeReference<>() {
        });
    }

    /**
     * Validates currency details based on the provided request.
     *
     * @param currencyRequest Currency validation request
     * @return Transaction response containing currency validation details
     */
    public TransactionResponse<String> getCurrencyValidate(CurrencyRequest currencyRequest) {
        logger.info("Validating currency for request: {}", currencyRequest);
        return post(CURRENCY_CHK_ENDPOINT, currencyRequest, new ParameterizedTypeReference<>() {
        });
    }

    /**
     * Validates channelBank based on the provided request.
     *
     * @param gatewayMapId String
     * @param channelBank  String
     * @return Transaction response containing ChannelBank validation details
     */
    public TransactionResponse<String> getChannelBankValidate(String gatewayMapId, String channelBank) {
        logger.info("Inside getChannelBankValidate");
        return post(CHANNEL_BANK_ENDPOINT, ChannelBankValidateRequest.builder().gtwMapId(gatewayMapId).channelBank(channelBank).build(), new ParameterizedTypeReference<>() {
        });
    }

    /**
     * This method is used to get the merchant notification info
     *
     * @param mId String
     * @return TransactionResponse<MerchantNotificationResponse>
     */
    public TransactionResponse<MerchantNotificationResponse> getMerchantNotification(String mId) {
        logger.info("Inside getMerchantNotification: {}", mId);
        return post(MERCHANT_NOTIFICATION_ENDPOINT + mId, mId, new ParameterizedTypeReference<>() {
        });
    }

    /**
     * This method is used to get the postalCode details.
     *
     * @param postalCode  postal Code
     * @return Transaction response containing postal code details
     */
    public TransactionResponse<MerchantPostalCodeResponse> getPostalCodeDetails(String postalCode) {
        logger.info("Fetching Postal code details for postal code: {}", postalCode);
        return get(POSTAL_CODE_ENDPOINT + postalCode, new ParameterizedTypeReference<>() {});
    }

    /**
     * This method is used to get the ifsc  details.
     *
     * @param ifsc  ifsc Code
     * @return Transaction response containing postal code details
     */
    public TransactionResponse<MerchantIfscCodeResponse> getIfscCodeDetails(String ifsc) {
        logger.info("Fetching ifsc code details for postal code: {}", ifsc);
        return get(IFSC_CODE_ENDPOINT + ifsc, new ParameterizedTypeReference<>() {});
    }

}
