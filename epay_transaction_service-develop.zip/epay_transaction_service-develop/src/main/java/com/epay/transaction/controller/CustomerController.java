package com.epay.transaction.controller;


import com.epay.transaction.model.request.EncryptedRequest;
import com.epay.transaction.model.response.TransactionResponse;
import com.epay.transaction.service.CustomerService;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

/**
 * Class Name: CustomerController
 * *
 * Description: Customer creation for given Merchant.
 * *
 * Author: V1018400 (Ranjan Kumar)
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@RestController
@RequestMapping("/customer")
@RequiredArgsConstructor
@Validated
public class CustomerController {
    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    private final CustomerService customerService;

    /**
     * Method name : createCustomer
     * Description : Creates the Merchant Customer
     * @param encryptedRequest : Object of CustomerRequest
     * @return object of TransactionResponse
     */
    @PostMapping("/create")
    @Operation(summary = "API for creation of merchant customer")
    @PreAuthorize("hasAnyRole('ACCESS')")
    public TransactionResponse<String> createCustomer(@Valid @RequestBody EncryptedRequest encryptedRequest) {
        log.info("Request to create Merchant Customer, encryptedRequest: {}", encryptedRequest);
        return customerService.createCustomer(encryptedRequest);
    }

    /**
     * Method name : getCustomer
     * Description : Fetches the merchant customer details
     * @param customerId : of type String
     * @return object of TransactionResponse
     */
    @GetMapping("/{customerId}")
    @Operation(summary = "API for getting the customer details")
    public TransactionResponse<String> getCustomer(@PathVariable String customerId) {
        log.info("Request to get the Merchant Customer by customerId: {}", customerId);
        return customerService.getCustomerByCustomerId(customerId);
    }

    /**
     * Method name : updateCustomerStatus
     * Description : Update merchant customer status
     * @param customerId : String
     * @param status     : String
     * @return object of TransactionResponse
     */
    @PostMapping("/{customerId}/{status}")
    @Operation(summary = "API for update the merchant customer status")
    public TransactionResponse<String> updateCustomerStatus(@PathVariable String customerId, @PathVariable String status) {
        log.info("Request to update the Merchant Customer by customerId: {} and status: {}", customerId, status);
        return customerService.updateCustomerStatus(customerId, status);
    }

}
