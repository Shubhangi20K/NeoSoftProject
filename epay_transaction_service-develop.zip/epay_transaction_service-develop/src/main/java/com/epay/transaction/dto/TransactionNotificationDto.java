package com.epay.transaction.dto;

import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;

/**
 * Class Name: TransactionNotificationDto
 * *
 * Description: Data transfer to for email and sms.
 * *
 * Author: Gireesh M
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Data
@Builder
public class TransactionNotificationDto {
    private String currencyCode;
    private BigDecimal gtwPostingAmount;
    private String payMode;
    private String merchantBrandName;
    private Date txnDate;
}
