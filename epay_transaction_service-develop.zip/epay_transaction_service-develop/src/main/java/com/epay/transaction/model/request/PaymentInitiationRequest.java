package com.epay.transaction.model.request;

import com.epay.transaction.util.enums.OperatingMode;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

import java.math.BigDecimal;

import static com.epay.transaction.util.TransactionErrorConstants.CHANNEL_BANK_IS_REQUIRED;

/**
 * Class Name: CustomerController
 * *
 * Description: Customer creation for given Merchant.
 * *
 * Author: V1018400 (Ranjan Kumar)
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Data
public class PaymentInitiationRequest {

    private String operatingMode;

    private String payProcId;

    private String payProcType;

    private String gtwMapsId;

    private String pgBankCode;

    private BigDecimal merchPostedAmount;

    private BigDecimal transactionAmount;

    private String upiAddress;

    @NotBlank(message = CHANNEL_BANK_IS_REQUIRED)
    private String channelBank;

    private String altNumber;

    private String expiryMonth;

    private String expiryYear;

    private String cvv;

    private String cardHolderName;

}
