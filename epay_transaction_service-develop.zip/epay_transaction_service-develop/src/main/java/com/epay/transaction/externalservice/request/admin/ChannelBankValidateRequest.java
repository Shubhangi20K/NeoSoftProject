package com.epay.transaction.externalservice.request.admin;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Class Name:ChannelBankValidateRequest
 * *
 * Description:
 * *
 * Author:V1014352(Ranjan Kumar)
 * <p>
 * Copyright (c) 2025 [State Bank of INdia]
 * All right reserved
 * *
 * Version:1.0
 */
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Data
public class ChannelBankValidateRequest {

    private String gtwMapId;
    private String channelBank;
}
