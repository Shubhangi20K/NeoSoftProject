package com.epay.transaction.mapper;


import com.epay.transaction.dto.MerchantOrderDuplicatePaymentsDto;
import com.epay.transaction.dto.MerchantPaymentOrderDto;
import com.epay.transaction.dto.ReconDataDetailsDto;
import com.epay.transaction.entity.MerchantOrderDuplicatePayments;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;

import java.util.List;

/**
 * Class Name:MerchantOrderDuplicatePaymentsMapper
 * *
 * Description:
 * *
 * Author:V00000001(Shilpa Kothre)
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
@Mapper(builder = @Builder(disableBuilder = true), componentModel = "spring",unmappedSourcePolicy = ReportingPolicy.IGNORE)
public interface MerchantOrderDuplicatePaymentsMapper {

    /**
     * Converts MerchantPaymentOrderDto to MerchantOrderPayment entity.
     * @param merchantPaymentOrderDto the DTO containing merchant order payment details
     * @return the entity representation of the merchant order payment
     */
    List<MerchantOrderDuplicatePayments> dtoToEntity(List<MerchantOrderDuplicatePaymentsDto> merchantPaymentOrderDto);

    MerchantPaymentOrderDto convertIntoMerchantPaymentDto(MerchantOrderDuplicatePaymentsDto merchantOrderDuplicatePaymentsDto);

    MerchantOrderDuplicatePaymentsDto convertIntoMerchantOrderPaymentDuplicateDto(ReconDataDetailsDto reconDataDetailsDto);

    MerchantOrderDuplicatePayments dtoToEntity(MerchantOrderDuplicatePaymentsDto merchantOrderDuplicatePaymentsDto);

}
