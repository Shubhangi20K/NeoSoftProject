package com.epay.transaction.util.enums;

/**
 * Class Name: InterfaceType
 * <p>
 * Description:
 * <p>
 * Copyright (c) [2025] [State Bank of India]
 * All rights reserved.
 * <p>
 * Author:@V0000001(Shilpa Kothre)
 * Version:1.0
 */
public enum InterfaceType {

    TXN_RECON_RECORD_MATCHED_TOPIC,
    TXN_RECON_RECORD_UNMATCHED_TOPIC,
    TXN_RECON_RECORD_DUPLICATE_TOPIC,
    TXN_RECON_FAIL_ACK_TOPIC,
    TXN_REFUND_ADJUST_DETAIL_TOPIC,
    TXN_REFUND_ADJUST_CONFIRMATION_TOPIC,

}
