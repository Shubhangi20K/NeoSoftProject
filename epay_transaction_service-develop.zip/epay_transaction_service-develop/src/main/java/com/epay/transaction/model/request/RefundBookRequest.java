package com.epay.transaction.model.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;

import static com.epay.transaction.util.TransactionErrorConstants.*;

/**
 * Class Name:RefundBookRequest
 * *
 * Description: Refund request object for refund booking
 * *
 * Author:Nirmal Gurjar
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RefundBookRequest implements Serializable {
    @JsonProperty("mId")
    private String mId;
    @NotBlank(message = REFUND_TYPE_IS_REQUIRED)
    private String refundType;
    @NotNull(message = REFUND_AMOUNT_IS_REQUIRED)
    private BigDecimal refundAmount;
    @NotBlank(message = ATRN_NUMBER_IS_REQUIRED)
    private String atrnNumber;
    private String remark;

}
