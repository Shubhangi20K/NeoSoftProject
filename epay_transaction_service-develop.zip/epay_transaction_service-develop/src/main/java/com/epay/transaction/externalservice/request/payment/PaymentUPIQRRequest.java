package com.epay.transaction.externalservice.request.payment;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Class Name:PaymentUpiQrREquest
 * *
 * Description:
 * *
 * Author:V1014352(Ranjan Kumar)
 * <p>
 * Copyright (c) 2025 [State Bank of INdia]
 * All right reserved
 * *
 * Version:1.0
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PaymentUPIQRRequest {

    @JsonProperty(value = "atrn")
    private String pspRefNo;
    private String gtwMapId;
}

