package com.epay.transaction.entity;

import com.epay.transaction.util.TransactionUtil;
import com.epay.transaction.util.enums.*;
import jakarta.persistence.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

/**
 * Class Name:MerchantOrderPayment
 * *
 * Description:
 * *
 * Author:V1014352(Ranjan Kumar)
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "MERCHANT_ORDER_PAYMENTS")
public class MerchantOrderPayment extends AuditEntity {

    @Id
    @Column(name = "ATRN_NUM", nullable = false, updatable = false, unique = true)
    private String atrnNumber;
    @Column(name = "MERCHANT_ID")
    private String mId;
    private String orderRefNumber;
    private String sbiOrderRefNumber;
    private String bankReferenceNumber;
    private String oldBankReferenceNumber;

    private String currencyCode;
    private BigDecimal orderAmount;
    @Column(name = "DEBIT_AMT")
    private BigDecimal debitAmount;
    private BigDecimal availableRefundAmount;
    private BigDecimal chargebackAmount;

    private String gstIn;
    private String channelBank;
    @Enumerated(EnumType.STRING)
    private PayMode payMode;
    @Column(name = "GTW_MAP_ID")
    private String pgBankCode;//this is gateway map id
    private String payProcId; //this is pay proc id e.g. Visa, Master, Rupay
    @Column(name = "PAY_PROC_TYPE")
    private String paymodeType; //this is Pay proc type e.g. onus, offus
    @Column(name = "GTW_ISSUE_MECODE")
    private String gatewayIssueMECode; //merchant wise and/or payment wise ME code received from bank
    private String cin;

    @Enumerated(EnumType.STRING)
    private PaymentStatus paymentStatus;
    @Enumerated(EnumType.STRING)
    private TransactionStatus transactionStatus;
    @Enumerated(EnumType.STRING)
    private SettlementStatus settlementStatus;
    @Enumerated(EnumType.STRING)
    private TransactionRefundStatus refundStatus;
    @Enumerated(EnumType.STRING)
    private CancellationStatus cancellationStatus;
    private String chargebackStatus;

    @Lob
    private String pushResponse;
    private Date paymentSuccessDate;
    private String failReason;
    private String pushStatus;

    private UUID rfId;
    private Long settlementTime;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "sbiOrderRefNumber", insertable = false, updatable = false)
    private Order order;

    /**
     * Generate ATRN number dynamically for transaction.
     */
    @PrePersist
    protected void generatedATRN() {
        this.atrnNumber = TransactionUtil.createAtrnNumber(mId, payMode);
    }

}
