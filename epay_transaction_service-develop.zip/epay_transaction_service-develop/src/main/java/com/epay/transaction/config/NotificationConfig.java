package com.epay.transaction.config;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

/**
 * Class Name: NotificationConfig
 * *
 * Description: Notification config for  email and sms.
 * *
 * Author: Gireesh M
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Data
@Configuration
public class NotificationConfig {
    @Value("${external.api.sms.gateway.base.path}")
    private String smsBasePath;

    @Value("${external.api.sms.gateway.user}")
    private String smsUserName;

    @Value("${external.api.sms.gateway.password}")
    private String smsPassword;

    @Value("${external.api.sms.body.content.type:text}")
    private String smsContentType;

    @Value("${external.api.sms.body.sender.id:SBIBNK}")
    private String smsSenderId;

    @Value("${external.api.sms.body.int.flag:0}")
    private int smsIntFlag;

    @Value("${external.api.sms.body.charging:0}")
    private int smsCharging;

    @Value("${external.api.sms.gateway.url:/bmg/sms/epaypgotpdom}")
    private String smsURL;

    @Value("${email.recipient:}")
    private String recipient;

    @Value("${email.from}")
    private String from;
}
