package com.epay.transaction.mapper;

import com.epay.transaction.dto.EisApiHistoryDto;
import com.epay.transaction.entity.EisApiHistory;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;

@Mapper(builder = @Builder(disableBuilder = true), componentModel = "spring")
public interface EisApiHistoryMapper {
    EisApiHistory dtoToEntity(EisApiHistoryDto eisApiHistoryDto);
    EisApiHistoryDto entityToDto(EisApiHistory eisApiHistory);
}
