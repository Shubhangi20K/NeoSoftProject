package com.epay.transaction.dto;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;

@AllArgsConstructor
@Data
@Builder
public class MerchantPricingDto {

    private BigDecimal merchantFeeAbs;
    private BigDecimal otherFeeAbs;
    private BigDecimal gtwFeeAbs;
    private BigDecimal aggServiceFeeAb;
    private BigDecimal postAmount;
    private BigDecimal bearableCutOffAmt;
    private BigDecimal customerBearableAmt;
    private BigDecimal customerBearableServiceTax;
    private BigDecimal merchantBearableAmt;
    private BigDecimal merchantBearableServiceTax;
}
