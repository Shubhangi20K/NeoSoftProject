package com.epay.transaction.externalservice.request.admin;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Class Name:GatewayConfigDetailsRequest
 * *
 * Description:
 * *
 * Author:V1014352(Ranjan Kumar)
 * <p>
 * Copyright (c) 2025 [State Bank of INdia]
 * All right reserved
 * *
 * Version:1.0
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class GatewayConfigDetailsRequest {
    @JsonProperty(value = "mId")
    private String mId;
    @JsonProperty(value = "aggGtwMapId")
    private String aggGtwMapId;
}
