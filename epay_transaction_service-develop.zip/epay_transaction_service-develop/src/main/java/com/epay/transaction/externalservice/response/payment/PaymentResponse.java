package com.epay.transaction.externalservice.response.payment;


import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PaymentResponse {
    private String  postURL;
    private String  data;
    private String key;
    private String merchantCode;
    private String atrn;
}
