package com.epay.transaction.etl.listener;

import com.epay.transaction.dto.RefundAdjustedDto;
import com.epay.transaction.etl.producer.RefundAdjustedConfirmationPublisher;
import com.epay.transaction.service.ReconSettlementService;
import com.epay.transaction.util.enums.InterfaceType;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sbi.epay.authentication.util.EPayAuthenticationConstant;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.MDC;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import java.util.UUID;

import static com.epay.transaction.util.EventMessageUtils.buildEventErrorLog;
import static com.epay.transaction.util.EventMessageUtils.buildEventReceivedLog;
import static com.epay.transaction.util.TransactionConstant.PAYOUT_ID;


/**
 * Class Name:RefundAdjustedListener
 * <p>
 * Description: Consume RefundAdjusted details data from recon producer.
 * <p>
 * Copyright (c) [2025] [State Bank of India]
 * All rights reserved.
 * <p>
 * Author:@V0000001(Shilpa Kothre)
 * Version:1.0
 */
@Component
@RequiredArgsConstructor
public class RefundAdjustedListener {

    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private final ObjectMapper objectMapper;
    private final ReconSettlementService reconSettlementService;
    private final RefundAdjustedConfirmationPublisher refundAdjustedConfirmationPublisher;
    private final ApplicationEventPublisher publisher;

    @KafkaListener(topics = "${spring.kafka.topic.transaction.refund.adjust}")
    public void processRefundAdjustedDetails(ConsumerRecord<String, String> consumerRecord) {
        MDC.put(EPayAuthenticationConstant.CORRELATION_ID, String.valueOf(UUID.randomUUID()));
        MDC.put(EPayAuthenticationConstant.SCENARIO, "RefundAdjustedListener");
        MDC.put(EPayAuthenticationConstant.OPERATION, "processRefundAdjustedDetails");
        logger.info("Received Kafka message request received for key : {} and value : {}", consumerRecord.key(), consumerRecord.value());
        try {
            publisher.publishEvent(buildEventReceivedLog(InterfaceType.TXN_REFUND_ADJUST_DETAIL_TOPIC, consumerRecord));
            RefundAdjustedDto refundAdjustedDto = objectMapper.readValue(consumerRecord.value(), RefundAdjustedDto.class);
            logger.info("Received Kafka message RefundAdjustedDto : {}", refundAdjustedDto);
            reconSettlementService.processRefundAdjustedArrns(refundAdjustedDto);
            refundAdjustedConfirmationPublisher.publish(PAYOUT_ID, String.valueOf(refundAdjustedDto.getPayoutId()), String.valueOf(refundAdjustedDto.getPayoutId()));
        } catch (Exception e) {
            publisher.publishEvent(buildEventErrorLog(InterfaceType.TXN_REFUND_ADJUST_DETAIL_TOPIC, consumerRecord, e.getMessage()));
            logger.error("Error during Refund Adjustment kafka listening message[key:{} and value: {}], error: {}", consumerRecord.key(), consumerRecord.value(), e.getMessage());
        }
    }
}
