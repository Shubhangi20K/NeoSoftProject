package com.epay.transaction.validator;


import com.epay.transaction.externalservice.request.admin.BinCheckRequest;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import java.util.ArrayList;
import static com.epay.transaction.util.TransactionErrorConstants.*;
import static com.epay.transaction.util.TransactionConstant.*;

/**
 * Class Name: CardValidator
 * *
 * Description: This class is used for validate cardBin
 * *
 * Author: V1017903(bhushan wadekar)
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Component
@RequiredArgsConstructor
public class CardValidator extends BaseValidator
{

    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());

    /**
     *This method is used for validate cardBin
     * @param cardBin
     */
    public void validateCardBin(String cardBin) {
        errorDtoList = new ArrayList<>();
        checkMandatoryField(cardBin, CARD_BIN);
        throwIfErrors();
        checkForLeadingTrailingAndSingleSpace(cardBin, CARD_BIN);
        throwIfErrors();
        validateFixedFieldLength(cardBin, CARD_BIN_LENGTH, CARD_BIN);
        throwIfErrors();
        validateFieldWithRegex(cardBin, CARD_BIN_REGEX, CARD_BIN, INCORRECT_FORMAT);
        throwIfErrors();
    }
}
