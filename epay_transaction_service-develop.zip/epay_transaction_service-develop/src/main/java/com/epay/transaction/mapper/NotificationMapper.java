package com.epay.transaction.mapper;

import com.epay.transaction.dto.TransactionEmailDto;
import com.epay.transaction.dto.TransactionSmsDto;
import com.sbi.epay.notification.model.EmailDto;
import com.sbi.epay.notification.model.SmsDto;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;

@Mapper(builder = @Builder(disableBuilder = true), componentModel = "spring")
public interface NotificationMapper {
    EmailDto mapTransactionEmailDtoToEmailDto(TransactionEmailDto transactionEmailDto);

    SmsDto mapTransactionSmsDtoToSmsDto(TransactionSmsDto transactionSmsDto);
}
