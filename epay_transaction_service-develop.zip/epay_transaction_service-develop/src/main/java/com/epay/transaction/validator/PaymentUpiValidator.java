package com.epay.transaction.validator;

import com.epay.transaction.dao.SbiUPIDao;
import com.epay.transaction.externalservice.request.payment.PaymentStatusRequest;
import com.epay.transaction.externalservice.request.payment.PaymentUPIVpaRequest;
import com.epay.transaction.util.EPayIdentityUtil;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.ArrayList;

import static com.epay.transaction.util.TransactionConstant.*;
import static com.epay.transaction.util.TransactionConstant.UPI_STATUS_LENGTH;
import static com.epay.transaction.util.TransactionConstant.ATRN_ARRN_LENGTH;
import static com.epay.transaction.util.TransactionErrorConstants.STATUS;
import static com.epay.transaction.util.TransactionErrorConstants.ATRN;
import static com.epay.transaction.util.TransactionErrorConstants.INCORRECT_FORMAT;

/**
 * Class Name: PaymentUpiValidator
 * *
 * Description: Validate the VPA request.
 * *
 * Author:V000001(Shilpa Kothre)
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
@Component
@RequiredArgsConstructor
public class PaymentUpiValidator extends BaseValidator {

    private final SbiUPIDao sbiUPIDao;
    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    /**
     * Validate the VPA request.
     * @param paymentUPIVpaRequest PaymentUPIVpaRequest
     */
    public void checkValidateUpiVPA(PaymentUPIVpaRequest paymentUPIVpaRequest) {
        errorDtoList = new ArrayList<>();
        validateMandatoryFields(paymentUPIVpaRequest);

        validateLeadingTrailingSpace(paymentUPIVpaRequest);
        validateLength(paymentUPIVpaRequest);
        validateFieldsValue(paymentUPIVpaRequest);

    }

    /**
     * Validating mandatory fields
     * @param paymentUPIVpaRequest PaymentUPIVpaRequest
     */
    private void validateMandatoryFields(PaymentUPIVpaRequest paymentUPIVpaRequest) {
        checkMandatoryField(paymentUPIVpaRequest.getMId(), MID_CONST);
        checkMandatoryField(paymentUPIVpaRequest.getVirtualAddress(), UPI_VIRTUAL_ADDRESS);
        checkMandatoryField(paymentUPIVpaRequest.getPayGtwMapId(), UPI_PAY_GTW_ID);

        throwIfErrors();
    }

    /**
     * Validating fields for leading trailing spaces.
     * @param paymentUPIVpaRequest PaymentUPIVpaRequest
     */
    private void validateLeadingTrailingSpace(PaymentUPIVpaRequest paymentUPIVpaRequest) {
        checkForLeadingTrailingAndSingleSpace(paymentUPIVpaRequest.getMId(), MID_CONST);
        checkForLeadingTrailingAndSingleSpace(paymentUPIVpaRequest.getVirtualAddress(), UPI_VIRTUAL_ADDRESS);
        checkForLeadingTrailingAndSingleSpace(paymentUPIVpaRequest.getPayGtwMapId(), UPI_PAY_GTW_ID);
        throwIfErrors();
    }

    /**
     * Validating field value with regex.
     * @param paymentUPIVpaRequest PaymentUPIVpaRequest
     */
    private void validateFieldsValue(PaymentUPIVpaRequest paymentUPIVpaRequest) {
        validateFieldWithRegex(paymentUPIVpaRequest.getMId(), NUMBER_ONLY, MID_CONST, UPI_INVALID_FORMAT);
        throwIfErrors();
        validateFieldWithRegex(paymentUPIVpaRequest.getVirtualAddress(), VPA_REGEX, UPI_VIRTUAL_ADDRESS, UPI_INVALID_FORMAT);
        throwIfErrors();
        validateFieldWithRegex(paymentUPIVpaRequest.getPayGtwMapId(), NUMBER_ONLY, UPI_PAY_GTW_ID, UPI_INVALID_FORMAT);
        throwIfErrors();
    }

    /**
     * Validating fields value length.
     * @param paymentUPIVpaRequest PaymentUPIVpaRequest
     */
    private void validateLength(PaymentUPIVpaRequest paymentUPIVpaRequest) {
        validateFixedFieldLength(paymentUPIVpaRequest.getMId(), MID_MAX_LENGTH, MID_CONST);
        throwIfErrors();
        validateFieldLength(paymentUPIVpaRequest.getVirtualAddress(), VIRTUAL_ADDRESS_MAX_LENGTH, UPI_VIRTUAL_ADDRESS);
        throwIfErrors();
        validateFieldLength(paymentUPIVpaRequest.getPayGtwMapId(), PAY_GTW_LENGTH, UPI_PAY_GTW_ID);
        throwIfErrors();
    }

    public void validateStatusEnquiryRequest(PaymentStatusRequest paymentStatusRequest) {
        log.info("Validating Status Enquiry Request");
        errorDtoList = new ArrayList<>();
        validateStatusEnquiryMandatoryFields(paymentStatusRequest);
        validateStatusEnquiryLeadingTrailingSpace(paymentStatusRequest);
        validateStatusEnquiryLength(paymentStatusRequest);
        validateStatusEnquiryFieldsValue(paymentStatusRequest);
    }

    /**
     * Method name : validateStatusEnquiryFieldsValue
     * Description : Validates fields values for payment status request
     * @param paymentStatusRequest : Object of PaymentStatusRequest
     */
    private void validateStatusEnquiryFieldsValue(PaymentStatusRequest paymentStatusRequest) {
        log.info("Validating Status Enquiry Fields Value");
        validateFieldWithRegex(paymentStatusRequest.getAtrn(), ATRN_ARRN_REGEX, ATRN, INCORRECT_FORMAT);
        validateFieldWithRegex(paymentStatusRequest.getStatus(), CAPS_REGEX, STATUS, INCORRECT_FORMAT);
        throwIfErrors();
    }

    /**
     * Method name : validateStatusEnquiryLength
     * Description : Validates fields length for payment status request
     * @param paymentStatusRequest : Object of PaymentStatusRequest
     */
    private void validateStatusEnquiryLength(PaymentStatusRequest paymentStatusRequest) {
        log.info("Validating Status Enquiry Length");
        validateFixedFieldLength(paymentStatusRequest.getAtrn(), ATRN_ARRN_LENGTH, ATRN);
        validateFixedFieldLength(paymentStatusRequest.getStatus(), UPI_STATUS_LENGTH, STATUS);
        throwIfErrors();
    }

    /**
     * Method name : validateStatusEnquiryMandatoryFields
     * Description : Validates mandatory fields of payment status request
     * @param paymentStatusRequest : Object of PaymentStatusRequest
     */
    private void validateStatusEnquiryMandatoryFields(PaymentStatusRequest paymentStatusRequest) {
        log.info("Validating Status Enquiry Mandatory Fields");
        checkMandatoryField(paymentStatusRequest.getAtrn(), ATRN);
        checkMandatoryField(paymentStatusRequest.getStatus(), STATUS);
        throwIfErrors();
    }

    /**
     * Method name : validateStatusEnquiryLeadingTrailingSpace
     * Description : Validates leading and trailing fields of payment status request
     * @param paymentStatusRequest : Object of PaymentStatusRequest
     */
    private void validateStatusEnquiryLeadingTrailingSpace(PaymentStatusRequest paymentStatusRequest) {
        log.info("Validating Status Enquiry Leading Trailing Space");
        checkForLeadingTrailingAndSingleSpace(paymentStatusRequest.getAtrn(), ATRN);
        checkForLeadingTrailingAndSingleSpace(paymentStatusRequest.getStatus(), STATUS);
        throwIfErrors();
    }

    public void validateAtrnMapping(String atrn){
        log.info("Validating Atrn Mapping");
        sbiUPIDao.validateByAtrnMidAndOrderRefNumber(EPayIdentityUtil.getUserPrincipal().getMId(), EPayIdentityUtil.getUserPrincipal().getOrderRef(), atrn);
    }
}