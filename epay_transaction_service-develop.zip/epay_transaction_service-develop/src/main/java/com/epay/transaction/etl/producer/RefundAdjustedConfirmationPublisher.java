package com.epay.transaction.etl.producer;

import com.epay.transaction.config.kafka.Topics;
import com.epay.transaction.util.enums.InterfaceType;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Component;

import java.util.UUID;

import static com.epay.transaction.util.EventMessageUtils.buildEventErrorLog;
import static com.epay.transaction.util.EventMessageUtils.buildEventSendLog;
import static com.epay.transaction.util.TransactionConstant.RECON_REFUND_ADJUSTED_CONFIRMATION_KEY;

/**
 * Class Name: RefundAdjustedConfirmationPublisher
 * Description: Kafka Service will publish Refund Adjusted PayoutId
 * Author:@V0000001(Shilpa Kothre)<br>
 * Copyright (c) 2025 [State Bank of India]<br>
 * All rights reserved<br>
 * Version:1.0
 */
@Component
@RequiredArgsConstructor
public class RefundAdjustedConfirmationPublisher extends TransactionProducer<String> {
    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    private final KafkaMessagePublisher kafkaMessagePublisher;
    private final Topics topics;
    private final ObjectMapper objectMapper;
    private final ApplicationEventPublisher publisher;

    /**
     * @param requestType String
     * @param routingKey  String
     * @param message     String
     */
    @Override
    public void publish(String requestType, String routingKey, String message) {
        log.debug("RefundAdjustedPayoutIdPublisher for requestType : {}, routingKey : {} and value : {}", requestType, routingKey, message);
        String kafkaRoutingKey = getRoutingKey(requestType, RECON_REFUND_ADJUSTED_CONFIRMATION_KEY, routingKey);
        try {
            publisher.publishEvent(buildEventSendLog(InterfaceType.TXN_REFUND_ADJUST_CONFIRMATION_TOPIC, topics.getRefundAdjustedConfirmationTopic(), kafkaRoutingKey, message));
            kafkaMessagePublisher.publish(topics.getRefundAdjustedConfirmationTopic(), kafkaRoutingKey, message);
            log.debug("RefundAdjusted PayoutId has been published");
        } catch (Exception e) {
            publisher.publishEvent(buildEventErrorLog(InterfaceType.TXN_REFUND_ADJUST_CONFIRMATION_TOPIC, topics.getRefundAdjustedConfirmationTopic(), kafkaRoutingKey, e.getMessage()));
            log.error("Error in RefundAdjustedPayoutIdPublisher {} {}", message, e.getMessage());
        }
    }

}
