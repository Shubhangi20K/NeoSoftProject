package com.epay.transaction.externalservice;

/*
 * Copyright (c) [2024] [State Bank of India]
 * All rights reserved.
 * <p>
 * Author:@V0000001(Shilpa Kothre)
 * Version:1.0
 */

import com.epay.transaction.client.ApiClient;
import com.epay.transaction.exceptions.TransactionException;
import com.epay.transaction.externalservice.request.merchant.UserValidationRequest;
import com.epay.transaction.externalservice.response.merchant.MerchantThemeResponse;
import com.epay.transaction.model.response.TransactionResponse;
import com.epay.transaction.util.TransactionErrorConstants;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import reactor.core.publisher.Mono;

import java.net.URI;

public class MerchantServicesClient extends ApiClient {
    public static final String TOKEN_VALIDATION = "/validation/token";
    public static final String MERCHANT_VALIDATION = "/validation/user";
    public static final String PAYMENT_THEME = "/paymenttheme/";
    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    public MerchantServicesClient(String baseUrl, String corsOrigin) {
        super(baseUrl, corsOrigin);
    }
    /**
     * Validates the merchant token by making a GET request to the external service.
     *
     * @param token The merchant token to be validated.
     * @return TransactionResponse<Void> indicating success or failure.
     */
    public TransactionResponse<String > validateMerchantToken(String token) {
        logger.info("Validating merchant token...");
        return get(TOKEN_VALIDATION, token, new ParameterizedTypeReference<>() {});
    }
    /**
     * Validates a merchant user based on the provided user validation request.
     *
     * @param userValidationRequest The request object containing user validation details.
     * @return TransactionResponse<String> containing validation results.
     */
    public TransactionResponse<String> validateMerchantUser(UserValidationRequest userValidationRequest) {
        logger.info("Validating merchant user with request: {}", userValidationRequest);
        return post(MERCHANT_VALIDATION, userValidationRequest, new ParameterizedTypeReference<>() {});
    }
    /**
     * Retrieves the merchant's payment theme based on the provided merchant ID.
     *
     * @param mId The merchant ID.
     * @return TransactionResponse<MerchantThemeResponse> containing theme details.
     */
    public TransactionResponse<MerchantThemeResponse> getMerchantPaymentTheme(String mId) {
        logger.info("Fetching payment theme for merchant ID: {}", mId);
        return get(PAYMENT_THEME + mId,new ParameterizedTypeReference<>() {});
    }


}
