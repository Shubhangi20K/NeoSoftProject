package com.epay.transaction.externalservice.response.admin;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.RequiredArgsConstructor;

/**
 * Class Name: MerchantInfoResponse
 * *
 * Description: dto for MerchantInfo which contains merchant information
 * *
 * Author: (Nirmal Gurjar)
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *MerchantPaymodeDTO
 * Version:1.0
 */
@Data
@RequiredArgsConstructor
public class MerchantInfoResponse {

    @JsonProperty("mId")
    private String mId;
    private String isActive;
    private String merchantName;
    private String countryCode;
    private String currency;
    private String preferredPayMode;
    private String preferredBank;
    private Long accessTokenExpiryTime;
    private Long transactionTokenExpiryTime;
    private Integer maxAtrnCount;
    private Long orderExpiryTime;
    private String merchantVolVelFlag;
    private String merchantMultiAccountFlag;
    private String numberOfAttemptsApplicable;
    private String numberOfAttempts;
    private String isRefundApplicable;
    private Integer refundWindowDays;
    private String merchantBusinessUrl;
    private String dvpType;
    private String refundAdjustment;

}