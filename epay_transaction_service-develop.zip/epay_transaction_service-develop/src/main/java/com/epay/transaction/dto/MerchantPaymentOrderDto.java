package com.epay.transaction.dto;

import com.epay.transaction.util.enums.*;
import lombok.*;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.UUID;

/**
 * Class Name:MerchantPaymentOrderDto
 * *
 * Description:
 * *
 * Author:V1014352(Ranjan Kumar)
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class MerchantPaymentOrderDto implements Serializable {

    private String atrnNumber;
    private String mId;
    private String merchantTokenId;

    /* Order Information */
    private String orderRefNumber;
    private String sbiOrderRefNumber;
    private String bankReferenceNumber;
    private String oldBankReferenceNumber;

    /* Payment Information */
    private PayMode payMode;
    private String paymentModeDetails;
    private BigDecimal orderAmount;
    private BigDecimal debitAmount;

    private String channelBank;
    private String cin;
    private String pushResponse;
    private OperatingMode operatingMode;
    private String payProcId;
    private String paymodeType;
    private String pgBankCode;
    private String gatewayIssueMECode;
    private BigDecimal availableRefundAmount;
    private BigDecimal chargeBackAmount;
    /* MerchantOrderPayment Information */
    private Long txnRequestCount;
    private String failReason;


    /* Status Information */
    private TransactionStatus transactionStatus;
    private PaymentStatus paymentStatus;
    private SettlementStatus settlementStatus;
    private TransactionRefundStatus refundStatus;
    private CancellationStatus cancellationStatus;
    private String chargeBackStatus;

    /* Audit Information */
    private String createdBy;
    private String updatedBy;
    private Long createdDate;
    private Long updatedDate;
    private String currencyCode;
    private String gstin;
    private String custVpaId;
    private Date paymentSuccessDate;

    /* Recon Information */
    private UUID rfId;
    private Long settlementTime;

}
