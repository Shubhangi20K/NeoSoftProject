package com.epay.transaction.entity;

import com.epay.transaction.util.enums.PaymentStatus;
import com.epay.transaction.util.enums.SettlementStatus;
import jakarta.persistence.*;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.math.BigDecimal;
import java.util.UUID;

/**
 * Class Name:MerchantOrderPayment
 * Class Name:MerchantOrderDuplicatePayments
 * Description:
 * Author:V00000001(Shilpa Kothre)
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * Version:1.0
 */

@Data
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "MERCHANT_ORDER_DUPLICATE_PAYMENTS")
public class MerchantOrderDuplicatePayments extends AuditEntity {
    @Id
    private UUID rfdId;
    @Column(name = "ATRN_NUM")
    private String atrnNumber;
    private String bankReferenceNumber;
    private BigDecimal debitAmount;
    @Enumerated(EnumType.STRING)
    private PaymentStatus paymentStatus;
    @Enumerated(EnumType.STRING)
    private SettlementStatus settlementStatus;
    private UUID rfId;


}
