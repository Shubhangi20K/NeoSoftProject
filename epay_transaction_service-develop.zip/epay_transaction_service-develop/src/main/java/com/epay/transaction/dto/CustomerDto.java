package com.epay.transaction.dto;

import com.epay.transaction.util.enums.CustomerStatus;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CustomerDto {

    @JsonProperty("mId")
    private String mId;
    private String customerId;
    private String customerName;
    private String email;
    private String gstIn;
    private String gstInAddress;
    private String phoneNumber;
    private String address1;
    private String address2;
    private String city;
    private String state;
    private String country;
    private String pinCode;
    @Builder.Default
    private CustomerStatus status = CustomerStatus.ACTIVE;
}