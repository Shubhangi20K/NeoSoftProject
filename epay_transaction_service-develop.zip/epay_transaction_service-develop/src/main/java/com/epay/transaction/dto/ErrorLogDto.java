package com.epay.transaction.dto;

import com.epay.transaction.util.enums.EntityType;
import com.epay.transaction.util.enums.FailureReason;
import com.epay.transaction.util.enums.PayMode;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ErrorLogDto {
    private String mId;
    private String orderRefNumber;
    private String sbiOrderRefNumber;
    private String atrnNum;

    @Enumerated(EnumType.STRING)
    private EntityType entityType;

    private String payMode;

    @Enumerated(EnumType.STRING)
    private FailureReason failureReason;

    private String errorCode;
    private String errorMessage;
}
