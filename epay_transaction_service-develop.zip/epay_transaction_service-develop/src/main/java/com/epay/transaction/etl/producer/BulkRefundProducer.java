package com.epay.transaction.etl.producer;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
/**
 * Class Name: BulkRefundProducer
 * *
 * Description: The implementation is for produce bulk refund related data to topic.
 * *
 * Author: V1019439(Rahul Yadav)
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Component
@RequiredArgsConstructor
public class BulkRefundProducer extends TransactionProducer<String> {
    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    private final ObjectMapper objectMapper;

    /**
     * @param requestType String
     * @param routingKey  String
     * @param bulkId    String
     */
    @Override
    public void publish(String requestType, String routingKey, String bulkId) {
        try {
            log.debug("Bulk refund published for requestType : {}, routingKey : {} and value : {}", requestType, routingKey, bulkId);
            kafkaMessagePublisher.publish(topics.getProcessBulkRefundTopic(), getRoutingKey("bulkId", requestType, routingKey), objectMapper.writeValueAsString(bulkId));
        } catch (Exception e) {
            log.error("Error in publish bulk message, BulkRefundBookingDto {}", bulkId, e.getMessage());
        }
    }
}
