package com.epay.transaction.externalservice.response.payment;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
public class PaymentRupayCardResponse {
    private String initiate2API;
    @JsonProperty("AccuCardholderId")
    private String accuCardholderId;
    @JsonProperty("AccuGuid")
    private String accuGuid;
    @JsonProperty("AccuReturnURL")
    private String accuReturnURL;
    @JsonProperty("AccuRequestId")
    private String accuRequestId;
    private String session;
    private String availableAuthMode;
    private String status;
    private String errorcode;
    private String errormsg;
    private String atrn;
    private String pgTransactionId;
    private String validityPeriod;

}
