package com.epay.transaction.externalservice.request.payment;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;



/**
 * Class Name: PaymentRequestVerifyCard
 * *
 * Description: Card Payment Service
 * *
 * Author: V1018400 - Ranjan Kumar )
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PaymentRequestVerifyCard {
    private String atrn;
    private String pgtransactionid;
    private String apiType;
    private String otp;

}
