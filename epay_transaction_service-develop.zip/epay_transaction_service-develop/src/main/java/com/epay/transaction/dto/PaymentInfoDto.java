package com.epay.transaction.dto;

import com.epay.transaction.util.enums.PayMode;
import com.epay.transaction.util.enums.TransactionStatus;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;

import java.math.BigDecimal;

/**
 * Class Name: PaymentInfoDto
 * *
 * Description: This class contains details related to merchant order payment details.
 * *
 * Author: Gireesh M
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Data
@AllArgsConstructor
public class PaymentInfoDto {
    private String atrn;
    private BigDecimal orderAmount;
    private BigDecimal totalAmount;
    private TransactionStatus transactionStatus;
    private PayMode payMode;
    private String bankName;
    private String bankTxnNumber;
    private String processor;
    private Long transactionTime;
    @JsonProperty("CIN")
    private String cin;
    @JsonIgnore
    private String pushStatus;
}
