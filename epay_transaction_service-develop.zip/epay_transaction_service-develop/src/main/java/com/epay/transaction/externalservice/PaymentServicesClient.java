package com.epay.transaction.externalservice;

import com.epay.transaction.client.ApiClient;
import com.epay.transaction.externalservice.request.payment.*;
import com.epay.transaction.externalservice.response.payment.*;
import com.epay.transaction.model.response.TransactionResponse;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;

/**
 * Class Name:PaymentServicesClient
 * *
 * Description: This class is client for payment-service, it has calls for payment-service endpoints.
 * *
 * Author:V1014352(Ranjan Kumar)
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
public class PaymentServicesClient extends ApiClient {
    @Value("${external.api.services.endpoint.vpa}")
    private String VPA_API_ENDPOINT ;
    @Value("${external.api.services.endpoint.inb}")
    private String INB_API_ENDPOINT ;
    @Value("${external.api.services.endpoint.other}")
    private String OTHER_INB_API_ENDPOINT ;
    @Value("${external.api.services.endpoint.visa-master-card}")
    private String VISA_MASTER_CARD_API_ENDPOINT ;
    @Value("${external.api.services.endpoint.rupay-card-api}")
    private String RUPAY_CARD_API_ENDPOINT ;
    @Value("${external.api.services.endpoint.upi-vpa}")
    private String UPI_VPA_ENDPOINT;
    @Value("${external.api.services.endpoint.upi-qr}")
    private String UPI_QR_ENDPOINT ;
    @Value("${external.api.services.endpoint.get-upi-status-details}")
    private String GET_UPI_STATUS_DETAILS;
    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    public PaymentServicesClient(String baseUrl, String corsOrigin) {
        super(baseUrl,corsOrigin);
    }
    /**
     * Validates a UPI payment VPA (Virtual Payment Address).
     *
     * @param paymentRequest the payment request containing VPA details
     * @return transaction response with validation details
     */
    public TransactionResponse<PaymentUPIVpaResponse> validateUPIPaymentVpa(PaymentUPIVpaRequest paymentRequest) {
        logger.debug("Calling PaymentService for validateUPIPaymentVpa");
        return post(VPA_API_ENDPOINT, paymentRequest, new ParameterizedTypeReference<>() {});
    }

    /**
     * Initiates an INB (Internet Banking) payment for other banks.
     *
     * @param paymentRequest the INB payment request
     * @return transaction response for the INB payment
     */
    public TransactionResponse<PaymentOtherInbResponse> initiateOtherINBPayments(PaymentOtherINBReqest paymentRequest) {
        logger.info("Initiating Other INB payment request: {}", paymentRequest);
        return post(OTHER_INB_API_ENDPOINT, paymentRequest, new ParameterizedTypeReference<>() {});
    }
    /**
     * Initiates an SBI Internet Banking (INB) payment.
     *
     * @param paymentRequest the SBI INB payment request
     * @return transaction response for the SBI INB payment
     */
    public TransactionResponse<PaymentResponse> initiateSBIINBPayments(PaymentINBRequest paymentRequest) {
        logger.info("Initiating SBI INB payment request: {}", paymentRequest);
        return post(INB_API_ENDPOINT, paymentRequest, new ParameterizedTypeReference<>() {});
    }
    /**
     * Initiates a Visa or MasterCard payment authentication.
     *
     * @param paymentRequest the card payment request
     * @return transaction response with authentication details
     */
    public TransactionResponse<PaymentVisaCardResponse> initiateVisaAndMasterCardAPI(PaymentCardRequest paymentRequest) {
        logger.info("Initiating Visa/MasterCard payment request: {}", paymentRequest);
        return post(VISA_MASTER_CARD_API_ENDPOINT, paymentRequest, new ParameterizedTypeReference<>() {});
    }
    /**
     * Initiates a Rupay card payment authentication.
     *
     * @param paymentRequest the Rupay card payment request
     * @return transaction response with authentication details
     */
    public TransactionResponse<PaymentRupayCardResponse> initiateRupPayCardAPI(PaymentCardRequest paymentRequest) {
        logger.info("Initiating Rupay card payment request: {}", paymentRequest);
        return post(RUPAY_CARD_API_ENDPOINT, paymentRequest, new ParameterizedTypeReference<>() {});
    }
    /**
     * Initiates a UPI payment using VPA.
     *
     * @param paymentRequest the UPI payment request
     * @return transaction response with UPI transaction details
     */
    public TransactionResponse<PaymentUPIVpaCollectGatewayResponse> initiateUPIVPAPayments(PaymentUPIRequest paymentRequest) {
        logger.info("Initiating UPI VPA payment request: {}", paymentRequest);
        return post(UPI_VPA_ENDPOINT, paymentRequest, new ParameterizedTypeReference<>() {});
    }
    /**
     * Fetches the status of a UPI payment transaction.
     *
     * @param paymentRequest the UPI payment status request
     * @return transaction response with UPI transaction status
     */
    public TransactionResponse<String> upiPaymentStatusEnquiry(PaymentStatusRequest paymentRequest) {
        logger.info("Checking UPI payment status: {}", paymentRequest);
        return post(GET_UPI_STATUS_DETAILS, paymentRequest, new ParameterizedTypeReference<>() {});
    }
    /**
     * Initiates a UPI QR-based payment.
     *
     * @param paymentRequest the UPI QR payment request
     * @return transaction response with UPI QR transaction details
     */
    public TransactionResponse<PaymentQRResponse> initiateUPIQRPayments(PaymentUPIQRRequest paymentRequest) {
        logger.info("Initiating UPI QR payment request: {}", paymentRequest);
        return post(UPI_QR_ENDPOINT, paymentRequest, new ParameterizedTypeReference<>() {});
    }

}