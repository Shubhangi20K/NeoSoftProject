package com.epay.transaction.util;

import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.time.DateUtils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

/**
 * Class Name:DateTimeUtils
 * *
 * Description: This class is used for time formatting
 * *
 * Author:V1014352
 * <p>
 * Copyright (c) 2024 [State Bank of india]
 * All right reserved
 * *
 * Version:1.0
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class DateTimeUtils {

    private static final LoggerUtility logger = LoggerFactoryUtility.getLogger(DateTimeUtils.class);
    public static final String DDMMYY = "dd/MM/yyyy";
    public static final DateFormat FORMATTER_DD_MM_YYYY = new SimpleDateFormat(DDMMYY);
    private static final ZoneId ZONE_ID_INDIA = ZoneId.of("Asia/Kolkata");
    private static final DateTimeFormatter FORMATTER_REPORT = DateTimeFormatter.ofPattern("dd-MM-yyyy hh:mm a", Locale.US);

    /**
     * Retrieves the current system time in milliseconds.
     */
    public static Long getCurrentTimeInMills() {
        logger.info("Fetching current time in milliseconds.");
        return System.currentTimeMillis();
    }

    /**
     * Checks whether the provided expiry time has passed.
     *
     * @param expiryTime The expiry time to check, in milliseconds.
     * @return `true` if the `expiryTime` is in the past, otherwise `false`.
     */
    public static boolean isPastDate(Long expiryTime) {
        logger.info("Checking if the expiry time {} has passed.", expiryTime);
        return expiryTime < getCurrentTimeInMills();
    }

    /**
     * Adds the specified number of minutes to the current system time and returns the resulting time in milliseconds.
     *
     * @param minute The number of minutes to add to the current time.
     * @return The resulting time in milliseconds after adding the specified number of minutes.
     */
    public static Long addMinutes(int minute) {
        logger.info("Adding {} minutes to the current time.", minute);
        return DateUtils.addMinutes(new Date(), minute).getTime();
    }

    /**
     * Retrieves end of the day millis i.e. millis at time 23:59:59 for current date.
     */
    public static long endOfDayMillis() {
        logger.info("Fetching end of day millis");
        return LocalDate.now().atTime(LocalTime.MAX).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
    }

    /**
     * Calculates the number of days between two time millis
     */
    public static int calculateDaysBetween(long millis1, long millis2) {
        logger.info("Calculating days between millis");
        return (int) (Math.abs(millis1 - millis2) / (1000 * 60 * 60 * 24));
    }

    /**
     * Converts the given milliseconds into a formatted date string.
     *
     * @param milliSeconds the time in milliseconds
     * @param format the date format to be used
     * @return the formatted date as a string
     */
    public static String getDate(Long milliSeconds, DateFormat format) {
        logger.debug("Converting milliseconds {} to formatted date string", milliSeconds);
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(milliSeconds);
        return format.format(calendar.getTime());
    }

    /**
     * Convert given millis to report format date string.
     * @param milliseconds Long
     * @return String IST format date.
     */
    public static String convertToReportDate(long milliseconds) {
        return Instant.ofEpochMilli(milliseconds).atZone(ZONE_ID_INDIA).format(FORMATTER_REPORT);
    }

    /**
     * This method is used to subtract for the give time.
     * @param currentMilliseconds long
     * @param minutesToSubtract long
     * @return long
     */
    public static long getSubtractedMilli(long currentMilliseconds, long minutesToSubtract){
        Instant newInstant = Instant.ofEpochMilli(currentMilliseconds).minus(Duration.ofMinutes(minutesToSubtract));
        return newInstant.toEpochMilli();
    }
}
