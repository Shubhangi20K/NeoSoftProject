package com.epay.transaction.service;

import com.epay.transaction.dto.TransactionEmailDto;
import com.epay.transaction.dto.TransactionSmsDto;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class NotificationService {

    private final com.epay.transaction.dao.NotificationDao notificationDao;

    public void sendEmail(TransactionEmailDto transactionEmailDto) {
        notificationDao.sendEmailNotification(transactionEmailDto);
    }

    public void sendSms(TransactionSmsDto merchantSmsDto) {
        notificationDao.sendSmsNotification(merchantSmsDto);
    }
}
