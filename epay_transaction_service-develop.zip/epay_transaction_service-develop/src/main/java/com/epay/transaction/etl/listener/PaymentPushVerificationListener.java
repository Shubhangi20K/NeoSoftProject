package com.epay.transaction.etl.listener;

import com.epay.transaction.exceptions.TransactionException;
import com.epay.transaction.service.PaymentPushVerificationService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.sbi.epay.authentication.util.EPayAuthenticationConstant;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.MDC;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import java.util.UUID;

/**
 * Class Name: PaymentPushVerificationListener
 * *
 * Description: The implementation is for consume the data from producer.
 * *
 * Author: Gireesh M
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Component
@RequiredArgsConstructor
public class PaymentPushVerificationListener {

    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    private final PaymentPushVerificationService paymentPushVerificationService;

    @KafkaListener(topics = "${spring.kafka.topic.transaction.push.verification}")
    public void paymentPushVerification(ConsumerRecord<String, String> consumerRecord) throws TransactionException, JsonProcessingException {
        log.info("Push verification request received for key: {} and value: {}", consumerRecord.key(), consumerRecord.value());
        MDC.put(EPayAuthenticationConstant.CORRELATION_ID, String.valueOf(UUID.randomUUID()));
        MDC.put(EPayAuthenticationConstant.SCENARIO, "PaymentPushVerificationListener");
        MDC.put(EPayAuthenticationConstant.OPERATION, "paymentPushVerification");
        String message = consumerRecord.value();
        paymentPushVerificationService.processPaymentPushVerification(message);
    }
}
