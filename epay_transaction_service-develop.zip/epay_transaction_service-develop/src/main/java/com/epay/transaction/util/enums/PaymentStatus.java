package com.epay.transaction.util.enums;

import com.epay.transaction.exceptions.TransactionException;

import java.text.MessageFormat;
import java.util.Arrays;

import static com.epay.transaction.util.TransactionErrorConstants.INVALID_ERROR_CODE_NO_REASON;
import static com.epay.transaction.util.TransactionErrorConstants.INVALID_ERROR_MESSAGE_NO_REASON;

public enum PaymentStatus {
    BOOKED,PAYMENT_INITIATION_START,SUCCESS, FAILED,PENDING, EXPIRED;

    public static boolean isValid(String status) {
        return Arrays.stream(PaymentStatus.values())
                .anyMatch(ps -> ps.name().equalsIgnoreCase(status));
    }

    public static PaymentStatus getPaymentStatus(String paymentStatus) {
        return Arrays.stream(values()).filter(p -> p.name().equalsIgnoreCase(paymentStatus)).findFirst().orElseThrow(() -> new TransactionException(INVALID_ERROR_CODE_NO_REASON, MessageFormat.format(INVALID_ERROR_MESSAGE_NO_REASON, "Payment status", paymentStatus)));
    }
}
