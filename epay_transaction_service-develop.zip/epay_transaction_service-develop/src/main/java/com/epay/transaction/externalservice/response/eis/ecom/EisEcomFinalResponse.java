package com.epay.transaction.externalservice.response.eis.ecom;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class EisEcomFinalResponse {
    private String ecomFlage;
}
