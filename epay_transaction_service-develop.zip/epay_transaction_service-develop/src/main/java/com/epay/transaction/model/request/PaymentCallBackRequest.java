package com.epay.transaction.model.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PaymentCallBackRequest {
    @JsonProperty("mId")
    private String mId;
    @JsonProperty("merchnat_order_Ref_No")
    private String merchnatOrderRefNo;
    @JsonProperty("Sbi_Order_Ref_No")
    private String sbiOrderRefNo;
    @JsonProperty("order_Amount")
    private String orderAmount;
    @JsonProperty("debit_Amount")
    private String debitAmount;
    private String atrn;
    private String status;
    private String reason;
    @JsonProperty("cin_no")
    private String cin;

    @JsonProperty("other_Details")
    private String otherDetails;
    @JsonProperty("bank_Name")
    private String bankName;
    @JsonProperty("bank_Trace_No")
    private String bankTraceNo;
    @JsonProperty("bank_Code")
    private String bankCode;
    @JsonProperty("customer_Id")
    private String customerId;
    @JsonProperty("order_Retry_Count")
    private String orderRetryCount;

}