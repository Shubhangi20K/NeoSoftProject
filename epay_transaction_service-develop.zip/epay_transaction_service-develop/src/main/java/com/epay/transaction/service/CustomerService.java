package com.epay.transaction.service;

import com.epay.transaction.dao.CustomerDao;
import com.epay.transaction.dto.CustomerDto;
import com.epay.transaction.mapper.CustomerMapper;
import com.epay.transaction.model.request.CustomerRequest;
import com.epay.transaction.model.request.EncryptedRequest;
import com.epay.transaction.model.response.TransactionResponse;
import com.epay.transaction.util.EPayIdentityUtil;
import com.epay.transaction.util.TransactionUtil;
import com.epay.transaction.util.enums.CustomerStatus;
import com.epay.transaction.validator.CustomerValidator;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

import static com.epay.transaction.util.EncryptionDecryptionUtil.encryptValue;
import static com.epay.transaction.util.TransactionConstant.RESPONSE_SUCCESS;
import static com.epay.transaction.util.TransactionUtil.buildRequestByEncryptRequest;

/**
 * Class Name : CustomerService
 * Description: Merchant's customer creation service.
 * Author     : V1018400(Ranjan Kumar)
 * Copyright (c) 2024 [State Bank of India]
 * All right reserved
 * Version:1.0
 */
@Service
@RequiredArgsConstructor
public class CustomerService {
    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private final CustomerDao customerDao;
    private final CustomerValidator customerValidator;
    private final CustomerMapper customerMapper;

    /**
     * Method name : createCustomer
     * Description : Creates new customer if details are valid.
     *
     * @param encryptedRequest : encrypted String
     * @return : an object of TransactionResponse
     */
    public TransactionResponse<String> createCustomer(EncryptedRequest encryptedRequest) {
        logger.debug("encryptedRequest : {}", encryptedRequest);

        //Step 1 : Get the MEK Key
        logger.info("Create Customer MEK request start");
        String mek = customerDao.getMerchantMek();
        logger.info("Create Customer MEK request end");

        //Step 2 : Encrypt the CustomerRequest and build MerchantCustomerResponseDto
        CustomerRequest customerRequest = buildRequestByEncryptRequest(encryptedRequest.getEncryptedRequest(), mek, CustomerRequest.class);
        logger.debug("Build MerchantCustomerResponseDto:{} ", customerRequest);

        //Step 3 : Validate MerchantCustomerResponseDto values before save
        customerValidator.validateCustomerRequest(customerRequest);
        logger.info("Merchant Customer validation done. ");

        //Step 4 : Save MerchantCustomerResponseDto
        CustomerDto customerDto = customerMapper.requestToDto(customerRequest);
        customerDto = customerDao.saveCustomer(customerDto);

        //Step 5 : Encrypt customerId and CustomerResponse
        logger.info("Merchant Customer Creation Request End");
        return TransactionResponse.<String>builder().data(List.of(encryptValue(mek, TransactionUtil.toJson(customerDto)))).status(RESPONSE_SUCCESS).build();
    }

    /**
     * Method name : getCustomerByCustomerId
     * Description : Fetch customer details by customerId.
     *
     * @param customerId of type UUID
     * @return : an object of TransactionResponse
     */
    public TransactionResponse<String> getCustomerByCustomerId(String customerId) {

        //Step 1 : validate customer id
        customerValidator.validateCustomerId(customerId);
        logger.info("Customer id validated");

        //Step 2 : Get the Customer by CustomerId
        CustomerDto customerDto = customerDao.getCustomerByCustomerId(EPayIdentityUtil.getUserPrincipal().getMId(), customerId);

        //Step 3 : Get the MEK Key
        logger.info("Fetch Customer MEK request start");
        String mek = customerDao.getMerchantMek();
        logger.info("Fetch Customer MEK request end");

        //Step 4 : Encrypt customerId and CustomerResponse
        logger.info("Fetch Customer By CustomerId end");
        return TransactionResponse.<String>builder().status(RESPONSE_SUCCESS).data(List.of(encryptValue(mek, TransactionUtil.toJson(customerDto)))).build();
    }

    /**
     * Method name : updateCustomerStatus
     * Description : Update customer status.
     *
     * @param customerId     of type UUID
     * @param customerStatus of type String
     * @return : an Object of TransactionResponse
     */
    public TransactionResponse<String> updateCustomerStatus(String customerId, String customerStatus) {
        logger.debug("Customer status update  start for Customer : {} with status : {} ", customerId, customerStatus);

        //Step 1 : validate customer id
        customerValidator.validateCustomerId(customerId);
        logger.info("Customer id validated");

        //Step 2 : update customer status
        CustomerDto customerDto = customerDao.updateCustomerStatus(EPayIdentityUtil.getUserPrincipal().getMId(), customerId, CustomerStatus.getStatus(customerStatus));

        //Step 3 : Get the MEK Key
        logger.info("Customer status update MEK request start");
        String mek = customerDao.getMerchantMek();
        logger.info("Customer status update MEK request end");

        //Step 4 : Encrypt customerId and CustomerResponse
        logger.info("Customer status update end");
        return TransactionResponse.<String>builder().data(List.of(encryptValue(mek, TransactionUtil.toJson(customerDto)))).status(RESPONSE_SUCCESS).build();
    }

}

