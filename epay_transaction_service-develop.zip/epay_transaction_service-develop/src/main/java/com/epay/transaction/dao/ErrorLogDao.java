package com.epay.transaction.dao;

import com.epay.transaction.dto.ErrorLogDto;
import com.epay.transaction.entity.ErrorLog;
import com.epay.transaction.mapper.ErrorMapper;
import com.epay.transaction.repository.ErrorLogRepository;
import com.epay.transaction.util.enums.EntityType;
import com.epay.transaction.util.enums.FailureReason;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Repository;

/**
 * Class Name:ErrorLogDao
 * Description:This DAO class is responsible for saving error log in database .
 * Copyright (c) [2024] [State Bank of India]
 * All rights reserved.
 * <p>
 * Author:Shubhangi Kurelay
 * Version:1.0
 */
@Repository
@RequiredArgsConstructor
public class ErrorLogDao {
    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private final ErrorLogRepository errorLogRepository;
    private final ErrorMapper errorMapper;

    /**
     * Logs a customer-related error with detailed information including ATRN, PayMode, and Order References.
     */
    public void logCustomerError(String mId, EntityType entityType, String atrnNum, String orderRefNumber, String sbiOrderRefNumber, String payMode, String errorCode, String errorMessage) {
        saveErrorLog(mId, entityType, atrnNum, orderRefNumber, sbiOrderRefNumber, payMode,FailureReason.CUSTOMER, errorCode, errorMessage);
    }

    /**
     * Logs a business-related error with detailed information including ATRN, PayMode, and Order References.
     */
    public void logBusinessError(String mId, EntityType entityType, String atrnNum, String orderRefNumber, String sbiOrderRefNumber, String payMode, String errorCode, String errorMessage) {
        saveErrorLog(mId, entityType, atrnNum, orderRefNumber, sbiOrderRefNumber, payMode,FailureReason.BUSINESS, errorCode, errorMessage);
    }

    /**
     * Logs a technical-related error with detailed information including ATRN, PayMode, and Order References.
     */
    public void logTechnicalError(String mId, EntityType entityType, String atrnNum, String orderRefNumber, String sbiOrderRefNumber, String payMode, String errorCode, String errorMessage) {
        saveErrorLog(mId, entityType, atrnNum, orderRefNumber, sbiOrderRefNumber, payMode, FailureReason.TECHNICAL, errorCode, errorMessage);
    }
    /**
     * Saves an error log with full information including failure reason, ATRN, PayMode, and Order references.
     */
    private void saveErrorLog(String mId, EntityType entityType, String atrnNum, String orderRefNumber, String sbiOrderRefNumber, String payMode, FailureReason failureReason, String errorCode, String errorMessage) {
        ErrorLogDto errorLogDto = ErrorLogDto.builder()
                .mId(mId)
                .entityType(entityType)
                .atrnNum(atrnNum)
                .orderRefNumber(orderRefNumber)
                .sbiOrderRefNumber(sbiOrderRefNumber)
                .payMode(payMode)
                .failureReason(failureReason)
                .errorCode(errorCode)
                .errorMessage(errorMessage)
                .build();

        logger.info("Saving Error Log: {}", errorLogDto);
        ErrorLog errorLog = errorMapper.dtoToEntity(errorLogDto);
        errorLogRepository.save(errorLog);
        logger.info("Error Log Saved Successfully.");
    }

}