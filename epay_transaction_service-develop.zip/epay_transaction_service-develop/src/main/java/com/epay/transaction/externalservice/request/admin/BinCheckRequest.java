package com.epay.transaction.externalservice.request.admin;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Class Name: BinCheckRequest
 * *
 * Description:
 * *
 * Author: V1018217
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class BinCheckRequest {
    private String cardBin;
}
