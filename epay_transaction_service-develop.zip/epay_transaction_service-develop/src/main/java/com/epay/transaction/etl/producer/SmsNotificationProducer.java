package com.epay.transaction.etl.producer;

import com.epay.transaction.dto.TransactionSmsDto;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

/**
 * Class Name: SmsNotificationProducer
 * *
 * Description: The implementation is for producer sms data from consume.
 * *
 * Author: Gireesh M
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Component
@RequiredArgsConstructor
public class SmsNotificationProducer extends TransactionProducer<TransactionSmsDto> {

    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());

    private final ObjectMapper objectMapper;

    @Override
    public void publish(String requestType, String routingKey, TransactionSmsDto smsDto) {
        try {
            log.info("Sms notification published for requestType : {}, routingKey : {} and smsDto : {}", requestType, routingKey, smsDto);
            kafkaMessagePublisher.publish(topics.getSmsTopic(), getRoutingKey("sms", requestType, routingKey), objectMapper.writeValueAsString(smsDto));
        } catch (Exception e) {
            log.error("Error in publish SMS message, MerchantSmsDto {}", smsDto, e.getMessage());
        }
    }
}
