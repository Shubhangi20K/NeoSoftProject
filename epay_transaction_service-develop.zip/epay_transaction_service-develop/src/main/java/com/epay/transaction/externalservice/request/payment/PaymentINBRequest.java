package com.epay.transaction.externalservice.request.payment;


import lombok.Builder;
import lombok.Data;


@Data
@Builder
public class PaymentINBRequest {
    private String atrn;
}
