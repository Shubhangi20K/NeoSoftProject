package com.epay.transaction.externalservice.response.eis.gst;
/*
 * Copyright (c) [2024] [State Bank of India]
 * All rights reserved.
 * <p>
 * Author:@author Shilpa Kothre
 */

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.util.List;

@Data
public class EISGstDetails {
    @JsonProperty("GSTINSEARCHID")
    private int gstSearchId;
    @JsonProperty("GSTIN")
    private String gstNumber;
    @JsonProperty("LEGAL_NAME")
    private String legalName;
    @JsonProperty("CONSTITUTION")
    private String constitution;
    @JsonProperty("ACTIVE_STATUS")
    private String activeStatus;
    @JsonProperty("STATE_JURI")
    private String state;
    @JsonProperty("CENTER_JURI")
    private String center;
    @JsonProperty("REGISTRATION_DATE")
    private String registrationDate;
    @JsonProperty("CANCELLATION_DATE")
    private String cancellationDate;
    @JsonProperty("CREATED_DATE")
    private String createdDate;
    @JsonProperty("NBA")
    private String nba;
    @JsonProperty("TAX_PAYER_TYPE")
    private String taxPayerType;
    @JsonProperty("CALL_COUNT")
    private int callCount;
    @JsonProperty("FP")
    private String fp;
    @JsonProperty("FILE_DATA")
    private String fileData;
    @JsonProperty("TRADE_NAME")
    private String tradeName;
    @JsonProperty("ADDRESS")
    private List<String> address;
    @JsonProperty("PRINCIPAL_ADDRESS")
    private EISGstPrincipalAddress eisGstPrincipalAddress;
    @JsonProperty("PREFERENCEJSN")
    private String preferenceJson;
}
