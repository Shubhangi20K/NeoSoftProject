package com.epay.transaction.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.math.BigDecimal;


/**
 * Class Name: MerchantOrderHybridFee
 * <p>
 * Description:
 * Stores Merchant Order Hybrid fee
 * <p>
 * Author: Nirmal Gurjar
 * <p>
 * Version: 1.0
 */
@EqualsAndHashCode(callSuper = true)
@Getter
@Setter
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "MERCHANT_ORDER_HYBRID_FEE_DTLS")
public class MerchantOrderHybridFee extends AuditEntity {

    @Id
    private String atrnNum;
    @Column(name = "MERCHANT_ID")
    private String mId;
    private Character bearableEntity;
    private String bearableComponent;
    private BigDecimal bearableAmountCutoff;
    private Character bearableRateType;
    private BigDecimal bearablePercentageRate;
    private BigDecimal bearableFlatRate;
    private BigDecimal merchantFeeBearableAbs;
    private BigDecimal customerFeeBearableAbs;
    private BigDecimal merchantGstBearableAbs;
    private BigDecimal customerGstBearableAbs;
    private String bearableLimit;
    private String createdBySessionId;
    private BigDecimal gstRate;
    private Character processFlag;

}
