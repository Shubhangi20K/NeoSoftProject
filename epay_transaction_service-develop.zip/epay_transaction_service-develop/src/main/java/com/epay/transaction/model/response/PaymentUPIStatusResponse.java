package com.epay.transaction.model.response;

import com.epay.transaction.dto.PaymentUPIAddInfoStatusDto;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

import java.math.BigDecimal;


@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class PaymentUPIStatusResponse {
    private Number upiTransRefNo;
    private String pspRefNo;
    private BigDecimal amount;
    private String txnAuthDate;
    private String status;
    private String statusDesc;
    private String responseCode;
    private String approvalNumber;
    private String payerVPA;
    private String payeeVPA;
    private String custRefNo;
    private String npciTransId;
    private String txn_type;
    private String errCode;
    private String txn_note;
    private String payer_name;
    private PaymentUPIAddInfoStatusDto addInfo;

}
