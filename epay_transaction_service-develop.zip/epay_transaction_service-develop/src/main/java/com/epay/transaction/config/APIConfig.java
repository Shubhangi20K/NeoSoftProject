package com.epay.transaction.config;

import com.epay.transaction.externalservice.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Copyright (c) [2024] [State Bank of India]
 * All rights reserved.
 * Description: This Class Store Configuration path to call External services
 * Author:@V0000001(Shilpa Kothre)
 * Version:1.0
 */
@Configuration
@Getter
@RequiredArgsConstructor
public class APIConfig {

    private final ObjectMapper objectMapper;

    @Value("${external.api.services.base.path.merchant}")
    private String merchantServicesBasePath;

    @Value("${external.api.services.base.path.admin}")
    private String adminServicesBasePath;

    @Value("${external.api.services.base.path.payment}")
    private String paymentServicesBasePath;

    @Value("${external.api.services.base.path.kms}")
    private String kmsServicesBasePath;

    @Value("${external.api.services.base.path.eis}")
    private String eisServiceBasePath;

    @Value("${security.cors.origin}")
    private String corsOrigin;

    @Bean
    public MerchantServicesClient constructMerchantServicesClient() {
        return new MerchantServicesClient(merchantServicesBasePath, corsOrigin);
    }

    @Bean
    public AdminServicesClient constructAdminServicesClient() {
        return new AdminServicesClient(adminServicesBasePath, corsOrigin);
    }

    @Bean
    public PaymentServicesClient constructPaymentServicesClient() {
        return new PaymentServicesClient(paymentServicesBasePath, corsOrigin);
    }

    @Bean
    public KmsServicesClient constructKMSServicesClient() {
        return new KmsServicesClient(kmsServicesBasePath, corsOrigin);
    }

    @Bean
    public EISServicesClient constructEISServicesClient() {
        return new EISServicesClient(eisServiceBasePath, objectMapper, corsOrigin);
    }

    @Bean
    public PaymentCallBackServicesClient constructPaymentCallBAckServicesClient() {
        return new PaymentCallBackServicesClient(paymentServicesBasePath, corsOrigin);
    }

}