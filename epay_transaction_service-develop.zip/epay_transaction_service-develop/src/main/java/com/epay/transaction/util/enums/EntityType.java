package com.epay.transaction.util.enums;

import com.epay.transaction.exceptions.TransactionException;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.text.MessageFormat;
import java.util.Arrays;

import static com.epay.transaction.util.TransactionErrorConstants.INVALID_ERROR_CODE_NO_REASON;
import static com.epay.transaction.util.TransactionErrorConstants.INVALID_ERROR_MESSAGE_NO_REASON;

/**
 * Class Name: EntityType
 * *
 * Description: This enum file keeps enums that are required to store error logs.
 * *
 * Author: Gireesh
 * <p>
 * Copyright (c) 2025 [State Bank of india]
 * All right reserved
 * *
 * Version:1.0
 */
@Getter
@AllArgsConstructor
public enum EntityType {

    TOKEN("Token"),
    CUSTOMER("Customer"),
    ORDER("Order"),
    PAYMENT("Payment"),
    BOOKING("Booking"),
    REFUND("Refund");

    private final String label;

    public static EntityType getEntityType(String label) {
        return Arrays.stream(values()).filter(p -> p.getLabel().equalsIgnoreCase(label)).findFirst().orElseThrow(() -> new TransactionException(INVALID_ERROR_CODE_NO_REASON, MessageFormat.format(INVALID_ERROR_MESSAGE_NO_REASON, "Entity Type", label)));
    }
}
