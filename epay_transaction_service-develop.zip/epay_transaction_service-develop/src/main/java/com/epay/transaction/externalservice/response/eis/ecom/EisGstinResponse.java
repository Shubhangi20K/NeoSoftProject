package com.epay.transaction.externalservice.response.eis.ecom;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class EisGstinResponse {
    private String status;
    private String gstin;
}
