package com.epay.transaction.mapper;


import com.epay.transaction.dto.MerchantPaymentOrderDto;
import com.epay.transaction.dto.PaymentInfoDto;
import com.epay.transaction.entity.MerchantOrderPayment;
import com.epay.transaction.model.response.OrderResponse;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;


/**
 * Class Name:MerchantOrderPaymentMapper
 * *
 * Description:
 * *
 * Author:V1014352(Ranjan Kumar)
 * <p>
 * Copyright (c) 2025 [State Bank of INdia]
 * All right reserved
 * *
 * Version:1.0
 */
@Mapper(builder = @Builder(disableBuilder = true), componentModel = "spring")
public interface MerchantOrderPaymentMapper {

    /**
     * Converts MerchantPaymentOrderDto to MerchantOrderPayment entity.
     *
     * @param merchantPaymentOrderDto the DTO containing merchant order payment details
     * @return the entity representation of the merchant order payment
     */
    MerchantOrderPayment dtoToEntity(MerchantPaymentOrderDto merchantPaymentOrderDto);
    /**
     * Converts MerchantPaymentOrderDto to MerchantOrderPayment entity.
     *
     * @param merchantPaymentOrderDto the DTO containing merchant order payment details
     * @return the entity representation of the merchant order payment
     */
    List<MerchantOrderPayment> dtoToEntity(List<MerchantPaymentOrderDto> merchantPaymentOrderDto);

    /**
     * Converts MerchantOrderPayment entity to MerchantPaymentOrderDto.
     *
     * @param merchantOrderPayment the entity containing merchant order payment details
     * @return the DTO representation of the merchant order payment
     */
    MerchantPaymentOrderDto entityToDto(MerchantOrderPayment merchantOrderPayment);

    /**
     * Converts MerchantOrderPayment entity to MerchantPaymentOrderDto.
     *
     * @return the DTO list representation of the merchant order payment
     */
    List<MerchantPaymentOrderDto> entityToDto(List<MerchantOrderPayment> merchantOrderPayments);

    /**
     * Converts MerchantOrderPayment entity to OrderResponse.
     *
     * @param merchantOrderPayment the entity containing merchant order payment details
     * @return the response model representation of the merchant order payment
     */
    @Mapping(target = "transactionDate", source ="createdDate")
    @Mapping(target = "transactionAmount", source ="debitAmount")
    @Mapping(target = "orderStatus", source ="order.status")
    OrderResponse entityToMerchantOrderResponse(MerchantOrderPayment merchantOrderPayment);

    // Map MerchantOrderPayment to PaymentVerificationDto
    @Mapping(source = "atrnNumber", target = "atrn")
    @Mapping(source = "debitAmount", target = "totalAmount")
    @Mapping(source = "channelBank", target = "bankName")
    @Mapping(source = "bankReferenceNumber", target = "bankTxnNumber")
    @Mapping(source = "payProcId", target = "processor")
    @Mapping(source = "createdDate", target = "transactionTime")
    PaymentInfoDto merchantOrderPaymentToPaymentInfoDto(MerchantOrderPayment merchantOrderPayment);
}
