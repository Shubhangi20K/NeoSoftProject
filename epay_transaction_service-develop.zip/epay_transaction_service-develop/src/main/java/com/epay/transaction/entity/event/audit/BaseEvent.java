package com.epay.transaction.entity.event.audit;

import com.epay.transaction.entity.AuditEntityByDate;
import com.epay.transaction.util.enums.InterfaceType;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.MappedSuperclass;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.SuperBuilder;


/**
 * Class Name: BaseEvent
 * Description:
 * Copyright (c) [2025] [State Bank of India]
 * All rights reserved.
 * Author:@V0000001(Shilpa Kothre)
 * Version:1.0
 */

@EqualsAndHashCode(callSuper = true)
@Data
@MappedSuperclass
@SuperBuilder
public class BaseEvent extends AuditEntityByDate {

    @Enumerated(EnumType.STRING)
    private InterfaceType interfaceType;
    private String topic;
    private String routingKey;
    private String message;

}

