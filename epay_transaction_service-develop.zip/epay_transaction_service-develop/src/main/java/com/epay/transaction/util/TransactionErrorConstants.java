package com.epay.transaction.util;

import lombok.experimental.UtilityClass;

/**
 * Class Name:TransactionErrorConstants
 * *
 * Description: this class contain TransactionErrorConstants
 * *
 * Author:V0000001(Shilpa Kothre)
 * <p>
 * Copyright (c) 2024 [State Bank of india]
 * All right reserved
 * *
 * Version:1.0
 */
@UtilityClass
public final class TransactionErrorConstants {

    /* Generic ErrorCodes */
    public static final String GENERIC_ERROR_CODE = "2110";
    public static final String MANDATORY_ERROR_CODE = "2001";
    public static final String MANDATORY_ERROR_MESSAGE = "{0} is required.";
    public static final String ENCRYPTED_REQUEST_IS_REQUIRED = "encryptedRequest is required.";
    public static final String ORDER_REQUEST_IS_REQUIRED = "orderRequest is required.";
    public static final String ORDER_REF_NUMBER_IS_REQUIRED = "orderRefNumber is required.";
    public static final String SBI_ORDER_REF_NUMBER_IS_REQUIRED = "sbiOrderRefNumber is required.";
    public static final String CHANNEL_BANK_IS_REQUIRED = "channelBank is required.";
    public static final String FAIL_REASON_IS_REQUIRED = "failReason is required.";
    public static final String STATUS_IS_REQUIRED = "status is required.";
    public static final String REFUND_TYPE_IS_REQUIRED = "refundType is required.";
    public static final String REFUND_AMOUNT_IS_REQUIRED = "refundAmount is required.";
    public static final String ATRN_NUMBER_IS_REQUIRED = "atrnNumber is required.";
    public static final String ATRN_IS_REQUIRED = "atrn is required.";
    public static final String ORDER_AMOUNT_IS_REQUIRED = "orderAmount is required.";
    public static final String NOT_FOUND_ERROR_CODE = "2003";
    public static final String NOT_FOUND_ERROR_MESSAGE = "{0} was not found.";
    public static final String ALREADY_EXIST_ERROR_CODE = "2004";
    public static final String ALREADY_EXIST_ERROR_MESSAGE = "{0} already exists.";
    public static final String FIXED_LENGTH_ERROR_CODE = "2005";
    public static final String FIXED_LENGTH_ERROR_MESSAGE = "The fixed length required for {0} is {1}.";


    public static final String ATTEMPT_EXPIRED_ERROR_CODE = "2202";
    public static final String ATTEMPT_EXPIRED_ERROR_MESSAGE = "Booking attempts limit exceeded for merchant order.";
    public static final String ATTEMPT_EXCEEDED_ERROR_CODE = "2109";
    public static final String ATTEMPT_EXCEEDED_ERROR_MESSAGE = "Maximum {0} retry attempts have been exceeded.";

    public static final String EXTERNAL_SERVICE_ERROR_CODE = "2101";
    public static final String EXTERNAL_SERVICE_ERROR_MESSAGE = "{0} service is currently unavailable. Please try again later.";
    public static final String EXTERNAL_SERVICE_4XX_ERROR_CODE = "2106";
    public static final String EXTERNAL_SERVICE_4XX_ERROR_MESSAGE = "Something went wrong while connecting {0} Service. Please try again";
    public static final String INVALID_ERROR_CODE = "2002";
    public static final String INVALID_ERROR_MESSAGE = "{0} is invalid. Reason : {1}";
    public static final String INVALID_JSTIN_ERROR_MESSAGE = "{0} is invalid";
    public static final String JSON_ERROR_CODE = "2011";
    public static final String JSON_ERROR_MESSAGE = "Invalid JSON data provided in {0}.";
    public static final String INVALID_STATUS_CODE = "2204";
    public static final String INVALID_STATUS_MESSAGE = "Order status cannot be modified.";
    public static final String INVALID_TXN_STATUS_CODE ="2209";
    public static final String INVALID_TXN_STATUS_MESSAGE ="The previous transaction was successful.";
    public static final String VALID_VALUES_ARE = "Valid values are ";
    /* Generic Messages */
    public static final String NULL_OR_EMPTY_ERROR_CODE = "2107";
    public static final String NULL_OR_EMPTY_ERROR_MESSAGE = "Value of {0} can not be null or empty.";
    public static final String S3_UPLOAD_FAILED = "S3 - Failed to upload file:{} on s3 with error:{}";
    public static final String LIMIT_EXCEED_ERROR_CODE = "2104";
    public static final String LIMIT_EXCEED_ERROR_MESSAGE = "{0} expiry cannot exceed 30 minutes.";
    public static final String REMARK = "remark";
    public static final String ATRN = "atrn";
    public static final String ARRN = "arrn";
    public static final String REFUND_TYPE = "refundType";
    public static final String FROM_DATE = "fromDate";
    public static final String TO_DATE = "toDate";
    public static final String INVALID_REMARK_REASON = "Please check remark format.";
    public static final String INVALID_ATRN_REASON = "Please check atrn format.";
    public static final String INVALID_ARRN_REASON = "Please check arrn format.";
    public static final String INVALID_ORDER_REF_REASON = "Please check order ref format.";
    public static final String INVALID_GATEWAY_REASON = "Please check gtwMapsId format.";
    public static final String EXCEED_LENGTH_ERROR_CODE = "2007";
    public static final String EXCEED_LENGTH_ERROR_MESSAGE = "The maximum allowed length for {0} is {1}.";
    public static final String NOT_BLANK = "Must not be blank";
    public static final String WHITESPACE_ERROR_CODE = "2010";
    public static final String WHITESPACE_ERROR_MESSAGE = "{0} contains leading or trailing spaces. Please provide a valid value.";
    public static final String INVALID_REFUND_TYPE_REASON = "Please check refundType format.";
    public static final String REASON = "failreason";

    /* Payment Functionality */
    public static final String PAYMENT_ERROR_CODE = "2102";
    public static final String PAYMENT_ERROR_MESSAGE = "An issue occurred during the {0} payment. Please try again.";

    public static final String PAYMENT_TRANSACTION_LIMIT_CODE = "2208";
    public static final String PAYMENT_LIMIT_ERROR_MESSAGE = "Merchant order payment limit exceeded.";

    public static final String PAYMENT_TIMELY_TRANSACTION_LIMIT_CODE = "2105";
    public static final String PAYMENT_TIMELY_LIMIT_ERROR_MESSAGE = "merchant order payment limit exceeded for {0}.";

    public static final String PAYMENT_LENGTH_ERROR_CODE = "2108";
    public static final String PAYMENT_LENGTH_ERROR_MESSAGE = "{0} length is not valid";

    /* Token Functionality */
    public static final String TOKEN_EXPIRATION_TIME = "Expiration time is required to generate a token for the merchant.";
    public static final String ACTIVE_TOKEN = "Active Token";

    /* Order Functionality */
    public static final String VALID_ORDER_HASH = "Valid OrderHash";
    public static final String MERCHANT_ORDR_PAYMENT_ST_NOT_VALID_AGAINST_ATRN = "MerchantOrderPayment status is not valid against passed ATRN.";
    public static final String MERCHANT_ORDER_PAYMENT_STATUS = "MerchantOrderPayment status";
    public static final String MERCHANT_ORDER = "MerchantOrder";
    public static final String ORDER_HASH = "Order Hash";
    public static final String INVALID_ORDER_HASH_REASON = "Please check order hash format";

    /* Refund Functionality */
    public static final String REFUND_AMOUNT = "RefundAmount";
    public static final String REFUND_REQUEST = "RefundRequest";
    public static final String REFUND_BOOKING_DETAIL = "Refund booking detail";
    public static final String REFUND_AMNT_MORE_THAN_AVAILABLE_AMNT_ERR_MSG = "Refund amount can not be more than available refund amount.";
    public static final String FULL_REFUND_AMOUNT_MIS_MATCH = "Refund amount does not match with available refund amount for full refund request type.";
    public static final String INVALID_REFUND_AMOUNT = "Invalid refund amount.";
    public static final String INVALID_REFUND_ERROR = "Something went wrong while processing request.";
    public static final String PARTIAL_PROCESS_MESSAGE = "Few rows can't be processed, please check details for erroneous rows.";
    public static final String SUCCESS_PROCESS_MESSAGE = "All rows processed successfully";
    public static final int CSV_MIN_VALUES_COUNT = 5;
    public static final String INVALID_REFUND_ROW = "Invalid row, required {0} column";
    public static final String REPORT_ROOT_FOLDER = "";
    public static final String FILE_GENERATION_ERROR_CODE = "2103";
    public static final String FILE_GENERATION_ERROR_MESSAGE = "Error during {0} generation: {1}.";

    public static final String SBI_ORDER_REF_NUMBER = "Sbi order Ref. Number";
    public static final String ORDER_REF_NUMBER = "Order Ref. Number";
    public static final String ORDER_AMOUNT = "Order amount";
    public static final String ORDER_EXPIRY = "Order Expiry";
    public static final String ORDER="Order";
    public static final String STATUS = "Status";
    public static final String MULTI_ACCOUNT = "Multi Account";
    public static final String INVALID_MULTIACCOUNT_IDENTIFIER = "MultiAccount identifier details are invalid.";
    public static final String  REQUEST_PARAMETER ="Request Parameter";
    public static final String MULTI_ACCOUNT_NOT_ENABLED="Multi Account is not enabled.";
    public static final String VALID_MERCHANT="Valid Merchant";
    public static final String VALID_PINCODE="Valid Pin Code";
    public static final String VALID_CITY="Valid City";
    public static final String VALID_STATE="Valid State";
    public static final String VALID_COUNTRY="Valid Country";
    public static final String GSTIN="gstin";

    public static final String IFSC ="ifsc";
    public static final String ACCOUNT ="account";
    public static final String MULTI_ACCOUNT_AMOUNT = "Multi account amount";
    public static final String SBIN="SBIN";

    //RFC Error Constants
    public static final String PAYMENT_RFC_THRESHOLD_ERROR_CODE = "2205";
    public static final String PAYMENT_RFC_THRESHOLD_ERROR_MESSAGE = "Transaction can not be initiated for given amount.";
    public static final String PAYMENT_RFC_DAILY_COUNT_ERROR_CODE = "2206";
    public static final String PAYMENT_RFC_DAILY_COUNT_ERROR_MESSAGE = "Daily card transaction count limit exceeded.";
    public static final String PAYMENT_RFC_DAILY_AMOUNT_ERROR_CODE = "2207";
    public static final String PAYMENT_RFC_DAILY_AMOUNT_ERROR_MESSAGE = "Daily card transaction amount limit exceeded.";

    public static final String REFUND_BOOK_REQUEST = "Refund book request";
    public static final String MERCHANT_REFUND_FLAG_NOT_ENABLED = "Refund booking is not enabled for this transaction.";
    public static final String MERCHANT_REFUND_WINDOW_EXPIRED = "Merchant refund window has expired.";
    public static final String INCORRECT_FORMAT = "Format is incorrect";
    public static final String CUSTOMER = "Customer";

    /*Generic Transaction Global Exception Handler Error Code/Message*/
    public static final String UNCATEGORIZED_ERROR_CODE="0003";
    public static final String UNCATEGORIZED_ERROR_MESSAGE="An unexpected error occurred while processing your request.";

    public static final String OR_ORDER_INVALID = " or Order is not valid.";

    public static final String INVALID_ERROR_CODE_NO_REASON = "2012";
    public static final String INVALID_ERROR_MESSAGE_NO_REASON = "{0} ''{1}'' is invalid.";

    public static final String INVALID_FORMAT_REASON = "Please check {0} format.";
    public static final String MERCHANT_ORDER_PAYMENT_STATUS_FAILED = "Merchant Order Payment status marked failed successfully.";
    public static final String INVALID_ATRN = "atrn status is not valid.";
    public static final String ATRN_INVALID = "Transaction status or atrn is not valid";

    public static final String INCORRECT_CARD_NUMBER_FORMAT = "Invalid cardNumber format";
    public static final String INCORRECT_GSTIN_NUMBER_FORMAT = "Invalid gstInNumber format";

    public static final String CARD_BIN = "Card Bin";
    public static final int CARD_BIN_LENGTH = 6;
    public static final String CARD_BIN_REGEX = "^\\d+$";
    public static final String MERCHANT_ORDER_ID = "Merchant Order Id";
    public static final String REFUND_CURRENCY = "Refund Currency";

    public static final String BANK_REF_NUMBER = "bankRefNumber";
    public static final String TRANSACTION_STATUS = "transactionStatus";
    public static final String ORDER_STATUS = "orderStatus";
    public static final String REFUND_STATUS = "refundStatus";
    public static final String PAYMENT_STATUS = "paymentStatus";
    public static final String INVALID_TRANSACTION_STATUS_REASON = "Please check transactionStatus format.";
    public static final String INVALID_ORDER_STATUS_REASON = "Please check orderStatus format.";
    public static final String INVALID_BANK_REF_REASON = "Please check bank ref number format.";
    public static final String INVALID_REUND_STATUS_REASON = "Please check refundStatus format.";
    public static final String INVALID_PAYMENT_STATUS_REASON = "Please check paymentStatus format.";
    public static final String INVALID_FORMAT = "Format is incorrect.";
    public static final String UNSUPPORTED_FILE_TYPE = "Unsupported file type.";
    public static final String INVALID_ENUM_ERROR_CODE = "2014";
    public static final String INVALID_ENUM_ERROR_MESSAGE = "{0} is invalid.";
    public static final String INVALID_SBIORDER_REFERENCE_REASON = "Please check sbiOrderRefNumber format.";
    public static final String INVALID_ERRORPAGE_MESSAGE = "{0} is exceeds the allowed limit. Value: {1}";
    public static final String DATE_RANGE = "dateRange";
    public static final String DATE_FORMAT_IN_LONG="^\\d+$";

    public static final String ONE_MANDATORY_ERROR= "At least one mandatory field from {0}";
    public static final String FUTURE_DATE_ERROR = "future date is not allowed";
    public static final String PAST_DATE_12M_ERROR = "past date more than 12 months is not allowed";
    public static final String FROM_TO_DATE_ERROR = "from date can not be more than to date";
    public static final String DATE_DIFF_1M_ERROR = "difference between from and to date more than 1 month is not allowed";


}
