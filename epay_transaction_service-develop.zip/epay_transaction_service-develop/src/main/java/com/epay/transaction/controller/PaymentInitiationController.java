package com.epay.transaction.controller;

import com.epay.transaction.model.request.EncryptedRequest;
import com.epay.transaction.model.response.EncryptedResponse;
import com.epay.transaction.model.response.TransactionResponse;
import com.epay.transaction.service.PaymentInitiationService;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

/**
 * Class Name:PaymentInitiationController
 * *
 * Description: Merchant Payment Processing
 * *
 * Author:V1018400(Ranjan Kumar)
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
@RestController
@RequiredArgsConstructor
@RequestMapping("/initiate-payment")
@Validated
public class PaymentInitiationController {
    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());

    private final PaymentInitiationService paymentInitiationService;

    /**
     * Method name : initiatePayment
     * Description :  processing payment
     * @param payMode : Defines payment mode
     * @param encryptedRequest: Object of encrypted paymentRequest
     * @return object of TransactionResponse
     */

    @PostMapping("/{payMode}")
    @Operation(summary = "Payment Initiation")
    @PreAuthorize("hasAnyRole('TRANSACTION')")
    public TransactionResponse<EncryptedResponse> initiatePayment(@PathVariable("payMode") String payMode, @Valid @RequestBody EncryptedRequest encryptedRequest) {
        logger.info(" Initiated payment Request for payMode {}", payMode);
        return paymentInitiationService.initiatePayment(payMode, encryptedRequest);
    }
}

