package com.epay.transaction.etl.producer;

import com.epay.transaction.config.kafka.Topics;
import com.epay.transaction.util.enums.InterfaceType;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Component;

import static com.epay.transaction.util.EventMessageUtils.buildEventErrorLog;
import static com.epay.transaction.util.EventMessageUtils.buildEventSendLog;
import static com.epay.transaction.util.TransactionConstant.RECON_FAILED_RECORD_KEY;

/**
 * Class Name: ReconRecordFailedDataProducer
 * Description: Kafka Service will publish Failed RfdId <br>
 * Author:@V0000001(Shilpa Kothre)<br>
 * Copyright (c) 2025 [State Bank of India]<br>
 * All rights reserved<br>
 * Version:1.0
 */
@Component
@RequiredArgsConstructor
public class ReconRecordFailedDataProducer extends TransactionProducer<String> {
    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    private final KafkaMessagePublisher kafkaMessagePublisher;
    private final Topics topics;
    private final ObjectMapper objectMapper;
    private final ApplicationEventPublisher publisher;

    /**
     * @param requestType  String
     * @param routingKey   String
     * @param message String
     */
    public void publish(String requestType, String routingKey, String message) {
        log.debug("ReconFileProcessingPublisher for requestType : {}, routingKey : {} and value : {}", requestType, routingKey, message);
        String kafkaRoutingKey = getRoutingKey(requestType, RECON_FAILED_RECORD_KEY, routingKey);
        try {
            publisher.publishEvent(buildEventSendLog(InterfaceType.TXN_RECON_FAIL_ACK_TOPIC, topics.getReconFailAckTopic(), kafkaRoutingKey, message));
            kafkaMessagePublisher.publish(topics.getReconFailAckTopic(), kafkaRoutingKey, message);
            log.debug("ReconFileProcessing has been published");
        } catch (Exception e) {
            publisher.publishEvent(buildEventErrorLog(InterfaceType.TXN_RECON_FAIL_ACK_TOPIC, topics.getReconFailAckTopic(), kafkaRoutingKey, e.getMessage()));
            log.error("Error in ReconFileProcessing , rfdId:Remark {}", message, e.getMessage());
        }
    }


}
