package com.epay.transaction.model.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Class Name:CustomerRequest
 * *
 * Description: This pojo will have customer create request after decryption.
 * *
 * Author:v1014352(Ranjan Kumar)
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CustomerRequest {

    private String customerName;
    private String email;
    private String gstIn;
    private String gstInAddress;
    private String phoneNumber;
    private String address1;
    private String address2;
    private String city;
    private String state;
    private String country;
    private String pinCode;

}