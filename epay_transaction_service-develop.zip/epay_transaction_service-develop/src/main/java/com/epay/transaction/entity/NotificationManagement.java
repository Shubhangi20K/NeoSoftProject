package com.epay.transaction.entity;

import com.epay.transaction.util.enums.NotificationEntityType;
import com.epay.transaction.util.enums.NotificationType;
import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.util.UUID;

/**
 * Class Name:NotificationManagement
 * *
 * Description: This entity used to handle the notification related info.
 * *
 * Author:Gireesh M
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
@EqualsAndHashCode(callSuper = true)
@Getter
@Setter
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "NOTIFICATION_MANAGEMENT")
public class NotificationManagement extends AuditEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;
    @Enumerated(EnumType.STRING)
    private NotificationEntityType entityName;
    private UUID entityId;
    private String requestType;
    @Enumerated(EnumType.STRING)
    private NotificationType notificationType;
    private String content;
    private int status;
}
