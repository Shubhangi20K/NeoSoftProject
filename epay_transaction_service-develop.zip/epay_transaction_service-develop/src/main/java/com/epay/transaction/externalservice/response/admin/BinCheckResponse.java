package com.epay.transaction.externalservice.response.admin;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.ToString;

/**
 * Class Name: BinCheckResponse
 * *
 * Description:
 * *
 * Author: V1018217
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */


@AllArgsConstructor
@Data
@ToString
public class BinCheckResponse {
    private String binType;
    private String cardProcessor;
    private String binOpModeId;
    private String binIssuerId;
}
