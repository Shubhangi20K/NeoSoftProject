package com.epay.transaction.dao;

import com.epay.transaction.dto.DeviceDetailsDto;
import com.epay.transaction.dto.OrderDto;
import com.epay.transaction.dto.TokenDto;
import com.epay.transaction.entity.Token;
import com.epay.transaction.exceptions.TransactionException;
import com.epay.transaction.externalservice.response.admin.MerchantInfoResponse;
import com.epay.transaction.mapper.TokenMapper;
import com.epay.transaction.repository.TokenRepository;
import com.epay.transaction.repository.TransactionDeviceInfoRepository;
import com.epay.transaction.util.EPayIdentityUtil;
import com.epay.transaction.util.TransactionErrorConstants;
import com.epay.transaction.util.enums.EntityType;
import com.epay.transaction.util.enums.TokenStatus;
import com.sbi.epay.authentication.util.enums.TokenType;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.stereotype.Component;

import java.text.MessageFormat;
import java.util.Optional;

import static com.epay.transaction.util.TransactionErrorConstants.*;

/**
 * Class Name:TokenDao
 * Description: DAO class responsible for handling token-related database operations.
 * Copyright (c) [2024] [State Bank of India]
 * All rights reserved.
 * <p>
 * Author:@V0000001(Shilpa Kothre)
 * Version:1.0
 */
@Component
@RequiredArgsConstructor
public class TokenDao {

    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private final TokenRepository tokenRepository;
    private final TransactionDeviceInfoRepository transactionDeviceInfoRepository;
    private final TokenMapper tokenMapper;
    private final KmsDao kmsDao;
    private final AdminDao adminDao;
    private final OrderDao orderDao;
    private final ErrorLogDao errorLogDao;

    /**
     * Method name : saveToken
     * Description : Saves a token in the database.
     *
     * @param tokenDto is an object of TokenDto
     */
    public void saveToken(TokenDto tokenDto) {
        logger.debug("Saving token with details: {}", tokenDto);
        Token token = tokenMapper.dtoToEntity(tokenDto);
        tokenRepository.save(token);
        logger.info("Token saved successfully.");
    }

    /**
     * Method name : getMIdByKeyIdAndSecret
     * Description : Retrieves Merchant ID using API key ID and scrt.
     *
     * @param merchantApiKeyId   API key ID of the merchant.
     * @param merchantApiKeyScrt API key scrt of the merchant.
     * @return Merchant ID.
     */
    public String getMIdByKeyIdAndSecret(String merchantApiKeyId, String merchantApiKeyScrt) {
        logger.info("Fetching Merchant ID using API key.");
        return kmsDao.getMIdByKeyIdAndSecret(merchantApiKeyId, merchantApiKeyScrt);
    }

    /**
     * Method name : getMerchantByMId
     * Description : Retrieves merchant details by Merchant ID.
     *
     * @param mId Merchant ID.
     * @return Merchant information response.
     */
    public MerchantInfoResponse getMerchantByMId(String mId) {
        logger.info("Fetching merchant details for MID: {}", mId);
        return adminDao.getMerchantByMId(mId);
    }

    /**
     * Method name : getMerchantOrderByOrderHash
     * Description : Fetch merchant Order from database using orderHash
     *
     * @param orderHash Order hash String
     * @return Merchant order details.
     */
    public OrderDto getMerchantOrderByOrderHash(String orderHash) {
        logger.info("Fetching merchant order for order hash: {}", orderHash);
        return orderDao.getActiveOrderByOrderHash(orderHash);
    }

    /**
     * Method name : isMerchantExistByMid
     * Description : Checks if a merchant exists using the Merchant ID.
     *
     * @param mId Merchant ID.
     * @return boolean true if merchant exists, false otherwise.
     */
    public boolean isMerchantExistByMid(String mId) {
        logger.info("Checking if merchant exists for mId: {}", mId);
        return ObjectUtils.isNotEmpty(adminDao.getMerchantByMId(mId));
    }

    /**
     * Method name : invalidateToken
     * Description : Set token status Inactive
     *
     * @param requestedToken Token to be invalidated.
     */
    public void invalidateToken(String requestedToken) {
        logger.info("Invalidating token: {}", requestedToken);
        Token token = tokenRepository.findFirstByGeneratedTokenAndStatusAndIsTokenValid(requestedToken, TokenStatus.ACTIVE, true).orElseThrow(() -> {
            errorLogDao.logCustomerError(null, EntityType.TOKEN, null,null,null,null,NOT_FOUND_ERROR_CODE, MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, ACTIVE_TOKEN));
            return new TransactionException(TransactionErrorConstants.NOT_FOUND_ERROR_CODE, MessageFormat.format(TransactionErrorConstants.NOT_FOUND_ERROR_MESSAGE, TransactionErrorConstants.ACTIVE_TOKEN));
        });
        markTokenInActive(token);
        tokenRepository.save(token);
        logger.info("Token invalidated successfully.");
    }

    /**
     * Method name : getActiveAccessTokenByMId
     * Description : Retrieves an active access token by Merchant ID.
     *
     * @param mId Merchant ID.
     * @return Optional containing TokenDto if found.
     */
    public Optional<TokenDto> getActiveAccessTokenByMId(String mId) {
        logger.info("Finding active ACCESS token for MID: {}", mId);
        Optional<Token> token = tokenRepository.findLatestValidToken(mId, System.currentTimeMillis());
        logger.info("ACCESS token found ");
        return token.map(tokenMapper::entityToDto);
    }

    /**
     * Method name : getEncryptionAESKey
     * Description : Fetch AES key from database
     *
     * @param generatedToken Token String
     * @return a String of AESKey
     */
    public String getEncryptionAESKey(String generatedToken) {
        logger.debug("Fetching AES key for token: {}", generatedToken);
        Token token = tokenRepository.findFirstByGeneratedTokenAndStatus(generatedToken, TokenStatus.ACTIVE).orElseThrow(() ->
        {
            errorLogDao.logBusinessError(EPayIdentityUtil.getUserPrincipal().getMId(), EntityType.PAYMENT, null, null, null, null,
                    NOT_FOUND_ERROR_CODE, MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, "Encryption Key"));
            return new TransactionException(TransactionErrorConstants.NOT_FOUND_ERROR_CODE, MessageFormat.format(TransactionErrorConstants.NOT_FOUND_ERROR_MESSAGE, "Encryption Key"));
        });
        logger.info("Getting Aes Key");
        return token.getAesKey();
    }

    /**
     * Method name : getHvalBySbiRefenceNumber
     * Description : Fetch AES key from database
     *
     * @param sbiOrderRefNumber String
     * @return a String of AESKey
     */
    public String findAesKeyBySbiOrderRefNumber(String sbiOrderRefNumber) {

        return tokenRepository.findAesKeyBySbiOrderRefNumber(sbiOrderRefNumber).get().getAesKey();
    }


    /**
     * Method name : saveTransactionRequestedDeviceInfo
     * Description : saving Device Details Information in database
     *
     * @param deviceDetailsDto DTO containing device details.
     */
    public void saveTransactionRequestedDeviceInfo(DeviceDetailsDto deviceDetailsDto) {
        logger.info("Saving transaction device info: {}", deviceDetailsDto);
        transactionDeviceInfoRepository.save(tokenMapper.dtoToEntity(deviceDetailsDto));
        logger.info("Device information saved successfully.");
    }

    /**
     * Method name : findByGeneratedTokenAndStatus
     * Description : Checks if a token exists with a given status and type.
     *
     * @param token     Token string.
     * @param tokenType Type of token.
     * @return boolean
     */
    public boolean findByGeneratedTokenAndStatus(String token, TokenType tokenType) {
        logger.info("Checking if token exists");
        return tokenRepository.existsByGeneratedTokenAndTokenTypeAndStatusAndIsTokenValid(token, tokenType, TokenStatus.ACTIVE, Boolean.TRUE);
    }

    /**
     * Method name : markTokenExpired
     * Description : marking Token status as inactive Using Scheduler
     */
    @Transactional
    public void markTokenExpired() {
        logger.info("Marking expired tokens as inactive.");
        Long currentTime = System.currentTimeMillis();

        if (tokenRepository.existsByStatusAndTokenExpiryTimeLessThan(TokenStatus.ACTIVE, currentTime)) {

            Integer totalTokenExpired = tokenRepository.updateTokenStatusInactive(String.valueOf(currentTime));

            logger.info("Marked Total {} Token Expired", totalTokenExpired);
        }
    }

    /**
     * Method name : markTokenInActive
     * Description : Setting Token status as inactive Using Scheduler
     *
     * @param token is a String
     */
    private void markTokenInActive(Token token) {
        logger.debug("Marking token as inactive: {}", token);
        token.setTokenValid(Boolean.FALSE);
        token.setStatus(TokenStatus.INACTIVE);
        token.setExpiredAt(System.currentTimeMillis());
    }


    /**
     * Method name : validatedTokenByOrderHash
     * Description : Validates a token based on order hash.
     *
     * @param orderHash is a String
     */
    public void validatedTokenByOrderHash(String orderHash) {
        logger.debug("Validating token for order hash: {}", orderHash);
        Optional<Token> token = tokenRepository.findLatestTokenByOrderHash(orderHash);
        if (token.isPresent()) {
            if (TokenStatus.INACTIVE.equals(token.get().getStatus())) {
                logger.debug("Token status is inactive for orderHash: {}", orderHash);
                throw new TransactionException(ATTEMPT_EXPIRED_ERROR_CODE, ATTEMPT_EXPIRED_ERROR_MESSAGE);
            } else {
                logger.info("Token already exist for that order");
                throw new TransactionException(ALREADY_EXIST_ERROR_CODE, MessageFormat.format(ALREADY_EXIST_ERROR_MESSAGE, "Token"));
            }

        }
    }

}
