package com.epay.transaction.util.dcms.eis;


import com.epay.transaction.exceptions.TransactionException;
import com.epay.transaction.util.TransactionConstant;
import com.epay.transaction.util.TransactionErrorConstants;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.*;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.text.MessageFormat;
import java.util.Arrays;
import java.util.Base64;

import static org.apache.commons.lang3.StringUtils.EMPTY;


@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class DCMSEISEncryptionDecryptionUtil {
    private static final LoggerUtility logger = LoggerFactoryUtility.getLogger(DCMSEISEncryptionDecryptionUtil.class);
   private static final String GST_ENCRYPT_ALGO = "AES/GCM/NoPadding";
    private static final int GCM_TAG_LENGTH = 128;

    public static String decrypt(String encryptedValue, String AESKey) {
        byte[] keyByte = AESKey.getBytes(StandardCharsets.UTF_8);
        IvParameterSpec iv = new IvParameterSpec(Arrays.copyOf(keyByte, 12));
        SecretKeySpec skeySpec = new SecretKeySpec(keyByte, "AES");
        Cipher cipher;
        GCMParameterSpec spec = new GCMParameterSpec(GCM_TAG_LENGTH, iv.getIV());
        try {

            cipher = Cipher.getInstance(GST_ENCRYPT_ALGO);
        } catch (NoSuchAlgorithmException | NoSuchPaddingException e) {
            logger.error("error in decrypting DCMSRequest: {}",e.getMessage());
            throw  new TransactionException(TransactionErrorConstants.GENERIC_ERROR_CODE,e.getMessage());
        }
        try {

            cipher.init(Cipher.DECRYPT_MODE, skeySpec, spec);
        } catch (InvalidKeyException | InvalidAlgorithmParameterException e) {
            logger.error("error in init cipher: {}",e.getMessage());
            throw  new TransactionException(TransactionErrorConstants.GENERIC_ERROR_CODE,e.getMessage());
        }
        byte[] decodedBytes;
        decodedBytes = Base64.getDecoder().decode(encryptedValue);

        byte[] decrypted;
        try {
            decrypted = cipher.doFinal(decodedBytes);
        } catch (IllegalBlockSizeException | BadPaddingException e) {
            logger.error("error in decrypting decodedBytes: {}",e.getMessage());
            throw  new TransactionException(TransactionErrorConstants.GENERIC_ERROR_CODE,e.getMessage());
        }
        return new String(decrypted);
    }

    public static String encryptGst(String request, String AESKey) {
        logger.info("encrypt eis starts");
        byte[] keybyte = AESKey.getBytes(StandardCharsets.UTF_8);
        byte[] ivkey = Arrays.copyOf(keybyte, 12);
        IvParameterSpec iv = new IvParameterSpec(ivkey);
        SecretKeySpec skeySpec = new SecretKeySpec(keybyte, "AES");
        Cipher cipher;
        byte[] encrypted;
        try {
            GCMParameterSpec spec = new GCMParameterSpec(GCM_TAG_LENGTH, iv.getIV());
            cipher = Cipher.getInstance(GST_ENCRYPT_ALGO);

            cipher.init(Cipher.ENCRYPT_MODE, skeySpec, spec);

            encrypted = cipher.doFinal(request.getBytes(StandardCharsets.UTF_8));
        } catch (NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException |
                 InvalidAlgorithmParameterException | IllegalBlockSizeException | BadPaddingException e) {
            logger.error("error in encrypting gstRequest: {}",e.getMessage());
            throw new TransactionException(TransactionErrorConstants.GENERIC_ERROR_CODE,e.getMessage());
        }
        return Base64.getEncoder().encodeToString(encrypted).replace("\n", "");
    }

    public static String decryptgst(String encryptedValue, String AESKey) {
        byte[] keyByte = AESKey.getBytes(StandardCharsets.UTF_8);
        IvParameterSpec iv = new IvParameterSpec(Arrays.copyOf(keyByte, 12));
        SecretKeySpec skeySpec = new SecretKeySpec(keyByte, "AES");

        Cipher cipher;
        GCMParameterSpec spec = new GCMParameterSpec(GCM_TAG_LENGTH, iv.getIV());
        try {

            cipher = Cipher.getInstance(GST_ENCRYPT_ALGO);
        } catch (NoSuchAlgorithmException | NoSuchPaddingException e) {
            logger.error("error in decrypting gstRequest: {}",e.getMessage());
           throw  new TransactionException(TransactionErrorConstants.GENERIC_ERROR_CODE,e.getMessage());
        }
        try {

            cipher.init(Cipher.DECRYPT_MODE, skeySpec, spec);
        } catch (InvalidKeyException | InvalidAlgorithmParameterException e) {
            logger.error("error in init cipher: {}",e.getMessage());
           throw  new TransactionException(TransactionErrorConstants.GENERIC_ERROR_CODE,e.getMessage());
        }
        byte[] decodedBytes;
        decodedBytes = Base64.getDecoder().decode(encryptedValue);

        byte[] decrypted;
        try {
            decrypted = cipher.doFinal(decodedBytes);
        } catch (IllegalBlockSizeException | BadPaddingException e) {
            logger.error("error in decrypting decodedBytes: {}",e.getMessage());
            throw  new TransactionException(TransactionErrorConstants.GENERIC_ERROR_CODE,e.getMessage());
        }
        return new String(decrypted);
    }


    public static String encryptPublicKey(String aesKey, PublicKey publicKey) {
        try {
            Cipher cipher = Cipher.getInstance(TransactionConstant.CIPHER_RSA_ECB);
            cipher.init(Cipher.ENCRYPT_MODE, publicKey);
            byte[] dataInByte = cipher.doFinal(aesKey.getBytes(StandardCharsets.UTF_8));
            return DCMSEISEncoderUtil.encode(dataInByte).replaceAll("\n", "");
        } catch (NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException | IllegalBlockSizeException |
                 BadPaddingException e) {
            logger.error("Issue in encrypt PublicKey for EIS, {}", e.getMessage());
            throw new TransactionException(TransactionErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(TransactionErrorConstants.INVALID_ERROR_MESSAGE, "EIS Key Encryption", "EIS Public Key Encryption Failed"));
        }
    }




    public static String signSHA256RSA(String requestData, String privateKeyPath) {
        logger.debug("Private Key Path: {}", privateKeyPath);
        try {
            byte[] keyb = Files.readAllBytes(Paths.get(privateKeyPath));
            String temp = new String(keyb);
            String realPK = temp.substring(temp.indexOf("\n", temp.indexOf("-----BEGIN")) + 1, temp.indexOf("-----END"))
                    .replaceAll("\\s+", EMPTY);
            byte[] b1 = Base64.getDecoder().decode(realPK);
            PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(b1);
            KeyFactory kf = KeyFactory.getInstance("RSA");
            Signature privateSignature = Signature.getInstance(TransactionConstant.SIGN_ALGO);
            privateSignature.initSign(kf.generatePrivate(spec));
            privateSignature.update(requestData.getBytes(StandardCharsets.UTF_8));
            byte[] s = privateSignature.sign();
            return DCMSEISEncoderUtil.encode(s).replaceAll("\n", EMPTY);
        } catch (IOException | NoSuchAlgorithmException | InvalidKeySpecException | InvalidKeyException |
                 SignatureException e) {
            logger.error("Issue in signSHA256RSA, error: {}, for requestData: {}", e.getMessage(), requestData);
            throw new TransactionException(TransactionErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(TransactionErrorConstants.INVALID_ERROR_MESSAGE, "EIS privateSignature File", "File Not found or Issue in privateKeySignature Creation"));
        }
    }

    public static PublicKey getEISPublicKey(String filename) {
        logger.info("Public Key Path of EIS: {}", filename);
        try {
            FileInputStream fin = new FileInputStream(filename);
            CertificateFactory f = CertificateFactory.getInstance("X.509");
            X509Certificate certificate = (X509Certificate) f.generateCertificate(fin);
            return certificate.getPublicKey();
        } catch (FileNotFoundException | CertificateException e) {
            logger.error("Issue in Loading EIS Certificate file, {}", e.getMessage());
            throw new TransactionException(TransactionErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(TransactionErrorConstants.INVALID_ERROR_MESSAGE, "EIS Certificate File", "File Not found or Issue in Certification Creation"));
        }
    }



}



