package com.epay.transaction.dao;


import com.epay.transaction.config.TransactionConfig;
import com.epay.transaction.dto.CallBackFinalResponseDto;
import com.epay.transaction.exceptions.TransactionException;
import com.epay.transaction.externalservice.KmsServicesClient;
import com.epay.transaction.externalservice.PaymentCallBackServicesClient;
import com.epay.transaction.externalservice.request.payment.*;

import com.epay.transaction.externalservice.response.kms.KMSEncryptionKeysResponse;
import com.epay.transaction.externalservice.response.payment.RupaySeamlessResponse;

import com.epay.transaction.model.request.PaymentCallBackRequest;
import com.epay.transaction.model.response.EncryptedResponse;
import com.epay.transaction.model.response.TransactionResponse;
import com.epay.transaction.repository.MerchantOrderPaymentRepository;
import com.epay.transaction.util.EPayIdentityUtil;
import com.epay.transaction.util.TransactionConstant;
import com.epay.transaction.util.TransactionErrorConstants;
import com.epay.transaction.util.enums.EntityType;
import com.sbi.epay.authentication.providers.EPayTokenProvider;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.text.MessageFormat;
import java.util.List;

import static com.epay.transaction.util.EncryptionDecryptionUtil.decryptValue;
import static com.epay.transaction.util.EncryptionDecryptionUtil.encryptValue;
import static com.epay.transaction.util.TransactionErrorConstants.*;
import static com.epay.transaction.util.TransactionUtil.toJson;


@Component
@RequiredArgsConstructor
public class PaymentCallbackForwardDao {
    private final TokenDao tokenDao;
    private final EPayTokenProvider ePayTokenProvider;
    private final PaymentCallBackServicesClient paymentCallBackServicesClient;
    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private final KmsServicesClient kmsServicesClient;
    private final TransactionConfig transactionConfig;
    private final MerchantOrderPaymentRepository merchantOrderPaymentRepository;
    private final ErrorLogDao errorLogDao;

    /**
     * Method name : getEncryptedAESKey
     * Description :  Fetching AES Key
     *
     * @return String of AES Key
     */
    public String getEncryptedAESKey() {
        logger.info("Fetching AES key from Token Table");
        return tokenDao.getEncryptionAESKey(ePayTokenProvider.getToken());
    }

    /**
     * @param mid:String
     * @return String
     */
    public String getMerchantMekKey(String mid) {
        KMSEncryptionKeysResponse encryptionKeysResponse = getMekByMid(mid);
        String kek = decryptValue(encryptionKeysResponse.getAek(), encryptionKeysResponse.getKek());
        return decryptValue(kek, encryptionKeysResponse.getMek());
    }

    /**
     * @param mId:String
     * @return String
     */
    private KMSEncryptionKeysResponse getMekByMid(String mId) {
        TransactionResponse<KMSEncryptionKeysResponse> kmsResponse = kmsServicesClient.getEncryptionKeys(mId);
        if (TransactionConstant.RESPONSE_SUCCESS == kmsResponse.getStatus() && CollectionUtils.isNotEmpty(kmsResponse.getData())) {
            KMSEncryptionKeysResponse encryptionKeyResponse = kmsResponse.getData().getFirst();
            encryptionKeyResponse.setAek(transactionConfig.getAek());
            return encryptionKeyResponse;
        } else if (CollectionUtils.isNotEmpty(kmsResponse.getErrors())) {
            throw new TransactionException(kmsResponse.getErrors());
        }
        throw new TransactionException(TransactionErrorConstants.NOT_FOUND_ERROR_CODE, MessageFormat.format(TransactionErrorConstants.NOT_FOUND_ERROR_MESSAGE, "Merchant Encryption Keys"));
    }


    public EncryptedResponse processRupayCardResendOtp(PaymentRequestResendCard paymentRequestResendCard, String key) {
        logger.info("Payment callBack process Started");
        TransactionResponse<RupaySeamlessResponse> rupayCardCallBackResentOtpResponse = paymentCallBackServicesClient.getRupayCardCallBackResentOtpResponse(paymentRequestResendCard);
        return handleCallBackResponse(rupayCardCallBackResentOtpResponse, key, "rupayRecentOtp");
    }


    public EncryptedResponse processRupayCardVerifyOtp(PaymentRequestVerifyCard paymentRequestResendCard, String key) {
        logger.info("Payment callBack process Started");
        TransactionResponse<RupaySeamlessResponse> rupayCardCallBackVerifyOtpResponse = paymentCallBackServicesClient.getRupayCardCallBackVerifyOtpResponse(paymentRequestResendCard);
        return handleCallBackResponse(rupayCardCallBackVerifyOtpResponse, key, "rupayVerifyOtp");
    }


    private <T> EncryptedResponse handleCallBackResponse(TransactionResponse<T> response, String key, String callBackType) {
        logger.info("Handling response for payment type: {}", callBackType);
        if (TransactionConstant.RESPONSE_SUCCESS == response.getStatus() && CollectionUtils.isNotEmpty(response.getData())) {
            String encryptionResponse = encryptValue(key, toJson(response.getData().getFirst()));
            return EncryptedResponse.builder().encryptedResponse(encryptionResponse).build();
        } else if (TransactionConstant.RESPONSE_FAILURE == response.getStatus() && CollectionUtils.isNotEmpty(response.getErrors())) {
            throw new TransactionException(response.getErrors());
        }
        errorLogDao.logBusinessError(EPayIdentityUtil.getUserPrincipal().getMId(), EntityType.PAYMENT,null,null,null,null, NOT_FOUND_ERROR_CODE, MessageFormat.format(TransactionErrorConstants.PAYMENT_ERROR_MESSAGE, callBackType));
        throw new TransactionException(TransactionErrorConstants.PAYMENT_ERROR_CODE, MessageFormat.format(TransactionErrorConstants.PAYMENT_ERROR_MESSAGE, callBackType));
    }

    public String buildEncryptedResponse(PaymentCallBackRequest paymentCallBackRequest, String encryptedResponse, String url) {
        CallBackFinalResponseDto callBackFinalResponseDto = buildEncryptedFinalResponse(paymentCallBackRequest, encryptedResponse, url);
        TransactionResponse<CallBackFinalResponseDto> transactionResponse=TransactionResponse.<CallBackFinalResponseDto>builder().data(List.of(callBackFinalResponseDto)).status(1).build();
        String aes = tokenDao.findAesKeyBySbiOrderRefNumber(paymentCallBackRequest.getSbiOrderRefNo());
        return encryptValue(aes, toJson(transactionResponse));
    }

    private CallBackFinalResponseDto buildEncryptedFinalResponse(PaymentCallBackRequest paymentCallBackRequest, String encryptedResponse, String url) {
        return CallBackFinalResponseDto.builder().encryptedPaymentFinalResponse(encryptedResponse).order_Retry_Count(paymentCallBackRequest.getOrderRetryCount()).atrn(paymentCallBackRequest.getAtrn()).status(paymentCallBackRequest.getStatus()).
                reason(paymentCallBackRequest.getReason()).sbi_Order_Ref_No(paymentCallBackRequest.getSbiOrderRefNo()).merchnat_order_Ref_No(paymentCallBackRequest.getMerchnatOrderRefNo()).debit_Amount(paymentCallBackRequest.getDebitAmount()).return_URL(transactionConfig.getPaymentCallbackUrl()).build();
    }
    public void validateByAtrnMidAndOrderRefNumber(String mId, String sbiOrderRefNumber, String atrn) {
        logger.info("Validating Mid, Atrn And OrderRefNumber");
        if (!merchantOrderPaymentRepository.existsBymIdAndSbiOrderRefNumberAndAtrnNumber(mId, sbiOrderRefNumber, atrn)) {
            throw new TransactionException(TransactionErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(TransactionErrorConstants.INVALID_ERROR_MESSAGE, ATRN, ATRN_INVALID));
        }
    }
}
