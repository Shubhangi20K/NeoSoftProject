package com.epay.transaction.dto;

import com.epay.transaction.util.enums.NotificationEntityType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;
import java.util.UUID;

/**
 * Class Name: TransactionEmailDto
 * *
 * Description: Data transfer of type email.
 * *
 * Author: Gireesh M
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TransactionEmailDto {

    private UUID entityId;
    private String requestType;
    private NotificationEntityType entityType;

    private String subject;
    private String emailTemplate;

    private Map<String, Object> body;
    private String from;

    private String recipient;
    private String cc;
    private String bcc;
}
