package com.epay.transaction.model.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

import static com.epay.transaction.util.TransactionErrorConstants.ATRN_IS_REQUIRED;
import static com.epay.transaction.util.TransactionErrorConstants.FAIL_REASON_IS_REQUIRED;

@Data
public class TransactionUpdateRequest {

    @NotBlank(message = ATRN_IS_REQUIRED)
    private String atrn;
    @NotBlank(message = FAIL_REASON_IS_REQUIRED)
    private String failReason;
}