package com.epay.transaction.util;

import com.epay.transaction.dto.TransactionNotificationDto;
import com.epay.transaction.exceptions.TransactionException;
import com.epay.transaction.util.enums.EmailType;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import java.text.MessageFormat;
import java.util.Map;

import static com.epay.transaction.util.TransactionConstant.REQUEST_TYPE_FAILURE;
import static com.epay.transaction.util.TransactionConstant.REQUEST_TYPE_SUCCESS;

/**
 * Class Name:EmailUtil
 * *
 * Description: This class is used for generated transaction notification for email
 * *
 * Author:Gireesh M
 * <p>
 * Copyright (c) 2025 [State Bank of india]
 * All right reserved
 * *
 * Version:1.0
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class EmailUtil {

    public static Map<String, Object> generatedTransactionNotification(TransactionNotificationDto transactionNotificationDto) {
        return Map.of("currencyCode", transactionNotificationDto.getCurrencyCode(), "gtwPostingAmt", transactionNotificationDto.getGtwPostingAmount(), "payMode", transactionNotificationDto.getPayMode(), "merchantBrandName",transactionNotificationDto.getMerchantBrandName(),"txnDate", transactionNotificationDto.getTxnDate());
    }
    public static EmailType getEMailType(String requestType) {
        return switch (requestType) {
            case REQUEST_TYPE_SUCCESS -> EmailType.TRANSACTION_SUCCESS;
            case REQUEST_TYPE_FAILURE -> EmailType.TRANSACTION_FAILURE;
            default -> throw new TransactionException(TransactionErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(TransactionErrorConstants.INVALID_ERROR_MESSAGE, "Email type", "The given email type is not present."));
        };
    }
}
