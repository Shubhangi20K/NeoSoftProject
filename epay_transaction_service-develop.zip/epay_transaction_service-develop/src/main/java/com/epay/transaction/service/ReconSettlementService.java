package com.epay.transaction.service;


import com.epay.transaction.dao.AdminDao;
import com.epay.transaction.dao.MerchantOrderDuplicatePaymentsDao;
import com.epay.transaction.dao.MerchantOrderPaymentDao;
import com.epay.transaction.dao.RefundDao;
import com.epay.transaction.dto.*;
import com.epay.transaction.etl.producer.ReconRecordFailedDataProducer;
import com.epay.transaction.exceptions.TransactionException;
import com.epay.transaction.externalservice.response.admin.MerchantInfoResponse;
import com.epay.transaction.mapper.MerchantOrderDuplicatePaymentsMapper;
import com.epay.transaction.util.enums.PaymentStatus;
import com.epay.transaction.util.enums.TransactionStatus;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import static com.epay.transaction.util.TransactionConstant.*;
import static com.epay.transaction.util.TransactionErrorConstants.NOT_FOUND_ERROR_CODE;

/**
 * Class Name: ReconSettlementService
 * <p>
 * Description: service to process matched atrn records
 * <p>
 * Copyright (c) [2025] [State Bank of India]
 * All rights reserved.
 * <p>
 * Author:@V0000001(Shilpa Kothre)
 * Version:1.0
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ReconSettlementService {

    public final MerchantOrderDuplicatePaymentsMapper merchantOrderDuplicatePaymentsMapper;
    public final MerchantOrderPaymentDao merchantOrderPaymentDao;
    public final AdminDao adminDao;
    public final RefundDao refundDao;
    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private final ReconRecordFailedDataProducer reconRecordFailedDataProducer;
    private final MerchantOrderDuplicatePaymentsDao merchantOrderDuplicatePaymentsDao;


    @Transactional
    public void processingMatchedTransaction(ReconDataDto reconDataDto) {
        logger.info("Start processingMatchedTransaction");
        try {
            MerchantPaymentOrderDto merchantPaymentOrderDto = merchantOrderPaymentDao.findByAtrn(reconDataDto.getAtrnNum());
            if (ObjectUtils.isEmpty(merchantPaymentOrderDto.getSettlementStatus())) {
                logger.info("Inside reconProcessingForMatchedTransaction -> merchantPaymentOrderDto : {}", merchantPaymentOrderDto);
                if (merchantPaymentOrderDto.getTransactionStatus().equals(TransactionStatus.SUCCESS) && (merchantPaymentOrderDto.getPaymentStatus().equals(PaymentStatus.SUCCESS))) {
                    logger.info("update merchantOrderPaymentDao for MATCHED_SUCCESS");
                    merchantOrderPaymentDao.update(reconDataDto, TXN_SUCCESS);
                } else {
                    logger.info("update merchantOrderPaymentDao for MATCHED_FAILED_TXN");
                    MerchantInfoResponse merchantInfoResponse = adminDao.getMerchantByMId(merchantPaymentOrderDto.getMId());
                    logger.info("DVP flag for mId: {} is:{}", merchantInfoResponse.getMId(), merchantInfoResponse.getDvpType());
                    if (DVP.equalsIgnoreCase(merchantInfoResponse.getDvpType())) {
                        logger.info("Inside reconProcessingForMatchedTransaction -> refund initiated");
                        refundDao.saveDvpRefundBooking(merchantPaymentOrderDto);
                        merchantOrderPaymentDao.update(reconDataDto, TXN_FAILED_DVP);
                        String errorMessage = reconDataDto.getRfdId() + ":DVP refund booked for Atrn";
                        reconRecordFailedDataProducer.publish(RECON_FAIL, reconDataDto.getAtrnNum(), errorMessage);
                    } else {
                        merchantOrderPaymentDao.update(reconDataDto, TXN_FAILED_NDVP);
                    }
                }
            } else if ((ObjectUtils.isNotEmpty(merchantPaymentOrderDto.getRfId()) && !StringUtils.equalsIgnoreCase(String.valueOf(merchantPaymentOrderDto.getRfId()), String.valueOf(reconDataDto.getRfId())))) {
                String errorMessage = reconDataDto.getRfdId() + ":Atrn is already processed in other file";
                reconRecordFailedDataProducer.publish(RECON_FAIL, reconDataDto.getAtrnNum(), errorMessage);
            } else {
                logger.info("Duplicate kafka  message received for atrn:{}", reconDataDto.getAtrnNum());
            }
        } catch (TransactionException e) {
            String errorMessage = reconDataDto.getRfdId() + ":" + e.getErrorMessage();
            reconRecordFailedDataProducer.publish(RECON_FAIL, reconDataDto.getAtrnNum(), errorMessage);
        } catch (Exception e) {
            String errorMessage = reconDataDto.getRfdId() + ":" + e.getMessage();
            reconRecordFailedDataProducer.publish(RECON_FAIL, reconDataDto.getAtrnNum(), errorMessage);
        }

        logger.info("Completed processingMatchedTransaction");
    }

    @Transactional
    public void processingUnMatchedTransaction(ReconDataDto reconDataDto) {

        try {
            MerchantPaymentOrderDto merchantPaymentOrderDto = merchantOrderPaymentDao.findByAtrn(reconDataDto.getAtrnNum());
            if (ObjectUtils.isEmpty(merchantPaymentOrderDto.getSettlementStatus())) {
                merchantOrderPaymentDao.update(reconDataDto);
                logger.info("Completed processingUnMatchedTransaction");
            } else {
                if (ObjectUtils.isNotEmpty(merchantPaymentOrderDto.getRfId()) && !StringUtils.equalsIgnoreCase(String.valueOf(merchantPaymentOrderDto.getRfId()), String.valueOf(reconDataDto.getRfId()))) {
                    String errorMessage = reconDataDto.getRfdId() + ":Atrn is already processed in other file";
                    reconRecordFailedDataProducer.publish(RECON_FAIL, reconDataDto.getAtrnNum(), errorMessage);
                }
            }

        } catch (TransactionException e) {
            if(!StringUtils.equalsIgnoreCase(NOT_FOUND_ERROR_CODE, e.getErrorCode())) {
                String errorMessage = reconDataDto.getRfdId() + ":" + e.getErrorMessage();
                reconRecordFailedDataProducer.publish(RECON_FAIL, reconDataDto.getAtrnNum(), errorMessage);
            }
        } catch (Exception e) {
            String errorMessage = reconDataDto.getRfdId() + ":" + e.getMessage();
            reconRecordFailedDataProducer.publish(RECON_FAIL, reconDataDto.getAtrnNum(), errorMessage);
        }
    }

    @Transactional
    public void processDuplicateTransaction(ReconDataDetailsDto reconFileDtls) {
        logger.info("Start processDuplicateTransaction");
        try {
            if (!merchantOrderDuplicatePaymentsDao.existsByRfdId(reconFileDtls.getRfdId())) {
                MerchantOrderDuplicatePaymentsDto merchantPaymentOrderDto = merchantOrderDuplicatePaymentsMapper.convertIntoMerchantOrderPaymentDuplicateDto(reconFileDtls);
                merchantOrderPaymentDao.processDuplicateReconRecord(merchantPaymentOrderDto);
                refundDao.saveDuplicateRefundBooking(merchantOrderDuplicatePaymentsMapper.convertIntoMerchantPaymentDto(merchantPaymentOrderDto));
            } else {
                logger.info("Duplicate RfId {} found", reconFileDtls.getRfId());
            }
        } catch (TransactionException e) {
            String errorMessage = reconFileDtls.getRfdId() + ":" + e.getErrorMessage();
            reconRecordFailedDataProducer.publish(RECON_FAIL, reconFileDtls.getAtrnNumber(), errorMessage);
        } catch (Exception e) {
            String errorMessage = reconFileDtls.getRfdId() + ":" + e.getMessage();
            reconRecordFailedDataProducer.publish(RECON_FAIL, reconFileDtls.getAtrnNumber(), errorMessage);
        }
        logger.info("Completed processDuplicateTransaction");
    }


    /**
     * Method name:processRefundAdjustedAtrns
     * Description:Update a refund adjusted status and payoutId based on the provided atrns.
     */
    public void processRefundAdjustedArrns(RefundAdjustedDto refundAdjustedDto) {
        logger.info("refund adjusted process start with payoutId {}", refundAdjustedDto.getPayoutId());
        refundDao.updateRefundAdjustStatus(refundAdjustedDto.getPayoutId(), refundAdjustedDto.getArrnList());
        logger.info("refund adjusted process end with payoutId {}", refundAdjustedDto.getPayoutId());
    }


}
