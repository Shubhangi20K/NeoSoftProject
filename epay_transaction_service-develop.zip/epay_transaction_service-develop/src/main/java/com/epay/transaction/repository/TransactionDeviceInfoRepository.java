package com.epay.transaction.repository;

import com.epay.transaction.entity.TransactionDeviceInfo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.UUID;

/**
 * Class Name:AuditRepository
 * *
 * Description:
 * *
 * Author:(Shubhangi Kurelay)
 * <p>
 * Copyright (c) 2024 [State Bank of INdia]
 * All right reserved
 * *
 * Version:1.0
 */
@Repository
public interface TransactionDeviceInfoRepository extends JpaRepository<TransactionDeviceInfo, UUID> {

}
