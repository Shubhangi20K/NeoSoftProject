package com.epay.transaction.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.Entity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

/**
 * Class Name:RefundBookingDto
 * *
 * Description:
 * *
 * Author:Nirmal Gurjar
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */

@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class RefundBookingDto {
    @JsonProperty("mId")
    private String mId;
    private String sbiOrderRefNumber;
    private String arrnNumber;
    private String atrnNumber;
    private BigDecimal refundAmount;
    private String refundType;
    private String refundStatus;
    private String remark;
    private String createdBy;
    private Long createdDate;
    private String updatedBy;
    private Long updatedDate;
    private Integer refundRetry;

}
