package com.epay.transaction.externalservice.response.payment;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RupaySeamlessResponse {
    private String status;
    private String availableAuthMode;
    private String validityPeriod;
    private String errorcode;
    private String errormsg;
    private String atrn;
    private String pgTransactionId;
}