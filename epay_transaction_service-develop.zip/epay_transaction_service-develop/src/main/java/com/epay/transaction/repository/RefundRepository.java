package com.epay.transaction.repository;

import com.epay.transaction.entity.RefundBooking;
import jakarta.transaction.Transactional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

/**
 * Class Name:RefundBookingRepository
 * *
 * Description:
 * *
 * Author:Nirmal
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */

@Repository
public interface RefundRepository extends JpaRepository<RefundBooking, UUID> {

    /**
     * Retrieves a paginated list of RefundBooking entities that match the given specification.
     *
     * @param specification The criteria for filtering refund bookings.
     * @param pageable      Pagination details for retrieving data in pages.
     * @return A Page containing the filtered RefundBooking entities.
     */
    Page<RefundBooking> findAll(Specification<RefundBooking> specification, Pageable pageable);

    /**
     * Retrieves a list of RefundBooking entities that match the given specification.
     *
     * @param specification The criteria for filtering refund bookings.
     * @return A list containing the filtered RefundBooking entities.
     */
    List<RefundBooking> findAll(Specification<RefundBooking> specification);

    /**
     * Retrieves a list of atrn to update refund status
     *
     * @param payoutId payoutId for refund bookings.
     */
    @Modifying
    @Transactional
    @Query("UPDATE RefundBooking rb SET rb.payoutId= :payoutId, rb.refundAdjusted='Y' WHERE rb.arrnNum IN (:arrns)")
    void updateRefundAdjustStatus(@Param("payoutId") UUID payoutId, @Param("arrns") List<String> arrns);

}