package com.epay.transaction.dao;

import com.epay.transaction.exceptions.TransactionException;
import com.epay.transaction.externalservice.request.payment.PaymentStatusRequest;
import com.epay.transaction.externalservice.request.payment.PaymentUPIVpaRequest;
import com.epay.transaction.model.response.EncryptedResponse;
import com.epay.transaction.repository.MerchantOrderPaymentRepository;
import com.epay.transaction.util.TransactionErrorConstants;
import com.sbi.epay.authentication.providers.EPayTokenProvider;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.text.MessageFormat;

/**
 * Class Name: SbiUPIDao
 * Description: DAO class responsible for handling UPI payment-related operations.
 * Author: V1018841(Saurabh Mahto)
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
@Component
@RequiredArgsConstructor
public class SbiUPIDao {
    private final PaymentDao paymentDao;
    private final TokenDao tokenDao;
    private final EPayTokenProvider ePayTokenProvider;
    private final MerchantOrderPaymentRepository merchantOrderPaymentRepository;
    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());

    /**
     * Retrieves the encrypted AES key using the authentication token.
     *
     * @return Encrypted AES key as a String.
     */
    public String getEncryptedAESKey() {
        logger.info("Fetching encrypted AES key.");
        return tokenDao.getEncryptionAESKey(ePayTokenProvider.getToken());
    }

    /**
     * Validates the UPI payment VPA (Virtual Payment Address).
     *
     * @param PaymentUPIVpaRequest Request object containing VPA details.
     * @param key                  Encryption key for securing the request.
     * @return EncryptedResponse containing the validation result.
     */
    public EncryptedResponse validateUPIPaymentVpa(PaymentUPIVpaRequest PaymentUPIVpaRequest, String key) {
        logger.info("Validating UPI Payment VPA for request: {}", PaymentUPIVpaRequest);
        return paymentDao.validateUPIPaymentVpa(PaymentUPIVpaRequest, key);
    }

    /**
     * Performs a status enquiry for a UPI payment.
     *
     * @param paymentStatusRequest Request object containing payment status details.
     * @param key                  Encryption key for securing the request.
     * @return EncryptedResponse containing the status enquiry result.
     */
    public EncryptedResponse upiPaymentStatusEnquiry(PaymentStatusRequest paymentStatusRequest, String key) {
        logger.info("Performing UPI payment status enquiry for request: {}", paymentStatusRequest);
        return paymentDao.upiPaymentStatusEnquiry(paymentStatusRequest, key);
    }

    public void validateByAtrnMidAndOrderRefNumber(String mId, String sbiOrderRefNumber, String atrn) {
        logger.info("Validating Mid, Atrn And OrderRefNumber");
        if (!merchantOrderPaymentRepository.existsBymIdAndSbiOrderRefNumberAndAtrnNumber(mId, sbiOrderRefNumber, atrn)) {
            throw new TransactionException(TransactionErrorConstants.NOT_FOUND_ERROR_CODE, MessageFormat.format(TransactionErrorConstants.NOT_FOUND_ERROR_MESSAGE, "Merchant Order Payment"));
        }
    }
}
