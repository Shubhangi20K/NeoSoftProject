package com.epay.transaction.entity;

import com.epay.transaction.util.enums.EntityType;
import com.epay.transaction.util.enums.FailureReason;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.SuperBuilder;

import java.util.UUID;

@EqualsAndHashCode(callSuper = true)
@Getter
@Setter
@SuperBuilder
@Entity
@Table(name = "ERROR_LOG")
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ErrorLog extends AuditEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(nullable = false, updatable = false, unique = true)
    private UUID id;
    @Column(name = "MERCHANT_ID")
    private String mId;
    private String orderRefNumber;
    private String sbiOrderRefNumber;
    private String atrnNum;

    @Enumerated(EnumType.STRING)
    private EntityType entityType;
    private String payMode;

    @Enumerated(EnumType.STRING)
    private FailureReason failureReason;

    private String errorCode;
    private String errorMessage;
}

