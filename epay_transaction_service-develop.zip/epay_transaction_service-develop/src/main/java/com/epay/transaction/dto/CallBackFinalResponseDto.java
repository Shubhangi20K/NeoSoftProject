package com.epay.transaction.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CallBackFinalResponseDto {
    private String atrn;
    private String status;
    private String reason;
    private String order_Retry_Count;
    private String merchnat_order_Ref_No;
    private String debit_Amount;
    private String sbi_Order_Ref_No;
    private String return_URL;

   private String encryptedPaymentFinalResponse;

}
