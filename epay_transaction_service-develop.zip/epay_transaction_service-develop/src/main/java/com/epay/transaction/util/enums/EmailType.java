package com.epay.transaction.util.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum EmailType {

    TRANSACTION_SUCCESS("Transaction Update Notification","transaction_success"),
    TRANSACTION_FAILURE("Transaction Failure Notification", "transaction_failure");

    private final String subjectName;
    private final String templateName;
}
