package com.epay.transaction.config.kafka;

import lombok.Getter;
import org.apache.kafka.clients.admin.NewTopic;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

/**
 * Class Name: Topics settings.
 * *
 * Description: kafka topic setting.
 * *
 * Author: Gireesh M
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Getter
@Component
public class Topics {

    @Value("${spring.kafka.topic.transaction.notification.sms}")
    private String smsTopic;

    @Value("${spring.kafka.topic.transaction.notification.email}")
    private String emailTopic;

    @Value("${spring.kafka.topic.transaction.push.verification}")
    private String paymentPushVerificationTopic;

    @Value("${spring.kafka.topic.transaction.bulkRefund.processBulkRefund}")
    private String processBulkRefundTopic;

    @Value("${spring.kafka.topic.partitions}")
    private int noOfPartitions;

    @Value("${spring.kafka.topic.replicationFactor}")
    private short replicationFactor;

    @Value("${spring.kafka.topic.transaction.bulkRefund.processBookingDetails}")
    private String processBookingDetailsTopic;

    @Value("${spring.kafka.topic.transaction.recon.fail.ack}")
    private String reconFailAckTopic;

    @Value("${spring.kafka.topic.transaction.refund.adjust.confirmation}")
    private String refundAdjustedConfirmationTopic;

    @Bean
    public NewTopic smsNotificationTopic() {
        return new NewTopic(smsTopic, noOfPartitions, replicationFactor);
    }

    @Bean
    public NewTopic emailNotificationTopic() {
        return new NewTopic(emailTopic, noOfPartitions, replicationFactor);
    }

    @Bean
    public NewTopic paymentPushVerification(){
        return new NewTopic(paymentPushVerificationTopic, noOfPartitions, replicationFactor);
    }

    @Bean
    public NewTopic processBulkRefundTopic() {
        return new NewTopic(processBulkRefundTopic, noOfPartitions, replicationFactor);
    }

    @Bean
    public NewTopic processFailedRfdIdTopic() {
        return new NewTopic(reconFailAckTopic, noOfPartitions, replicationFactor);
    }

    @Bean
    public NewTopic processRefundAdjustedConfirmationTopic() {
        return new NewTopic(refundAdjustedConfirmationTopic, noOfPartitions, replicationFactor);
    }



}
