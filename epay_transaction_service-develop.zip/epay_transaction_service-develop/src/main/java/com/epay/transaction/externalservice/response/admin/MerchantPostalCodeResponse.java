package com.epay.transaction.externalservice.response.admin;


import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * Class Name: MerchantPostalCodeResponse
 * *
 * Description: MerchantPostalCodeResponse to get admin service response
 * *
 * Author: (Shital s)
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@AllArgsConstructor
@Data
public class MerchantPostalCodeResponse {
    private String postalCode;
    private String cityName;
    private String countryCode;
    private String stateName;
}