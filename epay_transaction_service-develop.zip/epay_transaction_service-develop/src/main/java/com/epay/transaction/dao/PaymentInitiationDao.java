package com.epay.transaction.dao;

import com.epay.transaction.dto.*;
import com.epay.transaction.entity.MerchantOrderSummary;
import com.epay.transaction.externalservice.response.admin.GatewayConfigDetailsResponse;
import com.epay.transaction.externalservice.response.admin.MerchantVvlResponse;
import com.epay.transaction.model.request.MerchantPricingRequest;
import com.epay.transaction.model.request.PaymentInitiationRequest;
import com.epay.transaction.model.response.EncryptedResponse;
import com.epay.transaction.service.MerchantPricingService;
import com.epay.transaction.util.EPayIdentityUtil;
import com.epay.transaction.util.TransactionConstant;
import com.epay.transaction.util.TransactionUtil;
import com.epay.transaction.util.enums.OperatingMode;
import com.epay.transaction.util.enums.PayMode;
import com.epay.transaction.util.enums.PaymentStatus;
import com.epay.transaction.util.enums.TransactionStatus;
import com.sbi.epay.authentication.providers.EPayTokenProvider;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import java.util.List;
import java.util.Optional;


/**
 * Class Name:PaymentInitiationDao
 * <p>
 * Description: This class is used for payment client call
 * <p>
 * Copyright (c) [2024] [State Bank of India]
 * All rights reserved.
 * <p>
 * Author:V1014352(Ranjan Kumar)
 * Version:1.0
 */


@Component
@RequiredArgsConstructor
public class PaymentInitiationDao {
    private final TokenDao tokenDao;
    private final OrderDao orderDao;
    private final MerchantOrderPaymentDao merchantOrderPaymentDao;
    private final MerchantOrderSummaryDao merchantOrderSummaryDao;
    private final MerchantPricingService merchantPricingService;
    private final PaymentDao paymentDao;
    private final AdminDao adminDao;
    private final EPayTokenProvider ePayTokenProvider;
    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());



    private static MerchantPaymentOrderDto buildMerchantPaymentDto(PaymentInitiationRequest paymentInitiationRequest, String payMode, OrderDto orderDto, GatewayConfigDetailsResponse gatewayConfigDetails) {
        return MerchantPaymentOrderDto.builder().gatewayIssueMECode(gatewayConfigDetails.getGtwIssueDmeCode()).payProcId(paymentInitiationRequest.getPayProcId()).debitAmount(paymentInitiationRequest.getMerchPostedAmount()).paymodeType(paymentInitiationRequest.getPayProcType()).payMode(PayMode.getPayMode(payMode)).channelBank(paymentInitiationRequest.getChannelBank()).orderAmount(paymentInitiationRequest.getTransactionAmount()).cin(TransactionUtil.generateUniqueCin(orderDto.getMId())).pushResponse(TransactionConstant.TRANSACTION_PUSH_RESPONSE).sbiOrderRefNumber(orderDto.getSbiOrderRefNumber()).orderRefNumber(orderDto.getOrderRefNumber()).operatingMode(OperatingMode.getOperatingMode(paymentInitiationRequest.getOperatingMode())).pgBankCode(paymentInitiationRequest.getGtwMapsId()).paymentStatus(PaymentStatus.PAYMENT_INITIATION_START).currencyCode(orderDto.getCurrencyCode()).transactionStatus(TransactionStatus.BOOKED).mId(orderDto.getMId()).build();
    }

    public static MerchantPricingRequest buildMerchantPricingRequestDto(PaymentInitiationRequest paymentInitiationRequest, String atrn, String payMode, String mId) {
        return MerchantPricingRequest.builder().atrn(atrn).mId(mId).payModeCode(payMode).payProcType(paymentInitiationRequest.getPayProcType().toUpperCase()).gtwMapsId(paymentInitiationRequest.getGtwMapsId()).postAmount(paymentInitiationRequest.getMerchPostedAmount()).transactionAmount(paymentInitiationRequest.getTransactionAmount()).build();
    }

    /**
     * Method name : getEncryptedAESKey
     * Description :  Fetching AES Key
     * @return String of AES Key
     */
    public String getEncryptedAESKey() {
        logger.info("Fetching AES key from Token Table");
        return tokenDao.getEncryptionAESKey(ePayTokenProvider.getToken());
    }

    /**
     * Method name : getOrder
     * Description :  getMerchant Details
     * @return object of OrderDto
     */
    public OrderDto getMerchantOrder() {
        logger.info("Validating Order By SBI orderReferenceNo");
        return orderDao.getValidOrderBySBIOrderRefNumber(EPayIdentityUtil.getUserPrincipal().getMId(), EPayIdentityUtil.getUserPrincipal().getOrderRef());
    }


    /**
     * Method name : getMerchantVVLDetailsByPayMode
     * Description :  getVVL Details by PayMode
     * @param mId : Defines payment mode
     * @param payMode: Object of encrypted paymentRequest
     * @return object of  Optional<MerchantVvlResponse>
     */
    public Optional<MerchantVvlResponse> getMerchantVVLDetailsByPayMode(String mId, String payMode) {
        List<MerchantVvlResponse> merchantVvlInfo = adminDao.getMerchantVVLDetails(mId);
        return merchantVvlInfo.stream().filter(vvl -> vvl.getPayModeCode().equalsIgnoreCase(payMode)).findFirst();
    }

    /**
     * Method name : getMerchantOrderSummaryByPayMode
     * Description :  get merchant order Summary by PayMode
     * @param mId : mid
     * @param payMode: Defines Payment mode
     * @return object of  Optional<MerchantVvlResponse>
     */
    public List<MerchantOrderSummary> getMerchantOrderSummaryByPayMode(String mId, String payMode) {
        return merchantOrderSummaryDao.getMerchantOrderSummary(mId, payMode);
    }


    /**
     * Method name : processRequest
     * Description :  processing payment request
     * @param paymentInitiationRequest : defines payment request details
     * @param payMode: Defines Payment mode
     * @param orderDto : defines order details for payment
     * @return object of  Optional<MerchantVvlResponse>
     */

    public EncryptedResponse processRequest(PaymentInitiationRequest paymentInitiationRequest, String payMode, OrderDto orderDto, String key) {
        logger.info("Payment Initiation process Started");
        GatewayConfigDetailsResponse gatewayConfigDetails = adminDao.getGatewayConfigDetails(orderDto.getMId(), paymentInitiationRequest.getGtwMapsId(), payMode);
        logger.debug("Getting gatewayConfigDetails {}",gatewayConfigDetails);
        MerchantPaymentOrderDto merchantPaymentOrderDto = buildMerchantPaymentDto(paymentInitiationRequest, payMode, orderDto, gatewayConfigDetails);
        logger.debug("Build merchantPaymentOrderDto {}",merchantPaymentOrderDto);
        merchantPaymentOrderDto = merchantOrderPaymentDao.save(merchantPaymentOrderDto);
        logger.debug("Updating Order Retry Count to {}",(orderDto.getOrderRetryCount() - 1));
        orderDto.setOrderRetryCount(orderDto.getOrderRetryCount() - 1);
        orderDao.saveOrder(orderDto);

        MerchantPricingRequest merchantPricingRequest = buildMerchantPricingRequestDto(paymentInitiationRequest, merchantPaymentOrderDto.getAtrnNumber(), payMode.toUpperCase(), orderDto.getMId());
        logger.info("Pricing calculation and validation started");
        merchantPricingService.calculatePricing(merchantPricingRequest);
        logger.info("Pricing calculation validated an saved successfully");
        return paymentDao.paymentInitiation(payMode, merchantPaymentOrderDto, paymentInitiationRequest, key);
    }
}
