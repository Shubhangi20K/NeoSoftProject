package com.epay.transaction.listener;


import com.epay.transaction.entity.event.audit.BaseEvent;
import com.epay.transaction.repository.event.audit.BufferedRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class MessageEventListener {

    private final BufferedRepository bufferedRepository;

    @EventListener
    @Transactional
    public void sendEvent(BaseEvent eventData) {
        bufferedRepository.buffer(eventData);
    }

}
