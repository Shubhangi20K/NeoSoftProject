package com.epay.transaction.dao;

import com.epay.transaction.dto.CustomerDto;
import com.epay.transaction.dto.OrderDto;
import com.epay.transaction.exceptions.TransactionException;
import com.epay.transaction.externalservice.response.admin.MerchantInfoResponse;
import com.epay.transaction.externalservice.response.merchant.MerchantThemeResponse;
import com.epay.transaction.util.enums.OrderStatus;
import com.fasterxml.jackson.databind.JsonNode;
import com.sbi.epay.authentication.providers.EPayTokenProvider;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Class Name: BookingDao
 * *
 * Description: BookingDao for merchant order booking process
 * *
 * Author: V1018212
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Component
@RequiredArgsConstructor
public class BookingDao {

    private final OrderDao orderDao;
    private final CustomerDao customerDao;
    private final AdminDao adminDao;
    private final TokenDao tokenDao;
    private final MerchantDao merchantDao;
    private final EPayTokenProvider ePayTokenProvider;
    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());

    /**
     * Method name : getOrder
     * Description :Fetch merchant order details using orderHash
     * @param orderHash is a String
     * @return object of OrderDto
     */
    public OrderDto getMerchantOrder(String orderHash) {
        return orderDao.getOrderByOrderHashAndStatus(orderHash, List.of(OrderStatus.PAID, OrderStatus.CREATED, OrderStatus.ATTEMPTED, OrderStatus.ATTEMPT_FAIL, OrderStatus.EXPIRED, OrderStatus.FAILED));
    }

    /**
     * Method name : getMerchantInfo
     * Description :Fetch merchant info using mId
     * @param mId is a String
     * @return object of MerchantInfoResponse
     */
    public MerchantInfoResponse getMerchantInfo(String mId) {
        return adminDao.getMerchantByMId(mId);
    }

    /**
     * Method name : getMerchantPayModes
     * Description :Fetch merchant pay modes using mId
     * @param mId is a String
     * @return object of JsonNode
     */
    public JsonNode getMerchantPayModes(String mId) {
        return adminDao.getMerchantPayModes(mId);
    }

    /**
     * Method name : getMerchantCustomer
     * Description :Fetch Merchant Customer using customerId
     * @param customerId is a String
     * @return object of JsonNode
     */
    public CustomerDto getMerchantCustomer(String mId, String customerId) {
        return customerDao.getCustomerByCustomerId(mId, customerId);
    }

    /**
     * Method name : initiateTransactionBooking
     * Description :This method is used for updating order status
     * @param orderDto is an Object of OrderDto
     */
    public void initiateTransactionBooking(OrderDto orderDto) {
        logger.info("Initiate TransactionBooking Starts");
        orderDto.setStatus(OrderStatus.ATTEMPTED);
        orderDao.saveOrder(orderDto);
        logger.info("Initiate TransactionBooking ends");
    }

    /**
     * Method name : getEncryptionKey
     * Description :Fetch EncryptionKey based on token
     * @return a String
     */
    public String getEncryptionKey() {
        return tokenDao.getEncryptionAESKey(ePayTokenProvider.getToken());
    }

    /**
     * Method name : getMerchantTheme
     * Description : Fetch Merchant Theme using mid, if merchant is down return null.
     * @param mId is a String
     * @return an Object of MerchantThemeResponse
     */
    public MerchantThemeResponse getMerchantTheme(String mId) {
        try {
            logger.info("Getting theme details for mId: {}", mId);
            return merchantDao.getMerchantTheme(mId);
        } catch (TransactionException e) {
            logger.debug("Issue while fetching theme details for mId: {}", mId);
            return null;
        }
    }

}

