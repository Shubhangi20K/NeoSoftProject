package com.epay.transaction.externalservice.request.eis;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class EISEncryptedRequest {

    @JsonProperty("REQUEST")
    private String request;
    @JsonProperty("REQUEST_REFERENCE_NUMBER")
    private String requestReferenceNumber;
    @JsonProperty("DIGI_SIGN")
    private String digiSignData;
    
}
