package com.epay.transaction.externalservice.response.payment;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

@AllArgsConstructor
@Data
@Builder
@NoArgsConstructor
@JsonIgnoreProperties
public class PaymentVisaCardResponse {
    private String availableAuthMode;
    private String cardPaymentStatus;
    private String atrn;
    private String postURL;
    private String creq;

}

