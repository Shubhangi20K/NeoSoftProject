package com.epay.transaction.mapper;

import com.epay.transaction.model.request.CustomerRequest;
import com.epay.transaction.dto.CustomerDto;
import com.epay.transaction.entity.Customer;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;

/**
 * Class Name:CustomerMapper
 * *
 * Description:
 * *
 * Author:V1014352(Ranjan Kumar)
 * <p>
 * Copyright (c) 2025 [State Bank of INdia]
 * All right reserved
 * *
 * Version:1.0
 */
@Mapper(builder = @Builder(disableBuilder = true), componentModel = "spring")
public interface CustomerMapper {
    Customer dtoToEntity(CustomerDto customerDto);
    CustomerDto requestToDto(CustomerRequest customerRequest);
    CustomerDto entityToDto(Customer customer);
}
