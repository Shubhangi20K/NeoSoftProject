package com.epay.transaction.util.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum EisApiHistoryType {
    GSTN,ECOM;
}
