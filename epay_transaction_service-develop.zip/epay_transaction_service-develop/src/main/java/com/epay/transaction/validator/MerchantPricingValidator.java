package com.epay.transaction.validator;


import com.epay.transaction.exceptions.ValidationException;
import com.epay.transaction.model.request.MerchantPricingRequest;
import com.epay.transaction.util.enums.PayMode;
import com.epay.transaction.util.enums.PayProcType;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.text.MessageFormat;
import java.util.ArrayList;
import static com.epay.transaction.util.TransactionConstant.*;
import static com.epay.transaction.util.TransactionConstant.ATRN;
import static com.epay.transaction.util.TransactionErrorConstants.*;


/**
 * Class Name: MerchantPricingValidator
 * *
 * Description: Validator class for pricing calculation
 * *
 * Author: NIRMAL GURJAR
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */

@Component
@RequiredArgsConstructor
public class MerchantPricingValidator extends BaseValidator {

    private static final LoggerUtility logger = LoggerFactoryUtility.getLogger(MerchantPricingValidator.class);

    public void validatePricingRequest(MerchantPricingRequest merchantPricingRequest) {
        logger.info("Inside validatePricingRequest for merchantPricingRequest: {}", merchantPricingRequest);
        errorDtoList = new ArrayList<>();
        validateMandatoryFields(merchantPricingRequest);
        validateLeadingTrailingSpaces(merchantPricingRequest);
        validateFieldsLength(merchantPricingRequest);
        validateAmount(merchantPricingRequest.getTransactionAmount(), TRANSACTION_AMOUNT_FIELD);
        validateFieldWithRegex(merchantPricingRequest.getGtwMapsId(), GTW_MAPSID_REGEX, GATEWAY_MAPS_ID_FIELD, INVALID_GATEWAY_REASON);
        validateEnums(merchantPricingRequest);
        throwIfErrors();
    }

    private void validateFieldsLength(MerchantPricingRequest merchantPricingRequest) {
        logger.info("Inside validateFieldsLength for merchantPricingRequest");
        validateFieldLength(merchantPricingRequest.getPayModeCode(), PAY_MODE_CODE_LENGTH, PAY_MODE_CODE_FIELD);
        validateFieldLength(merchantPricingRequest.getGtwMapsId(), GATEWAY_MAP_ID_LENGTH, GATEWAY_MAPS_ID_FIELD);
        validateFieldLength(merchantPricingRequest.getPayProcType(), PAY_PROC_ID_TYPE_LENGTH, PAY_PROC_TYPE_FIELD);
        throwIfErrors();
    }

    private static void validateEnums(MerchantPricingRequest merchantPricingRequest) {
        PayMode.getPayMode(merchantPricingRequest.getPayModeCode()); //validate payMode enum
        PayProcType.getPayProcType(merchantPricingRequest.getPayProcType()); //validate payProcType enum
    }

    protected void validateMandatoryFields(MerchantPricingRequest merchantPricingRequest) {
        logger.info("Inside validateMandatoryFields for merchantPricingRequest: {}", merchantPricingRequest);
        checkMandatoryField(merchantPricingRequest.getPayProcType(), PAY_PROC_TYPE_FIELD);
        checkMandatoryField(merchantPricingRequest.getGtwMapsId(), GATEWAY_MAPS_ID_FIELD);
        checkMandatoryField(merchantPricingRequest.getPayModeCode(), PAY_MODE_CODE_FIELD);
        checkMandatoryField(merchantPricingRequest.getTransactionAmount(), TRANSACTION_AMOUNT_FIELD);
        throwIfErrors();
    }

    /**
     * Method name : validateLeadingAndTraling
     * Description : Validates leading and Traling spaces from merchant customer creation request
     * @param merchantPricingRequest : Object of MerchantPricingRequest
     */
    protected void validateLeadingTrailingSpaces(MerchantPricingRequest merchantPricingRequest) {
        checkForLeadingTrailingAndSingleSpace(merchantPricingRequest.getPayProcType(),PAY_PROC_TYPE_FIELD);
        checkForLeadingTrailingAndSingleSpace(merchantPricingRequest.getGtwMapsId(),GATEWAY_MAPS_ID_FIELD);
        checkForLeadingTrailingAndSingleSpace(merchantPricingRequest.getPayModeCode(),PAY_MODE_CODE_FIELD);
        if(StringUtils.isNotEmpty(merchantPricingRequest.getAtrn())) {
            checkForLeadingTrailingAndSingleSpace(merchantPricingRequest.getAtrn(), ATRN);
        }
        if(StringUtils.isNotEmpty(merchantPricingRequest.getMId())) {
            checkForLeadingTrailingAndSingleSpace(merchantPricingRequest.getMId(), MID);
        }
        throwIfErrors();
    }

    public void validateUnrecognisedFields(MerchantPricingRequest merchantPricingRequest) {
        logger.info("Inside validateUnrecognisedFields for merchantPricingRequest");
        if (StringUtils.isNotEmpty(merchantPricingRequest.getMId())) {
            throw new ValidationException(INVALID_ERROR_CODE, MessageFormat.format(INVALID_ERROR_MESSAGE, "Request object", "Unrecognised field: 'mId'"));
        }
        if (ObjectUtils.isNotEmpty(merchantPricingRequest.getPostAmount())) {
            throw new ValidationException(INVALID_ERROR_CODE, MessageFormat.format(INVALID_ERROR_MESSAGE, "Request object", "Unrecognised field: 'postAmount'"));
        }
        if (StringUtils.isNotEmpty(merchantPricingRequest.getAtrn())) {
            throw new ValidationException(INVALID_ERROR_CODE, MessageFormat.format(INVALID_ERROR_MESSAGE, "Request object", "Unrecognised field: 'Atrn'"));
        }
    }
}