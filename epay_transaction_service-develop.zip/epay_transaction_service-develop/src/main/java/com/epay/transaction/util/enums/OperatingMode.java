package com.epay.transaction.util.enums;

import com.epay.transaction.exceptions.TransactionException;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.text.MessageFormat;
import java.util.Arrays;

import static com.epay.transaction.util.TransactionErrorConstants.INVALID_ERROR_CODE_NO_REASON;
import static com.epay.transaction.util.TransactionErrorConstants.INVALID_ERROR_MESSAGE_NO_REASON;

@Getter
@AllArgsConstructor
public enum OperatingMode {
    DOM("DOM"), INTL ("INTL");

    private final String label;

    public static OperatingMode getOperatingMode(String label) {
        return Arrays.stream(values()).filter(p -> p.getLabel().equals(label)).findFirst().orElseThrow(() -> new TransactionException(INVALID_ERROR_CODE_NO_REASON, MessageFormat.format(INVALID_ERROR_MESSAGE_NO_REASON, "OperatingMode", label)));
    }
}
