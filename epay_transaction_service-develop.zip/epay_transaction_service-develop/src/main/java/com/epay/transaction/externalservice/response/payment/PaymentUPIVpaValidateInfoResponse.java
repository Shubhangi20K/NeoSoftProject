package com.epay.transaction.externalservice.response.payment;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * Class Name:PaymentUPIVpaValidateInfoResponse
 * *
 * Description:
 * *
 * Author:V1014352(Ranjan Kumar)
 * <p>
 * Copyright (c) 2025 [State Bank of INdia]
 * All right reserved
 * *
 * Version:1.0
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class PaymentUPIVpaValidateInfoResponse implements Serializable {
    private String pspRefNo;
}
