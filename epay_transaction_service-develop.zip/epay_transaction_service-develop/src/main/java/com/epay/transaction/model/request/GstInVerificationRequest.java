package com.epay.transaction.model.request;
/*
 *
 *  Copyright (c) [2024] [State Bank of India]
 *  All rights reserved.
 *
 *  Author:@V0000001(Shubhangi Kurelay)
 *  Version:1.0
 *
 */

import lombok.Data;

@Data
public class GstInVerificationRequest {
    private String gstInNumber;
    private String email;
}


