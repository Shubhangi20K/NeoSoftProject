package com.epay.transaction.dao;

import com.epay.transaction.dto.MerchantOrderDuplicatePaymentsDto;
import com.epay.transaction.mapper.MerchantOrderDuplicatePaymentsMapper;
import com.epay.transaction.repository.MerchantOrderDuplicatePaymentsRepository;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.stereotype.Component;

import java.util.UUID;

@Component
@RequiredArgsConstructor
public class MerchantOrderDuplicatePaymentsDao {

    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private final MerchantOrderDuplicatePaymentsRepository merchantOrderDuplicatePaymentsRepository;
    private final MerchantOrderDuplicatePaymentsMapper merchantOrderDuplicatePaymentsMapper;

    /**
     * Public method to batch insert merchant duplicate payment DTOs.
     */
    public void saveMerchantOrderPaymentDuplicateRecord(MerchantOrderDuplicatePaymentsDto merchantOrderDuplicatePaymentsDTO) {
        if (ObjectUtils.isEmpty(merchantOrderDuplicatePaymentsDTO)) {
            logger.info("No records to insert into MERCHANT_ORDER_DUPLICATE_PAYMENTS.");
            return;
        }
        merchantOrderDuplicatePaymentsDTO.setCreatedDate(System.currentTimeMillis());
        merchantOrderDuplicatePaymentsDTO.setCreatedBy("system");
        merchantOrderDuplicatePaymentsRepository.save(merchantOrderDuplicatePaymentsMapper.dtoToEntity(merchantOrderDuplicatePaymentsDTO));
    }

    public boolean existsByRfdId(UUID rfdId) {
        return merchantOrderDuplicatePaymentsRepository.existsById(rfdId);
    }


}
