package com.epay.transaction.util;


import com.sbi.epay.encryptdecrypt.service.DecryptionService;
import com.sbi.epay.encryptdecrypt.service.EncryptionService;
import com.sbi.epay.encryptdecrypt.service.HashingService;
import com.sbi.epay.encryptdecrypt.service.KeyGeneratorService;
import com.sbi.epay.encryptdecrypt.util.enums.*;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.StringUtils;

import java.util.Base64;

/**
 * Class Name:EncryptionDecryptionUtil
 * *
 * Description:
 * *
 * Author:V1014352(Ranjan Kumar)
 * <p>
 * Copyright (c) 2024 [State Bank of india]
 * All right reserved
 * *
 * Version:1.0
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class EncryptionDecryptionUtil {
    private static final LoggerUtility logger = LoggerFactoryUtility.getLogger(EncryptionDecryptionUtil.class);

    /**
     * Method name:keyGenerator
     * Description:Generates a cryptographic key using the AES algorithm with a 256-bit key length.
     * The key is generated using a predefined algorithm and length defined in the KeyGeneratorService.
     *
     * @return A randomly generated cryptographic key in the form of a String.
     */
    public static String keyGenerator() {
        logger.info("Starting key generation using AES algorithm with 256-bit key length.");
        return KeyGeneratorService.generateKeyByAlgo(SecretKeyLength.AES_256, KeyGenerationAlgo.AES);
    }

    /**
     * Method name:decryptValue
     * Description:Decrypts the given encrypted value using the provided key and the AES algorithm.
     * The decryption is performed using the specified parameters for the GCM IV length and tag length.
     *
     * @param key The decryption key used to decrypt the value.
     * @param value The encrypted value that needs to be decrypted.
     * @return The decrypted value (plain text).
     */
    public static String decryptValue(String key, String value) {
        logger.info("Decrypting value with provided key using AES-GCM algorithm.");
        return DecryptionService.decryptValueByStringKey(key, value, EncryptionDecryptionAlgo.AES_GCM_NO_PADDING, GCMIvLength.MAXIMUM, GCMTagLength.STANDARD);
    }

    /**
     * Method name:encryptValue
     * Description:Encrypts the given value using the provided key and the AES algorithm.
     * The encryption is performed with the specified parameters for the GCM IV length and tag length.
     *
     * @param key The encryption key used to encrypt the value.
     * @param value The plain text value that needs to be encrypted.
     * @return The encrypted value.
     */
    public static String encryptValue(String key, String value) {
        logger.info("Encrypting value with provided key using AES-GCM algorithm.");
        return EncryptionService.encryptValueByStringKey(key, value, EncryptionDecryptionAlgo.AES_GCM_NO_PADDING, GCMIvLength.MAXIMUM, GCMTagLength.STANDARD);
    }

    /**
     * Method name:hashValue
     * Description:Hashes a concatenation of provided values using a hash function.
     * The values are joined into a single string and then hashed.
     *
     * @param values A varargs parameter containing the values to be concatenated and hashed.
     * @return The hashed value as a string.
     */
    public static String hashValue(String... values) {
        logger.debug("Hashing concatenated values: {}", String.join("", values));
        return hashValue(String.join("", values));
    }

    /**
     * Method name:hashValue
     * Description:Hashes the provided value using the SHA-512 algorithm and returns the hashed value as a Base64 encoded string.
     *
     * @param values The input string to be hashed, assumed to be Base64 encoded.
     * @return The Base64 encoded hashed value after special character removal.
     */
    public static String hashValue(String values) {
        logger.debug("Hashing input value using SHA-512: {}", values);
        byte[] bytes = HashingService.generateHash(Base64.getDecoder().decode(values), HashAlgorithm.SHA_512);
        return Base64.getEncoder().encodeToString(bytes).replaceAll(TransactionConstant.SPECIAL_CHAR_REGEX, StringUtils.EMPTY);
    }
}
