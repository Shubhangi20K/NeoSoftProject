package com.epay.transaction.util.enums;

import com.epay.transaction.exceptions.TransactionException;

import java.text.MessageFormat;
import java.util.Arrays;

import static com.epay.transaction.util.TransactionErrorConstants.INVALID_ERROR_CODE_NO_REASON;
import static com.epay.transaction.util.TransactionErrorConstants.INVALID_ERROR_MESSAGE_NO_REASON;

/**
 * Copyright (c) [2025] [State Bank of India]
 * All rights reserved.
 * <p>
 * Author: Bhoopendra
 * <p>
 * Version:1.0
 */
public enum PayMode {
    UPI, NB, CC, DC, PC;

    public static PayMode getPayMode(String payMode) {
        return Arrays.stream(values()).filter(p -> p.name().equals(payMode)).findFirst().orElseThrow(() -> new TransactionException(INVALID_ERROR_CODE_NO_REASON, MessageFormat.format(INVALID_ERROR_MESSAGE_NO_REASON, "PayMode", payMode)));
    }
}
