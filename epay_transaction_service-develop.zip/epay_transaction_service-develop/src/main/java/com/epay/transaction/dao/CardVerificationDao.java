package com.epay.transaction.dao;

import com.epay.transaction.externalservice.response.admin.BinCheckResponse;
import com.epay.transaction.externalservice.request.admin.BinCheckRequest;
import com.epay.transaction.validator.CardValidator;
import com.sbi.epay.authentication.providers.EPayTokenProvider;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

/**
 *  Class Name:CardVerificationDao
 * <p>
 *  Description: Card Verification
 * <p>
 * Copyright (c) [2024] [State Bank of India]
 * All rights reserved.
 * <p>
 * Author:@V0000001(Shilpa Kothre)
 * Version:1.0
 */
@Component
@RequiredArgsConstructor
public class CardVerificationDao {

    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    private final TokenDao tokenDao;
    private final AdminDao adminDao;
    private final EPayTokenProvider ePayTokenProvider;
    private final CardValidator cardValidator;

    /**
     * Retrieves the AES encryption key using a token from the token provider.
     *
     * @return AES encryption key as a String
     */
    public String getEncryptionAesKey(){
        log.info("Fetching encryption AES key.");
        return tokenDao.getEncryptionAESKey(ePayTokenProvider.getToken());
    }

    /**
     * Fetches card BIN check details based on the provided request.
     *
     * @param binCheckRequest The request object containing card BIN details.
     * @return BinCheckResponse containing the validation details.
     */
    public BinCheckResponse validateBin(BinCheckRequest binCheckRequest){
        log.info("Validating card BIN check request.");
        cardValidator.validateCardBin(binCheckRequest.getCardBin());
        return adminDao.getBinCheckResponse(binCheckRequest);
    }

}
