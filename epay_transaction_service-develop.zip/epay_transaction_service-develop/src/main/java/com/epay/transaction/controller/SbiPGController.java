package com.epay.transaction.controller;

import com.epay.transaction.model.request.EncryptedRequest;
import com.epay.transaction.model.response.EncryptedResponse;
import com.epay.transaction.model.response.TransactionResponse;
import com.epay.transaction.service.CardVerificationService;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Class Name: CardVerificationController
 * *
 * Description: Card Details Verification
 * *
 * Author: V1018841(Saurabh Mahto)
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@RestController
@AllArgsConstructor
@RequestMapping("/card/sbi")
public class SbiPGController {
    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private final CardVerificationService cardVerificationService;
    /**
     * Endpoint to verify the card number (BIN check).
     *
     * @param encryptedRequest The encrypted request containing card details.
     * @return TransactionResponse containing the encrypted response with BIN check results.
     */
    @PostMapping("/validate-bin")
    @Operation(summary = "Card Bin Verification")
    @PreAuthorize("hasAnyRole('TRANSACTION')")
    public TransactionResponse<EncryptedResponse> validateBin(@Valid @RequestBody EncryptedRequest encryptedRequest) {
        logger.info("{+Checking the +}binCheck for encryptedRequest: {}", encryptedRequest);
        return cardVerificationService.validateBin(encryptedRequest);
    }


}
