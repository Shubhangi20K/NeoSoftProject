package com.epay.transaction.util;

import com.epay.transaction.dto.MerchantPricingDto;
import com.epay.transaction.externalservice.response.admin.MerchantPricingResponse;
import com.epay.transaction.model.request.MerchantPricingRequest;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Optional;

/**
 * Class Name:PricingUtil
 * *
 * Description:this class is used for calculate pricing
 * *
 * Author:V1014352
 * <p>
 * Copyright (c) 2024 [State Bank of india]
 * All right reserved
 * *
 * Version:1.0
 */
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class PricingUtil {

    private static final LoggerUtility logger = LoggerFactoryUtility.getLogger(PricingUtil.class);

    /**
     * Method name:calculateFee
     * Description:Calculates the pricing and bearable amount based on the merchant pricing structure and the transaction amount.
     *
     * @param pricingStructure       The merchant pricing structure containing the fee rules and limits.
     * @param merchantPricingRequest The request object containing transaction details, such as the transaction amount.
     * @return A MerchantPricingDto object containing the calculated fees and bearable amounts.
     */
    public static MerchantPricingDto calculateFee(MerchantPricingResponse pricingStructure, MerchantPricingRequest merchantPricingRequest) {
        MerchantPricingDto merchantPricingDto = calculateFee(pricingStructure, merchantPricingRequest.getTransactionAmount());
        logger.info("Fee calculation done");
        PricingUtil.calculateBearableAmount(pricingStructure, merchantPricingRequest.getTransactionAmount(), merchantPricingDto);
        logger.info("Bearable amount calculation done");
        return merchantPricingDto;
    }

    /**
     * Method name:calculateFee
     * Description:Calculates the fees for a merchant transaction, including the merchant fee, other fee, gateway fee,
     * and aggregate service fee based on the provided pricing structure and posted amount.
     * <p>
     * This method computes the various fees involved in a transaction based on the pricing structure, including:
     * - Merchant Fee
     * - Other Fee
     * - Gateway Fee
     * - Aggregate Service Fee
     * Each fee is calculated individually using the `calculateFee` helper method and is applied to the merchant's
     * posted amount. The final calculated fees are returned as a `MerchantPricingDto` object.
     *
     * @param pricingStructure The merchant pricing structure that contains the fee rules and amounts.
     * @param merchPostedAmt   The posted amount of the merchant's transaction used for fee calculation.
     * @return A `MerchantPricingDto` object containing the calculated fees.
     */
    private static MerchantPricingDto calculateFee(MerchantPricingResponse pricingStructure, BigDecimal merchPostedAmt) {
        logger.info("Fee calculation started.");
        //Step 1: Merchant Fee Calculation.
        BigDecimal merchantFeeAbs = calculateFee(pricingStructure.getMerchantFeeApplicable(), pricingStructure.getMerchantFeeType(), pricingStructure.getMerchantFee(), merchPostedAmt);

        //Step 2: Other Fee Calculation
        BigDecimal otherFeeAbs = calculateFee(pricingStructure.getOtherFeeApplicable(), pricingStructure.getOtherFeeType(), pricingStructure.getOtherFee(), merchPostedAmt);

        //Step 3: Gateway Fee Calculation
        BigDecimal gtwFeeAbs = calculateFee(pricingStructure.getGtwFeeApplicable(), pricingStructure.getGtwFeeType(), pricingStructure.getGtwFee(), merchPostedAmt);

        //Step 4: Agg Service Fee Calculation
        BigDecimal aggServiceFeeAbs = calculateFee(pricingStructure.getAggServiceFeeApplicable(), pricingStructure.getAggServiceFeeType(), pricingStructure.getAggServiceFee(), merchPostedAmt);

        return MerchantPricingDto.builder().merchantFeeAbs(merchantFeeAbs).otherFeeAbs(otherFeeAbs).gtwFeeAbs(gtwFeeAbs).aggServiceFeeAb(aggServiceFeeAbs).build();

    }

    /**
     * Method name:calculatePricingForBearableComponentAmount
     * Description:This method calculates the bearable component amounts for both the merchant and customer based on
     * the merchant's posted amount and the pricing structure. It determines how much of the fees
     * are bearable by the merchant and the customer, and how much of the service tax is applied to
     * both parties, depending on various conditions specified in the pricing structure.
     *
     * @param pricingStructure   The merchant pricing structure containing various fee types and values.
     * @param merchPostedAmt     The posted amount for the merchant's transaction.
     * @param merchantPricingDto The DTO object where the results (calculated fees and amounts) will be set.
     */
    private static void calculatePricingForBearableComponentAmount(MerchantPricingResponse pricingStructure, BigDecimal merchPostedAmt, MerchantPricingDto merchantPricingDto) {

        BigDecimal txCal;
        BigDecimal totalAbsFee;
        BigDecimal totalBearableFee;
        BigDecimal totalBearableFeeServiceTax;
        BigDecimal merchantBearableAmt = BigDecimal.ZERO;
        BigDecimal merchantBearableServiceTax = BigDecimal.ZERO;
        BigDecimal customerBearableAmt = BigDecimal.ZERO;
        BigDecimal customerBearableServiceTax = BigDecimal.ZERO;

        logger.info("Setting Pricing Structure.");
        //Pricing Structure
        Character merchantFeeType = pricingStructure.getMerchantFeeType();
        BigDecimal serviceTax = pricingStructure.getServiceTax();

        //as per old code
        String bearableComponent = pricingStructure.getBearableComponent();
        Character bearableEntity = pricingStructure.getBearableEntity();
        BigDecimal bearableCutOffAmt = pricingStructure.getBearableAmountCutoff();
        BigDecimal bearableFlatFee = pricingStructure.getBearableFlatRate();
        Character bearableType = pricingStructure.getBearableType();
        BigDecimal totalBearableFeeRate = pricingStructure.getTotalFeeRate();

        //txnFeeProcessFlag = Hybrid & bearableComponent = Amount & merchantFeeType = P
        if (validateAndMatch(merchantFeeType, TransactionConstant.MERCHANT_FEE_TYPE_PERCENTAGE)) {

            if (bearableCutOffAmt.compareTo(merchPostedAmt) > 0) {

                bearableCutOffAmt = merchPostedAmt;   // else condition not available in flow graph

            }

            // below calculation is only done for condition bearableCutOffAmt > merchPostedAmt in flow graph
            totalAbsFee = multiplyAndPercent(merchPostedAmt, totalBearableFeeRate);
            totalBearableFee = totalAbsFee;
            totalBearableFeeServiceTax = multiplyAndPercent(totalBearableFee, serviceTax);
            txCal = multiplyAndPercent(serviceTax, totalAbsFee);


            //txnFeeProcessFlag = Hybrid & bearableComponent = Amount & merchantFeeType = P & bearableEntity = M
            if (validateAndMatch(bearableEntity, TransactionConstant.BEARABLE_ENTITY_MERCHANT)) {

                merchantBearableAmt = totalBearableFee;
                merchantBearableServiceTax = totalBearableFeeServiceTax;
                customerBearableAmt = subtract(totalAbsFee, merchantBearableAmt);
                customerBearableServiceTax = subtract(txCal, totalBearableFeeServiceTax);


                //txnFeeProcessFlag = Hybrid & bearableComponent = Amount & merchantFeeType = P & bearableEntity = C
            } else if (validateAndMatch(bearableEntity, TransactionConstant.BEARABLE_ENTITY_CUSTOMER)) {

                customerBearableAmt = totalBearableFee;
                customerBearableServiceTax = totalBearableFeeServiceTax;
                merchantBearableAmt = subtract(totalAbsFee, customerBearableAmt);
                merchantBearableServiceTax = subtract(txCal, totalBearableFeeServiceTax);

            }

            //txnFeeProcessFlag = Hybrid & bearableComponent = Amount & merchantFeeType = F
        } else if (validateAndMatch(merchantFeeType, TransactionConstant.MERCHANT_FEE_TYPE_FLAT) && validateAndMatch(bearableType, TransactionConstant.BEARABLE_TYPE_FLAT)) {

            if (totalBearableFeeRate.compareTo(bearableFlatFee) > 0) {

                totalAbsFee = totalBearableFeeRate;
                txCal = multiplyAndPercent(serviceTax, totalAbsFee);
                totalBearableFee = bearableFlatFee;
                totalBearableFeeServiceTax = multiplyAndPercent(totalBearableFee, serviceTax);

            } else {

                totalAbsFee = totalBearableFeeRate;
                txCal = multiplyAndPercent(serviceTax, totalAbsFee);  // not in flow
                totalBearableFee = totalAbsFee;
                totalBearableFeeServiceTax = txCal;
            }

            //txnFeeProcessFlag = Hybrid & bearableComponent = Amount & merchantFeeType = F & bearableEntity = M
            if (validateAndMatch(bearableEntity, TransactionConstant.BEARABLE_ENTITY_MERCHANT)) {

                merchantBearableAmt = totalBearableFee;
                merchantBearableServiceTax = totalBearableFeeServiceTax;
                customerBearableAmt = subtract(totalAbsFee, merchantBearableAmt);
                //customerBearableServiceTax = subtract(txCal, totalBearableFeeServiceTax); // Check with code, difference found
                customerBearableServiceTax = multiplyAndPercent(serviceTax, customerBearableAmt); //  As per code

                //txnFeeProcessFlag = Hybrid & bearableComponent = Amount & merchantFeeType = F & bearableEntity = C
            } else if (validateAndMatch(bearableEntity, TransactionConstant.BEARABLE_ENTITY_CUSTOMER)) {

                customerBearableAmt = totalBearableFee;
                customerBearableServiceTax = totalBearableFeeServiceTax;
                merchantBearableAmt = subtract(totalAbsFee, customerBearableAmt);
                //merchantBearableServiceTax = subtract(txCal, totalBearableFeeServiceTax); // Check with code, difference found
                merchantBearableServiceTax = multiplyAndPercent(serviceTax, merchantBearableAmt); //  As per code

            }

        }

        BigDecimal postAmount = merchPostedAmt.add(customerBearableAmt).add(customerBearableServiceTax);

        merchantPricingDto.setCustomerBearableAmt(customerBearableAmt);
        merchantPricingDto.setCustomerBearableServiceTax(customerBearableServiceTax);
        merchantPricingDto.setMerchantBearableAmt(merchantBearableAmt);
        merchantPricingDto.setMerchantBearableServiceTax(merchantBearableServiceTax);
        merchantPricingDto.setPostAmount(postAmount);
        merchantPricingDto.setBearableCutOffAmt(bearableCutOffAmt);

    }

    /**
     * Method name:calculatePricingForBearableComponentFee
     * Description:This method calculates the bearable fee components for both the merchant and customer based on
     * the pricing structure and transaction amount. It calculates the bearable fee, service tax, and
     * the final post amount based on the merchant fee type (percentage or flat) and other conditions
     * related to bearable fee limits and types (business, percentage, flat).
     *
     * @param pricingStructure   The pricing structure containing details like fee types, bearable limits, etc.
     * @param merchPostedAmt     The transaction amount posted by the merchant.
     * @param merchantPricingDto The DTO object where the calculated bearable amounts and fees are stored.
     */

    private static void calculatePricingForBearableComponentFee(MerchantPricingResponse pricingStructure, BigDecimal merchPostedAmt, MerchantPricingDto merchantPricingDto) {

        BigDecimal txCal;
        BigDecimal totalAbsFee;
        BigDecimal totalBearableFee;
        BigDecimal totalBearableFeeServiceTax;
        BigDecimal merchantBearableAmt = BigDecimal.ZERO;
        BigDecimal merchantBearableServiceTax = BigDecimal.ZERO;
        BigDecimal customerBearableAmt = BigDecimal.ZERO;
        BigDecimal customerBearableServiceTax = BigDecimal.ZERO;
        BigDecimal bearablePercentFee = BigDecimal.ZERO;
        BigDecimal bearableFee = BigDecimal.ZERO;
        BigDecimal bearableFeeST = BigDecimal.ZERO;

        logger.info("Setting Pricing Structure.");
        //Pricing Structure
        Character merchantFeeType = pricingStructure.getMerchantFeeType();
        BigDecimal serviceTax = pricingStructure.getServiceTax();

        //as per old code
        Character bearableEntity = pricingStructure.getBearableEntity();
        BigDecimal bearableCutOffAmt = pricingStructure.getBearableAmountCutoff();
        BigDecimal bearableFlatFee = pricingStructure.getBearableFlatRate();
        String bearableLimit = pricingStructure.getBearableLimit();
        BigDecimal bearablePercentRate = pricingStructure.getBearablePercentageRate();
        Character bearableType = pricingStructure.getBearableType();
        BigDecimal totalBearableFeeRate = pricingStructure.getTotalFeeRate();

        //txnFeeProcessFlag = Hybrid & bearableComponent = FEE & merchantFeeType = P
        if (validateAndMatch(merchantFeeType, TransactionConstant.MERCHANT_FEE_TYPE_PERCENTAGE)) {

            totalBearableFee = multiplyAndPercent(merchPostedAmt, totalBearableFeeRate);
            totalBearableFeeServiceTax = multiplyAndPercent(totalBearableFee, serviceTax);
            txCal = totalBearableFeeServiceTax; // new added not being used
            totalAbsFee = totalBearableFee; // new added but not being used

            //txnFeeProcessFlag = Hybrid & bearableComponent = FEE & merchantFeeType = P & bearableType = B
            if (validateAndMatch(bearableType, TransactionConstant.BEARABLE_TYPE_BUSINESS)) {

                if (bearablePercentRate.compareTo(BigDecimal.ZERO) > 0) {

                    bearablePercentFee = multiplyAndPercent(totalBearableFee, bearablePercentRate);   // No else condition in flow graph
                }

                //txnFeeProcessFlag = Hybrid & bearableComponent = FEE & merchantFeeType = P & bearableType = B & bearableLimit = LOWER
                if (validateAndMatch(bearableLimit, TransactionConstant.BEARABLE_LIMIT_LOWER)) {

                    if (bearablePercentFee.compareTo(bearableFlatFee) < 0) {

                        bearableFee = bearablePercentFee;

                    } else {

                        bearableFee = bearableFlatFee;
                    }

                    bearableFeeST = multiplyAndPercent(bearableFee, serviceTax);

                    //txnFeeProcessFlag = Hybrid & bearableComponent = FEE & merchantFeeType = P & bearableType = B & bearableLimit = HIGHER
                } else if (validateAndMatch(bearableLimit, TransactionConstant.BEARABLE_LIMIT_HIGHER)) {

                    if (bearablePercentFee.compareTo(bearableFlatFee) > 0) {

                        bearableFee = bearablePercentFee;

                    } else {

                        bearableFee = bearableFlatFee;
                    }

                    bearableFeeST = multiplyAndPercent(bearableFee, serviceTax);

                }

                //txnFeeProcessFlag = Hybrid & bearableComponent = FEE & merchantFeeType = P & bearableType = P
            } else if (validateAndMatch(bearableType, TransactionConstant.BEARABLE_TYPE_PERCENTAGE)) {

                //txnFeeProcessFlag = Hybrid & bearableComponent = FEE & merchantFeeType = P & bearableType = P & bearableEntity = M
                if (validateAndMatch(bearableEntity, TransactionConstant.BEARABLE_ENTITY_MERCHANT)) {

                    //bearableFee = multiplyAndPercent(totalBearableFee, bearablePercentRate); // Check in code, seems incorrect in flow graph
                    bearableFee = totalBearableFee; //  As per code

                    //txnFeeProcessFlag = Hybrid & bearableComponent =  FEE & merchantFeeType = P & bearableType = P & bearableEntity = C
                } else if (validateAndMatch(bearableEntity, TransactionConstant.BEARABLE_ENTITY_CUSTOMER)) {

                    bearableFee = multiplyAndPercent(totalBearableFee, bearablePercentRate);

                }

                bearableFeeST = multiplyAndPercent(bearableFee, serviceTax);

                //txnFeeProcessFlag = Hybrid & bearableComponent = FEE & merchantFeeType = P & bearableType = F
            } else if (validateAndMatch(bearableType, TransactionConstant.BEARABLE_TYPE_FLAT)) {

                if (totalBearableFee.compareTo(bearableFlatFee) < 0) {

                    //bearableFee = multiplyAndPercent(totalBearableFee, bearablePercentRate); // Miss match in flow and code
                    bearableFee = totalBearableFee;  //  As per code
                    bearableFeeST = totalBearableFeeServiceTax; //  As per code


                } else {

                    //bearableFee = bearableFlatFee;  // Miss match in flow and code
                    bearableFee = bearableFlatFee; //  As per code
                    bearableFeeST = multiplyAndPercent(bearableFee, serviceTax); //  As per code

                }

                //bearableFeeST = multiplyAndPercent(bearableFee, serviceTax); // Miss match in flow and code
                //not present //  As per code, bearableFeeST is being calculated above
            }

            //txnFeeProcessFlag = Hybrid & bearableComponent = FEE & merchantFeeType = P & bearableEntity = M
            if (validateAndMatch(bearableEntity, TransactionConstant.BEARABLE_ENTITY_MERCHANT)) {

                merchantBearableAmt = bearableFee;
                merchantBearableServiceTax = bearableFeeST;
                customerBearableAmt = subtract(totalBearableFee, merchantBearableAmt);
                customerBearableServiceTax = subtract(totalBearableFeeServiceTax, bearableFeeST);

                //txnFeeProcessFlag = Hybrid & bearableComponent = FEE & merchantFeeType = P & bearableEntity = C
            } else if (validateAndMatch(bearableEntity, TransactionConstant.BEARABLE_ENTITY_CUSTOMER)) {

                customerBearableAmt = bearableFee;
                customerBearableServiceTax = bearableFeeST;
                merchantBearableAmt = subtract(totalBearableFee, customerBearableAmt);
                merchantBearableServiceTax = subtract(totalBearableFeeServiceTax, bearableFeeST);

            }

            //txnFeeProcessFlag = Hybrid & bearableComponent = FEE & merchantFeeType = F
        } else if (validateAndMatch(merchantFeeType, TransactionConstant.MERCHANT_FEE_TYPE_FLAT)) {

            totalAbsFee = totalBearableFeeRate;
            txCal = multiplyAndPercent(totalBearableFeeRate, serviceTax);

            //txnFeeProcessFlag = Hybrid & bearableComponent = FEE & merchantFeeType = F & bearableType = B
            if (validateAndMatch(bearableType, TransactionConstant.BEARABLE_TYPE_BUSINESS)) {

                if (bearablePercentRate.compareTo(BigDecimal.ZERO) > 0) {
                    bearablePercentFee = multiplyAndPercent(totalBearableFeeRate, bearablePercentRate);  // else condition missing in flow graph
                }

                //txnFeeProcessFlag = Hybrid & bearableComponent = FEE & merchantFeeType = F & bearableType = B & bearableLimit = LOWER
                if (validateAndMatch(bearableLimit, TransactionConstant.BEARABLE_LIMIT_LOWER)) {

                    if (bearablePercentFee.compareTo(bearableFlatFee) < 0) {

                        bearableFee = bearablePercentFee;

                    } else {

                        //bearableFee = bearablePercentFee; // check with code flow, seems wrong in flow graph
                        bearableFee = bearableFlatFee; //  As per code
                    }

                    //txnFeeProcessFlag = Hybrid & bearableComponent = FEE & merchantFeeType =  F & bearableType = B & bearableLimit = HIGHER
                } else if (validateAndMatch(bearableLimit, TransactionConstant.BEARABLE_LIMIT_HIGHER)) {

                    if (bearablePercentFee.compareTo(bearableFlatFee) > 0) {

                        bearableFee = bearablePercentFee;

                    } else {

                        //bearableFee = bearablePercentFee;  // check with code flow, seems wrong in flow graph
                        bearableFee = bearableFlatFee; //  As per code
                    }
                }

                bearableFeeST = multiplyAndPercent(bearableFee, serviceTax);

                //txnFeeProcessFlag = Hybrid & bearableComponent = FEE & merchantFeeType = F & bearableType = P
            } else if (validateAndMatch(bearableType, TransactionConstant.BEARABLE_TYPE_PERCENTAGE)) {

                bearableFee = multiplyAndPercent(totalBearableFeeRate, bearablePercentRate);
                bearableFeeST = multiplyAndPercent(bearableFee, serviceTax);

                //txnFeeProcessFlag = Hybrid & bearableComponent = FEE & merchantFeeType = F & bearableType = F
            } else if (validateAndMatch(bearableType, TransactionConstant.BEARABLE_TYPE_FLAT)) {

                if (totalBearableFeeRate.compareTo(bearableFlatFee) < 0) {

                    bearableFee = totalBearableFeeRate;

                } else {

                    bearableFee = bearableFlatFee;
                }

                bearableFeeST = multiplyAndPercent(bearableFee, serviceTax);

            }

            //txnFeeProcessFlag = Hybrid & bearableComponent = FEE & merchantFeeType = F & bearableEntity = M
            if (validateAndMatch(bearableEntity, TransactionConstant.BEARABLE_ENTITY_MERCHANT)) {

                merchantBearableAmt = bearableFee;
                merchantBearableServiceTax = bearableFeeST;
                customerBearableAmt = subtract(totalAbsFee, merchantBearableAmt);
                customerBearableServiceTax = subtract(txCal, merchantBearableServiceTax);

                //txnFeeProcessFlag = Hybrid & bearableComponent = FEE & merchantFeeType = F & bearableEntity = C
            } else if (validateAndMatch(bearableEntity, TransactionConstant.BEARABLE_ENTITY_CUSTOMER)) {

                customerBearableAmt = bearableFee;
                customerBearableServiceTax = bearableFeeST;
                merchantBearableAmt = subtract(totalAbsFee, customerBearableAmt);
                merchantBearableServiceTax = subtract(txCal, bearableFeeST);

            }

        }

        BigDecimal postAmount = merchPostedAmt.add(customerBearableAmt).add(customerBearableServiceTax);

        merchantPricingDto.setCustomerBearableAmt(customerBearableAmt);
        merchantPricingDto.setCustomerBearableServiceTax(customerBearableServiceTax);
        merchantPricingDto.setMerchantBearableAmt(merchantBearableAmt);
        merchantPricingDto.setMerchantBearableServiceTax(merchantBearableServiceTax);
        merchantPricingDto.setPostAmount(postAmount);
        merchantPricingDto.setBearableCutOffAmt(bearableCutOffAmt);
    }

    /**
     * Method name:calculateBearableAmount
     * Description:This method calculates the bearable amounts for the merchant based on the pricing structure,
     * which could either be based on an amount or a fee component. It performs calculations by determining
     * the bearable component (either "AMOUNT" or "FEE") and delegates to the appropriate calculation method.
     * After calculating the bearable components, the method calculates the total post amount, which includes
     * the gateway fee and other additional fees.
     *
     * @param pricingStructure   The pricing structure containing the bearable component details.
     * @param merchPostedAmt     The transaction amount posted by the merchant.
     * @param merchantPricingDto The DTO object where the calculated bearable amounts, fees, and post amount are stored.
     */
    public static void calculateBearableAmount(MerchantPricingResponse pricingStructure, BigDecimal merchPostedAmt, MerchantPricingDto merchantPricingDto) {

        logger.info("Determining merchant pricing info based on bearable component.");

        //Step 1: for bearable component AMOUNT
        if (pricingStructure.getBearableComponent().equalsIgnoreCase(TransactionConstant.BEARABLE_COMPONENT_AMOUNT)) {
            calculatePricingForBearableComponentAmount(pricingStructure, merchPostedAmt, merchantPricingDto);
        }

        //Step 2: for bearable component FEE
        if (pricingStructure.getBearableComponent().equalsIgnoreCase(TransactionConstant.BEARABLE_COMPONENT_FEE)) {
            calculatePricingForBearableComponentFee(pricingStructure, merchPostedAmt, merchantPricingDto);
        }

        //Step 3: Calculate total post amount
        //merchantPricingDto.setPostAmount(merchantPricingDto.getPostAmount().add(merchantPricingDto.getGtwFeeAbs()).add(merchantPricingDto.getOtherFeeAbs()));
    }

    /**
     * Method name:calculateFee
     * Description:This method calculates the fee based on the fee applicability, fee type, and the fee value.
     * The method checks whether the fee is applicable ('Y' for Yes) and then performs the fee calculation based on the type:
     * - If the fee type is percentage ('P'), the fee is calculated as a percentage of the posted amount.
     * - If the fee type is flat ('F'), the fee is returned as the given flat fee value.
     * <p>
     * If the fee is not applicable, it returns BigDecimal.ZERO, indicating no fee is charged.
     *
     * @param feeApplicable  A character indicating whether the fee is applicable ('Y' for Yes, 'N' for No).
     * @param feeType        A character indicating the fee type ('P' for percentage, 'F' for flat).
     * @param fee            The fee value, either as a percentage or a flat amount.
     * @param merchPostedAmt The transaction amount posted by the merchant, used for percentage-based fee calculation.
     * @return The calculated fee as a BigDecimal.
     */
    private static BigDecimal calculateFee(Character feeApplicable, Character feeType, BigDecimal fee, BigDecimal merchPostedAmt) {
        logger.info("Calculating fee based on applicability, type, and transaction amount.");
        if (feeApplicable.equals('Y')) {

            if (feeType.equals('P')) {
                return multiplyAndPercent(fee, merchPostedAmt);
            }

            if (feeType.equals('F')) {
                return fee;
            }
        }
        return BigDecimal.ZERO;
    }

    /**
     * Method name:multiplyAndPercent
     * Description:This method multiplies two BigDecimal values and then divides the result by 100 to calculate the percentage.
     * The result is rounded to two decimal places using the HALF_UP rounding mode.
     *
     * @param b1 The first BigDecimal value to be multiplied.
     * @param b2 The second BigDecimal value, which represents the percentage to be applied.
     * @return The calculated percentage value as a BigDecimal, rounded to two decimal places.
     */
    private static BigDecimal multiplyAndPercent(BigDecimal b1, BigDecimal b2) {
        logger.info("Calculating percentage by multiplying {} with {} and dividing by 100.", b1, b2);
        return b1.multiply(b2).divide(BigDecimal.valueOf(100), 2, RoundingMode.HALF_UP);
    }

    /**
     * Method name:subtract
     * Description:This method subtracts the second BigDecimal value from the first one.
     * The result is rounded to two decimal places using the HALF_UP rounding mode.
     *
     * @param b1 The BigDecimal value from which the second value will be subtracted.
     * @param b2 The BigDecimal value to subtract from the first one.
     * @return The result of the subtraction, rounded to two decimal places.
     */
    private static BigDecimal subtract(BigDecimal b1, BigDecimal b2) {
        logger.info("Subtracting {} from {} to get the result.", b2, b1);
        return b1.subtract(b2).setScale(2, RoundingMode.HALF_UP);
    }

    /**
     * Method name:validateAndMatch
     * Description:Validates and compares two objects of type Character or String, ignoring case sensitivity.
     * It checks if the first object is equal to the second object, considering the following:
     * - If both objects are characters, their uppercase values are compared.
     * - If both objects are strings, they are compared in a case-insensitive manner.
     *
     * @param a The first object to be compared, which could be of type Character or String.
     * @param b The second object to be compared, which could also be of type Character or String.
     * @return true if both objects are equal based on the rules above, false otherwise.
     */
    private static boolean validateAndMatch(Object a, Object b) {
        logger.info("Validating and matching: a = {}, b = {}", a, b);
        return Optional.ofNullable(a).flatMap(first -> Optional.ofNullable(b).map(second -> {
            if (first instanceof Character && second instanceof Character) {
                return Character.toUpperCase((Character) first) == Character.toUpperCase((Character) second);
            }
            if (first instanceof String && second instanceof String) {
                return ((String) first).equalsIgnoreCase((String) second);
            }
            return false;
        })).orElse(false);
    }


}
