package com.epay.transaction.service;

import com.epay.transaction.dao.SbiUPIDao;
import com.epay.transaction.externalservice.request.payment.PaymentStatusRequest;
import com.epay.transaction.externalservice.request.payment.PaymentUPIVpaRequest;
import com.epay.transaction.model.request.EncryptedRequest;
import com.epay.transaction.model.response.EncryptedResponse;
import com.epay.transaction.model.response.TransactionResponse;
import com.epay.transaction.util.TransactionConstant;
import com.epay.transaction.validator.PaymentUpiValidator;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Collections;

import static com.epay.transaction.util.TransactionUtil.buildRequestByEncryptRequest;

/**
 * Class Name:SbiUPIService
 * *
 * Description:
 * *
 * Author:V1018841(Saurabh Mahto)
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
@Service
@RequiredArgsConstructor
public class SbiUPIService {
    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private final SbiUPIDao sbiUPIDao;
    private final PaymentUpiValidator paymentUpiValidator;

    /**
     * This method validates a UPI Virtual Payment Address (VPA) payment request by invoking the paymentServicesClient to check
     * the provided payment request details. It returns a TransactionResponse containing a PaymentUPIVpaResponse,
     * which indicates whether the VPA is valid for the payment request.
     *
     * @param encryptedRequest Request we get for payment
     * @return paymentVpaResponse
     */

    public TransactionResponse<EncryptedResponse> validateUpiVPAPayment(EncryptedRequest encryptedRequest) {
        logger.info("Validating PaymentUPIVpaRequest from payment service.");
        String aesKey = sbiUPIDao.getEncryptedAESKey();
        // Step 1: Build PaymentUPIVpaRequest from requested encryptedRequest
        PaymentUPIVpaRequest payRequest = buildRequestByEncryptRequest(encryptedRequest.getEncryptedRequest(), aesKey, PaymentUPIVpaRequest.class);
        // Step 2: Validate Request
        paymentUpiValidator.checkValidateUpiVPA(payRequest);
        // Step 3: Validated Vpa and received EncryptedResponse of PaymentUPIVpaResponse
        EncryptedResponse response = sbiUPIDao.validateUPIPaymentVpa(payRequest, aesKey);
        // Step 4: Return the encrypted response wrapped in a TransactionResponse object
        return TransactionResponse.<EncryptedResponse>builder().data(Collections.singletonList(response)).status(TransactionConstant.RESPONSE_SUCCESS).build();
    }

    /**
     * This method retrieves the status of a UPI payment by querying the paymentServicesClient with the provided payment status request.
     * It returns a TransactionResponse containing a PaymentUPIStatusResponse with details about the current status of the UPI payment.
     *
     * @param encryptedRequest Request we get for payment
     * @return payment response
     */

    public TransactionResponse<EncryptedResponse> getStatusEnquiry(EncryptedRequest encryptedRequest) {
        logger.info("Validating PaymentUPIVpaRequest from payment service.");
        String aesKey = sbiUPIDao.getEncryptedAESKey();
        // Step 1: Build PaymentStatusRequest from requested encryptedRequest
        PaymentStatusRequest paymentStatusRequest = buildRequestByEncryptRequest(encryptedRequest.getEncryptedRequest(), aesKey, PaymentStatusRequest.class);
        // Step 2: validate status enquiry request
        paymentUpiValidator.validateStatusEnquiryRequest(paymentStatusRequest);
        // Step 3: validate atrn mapping with mid and sbi order ref
        paymentUpiValidator.validateAtrnMapping(paymentStatusRequest.getAtrn());
        // Step 4: Get EncryptedResponse of UPIPaymentStatus
        EncryptedResponse response = sbiUPIDao.upiPaymentStatusEnquiry(paymentStatusRequest, aesKey);
        // Step 5: Return the encrypted response wrapped in a TransactionResponse object
        return TransactionResponse.<EncryptedResponse>builder().status(TransactionConstant.RESPONSE_SUCCESS).data(Collections.singletonList(response)).build();
    }

}
