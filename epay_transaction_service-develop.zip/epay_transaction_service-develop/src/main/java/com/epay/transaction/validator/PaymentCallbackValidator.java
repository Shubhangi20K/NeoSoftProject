package com.epay.transaction.validator;

import com.epay.transaction.dao.PaymentCallbackForwardDao;
import com.epay.transaction.model.request.PaymentCallBackRequest;
import com.epay.transaction.util.TransactionConstant;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.ArrayList;

import static com.epay.transaction.util.TransactionConstant.*;
import static com.epay.transaction.util.TransactionErrorConstants.ATRN;
import static com.epay.transaction.util.TransactionErrorConstants.INCORRECT_FORMAT;

/**
 * Class Name: OrderValidator
 * *
 * Description: Validates Order Validator for create and update request.
 * *
 * Author: V1018212
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Component
@RequiredArgsConstructor
public class PaymentCallbackValidator extends BaseValidator {

    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private final PaymentCallbackForwardDao paymentCallbackForwardDao;

    public void validatePaymentRequest(PaymentCallBackRequest paymentCallBackRequest) {
        errorDtoList = new ArrayList<>();
        logger.info("Payment Initiation Validation Started");
        validateMandatoryFields(paymentCallBackRequest);
        validateLeadingTrailingAndSingleSpace(paymentCallBackRequest);
        validatedFieldLength(paymentCallBackRequest);
        validateFieldValue(paymentCallBackRequest);
        validateAtrnBySbiOrderNumber(paymentCallBackRequest);
        validateOptionalFiled(paymentCallBackRequest);
        logger.info("Payment Initiation Validation Completed");
    }

    /**
     * Method name : validateMandatoryFields
     * Description : Validates mandatory fields of payment call back request
     * @param paymentCallBackRequest : Object of PaymentCallBackRequest
     */
    private void validateMandatoryFields(PaymentCallBackRequest paymentCallBackRequest) {
        logger.debug("Validating paymentInitiationRequest {}", paymentCallBackRequest);
        checkMandatoryField(paymentCallBackRequest.getMId(), "mId");
        checkMandatoryField(paymentCallBackRequest.getMerchnatOrderRefNo(), "merchnat_order_Ref_No");
        checkMandatoryField(paymentCallBackRequest.getAtrn(), "atrn");
        checkMandatoryField(paymentCallBackRequest.getStatus(), "status");
        checkMandatoryField(paymentCallBackRequest.getOrderRetryCount(), "order_Retry_Count");
        checkMandatoryField(paymentCallBackRequest.getSbiOrderRefNo(), "Sbi_Order_Ref_No");
        checkMandatoryField(paymentCallBackRequest.getOrderAmount(), "order_amount");
        checkMandatoryField(paymentCallBackRequest.getDebitAmount(), "debit_Amount");
        checkMandatoryField(paymentCallBackRequest.getBankName(), "bank_name");
        checkMandatoryField(paymentCallBackRequest.getCin(), "cin_no");
        throwIfErrors();
    }

    /**
     * Method name : validateLeadingTrailingAndSingleSpace
     * Description : Validates leading and trailing fields of payment call back request
     * @param paymentCallBackRequest : Object of PaymentCallBackRequest
     */
    private void validateLeadingTrailingAndSingleSpace(PaymentCallBackRequest paymentCallBackRequest) {
        checkForLeadingTrailingAndSingleSpace(paymentCallBackRequest.getMId(), "mId");
        checkForLeadingTrailingAndSingleSpace(paymentCallBackRequest.getMerchnatOrderRefNo(), "merchnat_order_Ref_No");
        checkForLeadingTrailingAndSingleSpace(paymentCallBackRequest.getSbiOrderRefNo(), "sbiOrderRefNumber");
        checkForLeadingTrailingAndSingleSpace(paymentCallBackRequest.getAtrn(), "atrn");
        checkForLeadingTrailingAndSingleSpace(paymentCallBackRequest.getStatus(), "status");
        checkForLeadingTrailingAndSingleSpace(paymentCallBackRequest.getReason(), "reason");
        checkForLeadingTrailingAndSingleSpace(paymentCallBackRequest.getOrderRetryCount(), "order_Retry_Count");
        checkForLeadingTrailingAndSingleSpace(paymentCallBackRequest.getOrderAmount(), "order_Amount");
        checkForLeadingTrailingAndSingleSpace(paymentCallBackRequest.getDebitAmount(), "debit_Amount");
        checkForLeadingTrailingAndSingleSpace(paymentCallBackRequest.getBankCode(), "bankCode");
        checkForLeadingTrailingAndSingleSpace(paymentCallBackRequest.getBankName(), "bankName");
        checkForLeadingTrailingAndSingleSpace(paymentCallBackRequest.getBankTraceNo(), "bankTraceNumber");
        checkForLeadingTrailingAndSingleSpace(paymentCallBackRequest.getCin(), "cin");
        checkForLeadingTrailingAndSingleSpace(paymentCallBackRequest.getOtherDetails(), "otherDetails");
        checkForLeadingTrailingAndSingleSpace(paymentCallBackRequest.getCustomerId(), "customerId");

        throwIfErrors();
    }

    /**
     * Method name : validatedFieldLength
     * Description : Validates fields length of payment call back request
     * @param paymentCallBackRequest : Object of PaymentCallBackRequest
     */
    private void validatedFieldLength(PaymentCallBackRequest paymentCallBackRequest) {
        validateFieldLength(paymentCallBackRequest.getMId(), TransactionConstant.MID_MAX_LENGTH, "mId");
        validateFixedFieldLength(paymentCallBackRequest.getAtrn(), TransactionConstant.ATRN_ARRN_LENGTH, "atrn");
        validateFieldLength(paymentCallBackRequest.getStatus(), TransactionConstant.STATUS_LENGTH, "status");
        validateFieldLength(paymentCallBackRequest.getReason(), TransactionConstant.REASON_LENGTH, "reason");
        validateFieldLength(paymentCallBackRequest.getBankCode(), TransactionConstant.BANK_CODE_LENGTH, "bank code");
        validateFieldLength(paymentCallBackRequest.getBankName(), TransactionConstant.CHANNEL_BANK_LENGTH, "bank name");
        validateFieldLength(paymentCallBackRequest.getOtherDetails(), TransactionConstant.OTHER_DETAILS_LENGTH, "other_details");
        validateFieldLength(paymentCallBackRequest.getBankTraceNo(), TransactionConstant.BANKTRACE_LENGTH, "bank trace number");
        validateFieldLength(paymentCallBackRequest.getCin(), TransactionConstant.CIN_LENGTH, "CIN");
        validateFieldLength(paymentCallBackRequest.getOrderAmount(), TransactionConstant.AMOUNT_LENGTH, "order amount");
        validateFieldLength(paymentCallBackRequest.getDebitAmount(), TransactionConstant.AMOUNT_LENGTH, "debit amount");
        validateFieldLength(paymentCallBackRequest.getMerchnatOrderRefNo(), TransactionConstant.OTHERDETAILS_LENGTH, "merchant reference number");
        validateFieldLength(paymentCallBackRequest.getSbiOrderRefNo(), TransactionConstant.OTHERDETAILS_LENGTH, "sbiOrderReference number");
        validateFieldLength(paymentCallBackRequest.getOrderRetryCount(), TransactionConstant.ORDER_RETRY_LENGTH, "retry count");
        validateFixedFieldLength(paymentCallBackRequest.getCustomerId(), CUSTOMER_ID_LENGTH, FIELD_CUSTOMER_ID);
        throwIfErrors();
    }

    /**
     * Method name : validateFieldValue
     * Description : Validates fields values of payment call back request
     * @param paymentCallBackRequest : Object of PaymentCallBackRequest
     */
    private void validateFieldValue(PaymentCallBackRequest paymentCallBackRequest) {

        validateFieldWithRegex(paymentCallBackRequest.getAtrn(), ATRN_ARRN_REGEX, ATRN, INCORRECT_FORMAT);
        validateFieldWithRegex(paymentCallBackRequest.getMId(), NUMBER_ONLY, MID_CONST, INCORRECT_FORMAT);
        validateFieldWithRegex(paymentCallBackRequest.getOrderRetryCount(), NUMBER_ONLY, "order_Retry_Count", INCORRECT_FORMAT);
        validateFieldWithRegex(paymentCallBackRequest.getCin(), NUMBER_ONLY, "CIN", INCORRECT_FORMAT);
        validateFieldWithRegex(paymentCallBackRequest.getCustomerId(), CUSTOMER_ID_REGEX, FIELD_CUSTOMER_ID, INCORRECT_FORMAT);
        validateFieldWithRegex(paymentCallBackRequest.getMerchnatOrderRefNo(), ORDER_REFERENCE_NUMBER_REGEX, FIELD_ORDER_REF_NUMBER, INCORRECT_FORMAT);
        validateFieldWithRegex(paymentCallBackRequest.getSbiOrderRefNo(), ORDER_REFERENCE_NUMBER_REGEX, "Sbi_Order_Ref_No", INCORRECT_FORMAT);
        validateFieldWithRegex(paymentCallBackRequest.getOtherDetails(), SPEC_CHARACTER_REGEX, "other_details", INCORRECT_FORMAT);
        validateFieldWithRegex(paymentCallBackRequest.getStatus(), ALPHABET_CHARS_REGEX, "status", INCORRECT_FORMAT);
        validateFieldWithRegex(paymentCallBackRequest.getReason(), ALLOW_SPECIAL_CHAR_REGEX, "reason", INCORRECT_FORMAT);
        validateFieldWithRegex(paymentCallBackRequest.getBankTraceNo(), BANK_TRACE_NO_REGEX, "bank_trace_No", INCORRECT_FORMAT);
        validateFieldWithRegex(paymentCallBackRequest.getBankCode(), BANK_TRACE_NO_REGEX, "bank_code", INCORRECT_FORMAT);
        validateFieldWithRegex(paymentCallBackRequest.getBankName(), SPEC_CHARACTER_REGEX, "bank_name", INCORRECT_FORMAT);
        validateFieldWithRegex(paymentCallBackRequest.getOrderAmount(), BIGDECEMAL_ONLY, "orderAmount", INCORRECT_FORMAT);
        validateFieldWithRegex(paymentCallBackRequest.getDebitAmount(), BIGDECEMAL_ONLY, "debitAmount", INCORRECT_FORMAT);
        throwIfErrors();
        validateAmount(new BigDecimal(paymentCallBackRequest.getOrderAmount()), "order amount");
        validateAmount(new BigDecimal(paymentCallBackRequest.getDebitAmount()), "debit amount");
        throwIfErrors();
    }

    /**
     * Method name : validateAtrnBySbiOrderNumber
     * Description : Validate atrn by sbi order number of payment call back request
     * @param paymentCallBackRequest : Object of PaymentCallBackRequest
     */
    private void validateAtrnBySbiOrderNumber(PaymentCallBackRequest paymentCallBackRequest) {
        paymentCallbackForwardDao.validateByAtrnMidAndOrderRefNumber(paymentCallBackRequest.getMId(), paymentCallBackRequest.getSbiOrderRefNo(), paymentCallBackRequest.getAtrn());
    }

    /**
     * Method name : validateOptionalFiled
     * Description : Validate optional fields of payment call back request
     * @param paymentCallBackRequest : Object of PaymentCallBackRequest
     */
    private void validateOptionalFiled(PaymentCallBackRequest paymentCallBackRequest) {
        if(paymentCallBackRequest.getStatus().equalsIgnoreCase("success"))
        {
            checkMandatoryField(paymentCallBackRequest.getBankTraceNo(), "bankTraceNo");
            throwIfErrors();
        }
        else {
            checkMandatoryField(paymentCallBackRequest.getReason(), "reason");
            throwIfErrors();
        }

    }
}
