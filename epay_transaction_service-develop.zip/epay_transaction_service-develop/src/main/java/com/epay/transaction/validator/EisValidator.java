package com.epay.transaction.validator;


import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import java.util.ArrayList;
import static com.epay.transaction.util.TransactionConstant.*;
import static com.epay.transaction.util.TransactionConstant.GSTIN_NUMBER;
import static com.epay.transaction.util.TransactionErrorConstants.*;


/**
 * Class Name: EisValidator
 * *
 * Description: Validates EIS service request.
 * *
 * Author: V1018212
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Component
@RequiredArgsConstructor
public class EisValidator extends BaseValidator{
    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    /**
     * Method name : validateCardNumber
     * Description : Validates card number request details
     *
     * @param cardNumber : String of cardNumber
     */
    public void validateCardNumber(String cardNumber) {
        logger.info("Eis service card validation started for {}", cardNumber);
        errorDtoList = new ArrayList<>();
        checkMandatoryField(cardNumber, CARD_NUMBER);
        throwIfErrors();
        checkForLeadingTrailingAndSingleSpace(cardNumber, CARD_NUMBER);
        throwIfErrors();
        validateFixedFieldLength(cardNumber, CARD_NUMBER_LENGTH, CARD_NUMBER);
        throwIfErrors();
        validateFieldWithRegex(cardNumber, CARD_NUMBER_REGEX, CARD_NUMBER,  INCORRECT_CARD_NUMBER_FORMAT);
        throwIfErrors();
        logger.debug("Eis service card validation  completed");
    }

    /**
     * Method name : validateCardNumberRequest
     * Description : Validates card number request of encrypt request
     *
     * @param cardNumberRequest : String of cardNumberRequest
     */
    public void validateCardNumberRequest(String cardNumberRequest) {
        errorDtoList = new ArrayList<>();
        checkMandatoryField(cardNumberRequest, ENCRYPT_REQUEST);
        throwIfErrors();
        checkForLeadingTrailingAndSingleSpace(cardNumberRequest, ENCRYPT_REQUEST);
        throwIfErrors();

    }


    /**
     * Method name : validateGstInNumber
     * Description : Validates card GstInNumber
     *
     * @param gstInNumber : String of gstInNumber
     */
    public void validateGstInNumber(String gstInNumber) {
        logger.info("Eis service GstInNumber validation started for {}", gstInNumber);
        errorDtoList = new ArrayList<>();
        checkMandatoryField(gstInNumber, GSTIN_NUMBER);
        throwIfErrors();
        checkForLeadingTrailingAndSingleSpace(gstInNumber, GSTIN_NUMBER);
        throwIfErrors();
        validateFixedFieldLength(gstInNumber, GSTIN_LENGTH, GSTIN_NUMBER);
        throwIfErrors();
        validateFieldWithRegex(gstInNumber, GSTIN_REGEX, GSTIN_NUMBER,  INCORRECT_GSTIN_NUMBER_FORMAT);
        throwIfErrors();
        logger.debug("Eis service GstInNumber validation  completed");
    }

    public void validateEmailId(String email) {
        logger.info("Eis service email validation started for {}", email);
        errorDtoList = new ArrayList<>();
        checkMandatoryField(email, FIELD_EMAIL);
        throwIfErrors();
        checkForLeadingTrailingAndSingleSpace(email, FIELD_EMAIL);
        throwIfErrors();
        validateFieldLength(email, EMAIL_LENGTH, FIELD_EMAIL);
        throwIfErrors();
        validateFieldWithRegex(email, EMAIL_REGEX, FIELD_EMAIL,  INCORRECT_FORMAT);
        throwIfErrors();
        logger.info("Eis service GstInNumber validation  completed");
    }
}
