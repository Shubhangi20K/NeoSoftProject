package com.epay.transaction.controller;

import com.epay.transaction.dto.BulkRefundBookingDto;
import com.epay.transaction.model.request.EncryptedRequest;
import com.epay.transaction.model.request.RefundBookRequest;
import com.epay.transaction.model.request.RefundSearchRequest;
import com.epay.transaction.model.response.EncryptedResponse;
import com.epay.transaction.model.response.RefundResponse;
import com.epay.transaction.model.response.TransactionResponse;
import com.epay.transaction.service.RefundService;
import com.epay.transaction.util.TransactionConstant;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

/**
 * Class Name:RefundController
 * *
 * Description: Controller for refund booking, refund searching by merchant.
 * This controller provides endpoints for refund booking, refund status, refund searching and bulk refund booking.
 * This controller delegates the requests to RefundService.
 * *
 * Author:Nirmal Gurjar
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
@RestController
@RequiredArgsConstructor
@RequestMapping("/refund")
public class RefundController {

    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private final RefundService refundService;

    /**
     * This API is used to Book refund for a ATRN and requested parameters.
     *
     * @param encryptedRequest EncryptedRequest
     * @return TransactionResponse<RefundResponse>
     */
    @PostMapping("/book")
    @Operation(summary = "Refund booking API", description = "This API is used to book the refund against ATRN number used by merchant in encrypted form")
    @PreAuthorize("hasAnyRole('ACCESS')")
    public TransactionResponse<EncryptedResponse> bookRefund(@Valid @RequestBody EncryptedRequest encryptedRequest) {
        logger.info("Book Refund Request for refundBookRequest {} ", encryptedRequest);
        return refundService.bookRefund(encryptedRequest);
    }

    /**
     * This API is used to Book refund for a ATRN and requested parameters for merchant panel.
     *
     * @param refundBookRequest RefundBookRequest
     * @return TransactionResponse<RefundResponse>
     */
    @PostMapping("/merchant/book")
    @Operation(summary = "Refund booking API for merchant panel", description = "This API is used to book the refund against ATRN number used by merchant")
    @PreAuthorize("hasAnyRole('ADMIN','SUPER_ADMIN','USER')")
    public TransactionResponse<RefundResponse> bookRefund(@Valid @RequestBody RefundBookRequest refundBookRequest) {
        logger.info("Book Refund Request for refundBookRequest {} ", refundBookRequest);
        return refundService.bookRefundWithResponse(refundBookRequest);
    }

    /**
     * This API is used to search the refund details for a particular search request
     *
     * @param encryptedRequest EncryptedRequest
     * @return TransactionResponse<String> encrypted RefundResponse
     */
    @PostMapping("/search")
    @Operation(summary = "Refund details search API for merchant", description = "This API is used to search the refund details for a particular encrypted search request used by merchant and provides encrypted response")
    @PreAuthorize("hasAnyRole('ACCESS')")
    public TransactionResponse<String> searchRefundBooking(@Valid @RequestBody EncryptedRequest encryptedRequest, @PageableDefault(size = TransactionConstant.DEFAULT_MAX_PAGE_SIZE) Pageable pageable) {
        logger.info("Search refund request received in controller for encryptedRequest: {}", encryptedRequest.getEncryptedRequest());
        return refundService.getRefundBookingSearchResponse(encryptedRequest.getEncryptedRequest(), pageable);
    }

    /**
     * This API is used to search the refund details for a particular search request
     *
     * @param refundSearchRequest RefundSearchRequest
     * @return TransactionResponse<RefundDetailResponse>
     */
    @PostMapping("merchant/search")
    @Operation(summary = "Refund details search API for merchant panel", description = "This API is used to search the refund details for a particular search request used by merchant")
    @PreAuthorize("hasAnyRole('ADMIN','SUPER_ADMIN','USER')")
    public TransactionResponse<RefundResponse> searchRefundBooking(@Valid @RequestBody RefundSearchRequest refundSearchRequest, @PageableDefault(size = TransactionConstant.DEFAULT_MAX_PAGE_SIZE) Pageable pageable) {
        logger.info("Search refund request received in controller for refundDetailRequest: {}", refundSearchRequest);
        return refundService.getRefundBookingSearchResponse(refundSearchRequest, pageable);
    }

    /**
     * End point to upload the bulk refund csv file.
     * @param mId String, Merchant ID
     * @param bulkRefundFile MultipartFile
     * @return TransactionResponse
     */
    @PostMapping("/merchant/bulk-upload/{mId}")
    @Operation(summary = "Upload bulk refund CSV file for given MID for merchant panel")
    @PreAuthorize("hasAnyRole('ADMIN','SUPER_ADMIN','USER')")
    public TransactionResponse<String> uploadBulkRefund(@PathVariable("mId") String mId, @RequestParam(value = "file", required = false) MultipartFile bulkRefundFile) {
        logger.info("Upload bulk refund invoked for mId: {}", mId);
        return refundService.uploadBulkRefund(mId, bulkRefundFile);
    }

    /**
     * This API is used to get bulk refund details for a particular mId
     *
     * @param mId String
     * @param pageable Pageable
     * @return TransactionResponse<BulkRefundBookingDto>
     */
    @GetMapping("/merchant/bulk-details/{mId}")
    @Operation(summary = "Bulk Refund details API for merchant", description = "This API is used get bulk refund details for a particular mId param used by merchant")
    @PreAuthorize("hasAnyRole('ADMIN','SUPER_ADMIN','USER')")
    public TransactionResponse<BulkRefundBookingDto> getBulkRefundBooking(@PathVariable("mId") String mId, @PageableDefault(size = TransactionConstant.DEFAULT_MAX_PAGE_SIZE, sort = {"createdDate"}, direction = Sort.Direction.DESC) Pageable pageable) {
        logger.info("Get bulk refund request received in controller for mId: {}", mId);
        return refundService.getBulkRefundBooking(mId, pageable);
    }

    /**
     * Download the list of bulk refund in CSV format based on search filters.
     * @param response HttpServletResponse
     * @param bulkId String
     * @param status String
     */
    @PostMapping("/merchant/bulk-download/{bulkId}/{status}")
    @Operation(summary = "Download bulk refund details for merchant panel")
    @PreAuthorize("hasAnyRole('ADMIN','SUPER_ADMIN','USER')")
    public void downloadBulkRefund(HttpServletResponse response, @PathVariable("bulkId") String bulkId, @PathVariable("status") String status) {
        logger.info("Received request to download bulk refund for bulkId: {} and status: {}", bulkId,status);
        refundService.downloadBulkRefund(response, bulkId,status);
    }

    /**
     * Download refund bookings in CSV format based on a particular search request
     * @param refundSearchRequest RefundSearchRequest
     **/
    @PostMapping("/merchant/search/download")
    @Operation(summary = "Download refund bookings API for merchant", description = "This API is used to download the refund bookings for a particular search request used by merchant")
    @PreAuthorize("hasAnyRole('ADMIN','SUPER_ADMIN','USER')")
    public void downloadRefundBookings(HttpServletResponse response, @RequestBody RefundSearchRequest refundSearchRequest) {
        logger.info("Received request to download refund bookings in controller for refundDetailRequest: {}", refundSearchRequest);
        refundService.downloadRefundBookings(response,refundSearchRequest);
    }
}
