package com.epay.transaction.externalservice.request.payment;

import com.epay.transaction.util.enums.OperatingMode;
import com.epay.transaction.util.enums.PayMode;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;

/**
 * Class Name:PaymentCardRequest
 * *
 * Description:
 * *
 * Author:V1014352(Ranjan Kumar)
 * <p>
 * Copyright (c) 2025 [State Bank of INdia]
 * All right reserved
 * *
 * Version:1.0
 */
@Data
@Builder
public class PaymentCardRequest {
    private PayMode paymode;
    private String atrn;
    private OperatingMode operatingMode;
    private String payProcId;
    private String payProcType;
    private String altNumber;
    private String expiryMonth;
    private String expiryYear;
    private String cvv;
    private String cardHolderName;


}
