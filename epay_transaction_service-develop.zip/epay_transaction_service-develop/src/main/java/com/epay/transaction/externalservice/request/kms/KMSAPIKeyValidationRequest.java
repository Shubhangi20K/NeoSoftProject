package com.epay.transaction.externalservice.request.kms;

import lombok.Builder;
import lombok.Data;

/**
 * Class Name: KMSAPIKeyValidationRequest
 * <p>
 * Description: This class defines the request structure for validating KMS API keys, including the API key and its keySecret.
 * <p>
 * Author: V1018217
 * Copyright (c) 2024 State Bank of India
 * All rights reserved.
 * <p>
 * Version: 1.0
 */
@Data
@Builder
public class KMSAPIKeyValidationRequest {

    private String apiKey;
    private String apiKeySecret;
}
