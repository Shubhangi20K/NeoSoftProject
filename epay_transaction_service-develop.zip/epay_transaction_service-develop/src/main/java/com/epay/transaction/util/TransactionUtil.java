package com.epay.transaction.util;

import com.epay.transaction.config.WhitespaceDeserializer;
import com.epay.transaction.exceptions.TransactionException;
import com.epay.transaction.util.enums.PayMode;
import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.exc.UnrecognizedPropertyException;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import jakarta.servlet.http.HttpServletResponse;
import lombok.experimental.UtilityClass;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.StringEscapeUtils;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;

import java.io.File;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.charset.StandardCharsets;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;

import static com.epay.transaction.util.TransactionErrorConstants.INVALID_ERROR_CODE;
import static com.epay.transaction.util.TransactionErrorConstants.INVALID_ERROR_MESSAGE;

/**
 * Class Name:TransactionUtil
 * *
 * Description: this class is used for transaction utility
 * *
 * Author:V1018400(Ranjan Kumar)
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
@UtilityClass
public final class TransactionUtil {
    private static final LoggerUtility logger = LoggerFactoryUtility.getLogger(TransactionUtil.class);
    private static final String ALL_CHAR = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    private static final ObjectMapper objectMapper = new ObjectMapper(new JsonFactory().enable(JsonParser.Feature.STRICT_DUPLICATE_DETECTION)).enable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES).registerModule(new SimpleModule().addDeserializer(String.class, new WhitespaceDeserializer()));
    private static Random random = getSecureRandom();

    /**
     * Create SecureRandom
     * @return Random
     */
    public static Random getSecureRandom() {
        if (Objects.isNull(random)) {
            try {
                random = SecureRandom.getInstanceStrong();// Use strongest available algorithm
            } catch (NoSuchAlgorithmException e) {
                // Fallback to default if strong instance isn't available
                logger.warn("Strong instance not available. Falling back to default SecureRandom, error: {}", e.getMessage());
                random = new SecureRandom();
            }
        }
        return random;
    }

    /**
     * Generates a unique CIN by combining the merchant ID, the current date, and a random number.
     *
     * @param mId The merchant ID associated with the CIN.
     * @return A unique CIN string consisting of the merchant ID, current date, and a random number.
     */
    public static String generateUniqueCin(String mId) {
        logger.info("CIN generation initiated");
        String currentDate = new SimpleDateFormat("ddMMyyyy").format(new Date());
        String cin = StringUtils.join(mId,currentDate, random.nextInt(10000,99999));
        logger.debug("Random generated CIN: {}", cin);
        return cin;
    }

    /**
     * Converts an object to its JSON representation as a string.
     * Utilizes Jackson's ObjectMapper to serialize the provided object to a JSON string.
     * If an error occurs during serialization, it logs the error and throws a custom exception.
     *
     * @param t The object to be converted to JSON.
     * @param <T> The type of the object to be converted.
     * @return The JSON string representation of the object.
     * @throws TransactionException If the object fails to be converted to JSON.
     */
    public static <T> String toJson(T t) {
        try {
            return objectMapper.writeValueAsString(t);
        } catch (JsonProcessingException e) {
            logger.error("Failed to convert JSON string: {}", t);
            throw new TransactionException(INVALID_ERROR_CODE, "Failed to convert JSON string.");
        }
    }

    /**
     * Decrypts an encrypted request and then converts it to the specified object type.
     *
     * @param encryptedRequest The encrypted request data in string format.
     * @param key The key used to decrypt the encrypted request.
     * @param clazz The class type to which the decrypted request should be converted.
     * @param <T> The type of the object that the request is to be converted to.
     * @return The deserialized object of type T.
     * @throws TransactionException If decryption or deserialization fails.
     */
    public static <T> T buildRequestByEncryptRequest(String encryptedRequest, String key, Class<T> clazz) {
        logger.info("Request for decryption");
        String decryptedRequest = EncryptionDecryptionUtil.decryptValue(key, encryptedRequest);
        try {
            return objectMapper.readValue(decryptedRequest, clazz);
        } catch (JsonProcessingException e) {
            logger.error("error while parsing request of {}, error {}", clazz.getName(), e.getMessage());
            throw new TransactionException(INVALID_ERROR_CODE, MessageFormat.format(INVALID_ERROR_MESSAGE, "Request object", getParsingError(e)));
        }
    }

    /**
     * Create Atrn Number by mId and payMode
     *
     * @param mId     String
     * @param payMode PayMode
     * @return ATTRN String
     */
    public static String createAtrnNumber(String mId, PayMode payMode) {
        StringBuilder attrnSB = new StringBuilder();
        attrnSB.append(payMode.toString(), 0, 2)
                .append(mId, 4, 7)
                .append(StringUtils.reverse(Long.toString(System.currentTimeMillis(), 36)))
                .append(RandomStringUtils.randomAlphanumeric(7,7));
        return attrnSB.toString().toUpperCase();
    }

    /**
     * Create Atrn Number by mId and payMode
     *
     * @param mId     String
     * @param payMode PayMode
     * @return ATTRN String
     */
    public static String createArrnNumber(String mId, String payMode) {
        StringBuilder arrnSb = new StringBuilder();
        arrnSb.append(payMode, 0, 2)
                .append(mId, 4, 7)
                .append(StringUtils.reverse(Long.toString(System.currentTimeMillis(), 36)))
                .append(Long.toString(System.nanoTime(), 360), 3, 9);
        while (arrnSb.length() < 20) {
            arrnSb.append(random.nextInt(10));
        }
        return arrnSb.toString().toUpperCase();
    }

    /**
     * Set the response headers for a downloadable file
     * @param response HttpServletResponse
     * @param contentType String
     * @param fileName String
     */
    public static void setHeader(HttpServletResponse response, String contentType, String fileName) {
        response.setContentType(contentType);
        response.setCharacterEncoding(String.valueOf(StandardCharsets.UTF_8));
        response.setHeader(HttpHeaders.CONTENT_DISPOSITION, StringEscapeUtils.escapeJava("attachment;filename=" + fileName));
        HttpHeaders headers = new HttpHeaders();
        ContentDisposition contentDisposition = ContentDisposition.attachment().filename(fileName).build();
        headers.setContentDisposition(contentDisposition);
        response.setHeader(HttpHeaders.CONTENT_DISPOSITION, headers.getFirst(HttpHeaders.CONTENT_DISPOSITION));
        response.setHeader(HttpHeaders.ACCESS_CONTROL_EXPOSE_HEADERS, HttpHeaders.CONTENT_DISPOSITION);
    }

    /**
     * [clientId][sourceId][current year][day of year][HHmmssSSS][6digit random number]
     * @param sourceId String
     * @param clientId String
     * @return random string
     */
    public static String generateReqRefNo(String sourceId, String clientId) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HHmmssSSS");
        LocalDateTime localDateTime = LocalDateTime.now();
        String dayOfYear = String.valueOf(localDateTime.getDayOfYear());
        String formatDayOfYear = String.format("%03d", Integer.parseInt(dayOfYear));
        String timeMills = localDateTime.format(formatter);
        String randomNum = RandomStringUtils.randomNumeric(6, 6);
        return String.format("%s%s%02d%s%s%s", clientId, sourceId , localDateTime.getYear() % 100,  // Year in two digits
                formatDayOfYear, timeMills, randomNum);
    }

    public static String generateRandomKey() {
        logger.info("Generating RandomKey");
        return getSecureRandom().ints(TransactionConstant.AES_KEY_SIZE / 8, 0, ALL_CHAR.length()).mapToObj(i -> String.valueOf(ALL_CHAR.charAt(i))).collect(Collectors.joining());
    }

    /**
     * Parse exception error message.
     * @param cause JsonProcessingException
     * @return error message
     */
    public static String getParsingError(Throwable cause) {
        if (cause instanceof UnrecognizedPropertyException unrecognizedPropertyException) {
            return "Unrecognized field: '" + unrecognizedPropertyException.getPropertyName() + "'.";
        } else if (cause instanceof JsonParseException jsonParseException && StringUtils.startsWithIgnoreCase(jsonParseException.getMessage(),"Duplicate field")) {
            return jsonParseException.getMessage().substring(0, jsonParseException.getMessage().indexOf("\n")) + ".";
        } else if (cause instanceof JsonMappingException jsonMappingException) {
            Optional<String> fieldName = jsonMappingException.getPath().stream().map(JsonMappingException.Reference::getFieldName).reduce((first, second) -> second);
            if (fieldName.isPresent()) {
                return "Invalid input for field: '" + fieldName.get() + "'.";
            }
        }
        return "Invalid input.";
    }

    /**
     * Get the domain from passed uri string
     * @param uri uri String
     * @return domain String
     */
    public static String getDomain(String uri){
        logger.info("Getting domain from uri : {}", uri);
        try {
            String domain = StringUtils.isNotEmpty(uri) ? new URI(uri.trim()).getHost() : StringUtils.EMPTY;
            logger.info("Got the domain : {} from uri : {}", domain, uri);
            return domain;
        } catch (URISyntaxException e) {
            logger.error("Error while getting the domain from uri : {}", uri);
            return StringUtils.EMPTY;
        }
    }

    /**
     * Convert relative path to absolute path
     * @param fileName String
     * @return String
     */
    public static String getAbsolutePath(String fileName) {
        return new File(fileName).getAbsolutePath();
    }

    public static <T> List<T> parseStringToObject(List<String> inputs, Function<String[], T> mapper, String delimiter) {
         return inputs.stream().map( line -> line.split(delimiter)).map(mapper).toList();
    }

    public static <T>T parseStringToObject(String input, Function<String[], T> mapper, String delimiter) {
        return mapper.apply(input.split(delimiter));
    }


}