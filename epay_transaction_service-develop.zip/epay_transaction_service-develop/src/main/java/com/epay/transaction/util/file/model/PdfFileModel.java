package com.epay.transaction.util.file.model;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Map;
/**
 * Class Name: PdfFileModel
 * *
 * Description: This class represents the model for a PDF file, holding the data required to generate
 * a PDF file. It extends the FileModel class and uses a Map to store the data for PDF generation.
 * Lombok annotations are used for generating boilerplate code like getters, setters, equals, and hashCode methods.
 * *
 * Author: Bhoopendra Rajput
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Builder
@Data
@EqualsAndHashCode(callSuper = true)
public class PdfFileModel extends FileModel {
    /**
     * The data for the PDF file, represented as a map of key-value pairs.
     */
    private Map<String, Object> fileData;

}