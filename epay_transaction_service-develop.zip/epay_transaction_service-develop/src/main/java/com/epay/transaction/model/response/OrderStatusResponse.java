package com.epay.transaction.model.response;

import com.epay.transaction.dto.OrderInfoDto;
import com.epay.transaction.dto.PaymentInfoDto;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

import java.util.List;

/**
 * Class Name: OrderStatusResponse
 * *
 * Description: This class contains the details of order and merchant order payment.
 * *
 * Author: Gireesh M
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class OrderStatusResponse {
    private OrderInfoDto orderInfo;
    private List<PaymentInfoDto> paymentInfo;
}
