package com.epay.transaction.service;

import com.epay.transaction.config.NotificationConfig;
import com.epay.transaction.dao.CustomerDao;
import com.epay.transaction.dao.NotificationDao;
import com.epay.transaction.dto.*;
import com.epay.transaction.exceptions.TransactionException;
import com.epay.transaction.externalservice.AdminServicesClient;
import com.epay.transaction.externalservice.response.admin.MerchantNotificationResponse;
import com.epay.transaction.model.response.TransactionResponse;
import com.epay.transaction.util.EmailUtil;
import com.epay.transaction.util.SmsUtil;
import com.epay.transaction.util.TransactionErrorConstants;
import com.epay.transaction.util.enums.NotificationEntityType;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.text.MessageFormat;
import java.util.Date;
import java.util.UUID;

import static com.epay.transaction.util.TransactionConstant.EMAIL_SMS_CONSENT;

/**
 * Class Name:TransactionNotificationService
 * *
 * Description: This class is used to send notification.
 * *
 * Author:Gireesh M
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
@Service
@RequiredArgsConstructor
public class TransactionNotificationService {

    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());

    private final AdminServicesClient adminServicesClient;
    private final NotificationConfig notificationConfig;

    private final CustomerDao customerDao;
    private final NotificationDao notificationDao;

    /**
     * This method publishes a generic data notification for email and SMS.
     *
     * @param dto                    Generic object containing the data.
     * @param notificationEntityType The type of entity for the notification.
     * @param requestType            The type of email or SMS to be sent.
     */
    public void publishTransactionNotification(Object dto, NotificationEntityType notificationEntityType, String requestType) {
        logger.info("Processing payment notification for request type: {}", requestType);

        TransactionResponse<MerchantNotificationResponse> merchantNotificationResponse;
        CustomerDto customerDto;

        if (dto instanceof OrderDto orderDto) {
            logger.info("Processing OrderDto object.");
            merchantNotificationResponse = adminServicesClient.getMerchantNotification(orderDto.getMId());
            customerDto = customerDao.getCustomerByCustomerId(orderDto.getMId(), orderDto.getCustomerId());
        } else if (dto instanceof MerchantPaymentOrderDto merchantPaymentOrderDto) {
            logger.info("Processing TransactionDto object.");
            merchantNotificationResponse = adminServicesClient.getMerchantNotification(merchantPaymentOrderDto.getMId());
            customerDto = customerDao.getCustomerBySbiOrderRefNumber(merchantPaymentOrderDto.getSbiOrderRefNumber());
        } else {
            logger.error("Invalid object type provided for notification.");
            throw new TransactionException(TransactionErrorConstants.INVALID_ERROR_CODE,
                    MessageFormat.format(TransactionErrorConstants.INVALID_ERROR_MESSAGE, "Object type", "Error while type casting"));
        }

        checkConsentAndPublish(merchantNotificationResponse.getData().getFirst(), customerDto, dto, notificationEntityType, requestType);
        logger.info("Notification processed successfully.");
    }

    /**
     * Builds and publishes email and SMS notifications.
     *
     * @param merchantNotificationResponse Merchant notification details.
     * @param customerDto          Customer details.
     * @param object                       Generic object for data mapping.
     * @param notificationEntityType       Notification entity type.
     * @param type                         Type of email/SMS notification.
     */
    private void checkConsentAndPublish(MerchantNotificationResponse merchantNotificationResponse, CustomerDto customerDto, Object object, NotificationEntityType notificationEntityType, String type) {
        logger.info("Building notification for type: {}", type);

        if (EMAIL_SMS_CONSENT.equalsIgnoreCase(merchantNotificationResponse.getEmailAlertCustomer())) {
            logger.info("Publishing EMAIL for customer: {}", customerDto.getCustomerId());
            TransactionEmailDto transactionEmailDto = create(merchantNotificationResponse, object, notificationEntityType, type, customerDto.getEmail(), notificationConfig);
            notificationDao.publishEmailNotification(transactionEmailDto, customerDto.getCustomerId(), transactionEmailDto.getEntityId());
        }
        if (EMAIL_SMS_CONSENT.equalsIgnoreCase(merchantNotificationResponse.getEmailAlertMerchant())) {
            logger.info("Publishing EMAIL for merchant: {}", merchantNotificationResponse.getMId());
            TransactionEmailDto transactionEmailDto = create(merchantNotificationResponse, object, notificationEntityType, type, merchantNotificationResponse.getCommunicationEmail(), notificationConfig);
            notificationDao.publishEmailNotification(transactionEmailDto, merchantNotificationResponse.getMId(), transactionEmailDto.getEntityId());
        }
        if (EMAIL_SMS_CONSENT.equalsIgnoreCase(merchantNotificationResponse.getSmsAlertCustomer())) {
            logger.info("Publishing SMS for customer: {}", customerDto.getCustomerId());
            TransactionSmsDto transactionSmsDto = create(merchantNotificationResponse, object, notificationEntityType, type, customerDto.getPhoneNumber());
            notificationDao.publishSmsNotification(transactionSmsDto, customerDto.getCustomerId());
        }
        if (EMAIL_SMS_CONSENT.equalsIgnoreCase(merchantNotificationResponse.getSmsAlertMerchant())) {
            logger.info("Publishing SMS for merchant: {}", merchantNotificationResponse.getMId());
            TransactionSmsDto transactionSmsDto = create(merchantNotificationResponse, object, notificationEntityType, type, merchantNotificationResponse.getMobileNo());
            notificationDao.publishSmsNotification(transactionSmsDto, merchantNotificationResponse.getMId());
        }
    }

    /**
     * Maps data for email notifications.
     *
     * @param merchantNotificationResponse Merchant notification details.
     * @param object                       Generic object.
     * @param notificationEntityType       Notification entity type.
     * @param requestType                  Email/SMS request type.
     * @param recipientEmail               Email recipient.
     * @param transactionConfig            Email/SMS configuration.
     * @return Payment email DTO.
     */
    private TransactionEmailDto create(MerchantNotificationResponse merchantNotificationResponse, Object object, NotificationEntityType notificationEntityType, String requestType, String recipientEmail, NotificationConfig transactionConfig) {
        logger.debug("Creating email notification for recipient");
        TransactionNotificationDto notificationDto = buildTransactionNotificationDto(merchantNotificationResponse, object);
        return buildTransactionEmailDto(notificationEntityType, requestType, recipientEmail, transactionConfig, notificationDto);
    }

    private static TransactionEmailDto buildTransactionEmailDto(NotificationEntityType notificationEntityType, String requestType, String recipientEmail, NotificationConfig transactionConfig, TransactionNotificationDto notificationDto) {
        return TransactionEmailDto.builder()
                .entityId(UUID.randomUUID())
                .entityType(notificationEntityType)
                .emailTemplate(EmailUtil.getEMailType(requestType).getTemplateName())
                .requestType(requestType)
                .from(transactionConfig.getFrom())
                .recipient(recipientEmail)
                .bcc(transactionConfig.getRecipient())
                .body(EmailUtil.generatedTransactionNotification(notificationDto))
                .subject(EmailUtil.getEMailType(requestType).getSubjectName())
                .build();
    }

    private static TransactionNotificationDto buildTransactionNotificationDto(MerchantNotificationResponse merchantNotificationResponse, Object object) {
       return TransactionNotificationDto.builder()
                .merchantBrandName(merchantNotificationResponse.getBrandName())
                .gtwPostingAmount(object instanceof OrderDto ? ((OrderDto) object).getOrderAmount() : ((MerchantPaymentOrderDto) object).getDebitAmount())
                .currencyCode(object instanceof OrderDto ? ((OrderDto) object).getCurrencyCode() : ((MerchantPaymentOrderDto) object).getCurrencyCode())
                .payMode(object instanceof OrderDto ? ((OrderDto) object).getPaymentMode() : ((MerchantPaymentOrderDto) object).getPayMode().name())
                .txnDate(new Date())
                .build();
    }

    /**
     * Maps data for SMS notifications.
     *
     * @param merchantNotificationResponse Merchant notification details.
     * @param object                       Generic object.
     * @param notificationEntityType       Notification entity type.
     * @param requestType                  SMS request type.
     * @param mobileNumber                 Mobile number of the recipient.
     * @return Payment SMS DTO.
     */
    public TransactionSmsDto create(MerchantNotificationResponse merchantNotificationResponse, Object object, NotificationEntityType notificationEntityType, String requestType, String mobileNumber) {
        logger.info("Creating SMS notification for mobile number");
        return TransactionSmsDto.builder()
                .entityId(UUID.randomUUID())
                .entityType(notificationEntityType)
                .message(getMessage(merchantNotificationResponse, requestType, object))
                .mobileNumber(mobileNumber)
                .requestType(requestType)
                .build();
    }

    /**
     * Formats the message for SMS notifications.
     *
     * @param merchantNotificationViewDto Merchant notification details.
     * @param requestType                 Type of SMS notification.
     * @param object                      Generic object.
     * @return Formatted SMS message.
     */
    private String getMessage(MerchantNotificationResponse merchantNotificationViewDto, String requestType, Object object) {
        logger.info("Generating SMS message for request type: {}", requestType);
        return MessageFormat.format(SmsUtil.getSMSTemplate(requestType),
                object instanceof OrderDto ? ((OrderDto) object).getCurrencyCode() : ((MerchantPaymentOrderDto) object).getCurrencyCode(),
                object instanceof OrderDto ? ((OrderDto) object).getOrderAmount() : ((MerchantPaymentOrderDto) object).getOrderAmount(),
                object instanceof OrderDto ? ((OrderDto) object).getPaymentMode() : ((MerchantPaymentOrderDto) object).getPayMode(),
                merchantNotificationViewDto.getBrandName(),
                new Date());
    }
}
