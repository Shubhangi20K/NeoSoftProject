package com.epay.transaction.dao;

import com.epay.transaction.dto.CustomerDto;
import com.epay.transaction.entity.Customer;
import com.epay.transaction.exceptions.TransactionException;
import com.epay.transaction.mapper.CustomerMapper;
import com.epay.transaction.repository.CustomerRepository;
import com.epay.transaction.util.EPayIdentityUtil;
import com.epay.transaction.util.enums.CustomerStatus;
import com.epay.transaction.util.enums.EntityType;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.text.MessageFormat;
import java.util.Optional;
import java.util.UUID;

import static com.epay.transaction.util.TransactionConstant.VALID_CUSTOMER;
import static com.epay.transaction.util.TransactionErrorConstants.*;

/**
 * Class Name:CustomerDao
 * <p>
 * Description:
 * <p>
 * Author:V1014352(Ranjan Kumar)
 * <p>
 * Copyright (c) 2024 [State Bank of INdia]
 * All right reserved
 * <p>
 * Version:1.0
 */
@Component
@RequiredArgsConstructor
public class CustomerDao {
    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private final CustomerRepository customerRepository;
    private final KmsDao kmsDao;
    private final CustomerMapper customerMapper;
    private final ErrorLogDao errorLogDao;

    /**
     * Method name : findCustomerByEmailAndPhoneNumber
     * Description : Fetch merchant customer using email and phoneNumber
     *
     * @param email       a String
     * @param phoneNumber a String
     * @return object of MerchantCustomerResponseDto
     */
    public Optional<CustomerDto> findCustomerByEmailAndPhoneNumber(String mId, String email, String phoneNumber) {
        logger.info("Request to get customer by email:{} and phone:{}", email, phoneNumber);
        Optional<Customer> customer = customerRepository.findBymIdAndEmailAndPhoneNumber(mId, email, phoneNumber);
        if (customer.isPresent()) {
            logger.info("Found customer details, customer: {}", customer);
            return Optional.of(customerMapper.entityToDto(customer.get()));
        }
        return Optional.empty();
    }

    /**
     * Method name : saveCustomer
     * Description : Stores merchant customer into database
     *
     * @param customerDto an object of CustomerDto
     * @return a CustomerDto
     */
    public CustomerDto saveCustomer(CustomerDto customerDto) {
        Customer customer = customerMapper.dtoToEntity(customerDto);
        logger.info("Converted to customer from merchantCustomerResponseDto");
        customer.setMId(EPayIdentityUtil.getUserPrincipal().getMId());
        customer = customerRepository.save(customer);
        logger.info("Merchant Customer saved successfully.");
        return customerMapper.entityToDto(customer);
    }

    /**
     * Method name : getCustomerByCustomerId
     * Description : Fetch merchant customer from database using customerId
     *
     * @param customerId is a String
     * @return an Object of MerchantCustomerResponseDto
     */
    public CustomerDto getCustomerByCustomerId(String mId, String customerId) {
        Customer customer = customerRepository.findBymIdAndCustomerId(mId, customerId).orElseThrow(() -> {
            errorLogDao.logCustomerError(
                    mId,
                    EntityType.CUSTOMER,null,null,null,null,
                    NOT_FOUND_ERROR_CODE,MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, VALID_CUSTOMER)
                    );
            return new TransactionException(NOT_FOUND_ERROR_CODE, MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, VALID_CUSTOMER));
        });
        logger.info("Found the merchant customer by customerId");
        return customerMapper.entityToDto(customer);
    }

    /**
     * Method name : updateCustomerStatus
     * Description : Updates Customer Status
     *
     * @param customerId is a String
     * @param status     is a Status
     */
    public CustomerDto updateCustomerStatus(String mId, String customerId, CustomerStatus status) {
        Customer customer = customerRepository.findBymIdAndCustomerId(mId, customerId).orElseThrow(() -> {
            errorLogDao.logCustomerError(
                   mId,
                    EntityType.ORDER,null,null,null,null,
                    NOT_FOUND_ERROR_CODE,
                    MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, VALID_CUSTOMER));
            return new TransactionException(NOT_FOUND_ERROR_CODE, MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, VALID_CUSTOMER));
        });
        if (CustomerStatus.DELETE == customer.getStatus()) {
            throw new TransactionException(INVALID_ERROR_CODE, MessageFormat.format(INVALID_ERROR_MESSAGE, "Customer Status", "Customer is Already DELETED."));
        }
        logger.debug("Found the merchant customer for customerId");
        customer.setStatus(status);
        customerRepository.save(customer);
        logger.info("Merchant customer updated successfully.");
        return customerMapper.entityToDto(customer);
    }

    /**
     * Method name : existsByCustomerId
     * Description : Validates merchant customer using customerId
     *
     * @param customerId is a String
     * @return an object of MerchantCustomerResponseDto
     */
    public Boolean existsByCustomerId(String customerId, String mId) {
        return customerRepository.existsBymIdAndCustomerId(mId, customerId);
    }

    /**
     * Method name : getMerchantMek
     * Description : Fetches MEK from Key management Service
     *
     * @return a String
     */
    public String getMerchantMek() {
        return kmsDao.getMerchantMekKey();
    }

    /**
     * This method is used to get the customer by sbi order ref number
     *
     * @param sibOrderRefNumber String
     * @return MerchantCustomerResponseDto
     */
    public CustomerDto getCustomerBySbiOrderRefNumber(String sibOrderRefNumber) {
        Customer customer = customerRepository.findCustomerBySbiReferenceNumber(sibOrderRefNumber).orElseThrow(() -> {
            errorLogDao.logTechnicalError(
                    EPayIdentityUtil.getUserPrincipal().getMId(),
                    EntityType.ORDER,null,null,sibOrderRefNumber,null,
                    NOT_FOUND_ERROR_CODE,
                    MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, CUSTOMER));
            return new TransactionException(NOT_FOUND_ERROR_CODE, MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, CUSTOMER));

        });
        return customerMapper.entityToDto(customer);
    }

}