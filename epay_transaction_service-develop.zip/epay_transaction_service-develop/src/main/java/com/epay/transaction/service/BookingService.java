package com.epay.transaction.service;

import com.epay.transaction.dao.BookingDao;
import com.epay.transaction.dto.CustomerDto;
import com.epay.transaction.dto.OrderDto;
import com.epay.transaction.dto.TransactionBookingDto;
import com.epay.transaction.externalservice.response.admin.MerchantInfoResponse;
import com.epay.transaction.externalservice.response.merchant.MerchantThemeResponse;
import com.epay.transaction.model.response.EncryptedResponse;
import com.epay.transaction.model.response.TransactionResponse;
import com.epay.transaction.util.EPayIdentityUtil;
import com.epay.transaction.util.EncryptionDecryptionUtil;
import com.epay.transaction.util.TransactionConstant;
import com.epay.transaction.util.TransactionUtil;
import com.epay.transaction.validator.BookingValidator;
import com.epay.transaction.validator.TokenValidator;
import com.fasterxml.jackson.databind.JsonNode;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.stereotype.Service;
import java.util.List;

/**
 * Class Name: BookingService
 * *
 * Description: Transaction Booking Service
 * *
 * Author: V1018212
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@RequiredArgsConstructor
@Service
public class BookingService {

    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());

    private final BookingValidator bookingValidator;
    private final BookingDao bookingDao;

    private String encryptionKey;


    private final TokenValidator tokenValidator;

    /**
     * Method name : transactionBooking
     * Description : create booking for given orderHash
     * @param orderHash is a String
     * @return object of TransactionResponse
     */
    public TransactionResponse<EncryptedResponse> transactionBooking(String orderHash) {
        //Step 1: Validate Order hash
        tokenValidator.validateOrderHash(orderHash);
        logger.info("orderHash validation completed");

        //Step 2 : Fetch Encryption Key form Token
        logger.info("Key request for booking start");
        encryptionKey = bookingDao.getEncryptionKey();
        logger.info("Key request for booking end");

        //Step 3 : Fetch orderDto Key for given OrderHash
        OrderDto orderDto = bookingDao.getMerchantOrder(orderHash);
        logger.debug("OrderDto :{} are present for given OrderHash :{} ", orderDto,orderHash);

        //Step 4 : Validated OrderDto for booking
        bookingValidator.bookingValidation(orderDto);

        //Step 5 : Initiate Order Booking
        bookingDao.initiateTransactionBooking(orderDto);
        logger.info("Initiated transaction booking ");

        //Step 6 : Build Encrypted Transaction Response
        EncryptedResponse encryptedResponse = EncryptedResponse.builder().encryptedResponse(buildEncryptedTransactionBookingResponse(orderDto)).build();
        logger.info("Completed transactionBooking for order hash: {} ", orderHash);
        return TransactionResponse.<EncryptedResponse>builder().data(List.of(encryptedResponse)).status(TransactionConstant.RESPONSE_SUCCESS).build();
    }

    /**
     * Method name : buildEncryptedTransactionBookingResponse
     * Description : Builds and encrypts transaction booking Response
     * @param orderDto an Object of OrderDto
     * @return an encrypted String
     */
    private String buildEncryptedTransactionBookingResponse(OrderDto orderDto) {
        logger.info("Inside buildEncryptedTransactionBookingResponse for order Hash : {}", orderDto.getOrderHash());

        //Step 1 : Load and validated MerchantInfo
        MerchantInfoResponse merchantInfo = bookingDao.getMerchantInfo(orderDto.getMId());
        CustomerDto merchantCustomer= null;
        if(ObjectUtils.isNotEmpty(orderDto.getCustomerId())) {
            //Step 2 : Load and validated Customer
            merchantCustomer = bookingDao.getMerchantCustomer(EPayIdentityUtil.getUserPrincipal().getMId(), orderDto.getCustomerId());
        }
        //Step 3 : Load MerchantPayModes
        JsonNode merchantPayModes = bookingDao.getMerchantPayModes(orderDto.getMId());
        logger.info("Merchant Pay Modes details are present");

        //Step 4 : Load MerchantTheme
        MerchantThemeResponse merchantThemeResponse = bookingDao.getMerchantTheme(orderDto.getMId());

        //Step 5 : Build transaction booking object
        TransactionBookingDto transactionBookingDto = TransactionBookingDto.builder()
                .transactionBookingTime(System.currentTimeMillis())
                .transactionStatus(orderDto.getStatus().getLabel())
                .orderInfo(orderDto)
                .paymodes(merchantPayModes)
                .merchantInfo(merchantInfo)
                .theme(merchantThemeResponse)
                .customerInfo(merchantCustomer)
                .build();

        //Step 6 : Encrypting the transaction booking object
        return EncryptionDecryptionUtil.encryptValue(encryptionKey, TransactionUtil.toJson(transactionBookingDto));
    }

}
