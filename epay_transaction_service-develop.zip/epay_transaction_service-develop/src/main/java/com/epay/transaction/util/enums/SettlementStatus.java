package com.epay.transaction.util.enums;

import com.epay.transaction.exceptions.TransactionException;
import com.epay.transaction.util.TransactionErrorConstants;

import java.text.MessageFormat;
import java.util.Arrays;
/**
 *  Class Name:SettlementStatus
 * <p>
 *  Description: The implementation is for consume payment order status the data from producer.
 * <p>
 * Copyright (c) [2025] [State Bank of India]
 * All rights reserved.
 * <p>
 * Author:@V0000001(Shilpa Kothre)
 * Version:1.0
 */
public enum SettlementStatus {
    TO_BE_SETTLED, SETTLED, FAILED, PENDING, IN_PROCESS, SUCCESS;

    public static SettlementStatus getSettlementStatus(String settlementStatus) {
        return Arrays.stream(values()).filter(p -> p.name().equalsIgnoreCase(settlementStatus)).findFirst().orElseThrow(() -> new TransactionException(TransactionErrorConstants.INVALID_ERROR_CODE_NO_REASON, MessageFormat.format(TransactionErrorConstants.INVALID_ERROR_MESSAGE_NO_REASON, "settlement status '" + settlementStatus + "'")));
    }
}

