package com.epay.transaction.util.enums;

import com.epay.transaction.exceptions.TransactionException;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.text.MessageFormat;
import java.util.Arrays;

import static com.epay.transaction.util.TransactionErrorConstants.INVALID_ERROR_CODE_NO_REASON;
import static com.epay.transaction.util.TransactionErrorConstants.INVALID_ERROR_MESSAGE_NO_REASON;

/**
 * Copyright (c) [2024] [State Bank of India]
 * All rights reserved.
 * <p>
 * Author: Bhoopendra Rajput
 * <p>
 * Version:1.0
 */
@Getter
@AllArgsConstructor
public enum NotificationEntityType {

    ORDER_GENERATION("ORDER_GENERATION"),
    PAYMENT_INITIATION("PAYMENT_INITIATION"),
    PAYMENT_COMPLETED("PAYMENT_COMPLETED");

    public final String name;

    public static NotificationEntityType getNotificationEntityType(String entityType) {
        return Arrays.stream(values()).filter(rt -> rt.name().equalsIgnoreCase(entityType)).findFirst().orElseThrow(() -> new TransactionException(INVALID_ERROR_CODE_NO_REASON, MessageFormat.format(INVALID_ERROR_MESSAGE_NO_REASON, "NotificationEntityType", entityType)));
    }
}
