package com.epay.transaction.dao;

import com.epay.transaction.config.NotificationConfig;
import com.epay.transaction.dto.TransactionEmailDto;
import com.epay.transaction.dto.TransactionSmsDto;
import com.epay.transaction.entity.NotificationManagement;
import com.epay.transaction.etl.producer.EmailNotificationProducer;
import com.epay.transaction.etl.producer.SmsNotificationProducer;
import com.epay.transaction.mapper.NotificationMapper;
import com.epay.transaction.repository.NotificationManagementRepository;
import com.epay.transaction.util.enums.NotificationType;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import com.sbi.epay.notification.exception.NotificationException;
import com.sbi.epay.notification.model.EmailDto;
import com.sbi.epay.notification.model.SmsDto;
import com.sbi.epay.notification.service.EmailService;
import com.sbi.epay.notification.service.SmsService;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.util.UUID;

import static com.epay.transaction.util.TransactionConstant.RESPONSE_FAILURE;
import static com.epay.transaction.util.TransactionConstant.RESPONSE_SUCCESS;

@Component
@RequiredArgsConstructor
public class NotificationDao {

    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());

    private final NotificationMapper notificationMapper;
    private final NotificationManagementRepository notificationManagementRepository;
    private final EmailNotificationProducer emailNotificationProducer;
    private final SmsNotificationProducer smsNotificationProducer;
    private final NotificationConfig notificationConfig;

    private final EmailService emailService;
    private final SmsService smsService;

    private int emailResponse = RESPONSE_SUCCESS;
    private int smsResponse = RESPONSE_SUCCESS;

    /**
     * publish an email message using the provided email object.
     *
     * @param transactionEmailDto The email details, including content and recipient address.
     */
    public void publishEmailNotification(TransactionEmailDto transactionEmailDto, String routingKeyName, UUID entityId) {
        getEmailDto(transactionEmailDto, entityId);
        emailNotificationProducer.publish(transactionEmailDto.getRequestType(), routingKeyName, transactionEmailDto);
    }

    /**
     * publish a sms message using the provided sms object.
     *
     * @param transactionSmsDto The SMS details, including the recipient's mobile number and message content.
     */
    public void publishSmsNotification(TransactionSmsDto transactionSmsDto, String routingKeyName) {
        smsNotificationProducer.publish(transactionSmsDto.getRequestType(), routingKeyName, transactionSmsDto);
    }

    /**
     * Sends an Email notification to the specified recipient and logs the notification details.
     *
     * @param transactionEmailDto The Email details, including content and recipient address.
     */
    public void sendEmailNotification(TransactionEmailDto transactionEmailDto) {
        log.info("Sending Email to the respective receiver");
        sendEmail(notificationMapper.mapTransactionEmailDtoToEmailDto(transactionEmailDto));
        NotificationManagement notificationManagement = buildNotificationManagement(transactionEmailDto);
        notificationManagement.setStatus(emailResponse);
        notificationManagementRepository.save(notificationManagement);
    }

    /**
     * Sends an SMS notification to the specified recipient and logs the notification details.
     *
     * @param transactionSmsDto The SMS details, including the recipient's mobile number and message content.
     */
    public void sendSmsNotification(TransactionSmsDto transactionSmsDto) {
        log.info("Sending SMS to the respective receiver");
        sendSMS(notificationMapper.mapTransactionSmsDtoToSmsDto(transactionSmsDto));
        NotificationManagement notificationManagement = buildNotificationManagement(transactionSmsDto);
        notificationManagement.setStatus(smsResponse);
        notificationManagementRepository.save(notificationManagement);
    }

    /**
     * Asynchronously sends an email notification using the provided email details.
     * Handles exceptions during email delivery and updates the response status.
     *
     * @param emailDto The email details, including content and recipient address.
     */
    private void sendEmail(EmailDto emailDto) {
        try {
            emailService.sendEmail(emailDto);
        } catch (NotificationException n) {
            log.error("Error in send Email, emailDto {}", emailDto, n);
            emailResponse = RESPONSE_FAILURE;
        } catch (Exception e) {
            log.error("Error in send Email, emailDto {}", emailDto, e.getMessage());
            emailResponse = RESPONSE_FAILURE;
        }
    }

    /**
     * Asynchronously sends an SMS notification using the provided SMS details.
     * Handles exceptions during SMS delivery and updates the response status.
     *
     * @param smsDto The SMS details, including the recipient's mobile number and message content.
     */
    private void sendSMS(SmsDto smsDto) {
        try {
            smsService.sendSMS(smsDto);
        } catch (NotificationException n) {
            log.error("Error in send SMS, smsDto {}", smsDto, n);
            smsResponse = RESPONSE_FAILURE;
        } catch (Exception e) {
            log.error("Error in send SMS, smsDto {}", smsDto, e.getMessage());
            smsResponse = RESPONSE_FAILURE;
        }
    }


    /**
     * Constructs an EmailDto object using the provided email details.
     * Supports custom recipient and CC configurations.
     *
     * @param transactionEmailDto The email details, including content and type.
     */
    private void getEmailDto(TransactionEmailDto transactionEmailDto, UUID userId) {
        transactionEmailDto.setFrom(notificationConfig.getFrom());
        transactionEmailDto.setEntityId(userId);
        if (StringUtils.isNotEmpty(notificationConfig.getRecipient())) {
            transactionEmailDto.setRecipient(notificationConfig.getRecipient());
            transactionEmailDto.setCc(transactionEmailDto.getRecipient());
        }
    }

    private NotificationManagement buildNotificationManagement(TransactionEmailDto transactionEmailDto) {
        return NotificationManagement.builder().requestType(transactionEmailDto.getRequestType()).entityId(transactionEmailDto.getEntityId()).entityName(transactionEmailDto.getEntityType()).notificationType(NotificationType.EMAIL).content(String.valueOf(transactionEmailDto.getBody())).status(RESPONSE_SUCCESS).build();
    }

    private NotificationManagement buildNotificationManagement(TransactionSmsDto smsDto) {
        return NotificationManagement.builder().requestType(smsDto.getRequestType()).entityId(smsDto.getEntityId()).entityName(smsDto.getEntityType()).notificationType(NotificationType.SMS).content(smsDto.getMessage()).status(RESPONSE_SUCCESS).build();
    }

}
