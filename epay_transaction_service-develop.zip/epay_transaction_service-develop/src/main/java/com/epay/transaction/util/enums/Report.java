package com.epay.transaction.util.enums;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

/**
 * Name: Report
 * Description: Represents different types of reports that can be generated (e.g., Order, Settlements, etc.).
 * *
 * Author: Bhoopendra Rajput
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Getter
@RequiredArgsConstructor
public enum Report {

    TRANSACTION("Transaction", "report");
    private final String name;
    private final String templateName;

}