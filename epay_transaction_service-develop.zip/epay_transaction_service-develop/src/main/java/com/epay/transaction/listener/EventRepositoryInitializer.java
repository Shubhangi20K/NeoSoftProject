package com.epay.transaction.listener;

import com.epay.transaction.entity.event.audit.EventErrorLog;
import com.epay.transaction.entity.event.audit.EventReceivedLog;
import com.epay.transaction.entity.event.audit.EventSendLog;
import com.epay.transaction.repository.event.audit.BufferedRepository;
import com.epay.transaction.repository.event.audit.EventErrorLogRepository;
import com.epay.transaction.repository.event.audit.EventReceivedLogRepository;
import com.epay.transaction.repository.event.audit.EventSendLogRepository;
import jakarta.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Configuration;

/**
 * Class Name:EventRepositoryInitializer
 * Description:
 * Copyright (c) [2025] [State Bank of India]
 * All rights reserved.
 * Author:@V0000001(Shilpa Kothre)
 * Version:1.0
 */
@Configuration
@RequiredArgsConstructor
public class EventRepositoryInitializer {

    private final BufferedRepository bufferedRepository;
    private final EventSendLogRepository eventSendLogRepository;
    private final EventReceivedLogRepository eventReceivedLogRepository;
    private final EventErrorLogRepository eventErrorLogRepository;

    @PostConstruct
    public void init() {
        bufferedRepository.registerRepository(EventSendLog.class, eventSendLogRepository);
        bufferedRepository.registerRepository(EventReceivedLog.class, eventReceivedLogRepository);
        bufferedRepository.registerRepository(EventErrorLog.class, eventErrorLogRepository);
    }
}

