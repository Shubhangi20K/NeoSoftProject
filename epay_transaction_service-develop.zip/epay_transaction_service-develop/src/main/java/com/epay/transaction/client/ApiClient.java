package com.epay.transaction.client;

import com.epay.transaction.exceptions.TransactionException;
import com.epay.transaction.exceptions.ValidationException;
import com.epay.transaction.model.response.TransactionResponse;
import com.sbi.epay.authentication.util.EPayAuthenticationConstant;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import io.netty.handler.ssl.SslContextBuilder;
import io.netty.handler.ssl.util.InsecureTrustManagerFactory;
import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.MDC;
import org.springframework.core.NestedRuntimeException;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.netty.http.client.HttpClient;

import java.net.URI;
import java.text.MessageFormat;

import static com.epay.transaction.util.TransactionConstant.EXTERNAL_SERVICE;
import static com.epay.transaction.util.TransactionConstant.RESPONSE_FAILURE;
import static com.epay.transaction.util.TransactionErrorConstants.EXTERNAL_SERVICE_ERROR_CODE;
import static com.epay.transaction.util.TransactionErrorConstants.EXTERNAL_SERVICE_ERROR_MESSAGE;

/**
 * Copyright (c) [2024] [State Bank of India]
 * All rights reserved.
 * <p>
 * Author:@V0000001(Shilpa Kothre)
 * Version:1.0
 */
public class ApiClient {

    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private final String baseUrl;
    private final WebClient webClient;

    public ApiClient(String baseUrl, String corsOrigin) {
        this.baseUrl = baseUrl;
        this.webClient = WebClient.builder().clientConnector(new ReactorClientHttpConnector(HttpClient.create().secure(t -> t.sslContext(SslContextBuilder.forClient().trustManager(InsecureTrustManagerFactory.INSTANCE))))).defaultHeader(HttpHeaders.ORIGIN, corsOrigin).build();
    }

    protected String getBaseUrl() {
        return baseUrl;
    }

    protected WebClient getWebClient() {
        return webClient;
    }

    protected HttpHeaders prepareHttpHeaders() {
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.add(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);
        headers.add(EPayAuthenticationConstant.X_CORRELATION_ID, MDC.get(EPayAuthenticationConstant.CORRELATION_ID));
        return headers;
    }

    protected <T, R> TransactionResponse<R> post(String urlPath, T requestBody, ParameterizedTypeReference<TransactionResponse<R>> typeReference) {
        URI uri = URI.create(getBaseUrl() + urlPath);
        logger.info("Calling uri: {}", uri);
        try {
            TransactionResponse<R> transactionResponse = getWebClient().post().uri(uri).headers(httpHeaders -> httpHeaders.addAll(prepareHttpHeaders())).contentType(MediaType.APPLICATION_JSON).bodyValue(requestBody).exchangeToMono(response -> response.bodyToMono(typeReference)).block();
            return validateAndReturnResponse(transactionResponse);
        } catch (NestedRuntimeException e) {
            logger.error("Got exception while calling url: {}", e.getMessage(), uri);
            throw new TransactionException(EXTERNAL_SERVICE_ERROR_CODE, MessageFormat.format(EXTERNAL_SERVICE_ERROR_MESSAGE, getServiceName()));
        }
    }

    protected <T> TransactionResponse<T> get(String urlPath, ParameterizedTypeReference<TransactionResponse<T>> typeReference) {
        URI uri = URI.create(getBaseUrl() + urlPath);
        logger.info("Calling uri: {}", uri);
        try {
            TransactionResponse<T> transactionResponse = getWebClient().get().uri(uri).headers(httpHeaders -> httpHeaders.addAll(prepareHttpHeaders())).exchangeToMono(response -> response.bodyToMono(typeReference)).block();
            return validateAndReturnResponse(transactionResponse);
        } catch (NestedRuntimeException e) {
            logger.error("Got exception while calling url: {}", e.getMessage(), uri);
            throw new TransactionException(EXTERNAL_SERVICE_ERROR_CODE, MessageFormat.format(EXTERNAL_SERVICE_ERROR_MESSAGE, getServiceName()));
        }
    }

    protected <T> TransactionResponse<T> get(String urlPath, String token, ParameterizedTypeReference<TransactionResponse<T>> typeReference) {
        URI uri = URI.create(getBaseUrl() + urlPath);
        logger.info("Calling uri: {}", uri);
        try {
            HttpHeaders headers = prepareHttpHeaders();
            headers.set(HttpHeaders.AUTHORIZATION, "Bearer " + token);
            TransactionResponse<T> transactionResponse = getWebClient().get().uri(uri).headers(httpHeaders -> httpHeaders.addAll(headers)).exchangeToMono(response -> response.bodyToMono(typeReference)).block();
            return validateAndReturnResponse(transactionResponse);
        } catch (NestedRuntimeException e) {
            logger.error("Got exception while calling url: {}", e.getMessage(), uri);
            throw new TransactionException(EXTERNAL_SERVICE_ERROR_CODE, MessageFormat.format(EXTERNAL_SERVICE_ERROR_MESSAGE, getServiceName()));
        }
    }

    private String getServiceName() {
        String[] urlToken = getBaseUrl().split("/");
        return urlToken.length > 1 ? urlToken[urlToken.length - 2].substring(0, 1).toUpperCase() + urlToken[urlToken.length - 2].substring(1) : EXTERNAL_SERVICE;
    }

    private <T> TransactionResponse<T> validateAndReturnResponse(TransactionResponse<T> response) {
        if (response != null && RESPONSE_FAILURE == response.getStatus() && !CollectionUtils.isEmpty(response.getErrors())) {
            throw new ValidationException(response.getErrors());
        }
        return response;
    }
}