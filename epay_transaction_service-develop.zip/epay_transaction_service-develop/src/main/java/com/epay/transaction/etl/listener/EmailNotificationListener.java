package com.epay.transaction.etl.listener;

import com.epay.transaction.dto.TransactionEmailDto;
import com.epay.transaction.exceptions.TransactionException;
import com.epay.transaction.service.NotificationService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sbi.epay.authentication.util.EPayAuthenticationConstant;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.MDC;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import java.util.UUID;

/**
 * Class Name: EmailNotificationListener
 * *
 * Description: The implementation is for consume the data from producer.
 * *
 * Author: Gireesh M
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Component
@RequiredArgsConstructor
public class EmailNotificationListener {

    private final LoggerUtility log = LoggerFactoryUtility.getLogger(this.getClass());
    private final ObjectMapper objectMapper;
    private final NotificationService notificationService;

    @KafkaListener(topics = "${spring.kafka.topic.transaction.notification.email}")
    public void onEmailMessage(ConsumerRecord<String, String> consumerRecord) {
        log.debug("Send email notification request received for key : {} and value : {}", consumerRecord.key(), consumerRecord.value());
        try {
            MDC.put(EPayAuthenticationConstant.CORRELATION_ID, String.valueOf(UUID.randomUUID()));
            MDC.put(EPayAuthenticationConstant.SCENARIO, "EmailListener");
            MDC.put(EPayAuthenticationConstant.OPERATION, "sendEmail");
            TransactionEmailDto transactionEmailDto = objectMapper.readValue(consumerRecord.value(), TransactionEmailDto.class);
            notificationService.sendEmail(transactionEmailDto);
        } catch (TransactionException e) {
            log.error("Error during onEmailMessage kafka listening message[key:{} and value: {}], error: {}", consumerRecord.key(), consumerRecord.value(), e.getErrorMessage());
        } catch (Exception e) {
            log.error("Error during onEmailMessage kafka listening message[key:{} and value: {}], error: {}", consumerRecord.key(), consumerRecord.value(), e.getMessage());
        }
    }
}
