package com.epay.transaction.config.audit;
/*
 * Copyright (c) [2024] [State Bank of India]
 * All rights reserved.
 * <p>
 * Author:@V1018482 (Ranu Jain)
 * Version:1.0
 */


import com.sbi.epay.authentication.model.EPayPrincipal;
import org.springframework.data.domain.AuditorAware;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.Optional;

import static com.epay.transaction.util.TransactionConstant.SBIEPAY;


public class SpringSecurityAuditorAware implements AuditorAware<String> {

    @Override
    public Optional<String> getCurrentAuditor() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null) {
            Object principal = authentication.getPrincipal();
            if (principal instanceof EPayPrincipal ePayPrincipal) {
                return Optional.of(ePayPrincipal.getUsername());
            }
            return Optional.of((String) principal);
        } else {
            return Optional.of(SBIEPAY);
        }
    }


}
