package com.epay.transaction.exceptionhandlers;

import com.epay.transaction.dto.ErrorDto;
import com.epay.transaction.dto.ErrorFieldDto;
import com.epay.transaction.exceptions.TransactionException;
import com.epay.transaction.exceptions.ValidationException;
import com.epay.transaction.model.response.TransactionResponse;
import com.epay.transaction.util.TransactionErrorConstants;
import com.epay.transaction.util.TransactionUtil;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.sbi.epay.encryptdecrypt.exception.EncryptionDecryptionException;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import org.apache.commons.collections4.CollectionUtils;
import org.hibernate.exception.SQLGrammarException;
import org.springframework.context.support.DefaultMessageSourceResolvable;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.lang.Nullable;
import org.springframework.security.authorization.AuthorizationDeniedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingRequestHeaderException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.net.ConnectException;
import java.text.MessageFormat;
import java.util.*;
import java.util.stream.Collectors;

import static com.epay.transaction.util.TransactionConstant.RESPONSE_FAILURE;
import static com.epay.transaction.util.TransactionErrorConstants.INVALID_ERROR_CODE;
import static com.epay.transaction.util.TransactionErrorConstants.INVALID_ERROR_MESSAGE;

/**
 * Class Name: TransactionExceptionHandler.
 * Description: Global exception handler.
 * Copyright (c) [2024] [State Bank of India]
 * All rights reserved.
 * Author:@V0000001(Shilpa Kothre)
 * Version:1.0
 */
@ControllerAdvice
public class TransactionExceptionHandler extends ResponseEntityExceptionHandler {
    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());

    /**
     * Handle TransactionException and EncryptionDecryptionException.
     *
     * @param ex RuntimeException
     * @return ResponseEntity
     */
    @ExceptionHandler({TransactionException.class, EncryptionDecryptionException.class})
    public ResponseEntity<Object> handleSecurityException(RuntimeException ex) {
        ErrorDto errorDto;
        switch (ex) {
            case TransactionException tx -> {
                if (CollectionUtils.isNotEmpty(tx.getErrorMessages())) {
                    return generateResponseWithErrors(tx.getErrorMessages());
                }
                errorDto = ErrorDto.builder().errorCode(tx.getErrorCode()).errorMessage(tx.getErrorMessage()).build();
            }
            case EncryptionDecryptionException enx ->
                    errorDto = ErrorDto.builder().errorCode(enx.getErrorCode()).errorMessage(enx.getErrorMessage()).build();
            default ->
                    errorDto = ErrorDto.builder().errorCode(TransactionErrorConstants.GENERIC_ERROR_CODE).errorMessage(ex.getLocalizedMessage()).build();
        }
        return generateResponseWithErrors(List.of(errorDto));
    }

    /**
     * Handle ValidationException
     *
     * @param ex ValidationException
     * @return ResponseEntity
     */
    @ExceptionHandler(ValidationException.class)
    public ResponseEntity<Object> handleValidationException(ValidationException ex) {
        if (CollectionUtils.isEmpty(ex.getErrorMessages())) {
            ErrorDto errorDto = ErrorDto.builder().errorCode(ex.getErrorCode()).errorMessage(ex.getErrorMessage()).build();
            return generateResponseWithErrors(List.of(errorDto));
        }
        return generateResponseWithErrors(ex.getErrorMessages());
    }

    /**
     * Handle handleDBException exception
     *
     * @param ex DataAccessException
     * @return ResponseEntity
     */
    @ExceptionHandler(value = {DataAccessException.class, DataIntegrityViolationException.class, SQLGrammarException.class})
    public ResponseEntity<Object> handleDBException(Exception ex) {
        ErrorDto errorDto = ErrorDto.builder().errorCode(TransactionErrorConstants.UNCATEGORIZED_ERROR_CODE).errorMessage(TransactionErrorConstants.UNCATEGORIZED_ERROR_MESSAGE).build();
        return ResponseEntity.internalServerError().body(TransactionResponse.builder().status(RESPONSE_FAILURE).errors(List.of(errorDto)).build());
    }

    /**
     * Error handle for @Valid method RequestBody and @Validate For Validating Path Variables and Request Parameters--Ex:: @Size(min = 5, max = 10)
     *
     * @param constraintException ConstraintViolationException
     * @return ResponseEntity
     */
    @ExceptionHandler(value = ConstraintViolationException.class)
    public ResponseEntity<Object> handleConstraintViolationException(ConstraintViolationException constraintException) {
        List<ErrorFieldDto> fieldErrorResponse = parseErrors(constraintException);
        logger.error("Inside constraint violation filed errors: {}", fieldErrorResponse);
        List<ErrorDto> errorData = createFieldErrors(fieldErrorResponse);
        return generateResponseWithErrors(errorData);

    }

    /**
     * Get error list from ConstraintViolationException
     *
     * @param ex ConstraintViolationException
     * @return List of ErrorFieldDto
     */

    private List<ErrorFieldDto> parseErrors(ConstraintViolationException ex) {
        List<ErrorFieldDto> errorFieldDtos = new ArrayList<>();
        if (Objects.nonNull(ex)) {
            Set<ConstraintViolation<?>> violations = ex.getConstraintViolations();
            violations.forEach(error -> errorFieldDtos.add(new ErrorFieldDto(error.getPropertyPath().toString().substring(error.getPropertyPath().toString().lastIndexOf(".") + 1), MessageFormat.format(TransactionErrorConstants.MANDATORY_ERROR_MESSAGE, ""))));
        }
        return errorFieldDtos;
    }

    private List<ErrorDto> createFieldErrors(List<ErrorFieldDto> fieldErrors) {
        Map<String, String> fieldErrorData = fieldErrors.stream().collect(Collectors.toMap(ErrorFieldDto::getFieldName, ErrorFieldDto::getErrorMessage));
        return fieldErrorData.entrySet().stream().map(entry -> ErrorDto.builder().errorCode(TransactionErrorConstants.MANDATORY_ERROR_CODE).errorMessage(entry.getKey() + entry.getValue()).build()).toList();
    }


    /**
     * Handle AuthorizationDeniedException
     *
     * @param ex AuthorizationDeniedException
     * @return ResponseEntity<AuthorizationDeniedException>
     */
    @ExceptionHandler(value = {AuthorizationDeniedException.class})
    public ResponseEntity<Object> handleAuthorizationDeniedException(AuthorizationDeniedException ex) {
        logger.error("Error in handleAuthorizationDeniedException ", ex);
        ErrorDto errorDto = ErrorDto.builder().errorCode(String.valueOf(HttpStatus.FORBIDDEN.value())).errorMessage(ex.getMessage() + ": Not having the necessary permissions to access this resources").build();
        return ResponseEntity.status(HttpStatus.FORBIDDEN).body(TransactionResponse.builder().status(RESPONSE_FAILURE).errors(List.of(errorDto)).build());
    }

    /**
     * Handle ConnectException
     *
     * @param ex ConnectException
     * @return ResponseEntity<ConnectException>
     */
    @ExceptionHandler(value = {ConnectException.class})
    public ResponseEntity<Object> handleExternalServerException(ConnectException ex) {
        logger.error("Error in  RuntimeException {} ", ex.getMessage());
        ErrorDto errorDto = ErrorDto.builder().errorCode(TransactionErrorConstants.EXTERNAL_SERVICE_ERROR_CODE).errorMessage(MessageFormat.format(TransactionErrorConstants.EXTERNAL_SERVICE_ERROR_MESSAGE, "External")).build();

        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(TransactionResponse.builder().status(0).errors(List.of(errorDto)).build());
    }

    /**
     * Handle JsonProcessingException and JsonMappingException.
     *
     * @param ex RuntimeException
     * @return ResponseEntity
     */
    @ExceptionHandler(value = {JsonProcessingException.class, JsonMappingException.class})
    public ResponseEntity<Object> handleJsonException(RuntimeException ex) {
        logger.error("Error in JsonProcessingException or JsonMappingException", ex);
        ErrorDto errorDto = ErrorDto.builder().errorCode(TransactionErrorConstants.JSON_ERROR_CODE).errorMessage(MessageFormat.format(TransactionErrorConstants.JSON_ERROR_MESSAGE, ex.getMessage())).build();

        return ResponseEntity.status(HttpStatus.ACCEPTED).body(TransactionResponse.builder().status(0).errors(List.of(errorDto)).build());
    }


    /**
     * Handle IllegalArgumentException and IllegalStateException
     *
     * @param ex RuntimeException
     * @return ResponseEntity
     */
    @ExceptionHandler(value = {IllegalArgumentException.class, IllegalStateException.class})
    protected ResponseEntity<Object> handleConflict(RuntimeException ex) {
        logger.error("Error in handleConflict ", ex);
        ErrorDto errorDto = ErrorDto.builder().errorCode(TransactionErrorConstants.UNCATEGORIZED_ERROR_CODE).errorMessage(TransactionErrorConstants.UNCATEGORIZED_ERROR_MESSAGE).build();
        return ResponseEntity.status(HttpStatus.CONFLICT).body(TransactionResponse.builder().status(RESPONSE_FAILURE).errors(List.of(errorDto)).build());
    }

    /**
     * Handle general exception.
     *
     * @param ex Exception
     * @return ResponseEntity
     */
    @ExceptionHandler(value = {Exception.class})
    public ResponseEntity<Object> handleGenericException(Exception ex) {
        logger.error("Error in handleGenericException {} ", ex.getMessage());
        ErrorDto errorDto = ErrorDto.builder().errorCode(TransactionErrorConstants.UNCATEGORIZED_ERROR_CODE).errorMessage(TransactionErrorConstants.UNCATEGORIZED_ERROR_MESSAGE).build();
        return ResponseEntity.internalServerError().body(TransactionResponse.builder().status(0).errors(List.of(errorDto)).build());
    }

    /**
     * Handle method argument not exception.
     *
     * @param ex      the exception to handle
     * @param headers the headers to use for the response
     * @param status  the status code to use for the response
     * @param request the current request
     * @return ResponseEntity
     */
    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex, HttpHeaders headers, HttpStatusCode status, WebRequest request) {
        logger.error("Error in handleMethodArgumentNotValid {} ", ex);

        // Extracting the validation errors
        List<String> errorMessages = ex.getBindingResult().getFieldErrors().stream().map(DefaultMessageSourceResolvable::getDefaultMessage).toList();

        // Creating the error DTOs
        List<ErrorDto> errorDtos = errorMessages.stream().map(msg -> ErrorDto.builder().errorCode(TransactionErrorConstants.MANDATORY_ERROR_CODE).errorMessage(msg).build()).collect(Collectors.toList());

        return ResponseEntity.status(HttpStatus.OK).body(TransactionResponse.builder().status(0).errors(errorDtos).build());
    }

    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    public ResponseEntity<Object> handleMethodArgumentTypeMismatch(MethodArgumentTypeMismatchException ex) {
        logger.error("Error in handleMethodArgumentTypeMismatch {} ", ex);
        ErrorDto errorDto = ErrorDto.builder().errorCode(TransactionErrorConstants.INVALID_ERROR_CODE).errorMessage(MessageFormat.format(TransactionErrorConstants.INVALID_ERROR_MESSAGE, ex.getPropertyName(), "Required Type is " + Objects.requireNonNull(ex.getRequiredType()).getSimpleName())).build();
        return ResponseEntity.ok().body(TransactionResponse.builder().status(RESPONSE_FAILURE).errors(List.of(errorDto)).build());
    }

    @ExceptionHandler(MissingRequestHeaderException.class)
    public ResponseEntity<Object> handleMissingRequestHeaderException(MissingRequestHeaderException ex) {
        logger.error("Error in handleMethodArgumentTypeMismatch {} ", ex);
        ErrorDto errorDto = ErrorDto.builder().errorCode(TransactionErrorConstants.MANDATORY_ERROR_CODE).errorMessage(MessageFormat.format(TransactionErrorConstants.MANDATORY_ERROR_MESSAGE, "Header - " + ex.getHeaderName())).build();
        return ResponseEntity.ok().body(TransactionResponse.builder().status(RESPONSE_FAILURE).errors(List.of(errorDto)).build());
    }

    /**
     * Handle Message Not Readable exception.
     *
     * @param ex      the exception to handle
     * @param headers the headers to use for the response
     * @param status  the status code to use for the response
     * @param request the current request
     * @return ResponseEntity
     */
    @Override
    protected ResponseEntity<Object> handleHttpMessageNotReadable(HttpMessageNotReadableException ex, HttpHeaders headers, HttpStatusCode status, WebRequest request) {
        String reason = TransactionUtil.getParsingError(ex.getCause());
        ErrorDto errorDto = ErrorDto.builder().errorCode(INVALID_ERROR_CODE).errorMessage(MessageFormat.format(INVALID_ERROR_MESSAGE, "Request object", reason)).build();
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(TransactionResponse.builder().status(RESPONSE_FAILURE).errors(List.of(errorDto)).build());
    }

    /**
     * Handle http related exception.
     *
     * @param ex         the exception to handle
     * @param body       the body to use for the response
     * @param headers    the headers to use for the response
     * @param statusCode the status code to use for the response
     * @param request    the current request
     * @return ResponseEntity
     */
    @Override
    protected ResponseEntity<Object> handleExceptionInternal(Exception ex, @Nullable Object body, HttpHeaders headers, HttpStatusCode statusCode, WebRequest request) {
        if (request instanceof ServletWebRequest servletWebRequest) {
            HttpServletResponse response = servletWebRequest.getResponse();
            if (response != null && response.isCommitted()) {
                return null;
            }
        }
        ErrorDto errorDto = ErrorDto.builder().errorCode(TransactionErrorConstants.UNCATEGORIZED_ERROR_CODE).errorMessage(TransactionErrorConstants.UNCATEGORIZED_ERROR_MESSAGE).build();
        return ResponseEntity.status(statusCode).body(TransactionResponse.builder().status(RESPONSE_FAILURE).errors(List.of(errorDto)).build());
    }

    /**
     * Preparing errors in API response object.
     *
     * @param errors List
     * @return ResponseEntity
     */
    private ResponseEntity<Object> generateResponseWithErrors(List<ErrorDto> errors) {
        return ResponseEntity.ok().body(TransactionResponse.builder().status(RESPONSE_FAILURE).errors(errors).build());
    }
}