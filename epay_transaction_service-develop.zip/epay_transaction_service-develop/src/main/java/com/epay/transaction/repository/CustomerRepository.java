
package com.epay.transaction.repository;

import com.epay.transaction.entity.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * Class Name:CustomerRepository
 * Description:
 * Author:V1014352(Ranjan Kumar)
 * Copyright (c) 2024 [State Bank of INdia]
 * All right reserved
 * Version:1.0
 */
@Repository
public interface CustomerRepository extends JpaRepository<Customer, String> {

    Optional<Customer> findBymIdAndEmailAndPhoneNumber(String mId, String email, String phone);

    Optional<Customer> findBymIdAndCustomerId(String mId, String customerId);

    boolean existsBymIdAndCustomerId(String mId, String customerId);

    @Query(value = "SELECT c FROM  Customer c JOIN Order o ON c.customerId = o.customerId WHERE o.sbiOrderRefNumber = :sbiOrderRefNumber")
    Optional<Customer> findCustomerBySbiReferenceNumber(@Param("sbiOrderRefNumber") String sbiOrderRefNumber);

}
