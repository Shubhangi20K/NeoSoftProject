/**
 * Copyright (c) [2024] [State Bank of India]
 * All rights reserved.
 * <p>
 * Author:@V0000001(Shilpa Kothre)
 * <p>
 * Version:1.0
 * /
 */

package com.epay.transaction.dto;

import com.epay.transaction.util.enums.TokenStatus;
import com.sbi.epay.authentication.util.enums.TokenType;
import lombok.*;

import java.util.UUID;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TokenDto {

    private UUID id;
    private String mId;
    private TokenType tokenType;
    private String generatedToken;
    private String orderHash;
    private Long tokenExpiryTime;
    private boolean isTokenValid;
    private String failedReason;
    private String remarks;
    private Long expiredAt;
    private TokenStatus status;
    private String aesKey;

}
