package com.epay.transaction.scheduler;

import com.epay.transaction.service.TokenService;
import com.sbi.epay.authentication.util.EPayAuthenticationConstant;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;
import org.slf4j.MDC;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.UUID;

@Component
@RequiredArgsConstructor
public class TokenExpiryScheduler {
    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private final TokenService tokenService;

    /**
     * scheduler run at every 5 seconds
     */
    @Scheduled(cron = "${scheduler.cron.expression.token.expiry}")
    @SchedulerLock(name = "TransactionService_checkExpiredToken", lockAtLeastFor = "${scheduler.lockAtLeastFor}", lockAtMostFor = "${scheduler.lockAtMostFor}")
    public void checkExpiredToken() {
        MDC.put(EPayAuthenticationConstant.CORRELATION_ID, String.valueOf(UUID.randomUUID()));
        MDC.put(EPayAuthenticationConstant.SCENARIO, "TokenExpiryScheduler");
        MDC.put(EPayAuthenticationConstant.OPERATION, "checkExpiredToken");
        logger.info("Token Expiry scheduler start ");
        tokenService.markTokenExpired();
        logger.info("Token Expiry scheduler completed ");
    }
}
