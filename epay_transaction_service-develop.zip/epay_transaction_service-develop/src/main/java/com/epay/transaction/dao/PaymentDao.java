package com.epay.transaction.dao;

import com.epay.transaction.dto.MerchantPaymentOrderDto;
import com.epay.transaction.exceptions.TransactionException;
import com.epay.transaction.externalservice.PaymentServicesClient;
import com.epay.transaction.externalservice.request.payment.*;
import com.epay.transaction.externalservice.response.payment.*;
import com.epay.transaction.model.request.PaymentInitiationRequest;
import com.epay.transaction.model.response.EncryptedResponse;
import com.epay.transaction.model.response.TransactionResponse;
import com.epay.transaction.util.TransactionConstant;
import com.epay.transaction.util.TransactionErrorConstants;
import com.epay.transaction.util.enums.OperatingMode;
import com.epay.transaction.util.enums.PayMode;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Service;

import java.text.MessageFormat;

import static com.epay.transaction.util.EncryptionDecryptionUtil.encryptValue;
import static com.epay.transaction.util.TransactionConstant.PAY_PROC_ID;
import static com.epay.transaction.util.TransactionErrorConstants.INVALID_FORMAT_REASON;
import static com.epay.transaction.util.TransactionUtil.toJson;
import static com.epay.transaction.util.enums.PayMode.getPayMode;

/**
 * Class Name:PaymentDao
 * *
 * Description:
 * *
 * Author:V1014352(Ranjan Kumar)
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
@Service
@RequiredArgsConstructor
public class PaymentDao {
    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());

    private final PaymentServicesClient paymentServicesClient;

    /**
     * Method name : paymentInitiation
     * Description : Initiates a payment based on the provided payment mode.
     * @param payModeString            The payment mode (e.g., CC, DC, UPI, NB).
     * @param merchantPaymentOrderDto  Merchant payment details.
     * @param paymentInitiationRequest Payment initiation request details.
     * @param key                      Encryption key.
     * @return Encrypted response containing transaction details.
     */
    public EncryptedResponse paymentInitiation(String payModeString, MerchantPaymentOrderDto merchantPaymentOrderDto, PaymentInitiationRequest paymentInitiationRequest, String key) {
        logger.info("PaymentInitiation Started for payMode:{}",payModeString);
        PayMode payMode = getPayMode(payModeString);
        return switch (payMode) {
            case CC, DC, PC -> processCardPayment(merchantPaymentOrderDto, paymentInitiationRequest, key);
            case NB ->
                    TransactionConstant.SBI_NAME.equalsIgnoreCase(paymentInitiationRequest.getChannelBank()) ? initiateNetBankingPayment(merchantPaymentOrderDto, key) : initiateOtherINBPayment(merchantPaymentOrderDto, key);
            case UPI -> handleUpiPayment(merchantPaymentOrderDto, paymentInitiationRequest, key);
        };
    }


    /**
     * Method name : validateUPIPaymentVpa
     * Description : processing UPI VPA payment
     * @param paymentUPIVpaRequest The UPI VPA validation request.
     * @param key                  Encryption key.
     * @return Encrypted response with validation result.
     */
    public EncryptedResponse validateUPIPaymentVpa(PaymentUPIVpaRequest paymentUPIVpaRequest, String key) {
        logger.info("Validating UPI VPA: {}", paymentUPIVpaRequest);
        TransactionResponse<PaymentUPIVpaResponse> response = paymentServicesClient.validateUPIPaymentVpa(paymentUPIVpaRequest);
        return handleResponse(response, key, TransactionConstant.PAYMENT_TYPE_VPA);
    }

    /**
     * Method name : upiPaymentStatusEnquiry
     * Description : Checks the status of a UPI payment.
     * @param paymentStatusRequest Payment status request.
     * @param key                  Encryption key.
     * @return Encrypted response with payment status.
     */
    public EncryptedResponse upiPaymentStatusEnquiry(PaymentStatusRequest paymentStatusRequest, String key) {
        logger.info("Checking UPI payment status for request: {}", paymentStatusRequest);
        TransactionResponse<String> response = paymentServicesClient.upiPaymentStatusEnquiry(paymentStatusRequest);
        return handleUpiStatusEnquiryResponse(response, key, TransactionConstant.PAYMENT_TYPE_VPA);
    }

    /**
     * Method name : processCardPayment
     * Description : Processes a card payment transaction.
     * @param merchantPaymentOrderDto : defines payment order details
     * @param paymentInitiationRequest : defines request for payment
     * @param key : use for encryption
     * @return : object of EncryptedResponse
     */
    private EncryptedResponse processCardPayment(MerchantPaymentOrderDto merchantPaymentOrderDto, PaymentInitiationRequest paymentInitiationRequest, String key) {
        logger.info("processing card payment start");
        PaymentCardRequest paymentCardRequest = buildPaymentCardRequest(merchantPaymentOrderDto, paymentInitiationRequest);
        if (paymentInitiationRequest.getPayProcId().equalsIgnoreCase(TransactionConstant.PAYMENT_TYPE_VISA) || paymentInitiationRequest.getPayProcId().equalsIgnoreCase(TransactionConstant.PAYMENT_TYPE_MASTER)) {
            paymentCardRequest.setPayProcId(paymentCardRequest.getPayProcId().toUpperCase());
            TransactionResponse<PaymentVisaCardResponse> response = paymentServicesClient.initiateVisaAndMasterCardAPI(paymentCardRequest);
            return handleResponse(response, key, paymentInitiationRequest.getPayProcId());
        }
        TransactionResponse<PaymentRupayCardResponse> response = paymentServicesClient.initiateRupPayCardAPI(paymentCardRequest);
        logger.info("processing card payment end");
        return handleResponse(response, key, paymentInitiationRequest.getPayProcId());
    }

    /**
     * Method name : initiateNetBankingPayment
     * Description : Initiates a net banking payment for SBI.
     * @param merchantPaymentOrderDto : defines payment order details
     * @param key : use for encryption
     * @return : object of EncryptedResponse
     */
    private EncryptedResponse initiateNetBankingPayment(MerchantPaymentOrderDto merchantPaymentOrderDto, String key) {
        logger.info("processing NetBanking Payment start");
        TransactionResponse<PaymentResponse> response = paymentServicesClient.initiateSBIINBPayments(PaymentINBRequest.builder().atrn(merchantPaymentOrderDto.getAtrnNumber()).build());
        logger.info("processing NetBanking Payment end");
        return handleResponse(response, key, PayMode.NB.name());
    }



    /**
     * Method name : initiateOtherINBPayment
     * Description : Initiates a net banking payment for other banks.
     * @param merchantPaymentOrderDto : defines payment order details
     * @param key : use for encryption
     * @return : object of EncryptedResponse
     */
    private EncryptedResponse initiateOtherINBPayment(MerchantPaymentOrderDto merchantPaymentOrderDto, String key) {
        logger.info("processing OtherINB Payment start");
        TransactionResponse<PaymentOtherInbResponse> response = paymentServicesClient.initiateOtherINBPayments(buildPaymentOtherInbRequest(merchantPaymentOrderDto));
        logger.info("processing OtherINB Payment end");
        return handleResponse(response, key, PayMode.NB.name());
    }


    /**
     * Method name : handleUpiPayment
     * Description : Handles UPI payments based on the payment processor ID.
     * @param merchantPaymentOrderDto : defines payment order details
     * @param key : use for encryption
     * @return : object of EncryptedResponse
     */
    private EncryptedResponse handleUpiPayment(MerchantPaymentOrderDto merchantPaymentOrderDto, PaymentInitiationRequest paymentInitiationRequest, String key) {
        logger.info("processing UPI Payment start");
        if (paymentInitiationRequest.getPayProcId().equalsIgnoreCase(TransactionConstant.PAY_PROC_ID_SELF)) {
            logger.info("processing UPI Self Payment start");
            TransactionResponse<PaymentUPIVpaCollectGatewayResponse> response = paymentServicesClient.initiateUPIVPAPayments(buildPaymentUPIRequest(merchantPaymentOrderDto, paymentInitiationRequest));
            return handleResponse(response, key, PayMode.UPI.name());
        } else if (paymentInitiationRequest.getPayProcId().equalsIgnoreCase(TransactionConstant.PAY_PROC_ID_BHIMQR)) {
            logger.info("processing UPI BhimQR Payment start");
            TransactionResponse<PaymentQRResponse> response = paymentServicesClient.initiateUPIQRPayments(buildPaymentUPIQRRequest(merchantPaymentOrderDto, paymentInitiationRequest));
            return handleResponse(response, key, PayMode.UPI.name());
        }
        logger.error("Invalid UPI payment processor ID: {}", paymentInitiationRequest.getPayProcId());
        throw new TransactionException(TransactionErrorConstants.INVALID_ERROR_CODE, MessageFormat.format(TransactionErrorConstants.INVALID_ERROR_MESSAGE, PAY_PROC_ID, MessageFormat.format(INVALID_FORMAT_REASON, PAY_PROC_ID)));
    }

    private PaymentOtherINBReqest buildPaymentOtherInbRequest(MerchantPaymentOrderDto merchantPaymentOrderDto) {
        return PaymentOtherINBReqest.builder().atrn(String.valueOf(merchantPaymentOrderDto.getAtrnNumber())).build();
    }

    private PaymentCardRequest buildPaymentCardRequest(MerchantPaymentOrderDto merchantPaymentOrderDto, PaymentInitiationRequest paymentInitiationRequest) {
        return PaymentCardRequest.builder().altNumber(paymentInitiationRequest.getAltNumber()).cardHolderName(paymentInitiationRequest.getCardHolderName()).cvv(paymentInitiationRequest.getCvv()).expiryMonth(paymentInitiationRequest.getExpiryMonth()).expiryYear(paymentInitiationRequest.getExpiryYear()).operatingMode(OperatingMode.getOperatingMode(paymentInitiationRequest.getOperatingMode())).payProcId(paymentInitiationRequest.getPayProcId()).payProcType(paymentInitiationRequest.getPayProcType()).atrn(String.valueOf(merchantPaymentOrderDto.getAtrnNumber())).paymode(merchantPaymentOrderDto.getPayMode()).build();
    }

    private PaymentUPIRequest buildPaymentUPIRequest(MerchantPaymentOrderDto merchantPaymentOrderDto, PaymentInitiationRequest paymentInitiationRequest) {
        return PaymentUPIRequest.builder().payGtwMapId(paymentInitiationRequest.getGtwMapsId()).virtualAddress(paymentInitiationRequest.getUpiAddress()).atrn(merchantPaymentOrderDto.getAtrnNumber()).build();
    }

    private PaymentUPIQRRequest buildPaymentUPIQRRequest(MerchantPaymentOrderDto merchantPaymentOrderDto, PaymentInitiationRequest paymentInitiationRequest) {
        return PaymentUPIQRRequest.builder().gtwMapId(paymentInitiationRequest.getGtwMapsId()).pspRefNo(String.valueOf(merchantPaymentOrderDto.getAtrnNumber())).build();
    }



    /**
     * Handles the response from the payment service and encrypts the result.
     */

    private <T> EncryptedResponse handleResponse(TransactionResponse<T> response, String key, String paymentType) {
        logger.info("Handling response for payment type: {}", paymentType);
        if (TransactionConstant.RESPONSE_SUCCESS == response.getStatus() && CollectionUtils.isNotEmpty(response.getData())) {
            String encryptionResponse = encryptValue(key, toJson(response.getData().getFirst()));
            return EncryptedResponse.builder().encryptedResponse(encryptionResponse).build();
        } else if (TransactionConstant.RESPONSE_FAILURE == response.getStatus() && CollectionUtils.isNotEmpty(response.getErrors())) {
            throw new TransactionException(response.getErrors());
        }
        throw new TransactionException(TransactionErrorConstants.PAYMENT_ERROR_CODE, MessageFormat.format(TransactionErrorConstants.PAYMENT_ERROR_MESSAGE, paymentType));
    }

    /**
     * Handles the response from the payment service  for upi status enquiry.
     */
    private  EncryptedResponse handleUpiStatusEnquiryResponse(TransactionResponse<String> response, String key, String paymentType) {
        logger.info("Handling response for payment type: {}", paymentType);
        if (TransactionConstant.RESPONSE_SUCCESS == response.getStatus() && CollectionUtils.isNotEmpty(response.getData())) {
            String encryptionResponse = response.getData().getFirst();
            return EncryptedResponse.builder().encryptedResponse(encryptionResponse).build();
        } else if (TransactionConstant.RESPONSE_FAILURE == response.getStatus() && CollectionUtils.isNotEmpty(response.getErrors())) {
            throw new TransactionException(response.getErrors());
        }
        throw new TransactionException(TransactionErrorConstants.PAYMENT_ERROR_CODE, MessageFormat.format(TransactionErrorConstants.PAYMENT_ERROR_MESSAGE, paymentType));
    }
}
