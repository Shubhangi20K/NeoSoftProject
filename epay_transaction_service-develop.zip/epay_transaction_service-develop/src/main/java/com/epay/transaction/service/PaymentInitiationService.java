package com.epay.transaction.service;


import com.epay.transaction.dao.PaymentInitiationDao;
import com.epay.transaction.dto.OrderDto;
import com.epay.transaction.model.request.EncryptedRequest;
import com.epay.transaction.model.request.PaymentInitiationRequest;
import com.epay.transaction.model.response.EncryptedResponse;
import com.epay.transaction.model.response.TransactionResponse;
import com.epay.transaction.validator.PaymentInitiationValidator;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

import static com.epay.transaction.util.TransactionUtil.buildRequestByEncryptRequest;

/**
 * Class Name: PaymentInitiationService
 * *
 * Description: PaymentInitiationService to initiate payment process.
 * *
 * Author: V1018400 (Ranjan Kumar)
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Service
@RequiredArgsConstructor
public class PaymentInitiationService {

    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private final PaymentInitiationDao paymentInitiationDao;
    private final PaymentInitiationValidator paymentInitiationValidator;

    /**
     * Method name : initiatePayment
     * Description :  processing payment
     * @param payMode : Defines payment mode
     * @param request: Object of encrypted paymentRequest
     * @return object of TransactionResponse
     */
    public TransactionResponse<EncryptedResponse> initiatePayment(String payMode, EncryptedRequest request) {
        logger.info("Payment Initiation Request for payMode {} ", payMode);
        //Step 1 : Fetch Merchant Order from requested Token
        OrderDto orderDto = paymentInitiationDao.getMerchantOrder();

        //Step 2 : Build PaymentInitiationRequest by Decrypting given request
        String aesKey = paymentInitiationDao.getEncryptedAESKey();
        PaymentInitiationRequest paymentInitiationRequest = buildRequestByEncryptRequest(request.getEncryptedRequest(), aesKey, PaymentInitiationRequest.class);

        //Step 3 : Validated PaymentInitiationRequest
        paymentInitiationValidator.validatePaymentRequest(paymentInitiationRequest, orderDto, payMode);

        //Step 4 : Process PaymentInitiationRequest for Payment
        EncryptedResponse encryptedResponse = paymentInitiationDao.processRequest(paymentInitiationRequest, payMode, orderDto, aesKey);
        return TransactionResponse.<EncryptedResponse>builder().data(List.of(encryptedResponse)).status(1).build();
    }
}
