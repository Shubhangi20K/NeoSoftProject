package com.epay.transaction.externalservice.response.admin;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;

/**
 * Class Name: MerchantFeeStructure
 * *
 * Description: MerchantFeeStructure entity class
 * *
 * Author: (Nirmal Gurjar)
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */

@Data
@Builder
public class MerchantPricingResponse {

    @JsonProperty("mId")
    private String mId;
    private String payModeCode;
    private String gtwMapsId;
    private String payProcType;
    private BigDecimal merchantFee;
    private String instructionType;
    private BigDecimal slabFrom;
    private BigDecimal slabTo;
    private Character merchantFeeApplicable;
    private Character merchantFeeType;
    private Character otherFeeApplicable;
    private Character otherFeeType;
    private BigDecimal otherFee;
    private Character gtwFeeApplicable;
    private Character gtwFeeType;
    private BigDecimal gtwFee;
    private Character aggServiceFeeApplicable;
    private Character aggServiceFeeType;
    private BigDecimal aggServiceFee;
    private Character feeProcessingFlag;
    private BigDecimal serviceTax;
    private String serviceTaxType;
    private String serviceTaxId;
    private Character txnApplicable;
    private String transactionType;
    private String bearableComponent;
    private Character bearableEntity;
    private BigDecimal bearableAmountCutoff;
    private BigDecimal bearableFlatRate;
    private String bearableLimit;
    private BigDecimal bearablePercentageRate;
    private Character bearableType;
    private BigDecimal totalFeeRate;
    private Character processFlag;

}
