package com.epay.transaction.util.enums;

import lombok.Getter;

@Getter
public enum Frequency {
    DAILY, WEEKLY, MONTHLY, YEARLY, QUARTERLY, HALF_YEARLY
}
