package com.epay.transaction.repository;

import com.epay.transaction.entity.MerchantOrderHybridFee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MerchantOrderHybridFeeRepository extends JpaRepository<MerchantOrderHybridFee, String> {


}
