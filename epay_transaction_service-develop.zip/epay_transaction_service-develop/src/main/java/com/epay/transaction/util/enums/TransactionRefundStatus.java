package com.epay.transaction.util.enums;

import com.epay.transaction.exceptions.TransactionException;

import java.text.MessageFormat;
import java.util.Arrays;

import static com.epay.transaction.util.TransactionErrorConstants.INVALID_ERROR_CODE_NO_REASON;
import static com.epay.transaction.util.TransactionErrorConstants.INVALID_ERROR_MESSAGE_NO_REASON;

/**
 * Copyright (c) [2024] [State Bank of India]
 * All rights reserved.
 * <p>
 * Author:NIRMAL GURJAR
 * <p>
 * Version:1.0
 */
public enum TransactionRefundStatus {

    FULL_REFUND_BOOKED, PARTIAL_REFUND_BOOKED;

    public static TransactionRefundStatus getTransactionRefundStatus(String transactionRefundStatus) {
        return Arrays.stream(values()).filter(p -> p.name().equalsIgnoreCase(transactionRefundStatus)).findFirst().orElseThrow(() -> new TransactionException(INVALID_ERROR_CODE_NO_REASON, MessageFormat.format(INVALID_ERROR_MESSAGE_NO_REASON, "Payment refund status", transactionRefundStatus)));
    }
}
