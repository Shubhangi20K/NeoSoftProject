package com.epay.transaction.scheduler;

import com.epay.transaction.service.PaymentPushVerificationService;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import net.javacrumbs.shedlock.spring.annotation.SchedulerLock;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * Class Name: PaymentPushVerificationScheduler
 * *
 * Description: This class serve the job to publish ATRNs for push verification.
 * <p>
 * Author: Gireesh M
 * <p>
 * Copyright 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Component
@RequiredArgsConstructor
public class PaymentPushVerificationScheduler {
    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());

    private final PaymentPushVerificationService paymentPushVerificationService;

    /**
     * This job runs at every 5 min.
     * This method is used to run a job to get list of merchant order payment data
     * to publish ATRNs and MId respectively.
     */
    @Scheduled(cron = "${scheduler.cron.expression.push.verification}")
    @SchedulerLock(name = "PaymentPushVerification", lockAtLeastFor = "${scheduler.lockAtLeastFor}", lockAtMostFor = "${scheduler.lockAtMostFor}")
    public void publishPaymentPushVerification() {
        logger.info("Payment push verification scheduler start");
        paymentPushVerificationService.publishPushVerificationResponse();
    }
}
