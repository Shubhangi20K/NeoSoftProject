package com.epay.transaction.model.response;

import lombok.Builder;
import lombok.Data;

import java.io.Serializable;

/**
 * Class Name: EncryptedResponse
 * *
 * Description:
 * *
 * Author: V1017903(bhushan wadekar)
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Data
@Builder
public class EncryptedResponse implements Serializable {
    private String encryptedResponse;
}
