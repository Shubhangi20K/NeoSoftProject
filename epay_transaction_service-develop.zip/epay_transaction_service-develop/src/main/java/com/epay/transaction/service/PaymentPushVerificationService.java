package com.epay.transaction.service;

import com.epay.transaction.config.TransactionConfig;
import com.epay.transaction.dao.KmsDao;
import com.epay.transaction.dao.MerchantOrderPaymentDao;
import com.epay.transaction.dto.MerchantPaymentOrderDto;
import com.epay.transaction.dto.OrderInfoDto;
import com.epay.transaction.dto.PaymentInfoDto;
import com.epay.transaction.etl.producer.PaymentPushVerificationProducer;
import com.epay.transaction.exceptions.TransactionException;
import com.epay.transaction.externalservice.AdminServicesClient;
import com.epay.transaction.externalservice.PaymentPushVerificationClient;
import com.epay.transaction.externalservice.response.admin.MerchantNotificationResponse;
import com.epay.transaction.model.response.OrderStatusResponse;
import com.epay.transaction.model.response.TransactionResponse;
import com.epay.transaction.util.EncryptionDecryptionUtil;
import com.epay.transaction.util.TransactionErrorConstants;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.text.MessageFormat;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import static com.epay.transaction.util.DateTimeUtils.getCurrentTimeInMills;
import static com.epay.transaction.util.DateTimeUtils.getSubtractedMilli;
import static com.epay.transaction.util.TransactionConstant.*;

/**
 * Class Name:PaymentPushVerificationService
 * *
 * Description: This class is used to verify the payment.
 * *
 * Author:Gireesh M
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
@Service
@RequiredArgsConstructor
public class PaymentPushVerificationService {

    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());

    private final AdminServicesClient adminServicesClient;
    private final PaymentPushVerificationClient paymentPushVerificationClient;
    private final PaymentPushVerificationProducer paymentPushVerificationProducer;
    private final TransactionConfig transactionConfig;

    private final MerchantOrderPaymentDao merchantOrderPaymentDao;
    private final KmsDao kmsDao;

    private final ObjectMapper objectMapper;

    private final AtomicInteger atomicInteger = new AtomicInteger(PUSH_RESPONSE_INITIAL_COUNT);

    /**
     * This method used to process the payment push verification.
     *
     * @param message request for process to verification.
     */
    public void processPaymentPushVerification(String message) throws JsonProcessingException, TransactionException {
        //Get merchant id and ATRN number from map.
        Map<String, Object> map = objectMapper.readValue(message, new TypeReference<>() {
        });
        String artnNumber = (String) map.getOrDefault("atrnNumber", "");
        String mId = (String) map.getOrDefault("mId", "");

        if (atomicInteger.incrementAndGet() > MAX_PUSH_RESPONSE_COUNT) {
            logger.info("Max push response retry reached and updating the push status as F");
            merchantOrderPaymentDao.updatePushVerificationStatus(artnNumber, PUSH_RESPONSE_STATUS_FAILURE);
            atomicInteger.set(PUSH_RESPONSE_INITIAL_COUNT);
            return;
        }

        logger.info("Starting payment push verification for ATRN: {}", artnNumber);
        merchantOrderPaymentDao.getTransactionAndOrderDetail(artnNumber)
                .map(this::buildPaymentVerificationResponse)
                .map(response -> {
                    if (response.getPaymentInfo().getFirst().getPushStatus().equalsIgnoreCase(PUSH_RESPONSE_STATUS_PENDING) && encryptAndSendToMerchant(mId, response)) {
                        merchantOrderPaymentDao.updatePushVerificationStatus(artnNumber, PUSH_RESPONSE_STATUS_SUCCESS);
                        atomicInteger.set(PUSH_RESPONSE_INITIAL_COUNT);
                    } else {
                        logger.warn("Push verification process failed due to encryption or merchant url response for ATRN: {}", artnNumber);
                        return new TransactionException(TransactionErrorConstants.EXTERNAL_SERVICE_ERROR_CODE, MessageFormat.format(TransactionErrorConstants.EXTERNAL_SERVICE_ERROR_MESSAGE, "KMS"));
                    }
                    return true;
                })
                .orElseThrow(() -> {
                    logger.warn("Push verification process failed due to missing transaction data for ATRN: {}", artnNumber);
                    return new TransactionException(TransactionErrorConstants.NOT_FOUND_ERROR_CODE, TransactionErrorConstants.NOT_FOUND_ERROR_MESSAGE);
                });
    }

    /**
     * This method is used to publish the ATRNs for payment push verification.
     */
    public void publishPushVerificationResponse() {
        long endAt = getCurrentTimeInMills();
        long startAt = getSubtractedMilli(endAt, transactionConfig.getSubtractionTime());
        logger.info("Fetch merchant order payment between updatedDate and createdDate: [{}] to [{}] and [{}]", endAt, startAt, startAt);
        List<MerchantPaymentOrderDto> merchantOrderPaymentDtoList = merchantOrderPaymentDao.findByUpdatedDateBetweenAndCreatedDate(startAt, endAt);
        logger.info("Publishing list of atrns.");
        if (CollectionUtils.isEmpty(merchantOrderPaymentDtoList)) {
            logger.info("Merchant order payment not found. for given time : [{}] to [{}]", endAt, startAt);
            return;
        }
        merchantOrderPaymentDtoList.forEach((merchantOrderPaymentsDto) -> {
            paymentPushVerificationProducer.publish("PaymentVerification", merchantOrderPaymentsDto.getAtrnNumber(), Map.of("atrn", merchantOrderPaymentsDto.getAtrnNumber(), "mId", merchantOrderPaymentsDto.getMId()));
        });
        logger.info("Atrn published successfully.");
    }

    /**
     * This method is used to encrypt the payment push verification data and send to merchant service.
     *
     * @param mId      merchant ID.
     * @param response push verification response data.
     * @return boolean
     */
    private boolean encryptAndSendToMerchant(String mId, OrderStatusResponse response) {
        boolean merchantResponseFlag;
        try {
            logger.info("Fetching encryption key for Merchant ID: {}", mId);
            String encryptedPushVerificationResponse = EncryptionDecryptionUtil.encryptValue(objectMapper.writeValueAsString(response), kmsDao.getMerchantMekKey());
            logger.info("Encrypted payment push data: {}", encryptedPushVerificationResponse);
            TransactionResponse<MerchantNotificationResponse> merchantNotification = adminServicesClient.getMerchantNotification(mId);
            if (merchantNotification.getData().getFirst().getMerchPushResponseFlag().equalsIgnoreCase(MERCHANT_PUSH_RESPONSE_FLAG)) {
                merchantResponseFlag = paymentPushVerificationClient.postPaymentPushVerification(encryptedPushVerificationResponse, merchantNotification.getData().getFirst().getMerchPushResponseUrl());
            } else {
                merchantResponseFlag = true;
            }
        } catch (Exception e) {
            logger.error("Error encrypting and sending payment push verification: {}", e.getMessage());
            throw new TransactionException(TransactionErrorConstants.NOT_FOUND_ERROR_CODE, TransactionErrorConstants.NOT_FOUND_ERROR_MESSAGE);
        }
        return merchantResponseFlag;

    }

    /**
     * * This Method Is Used Map Transaction and Order List To Payment Verification Response.
     *
     * @param transactionOrderList transactionOrderList list of transaction and order details
     * @return Payment Verification Response.
     */
    private OrderStatusResponse buildPaymentVerificationResponse(List<Object[]> transactionOrderList) {
        //validating and returning empty object
        if (CollectionUtils.isEmpty(transactionOrderList)) {
            throw new TransactionException(TransactionErrorConstants.NOT_FOUND_ERROR_CODE, MessageFormat.format(TransactionErrorConstants.NOT_FOUND_ERROR_MESSAGE, "Push verification data"));
        }
        logger.info(" Retrieve the record from object[]");
        // Retrieve the record from object[]
        Object[] record = transactionOrderList.getFirst();

        // Build and return the response
        return OrderStatusResponse.builder()
                .paymentInfo(List.of((PaymentInfoDto) record[0]))
                .orderInfo((OrderInfoDto) record[1])
                .build();
    }
}
