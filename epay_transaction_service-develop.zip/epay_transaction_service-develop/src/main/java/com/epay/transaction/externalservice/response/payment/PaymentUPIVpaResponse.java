package com.epay.transaction.externalservice.response.payment;

import lombok.*;

import java.io.Serializable;

/**
 * Class Name:PaymentUPIVpaResponse
 * *
 * Description:
 * *
 * Author:V1014352(Ranjan Kumar)
 * <p>
 * Copyright (c) 2025 [State Bank of India
 * All right reserved
 * *
 * Version:1.0
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class PaymentUPIVpaResponse implements Serializable {
    private PaymentUPIVpaValidateInfoResponse requestInfo;
    private PaymentUPIVpaValidatePayeeTypeResponse payeeType;
    private String status;
    private String statusDesc;
    private String timeIntervalApplicable;
}
