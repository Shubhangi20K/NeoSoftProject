package com.epay.transaction.model.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;


/**
 *
 *  Copyright (c) [2024] [State Bank of India]
 *  All rights reserved.
 *  Author:@V1018400(Ranjan Kumar)
 *  Version:1.0
 *
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class TransactionUpdateStatusResponse implements Serializable {

    private String statusMessage;
    private Integer orderRetryCount;
}
