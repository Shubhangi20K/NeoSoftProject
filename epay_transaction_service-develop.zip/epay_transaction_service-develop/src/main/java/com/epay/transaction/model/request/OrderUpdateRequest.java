package com.epay.transaction.model.request;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import static com.epay.transaction.util.TransactionErrorConstants.*;

/**
 * Class Name: OrderUpdateRequest
 * *
 * Description: Class to take order update request
 * *
 * Author:V1019620
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OrderUpdateRequest {

    @NotBlank(message = ORDER_REF_NUMBER_IS_REQUIRED)
    private String orderRefNumber;
    @NotBlank(message = SBI_ORDER_REF_NUMBER_IS_REQUIRED)
    private String sbiOrderRefNumber;
    @NotBlank(message = STATUS_IS_REQUIRED)
    private String status;
}
