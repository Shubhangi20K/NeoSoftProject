package com.epay.transaction.model.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;

@Data
@Builder
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RefundResponse {

    private String arrnNumber;
    private String sbiOrderRefNumber;
    private String atrnNumber;
    private BigDecimal refundAmount;
    private String refundType;
    private String refundStatus;
    private Long requestTime;
    private BigDecimal refundAvailableAmount;
    private String remark;

}
