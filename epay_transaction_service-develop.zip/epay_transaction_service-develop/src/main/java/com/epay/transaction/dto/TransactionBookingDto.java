package com.epay.transaction.dto;

import com.epay.transaction.externalservice.response.admin.MerchantInfoResponse;
import com.epay.transaction.externalservice.response.merchant.MerchantThemeResponse;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.*;

import java.io.Serializable;
/**
 * Class Name: TransactionBookingDto
 * *
 * Description:This class is used for returning the response from Order Transaction booking API.
 * Author: V1018212
 * Copyright (c) 2024 [State Bank of India]
 * ALl rights reserved
 * *
 * Version: 1.0
 */
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
@ToString
public class TransactionBookingDto implements Serializable {
    private OrderDto orderInfo;
    private CustomerDto customerInfo;
    private MerchantInfoResponse merchantInfo;
    private MerchantThemeResponse theme;
    private String transactionStatus;
    private Long transactionBookingTime;
    private JsonNode paymodes;
}
