package com.epay.transaction.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 *
 *  Copyright (c) [2025] [State Bank of India]
 *  All rights reserved.
 *  Author:@V0000001(Shilpa Kothre)
 *  Version:1.0
 *
 */

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class SettlementStatusDto {
    private String atrn;
    private String status;

}
