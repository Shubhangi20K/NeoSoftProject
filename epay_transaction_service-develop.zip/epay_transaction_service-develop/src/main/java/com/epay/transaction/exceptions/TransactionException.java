/**
 * Copyright (c) [2024] [State Bank of India]
 * All rights reserved.
 * <p>
 * Author:@V0000001(Shilpa Kothre)
 * Version:1.0
 */

package com.epay.transaction.exceptions;


import com.epay.transaction.dto.ErrorDto;
import lombok.Getter;

import java.util.List;


@Getter
public class TransactionException extends RuntimeException {
    private String errorCode;
    private String errorMessage;
    private List<ErrorDto> errorMessages;

    public TransactionException(String errorCode, String errorMessage) {
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
    }

    public TransactionException(List<ErrorDto> errorMessages) {
        this.errorMessages = errorMessages;
    }
}