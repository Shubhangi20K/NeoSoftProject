package com.epay.transaction.mapper;

import com.epay.transaction.dto.ErrorLogDto;
import com.epay.transaction.entity.ErrorLog;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;

@Mapper(builder = @Builder(disableBuilder = true), componentModel = "spring")
public interface ErrorMapper {

    ErrorLog dtoToEntity(ErrorLogDto errorLogDto);

}
