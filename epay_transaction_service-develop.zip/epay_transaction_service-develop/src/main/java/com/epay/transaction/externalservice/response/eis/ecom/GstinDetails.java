package com.epay.transaction.externalservice.response.eis.ecom;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class GstinDetails {
     public Detailsofgst detailsofgst;
}
