package com.epay.transaction.repository;

import com.epay.transaction.entity.MerchantOrderPayment;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

/**
 * Class Name:PaymentInitiation
 * *
 * Description: MerchantOrderPaymentRepository class for manage payment related data persistence and retrieval in a database.
 * *
 * Author:V1014352(Ranjan Kumar)
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */

@Repository
public interface MerchantOrderPaymentRepository extends JpaRepository<MerchantOrderPayment, String> {

    /**
     * Retrieves a MerchantOrderPayment entity based on the given Merchant ID and ATRN number.
     *
     * @param mId Merchant ID.
     * @param atrnNumber ATRN number used to search for the order payment.
     * @return Optional containing the MerchantOrderPayment if found, otherwise empty.
     */
    Optional<MerchantOrderPayment> findBymIdAndAtrnNumber(String mId, String atrnNumber);
    /**
     * Counts the number of transactions associated with a given SBI order reference number
     * and a list of transaction statuses.
     *
     * @param sbiOrderRefNumber SBI order reference number.
     * @param statusList List of transaction statuses to filter results.
     * @return Count of matching transactions.
     */
    @Query(value = "SELECT COUNT(t) FROM MerchantOrderPayment t WHERE t.sbiOrderRefNumber =:sbiOrderRefNumber AND t.transactionStatus IN (:statusList)")
    int countBySbiOrderRefNumberAndTransactionStatusIn(String sbiOrderRefNumber, List<String> statusList);
    /**
     * Retrieves the count and sum of debit amounts for successful transactions
     * using an alternative card hash.
     *
     * @param altHash Alternate hash of the card.
     * @return An Object array where index 0 contains the count and index 1 contains the sum of debit amounts.
     */
    @Query(value = "SELECT COUNT(*),NVL(SUM(MOP.DEBIT_AMT),0) FROM CARD_PAYMENT_SUMMARY CPS,MERCHANT_ORDER_PAYMENTS MOP WHERE CPS.ATRN_NUM = MOP.ATRN_NUM and MOP.TRANSACTION_STATUS = 'SUCCESS' and CARD_HASH =:altHash and TRUNC((TO_DATE('1970-01-01 00:00:00', 'yyyy-mm-dd hh24:mi:ss') + CPS.CREATED_DATE/1000/86400)) = TRUNC(SYSDATE)", nativeQuery = true)
    List<BigDecimal[]> cardPaymentSummary(String altHash);

    Page<MerchantOrderPayment> findAll(Specification<MerchantOrderPayment> specification, Pageable pageable);

    @Query("SELECT new com.epay.transaction.dto.PaymentInfoDto(t.atrnNumber AS atrn, t.orderAmount, t.debitAmount AS totalAmount, t.transactionStatus, t.payMode, t.channelBank AS bankName, t.bankReferenceNumber AS bankTxnNumber, t.payProcId AS processor, t.createdDate AS transactionTime, t.cin AS CIN, t.pushStatus), " +
            "new com.epay.transaction.dto.OrderInfoDto(o.sbiOrderRefNumber AS sbiOrderId, o.orderRefNumber AS merchantOrderNumber, o.status AS orderStatus, o.currencyCode AS currency)" +
            " FROM MerchantOrderPayment t " +
            "JOIN Order o ON t.orderRefNumber = o.orderRefNumber " +
            "WHERE t.atrnNumber = :atrnNumber " +
            "AND t.pushStatus = :pushStatus")
    Optional<List<Object[]>> findTransactionAndOrderDetail(@Param("atrnNumber") String atrnNumber,
                                                           @Param("pushStatus") String pushStatus);

    @Modifying
    @Transactional
    @Query("UPDATE MerchantOrderPayment t SET t.pushStatus = :pushStatus WHERE t.atrnNumber = :atrnNumber")
    void updatePushStatusByAtrnNumber(@Param("atrnNumber") String atrnNumber, @Param("pushStatus") String pushStatus);
    /**
     * Retrieves a MerchantOrderPayment entity based on the given sbiOrderRefNumber.
     * @param sbiOrderRefNumber:used to search for the order payment
     * @return list of MerchantOrderPayment
     */

    List<MerchantOrderPayment> findBySbiOrderRefNumber(String sbiOrderRefNumber);

    boolean existsBymIdAndSbiOrderRefNumberAndAtrnNumber(String mId , String sbiOrderRefNumber, String atrnNumber);

    Optional<MerchantOrderPayment> findByAtrnNumber(String atrnNumber);

    List<MerchantOrderPayment> findByUpdatedDateBetweenAndCreatedDateLessThanEqual(long startAt, long endAt, long starAt);

}