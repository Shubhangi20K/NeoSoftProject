package com.epay.transaction.controller;

import com.epay.transaction.model.request.EncryptedRequest;
import com.epay.transaction.model.request.MerchantOrderPaymentSearchRequest;
import com.epay.transaction.model.request.OrderUpdateRequest;
import com.epay.transaction.model.response.OrderResponse;
import com.epay.transaction.model.response.TransactionResponse;
import com.epay.transaction.service.OrderService;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

/**
 * Class Name: OrderController
 * *
 * Description: Order creation
 * *
 * Author: V1012904(Shital suryawanshi)
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */

@RestController
@RequiredArgsConstructor
@RequestMapping("/order")
@Validated
public class OrderController {
    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private final OrderService orderService;

    /**
     * Method name : createMerchantOrder
     * Description : Creates the merchant order
     * @param encryptedRequest : encrypted String
     * @return object of TransactionResponse
     */
    @PostMapping("/create")
    @Operation(summary = "API for Order Creation")
    @PreAuthorize("hasAnyRole('ACCESS')")
    public TransactionResponse<String> createMerchantOrder(@Valid @RequestBody EncryptedRequest encryptedRequest) {
        logger.info("Initiated order request: {}", encryptedRequest);
        return orderService.createMerchantOrder(encryptedRequest);
    }

    /**
     * Method name : getOrderByOrderRefNumber
     * Description : Fetches merchant order details
     * @param sbiOrderRefNumber : is a String
     * @return object of TransactionResponse
     */
    @GetMapping("/{sbiOrderRefNumber}")
    @Operation(summary = "API for Get Order Details")
    public TransactionResponse<String> getOrderBySbiOrderRefNumber(@PathVariable("sbiOrderRefNumber") String sbiOrderRefNumber) {
        logger.info("Initiated get order by sbi order reference number: {}", sbiOrderRefNumber);
        return orderService.getMerchantOrderBySbiOrderRefNumber(sbiOrderRefNumber);
    }

    /**
     * Method name : updateOrderStatus
     * Description : Update merchant order details
     * @param orderUpdateRequest : is an object of OrderUpdateRequest
     * @return : object of TransactionResponse
     */
    @PostMapping("/update-status")
    @Operation(summary = "API for Update Order Details")
    public TransactionResponse<String> updateOrderStatus(@Valid @RequestBody OrderUpdateRequest orderUpdateRequest) {
        logger.info("Initiated update order status: {}", orderUpdateRequest);
        return orderService.updateOrderStatus(orderUpdateRequest);
    }


    /**
     * method name:getMerchantOrderPayments
     * Description:This method handles the retrieval of merchant order and refund transactions for a given merchant ID (mId).
     * It accepts a request containing order and refund search criteria, along with pagination information, and returns
     * a response with the transaction details.
     *
     * @param mId        The merchant ID for which the order and refund transactions are to be fetched.
     * @param requestDto The request containing search criteria for the merchant's order and refund transactions.
     * @param pageable   The pagination details (page size and number) for fetching transactions.
     * @return TransactionResponse<OrderResponse> The response containing the merchant's order and refund transaction details.
     */
    @PostMapping("/search/{mId}")
    @Operation(summary = "Order and Refund transactions for merchant")
    @PreAuthorize("hasAnyRole('SUPER_ADMIN','ADMIN', 'USER')")
    public TransactionResponse<OrderResponse> getMerchantOrderPayments(@PathVariable String mId, @RequestBody MerchantOrderPaymentSearchRequest requestDto, @PageableDefault(size = 50) Pageable pageable) {
        // Log incoming request for order and refund transactions
        logger.info("Received request for order and refund transactions for MID: {} MerchantOrderPaymentSearchRequest {}", mId, requestDto);
        // Call the service to fetch transactions and return the response
        return orderService.getMerchantOrderPayments(mId, requestDto, pageable, false);
    }

    /**
     * Method name:downloadMerchantOrderRefundReport
     * Description:This method handles the download request for merchant order and refund transactions. It receives a request with the
     * merchant ID and a date range, then calls the service to generate and download the merchant order and refund report.
     *
     * @param response   The HttpServletResponse object used to send the generated report back to the client.
     * @param mId        The Merchant ID for which the order and refund report is requested.
     * @param requestDto The request object containing the search parameters, including date range for the report.
     */
    @PostMapping("/download/{mId}")
    @Operation(summary = "Order and Refund transactions for merchant")
    @PreAuthorize("hasAnyRole('SUPER_ADMIN','ADMIN', 'USER')")
    public void downloadMerchantOrderRefundReport(HttpServletResponse response, @PathVariable String mId, @RequestBody MerchantOrderPaymentSearchRequest requestDto) {
        // Log incoming request for order and refund transactions
        logger.info("Received request for download order and refund transactions for Merchant ID: {} from {} to {}", mId, requestDto.getFromDate(), requestDto.getToDate());
        // Call the service to fetch transactions and return the response
        orderService.downloadMerchantOrderPaymentReport(response, mId, requestDto);
    }


    /**
     * This method is used get the order status containing order and payment info.
     *
     * @param encryptedRequest encrypted inquiry request
     * @return order and payment info response with encrypted string
     */
    @PostMapping("/status")
    @Operation(summary = "This end point is used to get the order status")
    @PreAuthorize("hasAnyRole('ACCESS')")
    public TransactionResponse<String> getOrderStatus(@Valid @RequestBody EncryptedRequest encryptedRequest) {
        logger.info("Getting order status for request: {} ", encryptedRequest);
        return orderService.getOrderStatus(encryptedRequest.getEncryptedRequest());
    }
}