package com.epay.transaction.config;


import lombok.Getter;
import net.javacrumbs.shedlock.core.LockProvider;
import net.javacrumbs.shedlock.provider.jdbctemplate.JdbcTemplateLockProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.sql.DataSource;

@Configuration
@Getter
public class TransactionConfig {

    @Value("${token.access.regenerate.time}")
    private long tokenRegenerationTime;

    @Value("${file.refund.bulk.size.max:2097152}")
    private long bulkRefundFileMaxSize;

    @Value("${merchant.order.retry.count}")
    private Integer orderRetryCount;

    @Value("${key.aek}")
    private String aek;

    @Value("${external.web.transaction.app.base.path}")
    private String transactionWebAppBasePath;

    @Value("${formPostingUrl}")
    private String formPostUrl;

    @Value("${transaction.report.page.size:10000}")
    private int reportPageSize;

    @Value("${external.api.eis.services.uat.path}")
    private String eisPublicKeyPath;

    @Value("${external.api.eis.services.privatkey.path}")
    private String eisPrivateKey;

    @Value("${paymentCallbackUrl}")
    private String paymentCallbackUrl;

    @Value("${queue.batch.size.event:1000}")
    private int eventQueueBatchSize;

    @Value("${subtraction.time}")
    private long subtractionTime;
    @Bean
    public LockProvider lockProvider(DataSource dataSource) {

        return new JdbcTemplateLockProvider((JdbcTemplateLockProvider.Configuration.builder().withJdbcTemplate(new JdbcTemplate(dataSource)).usingDbTime().build()));
    }
}
