package com.epay.transaction.validator;


import com.epay.transaction.dao.AdminDao;
import com.epay.transaction.dao.MerchantOrderPaymentDao;
import com.epay.transaction.dao.PaymentInitiationDao;
import com.epay.transaction.dto.ErrorDto;
import com.epay.transaction.dto.OrderDto;
import com.epay.transaction.entity.MerchantOrderSummary;
import com.epay.transaction.exceptions.TransactionException;
import com.epay.transaction.exceptions.ValidationException;
import com.epay.transaction.externalservice.response.admin.GatewayConfigDetailsResponse;
import com.epay.transaction.externalservice.response.admin.MerchantRfcResponse;
import com.epay.transaction.externalservice.response.admin.MerchantVvlResponse;
import com.epay.transaction.model.request.PaymentInitiationRequest;
import com.epay.transaction.util.TransactionConstant;
import com.epay.transaction.util.TransactionErrorConstants;
import com.epay.transaction.util.enums.Frequency;
import com.epay.transaction.util.enums.OperatingMode;
import com.epay.transaction.util.enums.PayMode;
import com.epay.transaction.util.enums.PayProcType;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.text.MessageFormat;
import java.util.*;

import static com.epay.transaction.util.EncryptionDecryptionUtil.hashValue;
import static com.epay.transaction.util.TransactionConstant.*;
import static com.epay.transaction.util.TransactionErrorConstants.*;

/**
 * Class Name:PaymentInitiationValidator
 * *
 * Description:
 * *
 * Author:V1018400(Ranjan Kumar)
 * Copyright (c) 2024 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
@Component
@RequiredArgsConstructor
public class PaymentInitiationValidator extends BaseValidator {

    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private final PaymentInitiationDao paymentInitiationDao;
    private final AdminDao adminDao;
    private final MerchantOrderPaymentDao merchantOrderPaymentDao;


    private static ErrorDto getErrorDto(Frequency frequency) {
        return switch (frequency) {
            case DAILY ->
                    ErrorDto.builder().errorMessage(MessageFormat.format(TransactionErrorConstants.PAYMENT_TIMELY_LIMIT_ERROR_MESSAGE, "Daily")).errorCode(TransactionErrorConstants.PAYMENT_TIMELY_TRANSACTION_LIMIT_CODE).build();
            case WEEKLY ->
                    ErrorDto.builder().errorMessage(MessageFormat.format(TransactionErrorConstants.PAYMENT_TIMELY_LIMIT_ERROR_MESSAGE, "Weekly")).errorCode(TransactionErrorConstants.PAYMENT_TIMELY_TRANSACTION_LIMIT_CODE).build();
            case MONTHLY ->
                    ErrorDto.builder().errorMessage(MessageFormat.format(TransactionErrorConstants.PAYMENT_TIMELY_LIMIT_ERROR_MESSAGE, "Monthly")).errorCode(TransactionErrorConstants.PAYMENT_TIMELY_TRANSACTION_LIMIT_CODE).build();
            case QUARTERLY ->
                    ErrorDto.builder().errorMessage(MessageFormat.format(TransactionErrorConstants.PAYMENT_TIMELY_LIMIT_ERROR_MESSAGE, "Quarterly")).errorCode(TransactionErrorConstants.PAYMENT_TIMELY_TRANSACTION_LIMIT_CODE).build();
            case HALF_YEARLY ->
                    ErrorDto.builder().errorMessage(MessageFormat.format(TransactionErrorConstants.PAYMENT_TIMELY_LIMIT_ERROR_MESSAGE, "Halfyearly")).errorCode(TransactionErrorConstants.PAYMENT_TIMELY_TRANSACTION_LIMIT_CODE).build();
            case YEARLY ->
                    ErrorDto.builder().errorMessage(MessageFormat.format(TransactionErrorConstants.PAYMENT_TIMELY_LIMIT_ERROR_MESSAGE, "Annual")).errorCode(TransactionErrorConstants.PAYMENT_TIMELY_TRANSACTION_LIMIT_CODE).build();
        };
    }

    private static void validateAggregatedTransactionLimits(BigDecimal merchPostedAmount, MerchantVvlResponse paymodeVVL, MerchantOrderSummary merchantOrderSummary) {
        List<ErrorDto> errors = new ArrayList<>();
        Map<Frequency, BigDecimal> existingLimits = Map.of(Frequency.DAILY, merchantOrderSummary.getDailyTxnAmount(), Frequency.WEEKLY, merchantOrderSummary.getWeeklyTxnAmount(), Frequency.MONTHLY, merchantOrderSummary.getMonthlyTxnAmount(), Frequency.QUARTERLY, merchantOrderSummary.getQuarterlyTxnAmount(), Frequency.HALF_YEARLY, merchantOrderSummary.getHalfYearlyTxnAmount(), Frequency.YEARLY, merchantOrderSummary.getAnnuallyTxnAmount());
        Map<Frequency, BigDecimal> limitTypes = Map.of(Frequency.DAILY, paymodeVVL.getDailyTxnAmountLimit(), Frequency.WEEKLY, paymodeVVL.getWeeklyTxnAmountLimit(), Frequency.MONTHLY, paymodeVVL.getMonthlyTxnAmountLimit(), Frequency.QUARTERLY, paymodeVVL.getQuarterlyTxnAmountLimit(), Frequency.HALF_YEARLY, paymodeVVL.getHalfYearlyTxnAmountLimit(), Frequency.YEARLY, paymodeVVL.getAnnualTxnAmountLimit());
        limitTypes.forEach((period, limit) -> {
            BigDecimal totalAmount = merchPostedAmount.add(existingLimits.get(period));
            if (limit.compareTo(totalAmount) < 0) {
                errors.add(getErrorDto(period));
            }
        });
        if (CollectionUtils.isNotEmpty(errors)) {
            throw new ValidationException(errors);
        }
    }

    private static MerchantVvlResponse getMerchantVolumeVelocityResponse(PaymentInitiationRequest paymentInitiationRequest, MerchantVvlResponse merchantVvlResponse) {
        if (paymentInitiationRequest.getMerchPostedAmount().compareTo(merchantVvlResponse.getMinTxnLimit()) < 0 || paymentInitiationRequest.getMerchPostedAmount().compareTo(merchantVvlResponse.getMaxTxnLimit()) > 0) {
            throw new ValidationException(TransactionErrorConstants.PAYMENT_TRANSACTION_LIMIT_CODE, TransactionErrorConstants.PAYMENT_LIMIT_ERROR_MESSAGE);
        }
        return merchantVvlResponse;
    }

    public void validatePaymentRequest(PaymentInitiationRequest paymentInitiationRequest, OrderDto orderDto, String payMode) {
        errorDtoList = new ArrayList<>();
        logger.info("Payment Initiation Validation Started");
        validateMerchantOrder(orderDto);
        validateMandatoryFields(paymentInitiationRequest);
        validateLeadingTrailingAndSingleSpace(paymentInitiationRequest);
        validatedFieldLength(paymentInitiationRequest);
        validateFieldValue(paymentInitiationRequest);
        validateGatewayMap(orderDto.getMId(), paymentInitiationRequest.getGtwMapsId(),payMode);
        validateMandatoryFieldForPaymentRequest(payMode, paymentInitiationRequest);
        validateVvlAndRfc(payMode, orderDto, paymentInitiationRequest);
        logger.info("Payment Initiation Validation Completed");
    }

    /**
     * Method name : validateMerchantOrder
     * Description : Validates merchant order of orderDto
     * @param orderDto : Object of OrderDto
     */
    private void validateMerchantOrder(OrderDto orderDto) {
        logger.debug("Validating OrderDto {}", orderDto);
        if (orderDto.getOrderRetryCount() <= 0) {
            addError(ATTEMPT_EXCEEDED_ERROR_CODE, MessageFormat.format(ATTEMPT_EXCEEDED_ERROR_MESSAGE, "Payment"));
        }
        throwIfErrors();
    }


    private void validateChannelBank(String gatewayMapsId, String channelBank) {
        errorDtoList = new ArrayList<>();
        boolean isValidChannelBank = adminDao.isValidChannelBank(gatewayMapsId, channelBank);
        if (!isValidChannelBank) {
            addError(NOT_FOUND_ERROR_CODE, MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, "ChannelBank and GtwMapsId Mapping"));
        }
        throwIfErrors();
    }

    private void validateGatewayMap(String mId, String gtwMapId,String payMode) {
        logger.debug("Validating GatewayMap for mId {}", mId);
        GatewayConfigDetailsResponse gatewayConfigDetailsResponse = adminDao.getGatewayConfigDetails(mId, gtwMapId,payMode);
        if (StringUtils.isEmpty(gatewayConfigDetailsResponse.getGtwIssueDmeCode())) {
            addError(INVALID_ERROR_CODE, TransactionErrorConstants.INVALID_ERROR_MESSAGE, "gtwMapId", "channelBank is not found against gtwMapsId");
        }
        throwIfErrors();
    }

    /**
     * Method name : validateMandatoryFields
     * Description : Validates mandatory fields of payment initiation request
     * @param paymentInitiationRequest : Object of PaymentInitiationRequest
     */
    private void validateMandatoryFields(PaymentInitiationRequest paymentInitiationRequest) {
        logger.debug("Validating paymentInitiationRequest {}", paymentInitiationRequest);
        checkMandatoryField(paymentInitiationRequest.getOperatingMode(), "OperatingMode");
        checkMandatoryField(paymentInitiationRequest.getPayProcType(), "PayProcType");
        checkMandatoryField(paymentInitiationRequest.getGtwMapsId(), "GtwMapsId");
        checkMandatoryField(paymentInitiationRequest.getTransactionAmount(), "TransactionAmount");
        checkMandatoryField(paymentInitiationRequest.getMerchPostedAmount(), "MerchantPostedAmount");
        checkMandatoryField(paymentInitiationRequest.getPayProcId(), "PayProcId");
        throwIfErrors();
    }

    private void validateMandatoryFieldForPaymentRequest(String payMode, PaymentInitiationRequest paymentInitiationRequest) {
        switch (PayMode.getPayMode(payMode)) {
            case CC, DC, PC -> validateCardPayMode(paymentInitiationRequest);
            case NB -> validateNBRequest(paymentInitiationRequest);
            case UPI -> validateUPIRequest(paymentInitiationRequest);
            default ->
                    throw new TransactionException(INVALID_ERROR_CODE, MessageFormat.format(TransactionErrorConstants.INVALID_ERROR_MESSAGE, payMode, "Given PayMode is not configured for Payment"));
        }
    }

    /**
     * Method name : validateLeadingTrailingAndSingleSpace
     * Description : Validates leading and railing spaces of payment initiation request
     * @param paymentInitiationRequest : Object of PaymentInitiationRequest
     */
    private void validateLeadingTrailingAndSingleSpace(PaymentInitiationRequest paymentInitiationRequest) {
        checkForLeadingTrailingAndSingleSpace(paymentInitiationRequest.getOperatingMode(), "OperationMode");
        checkForLeadingTrailingAndSingleSpace(paymentInitiationRequest.getPayProcType(), "PayProcType");
        checkForLeadingTrailingAndSingleSpace(paymentInitiationRequest.getGtwMapsId(), "GtwMapsId");
        checkForLeadingTrailingAndSingleSpace(paymentInitiationRequest.getPayProcId(), "PayProcId");
        throwIfErrors();
    }

    /**
     * Method name : validateFieldValue
     * Description : Validates fields values of payment initiation request
     * @param paymentInitiationRequest : Object of PaymentInitiationRequest
     */
    private void validateFieldValue(PaymentInitiationRequest paymentInitiationRequest) {
        logger.debug("Validating Field value paymentInitiationRequest {}", paymentInitiationRequest);
        validateAmount(paymentInitiationRequest.getTransactionAmount(), "TransactionAmount");
        validateAmount(paymentInitiationRequest.getMerchPostedAmount(), "MerchantPostedAmount");
        validateFieldWithRegex(paymentInitiationRequest.getPayProcId(), TransactionConstant.CAPS_REGEX, "PayProcId", "Please check payprocId format");
        validateFieldWithRegex(paymentInitiationRequest.getGtwMapsId(), TransactionConstant.GTW_MAPSID_REGEX, "GtwMapsId", "Please check gtwMapsId format");
        validateFieldValue(paymentInitiationRequest.getOperatingMode(), Arrays.stream(OperatingMode.values()).map(Enum::name).toList(), "OperatingMode","Invalid OperatingMode format");
        PayProcType.getPayProcType(paymentInitiationRequest.getPayProcType());
        throwIfErrors();
    }

    /**
     * Method name : validatedFieldLength
     * Description : Validates fields length of payment initiation request
     * @param paymentInitiationRequest : Object of PaymentInitiationRequest
     */
    private void validatedFieldLength(PaymentInitiationRequest paymentInitiationRequest) {
        validateFieldLength(paymentInitiationRequest.getPayProcType(), TransactionConstant.PAY_PROC_ID_TYPE_LENGTH, "payProcType");
        validateFieldLength(paymentInitiationRequest.getChannelBank(), TransactionConstant.CHANNEL_BANK_LENGTH, "channel Bank");
        validateFieldLength(paymentInitiationRequest.getOperatingMode(), TransactionConstant.OPERATING_MODE, "operatingMode");
        validateFieldLength(paymentInitiationRequest.getGtwMapsId(), TransactionConstant.GATEWAY_MAP_ID_LENGTH, "gtwMapsId");
        validateFieldLength(paymentInitiationRequest.getPayProcId(), TransactionConstant.PAY_MODE_CODE_LENGTH, "payProcId");

    }

    private void validateVvlAndRfc(String payMode, OrderDto orderDto, PaymentInitiationRequest paymentInitiationRequest) {

        logger.debug("Validating Merchant Volume Velocity for payMode {}", payMode);

        //Step-1 VVL Validation
        Optional<MerchantVvlResponse> vvlResponse = paymentInitiationDao.getMerchantVVLDetailsByPayMode(orderDto.getMId(), payMode);
        if (vvlResponse.isPresent()) {
            MerchantVvlResponse merchantVvlResponse = getMerchantVolumeVelocityResponse(paymentInitiationRequest, vvlResponse.get());
            List<MerchantOrderSummary> orderSummary = paymentInitiationDao.getMerchantOrderSummaryByPayMode(orderDto.getMId(), payMode);
            if (CollectionUtils.isNotEmpty(orderSummary)) {
                validateAggregatedTransactionLimits(paymentInitiationRequest.getMerchPostedAmount(), merchantVvlResponse, orderSummary.getFirst());
            }
        }

        //Step2 RFC Validation for cards
        if (PayMode.CC.name().equalsIgnoreCase(payMode) || PayMode.DC.name().equalsIgnoreCase(payMode) || PayMode.PC.name().equalsIgnoreCase(payMode)) {
            logger.info("Request for Merchant RFC Details");
            MerchantRfcResponse merchantRfcDetailsDto = adminDao.getMerchantRFCDetails(orderDto.getMId());
            logger.info("Request for Card Summary Details");
            List<BigDecimal[]> cardDetails = merchantOrderPaymentDao.cardPaymentSummary(hashValue(paymentInitiationRequest.getAltNumber()));
            validateRFCDetailsForCards(merchantRfcDetailsDto, cardDetails, paymentInitiationRequest.getMerchPostedAmount());
        }
    }

    private void validateRFCDetailsForCards(MerchantRfcResponse merchantRfcDetailsDto,List<BigDecimal[]> cardDetails, BigDecimal merchantPostAmount) {
        logger.info("Validating RFC card details.");
        long count = cardDetails.getFirst()[0].longValue();
        BigDecimal sum = cardDetails.getFirst()[1];

        logger.debug("Validating RFC details : {}", merchantRfcDetailsDto);
        //Step-1: if ThresholdAmountAction is BLOCK AND merchantPostAmount greater than Threshold amount then stop processing
        if (BLOCK_ACTION.equalsIgnoreCase(merchantRfcDetailsDto.getThresholdAmountAction()) && merchantPostAmount.compareTo(merchantRfcDetailsDto.getThresholdAmount()) >= 0) {
            throw new ValidationException(PAYMENT_RFC_THRESHOLD_ERROR_CODE, PAYMENT_RFC_THRESHOLD_ERROR_MESSAGE);
        }

        //Step-2: if rfc count greater than zero AND count greater than DayCardTxnCount AND DayCardTxnCountAction is BLOCK then stop processing
        if (BLOCK_ACTION.equalsIgnoreCase(merchantRfcDetailsDto.getDayCardTxnCountAction()) && count > 0 && count >= merchantRfcDetailsDto.getDayCardTxnCount()) {
            throw new ValidationException(PAYMENT_RFC_DAILY_COUNT_ERROR_CODE, PAYMENT_RFC_DAILY_COUNT_ERROR_MESSAGE);
        }

        //Step-3: if DayCardTxnAmountAction is BLOCK AND total of RFC Sum & Merchant Post Amount is greater than DayCardTxnAmount then stop processing
        if (BLOCK_ACTION.equalsIgnoreCase(merchantRfcDetailsDto.getDayCardTxnAmountAction()) && (sum.add(merchantPostAmount)).compareTo(merchantRfcDetailsDto.getDayCardTxnAmount()) >= 0) {
            throw new ValidationException(PAYMENT_RFC_DAILY_AMOUNT_ERROR_CODE, PAYMENT_RFC_DAILY_AMOUNT_ERROR_MESSAGE);
        }
    }

    private void validateNBRequest(PaymentInitiationRequest paymentInitiationRequest) {
        logger.debug("Validating PaymentInitiationRequest {} for NetBanking", paymentInitiationRequest);
        checkMandatoryField(paymentInitiationRequest.getChannelBank(), "ChannelBank");
        throwIfErrors();
        checkForLeadingTrailingAndSingleSpace(paymentInitiationRequest.getChannelBank(), "ChannelBank");
        throwIfErrors();
        validateChannelBank(paymentInitiationRequest.getGtwMapsId(), paymentInitiationRequest.getChannelBank());
    }

    private void validateCardPayMode(PaymentInitiationRequest paymentInitiationRequest) {
        logger.debug("Validating PaymentInitiationRequest {} for card Paymode", paymentInitiationRequest);
        validateMandatoryCardFields(paymentInitiationRequest);
        checkLeadingTrailingSpaceForCard(paymentInitiationRequest);
        validateLengthForCardFields(paymentInitiationRequest);
        validateCardFieldsValue(paymentInitiationRequest);
    }

    private void validateLengthForCardFields(PaymentInitiationRequest paymentInitiationRequest) {
        logger.debug("Validating length for PaymentInitiationRequest {} for card Paymode", paymentInitiationRequest);
        validateFixedFieldLength(paymentInitiationRequest.getAltNumber(), CARD_NUMBER_LENGTH, ALTNUMBER);
        validateFixedFieldLength(paymentInitiationRequest.getCvv(), CVV_LENGTH_THREE, CVV);
        validateFixedFieldLength(paymentInitiationRequest.getExpiryMonth(), EXPIRY_MONTH_LENGTH, EXPIRY_MONTH);
        validateFixedFieldLength(paymentInitiationRequest.getExpiryYear(), EXPIRY_YEAR_LENGTH, EXPIRY_YEAR);
        validateFieldLength(paymentInitiationRequest.getCardHolderName(), CARD_HOLDER_LENGTH, CARD_HOLDER_NAME);
        throwIfErrors();
    }

    private void checkLeadingTrailingSpaceForCard(PaymentInitiationRequest paymentInitiationRequest) {
        checkForLeadingTrailingAndSingleSpace(paymentInitiationRequest.getAltNumber(), "altNumber");
        checkForLeadingTrailingAndSingleSpace(paymentInitiationRequest.getCvv(), "CVV");
        checkForLeadingTrailingAndSingleSpace(paymentInitiationRequest.getExpiryMonth(), "ExpiryMonth");
        checkForLeadingTrailingAndSingleSpace(paymentInitiationRequest.getExpiryYear(), "ExpiryYear");
        checkForLeadingTrailingAndSingleSpace(paymentInitiationRequest.getCardHolderName(), CARD_HOLDER_NAME);
        throwIfErrors();
    }

    private void validateUPIRequest(PaymentInitiationRequest paymentInitiationRequest) {
        logger.debug("Validating PaymentInitiationRequest {} for UPI", paymentInitiationRequest);
        if (TransactionConstant.PAY_PROC_ID_SELF.equalsIgnoreCase(paymentInitiationRequest.getPayProcId())) {
            validateVPAMandatoryField(paymentInitiationRequest);
        }
    }

    private void validateCardFieldsValue(PaymentInitiationRequest paymentInitiationRequest) {
        validateFieldWithRegex(paymentInitiationRequest.getCardHolderName(), TransactionConstant.ALLOWED_ALPHABET_REGEX, "CardHolderName", "Please check cardHolderName format");
        validateFieldWithRegex(paymentInitiationRequest.getCvv(), TransactionConstant.CVV_NUMBER, "CVV", "Invalid CVV.");
        validateFieldWithRegex(paymentInitiationRequest.getExpiryMonth(), TransactionConstant.MONTH_REGEX, "expiryMonth", "Invalid expiryMonth.");
        validateFieldWithRegex(paymentInitiationRequest.getExpiryYear(), TransactionConstant.YEAR_REGEX, "expiryYear", "Invalid expiryYear.");
        validateFieldWithRegex(paymentInitiationRequest.getAltNumber(), TransactionConstant.ALT_NUMBER, "altNumber", "Invalid Card Number.");
        throwIfErrors();
    }

    private void validateMandatoryCardFields(PaymentInitiationRequest paymentInitiationRequest) {
        logger.debug("Validating paymentInitiationRequest {} for Card Fields", paymentInitiationRequest);
        checkMandatoryField(paymentInitiationRequest.getCardHolderName(), "CardHolderName");
        checkMandatoryField(paymentInitiationRequest.getAltNumber(), "altNumber");
        checkMandatoryField(paymentInitiationRequest.getExpiryMonth(), "expiryMonth");
        checkMandatoryField(paymentInitiationRequest.getCvv(), "CVV");
        checkMandatoryField(paymentInitiationRequest.getExpiryYear(), "expiryYear");
        throwIfErrors();
    }

    private void validateVPAMandatoryField(PaymentInitiationRequest paymentInitiationRequest) {
        checkMandatoryField(paymentInitiationRequest.getUpiAddress(), "upiAddress");
        throwIfErrors();
        checkForLeadingTrailingAndSingleSpace(paymentInitiationRequest.getUpiAddress(), "upiAddress");
        throwIfErrors();
        validateFieldLength(paymentInitiationRequest.getUpiAddress(), VIRTUAL_ADDRESS_MAX_LENGTH, UPI_VIRTUAL_ADDRESS);
        throwIfErrors();
        validateFieldWithRegex(paymentInitiationRequest.getUpiAddress(), VPA_REGEX, UPI_VIRTUAL_ADDRESS, UPI_INVALID_FORMAT);
        throwIfErrors();

    }
}
