package com.epay.transaction.dao;

import com.epay.transaction.dto.MerchantOrderDuplicatePaymentsDto;
import com.epay.transaction.dto.MerchantPaymentOrderDto;
import com.epay.transaction.dto.OrderDto;
import com.epay.transaction.dto.ReconDataDto;
import com.epay.transaction.entity.MerchantOrderPayment;
import com.epay.transaction.etl.producer.ReconRecordFailedDataProducer;
import com.epay.transaction.exceptions.TransactionException;
import com.epay.transaction.mapper.MerchantOrderPaymentMapper;
import com.epay.transaction.model.request.MerchantOrderPaymentSearchRequest;
import com.epay.transaction.model.response.OrderResponse;
import com.epay.transaction.repository.MerchantOrderPaymentRepository;
import com.epay.transaction.specification.TransactionSpecification;
import com.epay.transaction.util.EPayIdentityUtil;
import com.epay.transaction.util.enums.*;
import com.sbi.epay.authentication.providers.EPayTokenProvider;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.text.MessageFormat;
import java.util.*;

import static com.epay.transaction.util.JdbcQueryUtility.*;
import static com.epay.transaction.util.TransactionConstant.ATRN;
import static com.epay.transaction.util.TransactionConstant.*;
import static com.epay.transaction.util.TransactionErrorConstants.*;

/**
 * Class Name:MerchantOrderPaymentDao
 * *
 * Description: This class is used for merchant order payment
 * *
 * Author:V1017903
 * <p>
 * Copyright (c) 2024 [State Bank of india]
 * All right reserved
 * *
 * Version:1.0
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class MerchantOrderPaymentDao {

    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());

    private final ReconRecordFailedDataProducer reconRecordFailedDataProducer;
    private final MerchantOrderPaymentRepository merchantOrderPaymentRepository;
    private final MerchantOrderDuplicatePaymentsDao merchantOrderDuplicatePaymentsDao;
    private final MerchantOrderPaymentMapper merchantOrderPaymentMapper;
    private final EPayTokenProvider ePayTokenProvider;
    private final TokenDao tokenDao;
    private final ErrorLogDao errorLogDao;
    private final KmsDao kmsDao;
    private final OrderDao orderDao;
    private final NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    /**
     * Method name:getEncryptedAESKey
     * Description:Retrieves the encrypted AES key used for encryption/decryption operations.
     * <p>
     * This method fetches the AES encryption key from the database using the current token provided by the
     * ePayTokenProvider.
     *
     * @return The encrypted AES key as a string.
     */
    public String getEncryptedAESKey() {
        logger.info("Fetching the encrypted AES key using the current token.");
        return tokenDao.getEncryptionAESKey(ePayTokenProvider.getToken());
    }

    /**
     * Method name:save
     * Description:Saves a merchant payment order and returns the saved order data.
     * <p>
     * This method takes a `MerchantPaymentOrderDto` object, converts it into a `MerchantOrderPayment` entity using the
     * `merchantOrderPaymentMapper`. It then saves this entity to the database using the `merchantOrderPaymentRepository`.
     * After successfully saving the entity, the saved data is converted back to a `MerchantPaymentOrderDto` and returned.
     *
     * @param merchantPaymentOrderDto The merchant payment order data to be saved.
     * @return The saved `MerchantPaymentOrderDto` with the updated data from the database.
     */
    public MerchantPaymentOrderDto save(MerchantPaymentOrderDto merchantPaymentOrderDto) {
        logger.info("Starting to save merchant payment order: {}", merchantPaymentOrderDto);
        MerchantOrderPayment merchantOrderPaymentData = merchantOrderPaymentRepository.save(merchantOrderPaymentMapper.dtoToEntity(merchantPaymentOrderDto));
        logger.info("Successfully saved merchant payment order with ATRN is {} and mid is {} ", merchantPaymentOrderDto.getAtrnNumber(), merchantPaymentOrderDto.getMId());
        return merchantOrderPaymentMapper.entityToDto(merchantOrderPaymentData);
    }

    /**
     * Method name:markMerchantOrderPaymentStatusFail
     * Description:Marks the status of a merchant order payment as failed.
     *
     * @throws TransactionException If the ATRN does not exist or if the status is already updated to 'FAILED' or 'SUCCESS'.
     */
    public void updateTransactionFail(String atrn, String reason) {
        logger.debug(" going to start update merchantOrderPayment status: ");
        String mId = EPayIdentityUtil.getUserPrincipal().getMId();
        MerchantOrderPayment merchantOrderPayment = merchantOrderPaymentRepository.findBymIdAndAtrnNumber(mId, atrn).orElseThrow(() -> {
            errorLogDao.logBusinessError(mId, EntityType.CUSTOMER, atrn, null, null, null, NOT_FOUND_ERROR_CODE, MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, MERCHANT_ORDER_PAYMENT));
            return new TransactionException(NOT_FOUND_ERROR_CODE, MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, MERCHANT_ORDER_PAYMENT));
        });
        if (StringUtils.isEmpty(merchantOrderPayment.getAtrnNumber()) || PaymentStatus.SUCCESS.equals(merchantOrderPayment.getPaymentStatus()) || PaymentStatus.FAILED.equals(merchantOrderPayment.getPaymentStatus())) {
            throw new TransactionException(INVALID_ERROR_CODE, MessageFormat.format(INVALID_ERROR_MESSAGE, ATRN, INVALID_ATRN));
        }
        merchantOrderPayment.setTransactionStatus(TransactionStatus.FAILED);
        merchantOrderPayment.setPaymentStatus(PaymentStatus.FAILED);
        merchantOrderPayment.setFailReason(reason);
        merchantOrderPayment = merchantOrderPaymentRepository.save(merchantOrderPayment);
        logger.debug(" Updated merchantOrderPayment status: " + merchantOrderPayment);
    }

    /**
     * Method name:validatedMerchantOrderPaymentForBooking
     * Description:Validates if there are any merchant order payments associated with a given SBI order reference number
     * and that the transaction status is within the provided list of valid statuses.
     *
     * @param sbiOrderRefNumber The SBI order reference number to validate the payments for.
     * @param statusList        A list of valid transaction statuses to match against.
     * @return boolean Returns true if there is at least one matching merchant order payment with the provided order reference number and status list; otherwise, false.
     */
    public boolean validatedMerchantOrderPaymentForBooking(String sbiOrderRefNumber, List<String> statusList) {
        return merchantOrderPaymentRepository.countBySbiOrderRefNumberAndTransactionStatusIn(sbiOrderRefNumber, statusList) > 0;
    }

    /**
     * Method name:cardPaymentSummary
     * Description:Fetches a summary of card payment data by querying the MerchantOrderPayment and Order tables
     * using the provided alternative hash value.
     *
     * @param altHash The alternative hash used to fetch the card payment summary data.
     * @return Object[] An array containing the summary data fetched from the database. The specific elements
     * in the array depend on the query result from the `cardPaymentSummary` repository method.
     */
    public List<BigDecimal[]> cardPaymentSummary(String altHash) {
        logger.info("Fetching data from MerchantOrderPayment and Order table.");
        return merchantOrderPaymentRepository.cardPaymentSummary(altHash);
    }

    /**
     * Method name:findByAtrnNumber
     * Description:Finds a MerchantOrderPayment by its ATRN number and returns the corresponding MerchantPaymentOrderDto.
     *
     * @param atrn The ATRN  used to look up the MerchantOrderPayment.
     * @return MerchantPaymentOrderDto The DTO corresponding to the MerchantOrderPayment with the provided ATRN.
     * @throws TransactionException If no MerchantOrderPayment is found with the provided ATRN, throws a custom exception.
     */
    public MerchantPaymentOrderDto findByAtrnNumber(String mId, String atrn) {
        logger.info("Searching for MerchantOrderPayment with ATRN: {}", atrn);
        MerchantOrderPayment merchantOrderPayment = merchantOrderPaymentRepository.findBymIdAndAtrnNumber(mId, atrn).orElseThrow(() -> {
            errorLogDao.logCustomerError(EPayIdentityUtil.getUserPrincipal().getMId(), EntityType.REFUND, atrn, null, null, null, NOT_FOUND_ERROR_CODE, MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, "MerchantOrderPayment detail"));
            return new TransactionException(NOT_FOUND_ERROR_CODE, MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, "MerchantOrderPayment detail"));
        });
        return merchantOrderPaymentMapper.entityToDto(merchantOrderPayment);
    }

    /**
     * Method name:findBySpecification
     * Description:Finds and returns a paginated list of OrderResponse based on the provided merchant ID and search criteria.
     *
     * @param mId                               The Merchant ID to filter the search results.
     * @param merchantOrderPaymentSearchRequest The search criteria to filter the MerchantOrderPayment entities.
     * @param pageable                          The Pageable object that contains pagination information such as page number and size.
     * @return Page<OrderResponse> A paginated list of OrderResponse DTOs.
     */
    public Page<OrderResponse> findBySpecification(String mId, MerchantOrderPaymentSearchRequest merchantOrderPaymentSearchRequest, Pageable pageable) {
        logger.info("Searching for transactions for merchant ID: {} with search criteria: {}", mId, merchantOrderPaymentSearchRequest);
        Specification<MerchantOrderPayment> specification = TransactionSpecification.searchTransaction(mId, merchantOrderPaymentSearchRequest);
        return merchantOrderPaymentRepository.findAll(specification, pageable).map(this::convertEntityToMerchantOrderResponse);
    }

    /**
     * This Method Is Used To Get Transaction And Order Details.
     *
     * @param atrnNumber decrypted payment verification request
     * @return List Of Object array.
     */
    public Optional<List<Object[]>> getTransactionAndOrderDetail(String atrnNumber) {
        logger.info("Fetching data from transaction and order table.");
        return merchantOrderPaymentRepository.findTransactionAndOrderDetail(atrnNumber, PUSH_RESPONSE_STATUS_PENDING);
    }

    /**
     * This method is used to update the push response status.
     *
     * @param atrnNumber ATRN number`
     * @param pushStatus status which needs to update.
     */
    public void updatePushVerificationStatus(String atrnNumber, String pushStatus) {
        logger.info("Updating push status as : {}", pushStatus);
        merchantOrderPaymentRepository.updatePushStatusByAtrnNumber(atrnNumber, pushStatus);
    }

    /**
     * This method is used to convert merchant order payment entity to merchant order payment response
     *
     * @param merchantOrderPayment merchant order payment details.
     * @return OrderResponse
     */
    private OrderResponse convertEntityToMerchantOrderResponse(MerchantOrderPayment merchantOrderPayment) {
        logger.debug("Converting MerchantOrderPayment entity to OrderResponse DTO for ATRN: {}", merchantOrderPayment.getAtrnNumber());
        return merchantOrderPaymentMapper.entityToMerchantOrderResponse(merchantOrderPayment);
    }

    public List<MerchantOrderPayment> findBySbiOrderRefNumber(String sbiOrderRefNumber) {
        logger.info("Searching for MerchantOrderPayment with ATRN: {}", sbiOrderRefNumber);
        return merchantOrderPaymentRepository.findBySbiOrderRefNumber(sbiOrderRefNumber);
    }

    /**
     * Method name : getMerchantMek
     * Description : Fetches MEK from Key management Service
     *
     * @return a String
     */
    public String getMerchantMek() {
        return kmsDao.getMerchantMekKey();
    }

    /**
     * Method name : getOrder
     * Description :  getMerchant Details
     *
     * @return object of OrderDto
     */
    public OrderDto getMerchantOrder() {
        logger.info("Validating Order By SBI orderReferenceNo");
        return orderDao.getValidOrderBySBIOrderRefNumber(EPayIdentityUtil.getUserPrincipal().getMId(), EPayIdentityUtil.getUserPrincipal().getOrderRef());
    }

    /**
     * Getting List<MerchantPaymentOrderDto> data based upon atrnList.
     */
    public MerchantPaymentOrderDto findByAtrn(String atrn) {
        MerchantOrderPayment merchantOrderPayment = merchantOrderPaymentRepository.findByAtrnNumber(atrn).orElseThrow(() -> new TransactionException(NOT_FOUND_ERROR_CODE, MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, "MerchantOrderPayment")));
        return merchantOrderPaymentMapper.entityToDto(merchantOrderPayment);
    }

    public void update(ReconDataDto reconDataDto) {
        int count = namedParameterJdbcTemplate.update(MERCHANT_PAYMENT_ORDER_UPDATE, buildMerchantOrderPaymentParamMap(reconDataDto, false));
        log.info("Record Update done of merchantOrderPayment for ReconDataDto {} and update record count is {}", reconDataDto, count);
        publishReconData(reconDataDto, count);
    }

    public void update(ReconDataDto reconDataDto, String recordType) {
        logger.info("updating merchantOrderPayment for ReconDataDto {} and type {}", reconDataDto, recordType);
        Map<String, Object> param = buildMerchantOrderPaymentParamMap(reconDataDto, recordType);
        int count = 0;

        switch (recordType){
            case TXN_FAILED_DVP -> count = namedParameterJdbcTemplate.update(DVP_MERCHANT_PAYMENT_ORDER_UPDATE, param);
            case TXN_FAILED_NDVP -> count = namedParameterJdbcTemplate.update(NDVP_MERCHANT_PAYMENT_ORDER_UPDATE, param);
            case TXN_SUCCESS ->  count = namedParameterJdbcTemplate.update(MERCHANT_PAYMENT_ORDER_UPDATE, param);
        }

        if (count == 0) {
            log.error("No Record Update done of merchantOrderPayment for ReconDataDto {} and type {}", reconDataDto, recordType);
            publishReconData(reconDataDto, count);
        }
        logger.info("Update done of merchantOrderPayment for ReconDataDto {} and type {}", reconDataDto, recordType);
    }

    private void publishReconData(ReconDataDto reconDataDto, int count) {
        if (count == 0) {
            String errorMessage = reconDataDto.getRfdId() + ":" + "No Data Update";
            reconRecordFailedDataProducer.publish(RECON_FAIL, reconDataDto.getAtrnNum(), errorMessage);
        }
    }

    private Map<String, Object> buildMerchantOrderPaymentParamMap(ReconDataDto reconDataDto, String type) {

        Map<String, Object> paramMap = buildMerchantOrderPaymentParamMap(reconDataDto, true);

        if (TXN_FAILED_DVP.equalsIgnoreCase(type)) {
            paramMap.put("paymentStatus", PaymentStatus.FAILED.name());
            paramMap.put("transactionStatus", TransactionStatus.FAILED.name());
            paramMap.put("refundStatus", TransactionRefundStatus.FULL_REFUND_BOOKED.name());
        }

        if (TXN_FAILED_NDVP.equalsIgnoreCase(type)) {
            paramMap.put("paymentStatus", PaymentStatus.SUCCESS.name());
            paramMap.put("transactionStatus", TransactionStatus.SUCCESS.name());
        }

        return paramMap;
    }

    private Map<String, Object> buildMerchantOrderPaymentParamMap(ReconDataDto reconDataDto, boolean matched) {
        Map<String, Object> paramMap = new HashMap<>();
        UUID rfId = UUID.fromString(reconDataDto.getRfId());
        paramMap.put("bankReferenceNumber", reconDataDto.getBankRefNumber());
        paramMap.put("atrnNum", reconDataDto.getAtrnNum());
        paramMap.put("settlementStatus", matched ? SettlementStatus.SETTLED.name() : SettlementStatus.FAILED.name());
        paramMap.put("settlementTime", System.currentTimeMillis());
        paramMap.put("rfId", uuidToBytes(rfId));
        return paramMap;
    }

    public void processDuplicateReconRecord(MerchantOrderDuplicatePaymentsDto merchantPaymentOrderDtoList) {
        merchantOrderDuplicatePaymentsDao.saveMerchantOrderPaymentDuplicateRecord(merchantPaymentOrderDtoList);
    }

    /**
     * This method is used to fetch merchant order payments between startAt and endAt by updated and create date.
     * @param startAt long
     * @param endAt long
     * @return List of merchant order payments.
     */
    public List<MerchantPaymentOrderDto> findByUpdatedDateBetweenAndCreatedDate(long startAt, long endAt){
        return merchantOrderPaymentMapper.entityToDto(merchantOrderPaymentRepository.findByUpdatedDateBetweenAndCreatedDateLessThanEqual(startAt, endAt, startAt));
    }
}
