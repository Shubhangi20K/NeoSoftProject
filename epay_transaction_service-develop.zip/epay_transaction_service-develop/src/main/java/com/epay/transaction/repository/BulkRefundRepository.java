package com.epay.transaction.repository;

import com.epay.transaction.entity.BulkRefundBooking;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

/**
 * Class Name:BulkRefundRepository
 * *
 * Description:
 * *
 * Author:Nirmal
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */


public interface BulkRefundRepository extends JpaRepository<BulkRefundBooking, UUID> {

    BulkRefundBooking findByBulkIdAndMerchantId(String bulkId, String mId);

    Page<BulkRefundBooking> findByMerchantId(String mId, Pageable pageable);

    BulkRefundBooking findByBulkId(String bulkId);

}