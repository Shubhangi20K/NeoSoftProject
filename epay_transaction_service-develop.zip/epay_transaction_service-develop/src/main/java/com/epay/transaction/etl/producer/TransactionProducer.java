package com.epay.transaction.etl.producer;

import com.epay.transaction.config.kafka.Topics;
import org.springframework.beans.factory.annotation.Autowired;

import java.text.MessageFormat;

/**
 * Class Name: TransactionProducer
 * *
 * Description: The parent producer for transaction service.
 * *
 * Author: Gireesh M
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
public abstract class TransactionProducer<T> {

    @Autowired
    protected KafkaMessagePublisher kafkaMessagePublisher;

    @Autowired
    protected Topics topics;

    String getRoutingKey(String key, String requestType, String routingKey) {
        return MessageFormat.format("{0}.{1}.{2}", key, requestType, routingKey);
    }

    public abstract void publish(String requestType, String routingKey, T message);
}
