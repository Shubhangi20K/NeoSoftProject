package com.epay.transaction.externalservice.response.admin;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

import java.math.BigDecimal;


/**
 * Class Name: MerchantRfcDetailsDto
 * *
 * Description: MerchantRfcDetailsDto
 * *
 * Author: V1015793 (Saurabh Navghare)
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */

@Data
@Builder
public class MerchantRfcResponse {

    @JsonProperty("mId")
    private String mId;
    private BigDecimal thresholdAmount;
    private String thresholdAmountAction;
    private String pepAction;
    private Integer dayCardTxnCount;
    private String dayCardTxnCountAction;
    private Integer dormancyDays;
    private String dormancyAction;
    private String binMode;
    private String binModeAction;
    private Boolean isActive;
    private String instructionType;
    private String recordStatus;
    private BigDecimal dayCardTxnAmount;
    private String dayCardTxnAmountAction;
}
