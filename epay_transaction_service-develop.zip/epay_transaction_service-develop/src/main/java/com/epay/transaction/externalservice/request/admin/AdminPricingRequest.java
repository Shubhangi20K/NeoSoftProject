package com.epay.transaction.externalservice.request.admin;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

/**
 * Class Name: AdminPricingRequest
 * *
 * Description: AdminPricingRequest entity class
 * *
 * Author: (Nirmal Gurjar)
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AdminPricingRequest {

    @JsonProperty("mId")
    private String mId;
    private BigDecimal transactionAmount;
    private String payModeCode;
    private String gtwMapsId;
    private String payProcType;

}
