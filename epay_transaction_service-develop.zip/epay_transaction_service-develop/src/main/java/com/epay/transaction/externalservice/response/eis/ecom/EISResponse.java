package com.epay.transaction.externalservice.response.eis.ecom;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class EISResponse {

    @JsonProperty("RESPONSE")
    private String encryptedResponse;

    @JsonProperty("EIS_RESPONSE")
    private EisEComResponse eisEComResponse;

    @JsonProperty("ERROR_CODE")
    private String errorCode;

    @JsonProperty("ERROR_DESCRIPTION")
    private String errorDescription;

    @JsonProperty("RESPONSE_STATUS")
    private String responseStatus;

    @JsonProperty("DIGI_SIGN")
    private String digiSign;

    @JsonProperty("REQUEST_REFERENCE_NUMBER")
    private String requestReferenceNumber;

    @JsonProperty("RESPONSE_DATE")
    private String responseDate;


}
