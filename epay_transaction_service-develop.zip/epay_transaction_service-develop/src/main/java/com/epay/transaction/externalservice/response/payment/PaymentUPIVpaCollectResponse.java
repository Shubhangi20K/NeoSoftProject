package com.epay.transaction.externalservice.response.payment;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Class Name:PaymentUPIVpaCollectResponse
 * *
 * Description:
 * *
 * Author:V1014352(Ranjan Kumar)
 * <p>
 * Copyright (c) 2025 [State Bank of INdia]
 * All right reserved
 * *
 * Version:1.0
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonPropertyOrder
public class PaymentUPIVpaCollectResponse {
    private String pspRefNo;
    private String upiTransRefNo;
    private String npciTransId;
    private String custRefNo;
    private String amount;
    private String txnAuthDate;
    private String status;
    private String statusDesc;
    private String addInfo2;
    private String payerVPA;
    private String payeeVPA;
}
