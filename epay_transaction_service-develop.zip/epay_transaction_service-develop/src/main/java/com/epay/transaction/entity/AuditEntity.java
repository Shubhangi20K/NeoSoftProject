package com.epay.transaction.entity;

import jakarta.persistence.MappedSuperclass;
import lombok.*;
import lombok.experimental.SuperBuilder;
import org.hibernate.envers.Audited;
import org.springframework.data.annotation.CreatedBy;
import org.springframework.data.annotation.LastModifiedBy;

import java.io.Serializable;

@Getter
@Setter
@MappedSuperclass
@Audited
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class AuditEntity extends AuditEntityByDate implements Serializable {
    @CreatedBy
    private String createdBy;

    @LastModifiedBy
    private String updatedBy;
}
