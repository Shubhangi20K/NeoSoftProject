package com.epay.transaction.model.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

/**
 *
 *  Copyright (c) [2024] [State Bank of India]
 *  All rights reserved.
 *  Author:@V0000001(Shilpa Kothre)
 *  Version:1.0
 *
 */

@Data
@Builder
@AllArgsConstructor
public class TransactionTokenResponse {
    private String token;
    private String hval;
}
