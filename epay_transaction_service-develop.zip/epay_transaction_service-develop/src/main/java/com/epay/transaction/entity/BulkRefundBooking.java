package com.epay.transaction.entity;

import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.SuperBuilder;
import java.util.UUID;

/**
 * Class Name:BulkRefundBooking
 * *
 * Description:
 * *
 * Author:Nirmal Gurjar
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
@EqualsAndHashCode(callSuper = true)
@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
@SuperBuilder
@Table(name = "BULK_REFUND_BOOKING")
public class BulkRefundBooking extends AuditEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;
    private String bulkId;
    private String merchantId;
    private String fileName;
    private String filePath;
    private Integer totalRecords;
    private Integer validRecords;
    private Integer invalidRecords;
    private String bulkRefundStatus;
    private String remark;

    /**
     * custom generator, do not remove it
     */
    @PrePersist
    protected void generateBulkId() {
        this.bulkId =  new StringBuilder().append(System.nanoTime()).reverse().append(this.merchantId, 2, 7).reverse().toString();
    }

}
