package com.epay.transaction.validator;

import com.epay.transaction.dao.AdminDao;
import com.epay.transaction.dao.CustomerDao;
import com.epay.transaction.dao.ErrorLogDao;
import com.epay.transaction.exceptions.TransactionException;
import com.epay.transaction.externalservice.response.admin.MerchantPostalCodeResponse;
import com.epay.transaction.model.request.CustomerRequest;
import com.epay.transaction.dto.CustomerDto;
import com.epay.transaction.util.EPayIdentityUtil;
import com.epay.transaction.util.enums.EntityType;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.Optional;

import static com.epay.transaction.util.TransactionConstant.*;
import static com.epay.transaction.util.TransactionErrorConstants.*;

/**
 * Class Name: CustomerValidator
 * *
 * Description: Validates merchant customer details .
 * *
 * Author: V1018212
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Component
@RequiredArgsConstructor
public class CustomerValidator extends BaseValidator {
    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private final CustomerDao customerDao;
    private final AdminDao adminDao;
    private final ErrorLogDao errorLogDao;

    /**
     * Method name : validateCustomerId
     * Description : Validates customer id
     * @param customerId : String
     */
    public void validateCustomerId(String customerId){
        logger.info("Validating customer id: {}", customerId);
        errorDtoList = new ArrayList<>();
        checkForLeadingTrailingAndSingleSpace(customerId, FIELD_CUSTOMER_ID);
        throwIfErrors();
        validateFieldLength(customerId, CUSTOMER_ID_LENGTH, FIELD_CUSTOMER_ID);
        throwIfErrors();
        validateFieldWithRegex(customerId, CUSTOMER_ID_REGEX, FIELD_CUSTOMER_ID,  INCORRECT_FORMAT);
        throwIfErrors();
    }

    /**
     * Method name : validateCustomerRequest
     * Description : Validates merchant customer creation request details
     * @param customerRequest : Object of CustomerRequest
     */
    public void validateCustomerRequest(CustomerRequest customerRequest) {
        errorDtoList = new ArrayList<>();
        logger.debug("Customer validation start for {}", customerRequest);
        validateMandatoryFields(customerRequest);
        logger.debug("Customer mandatory validation completed for {}", customerRequest);
        validateLeadingTrailingSpaces(customerRequest);
        validateFieldsLength(customerRequest);
        logger.debug("Customer leading and trailing space validation completed for {}", customerRequest);
        validateFieldsValue(customerRequest);
        logger.debug("Customer field validation completed for {}", customerRequest);
        validateUniqueCustomer(customerRequest);
        logger.debug("Customer all validation completed for {}", customerRequest);
        validatePostalCode(customerRequest);
    }

    /**
     * Method name : validateFieldsLength
     * Description : Validates merchant customer creation request length details
     * @param customerRequest : Object of CustomerRequest
     */
    private void validateFieldsLength(CustomerRequest customerRequest){
        validateFixedFieldLength(customerRequest.getPhoneNumber(),PHONE_NUMBER_LENGTH,FIELD_PHONE);
        validateFixedFieldLength(customerRequest.getPinCode(),PINCODE_LENGTH,FIELD_PINCODE);
        validateFixedFieldLength(customerRequest.getGstIn(),GSTIN_LENGTH, FIELD_GST);
        validateFieldLength(customerRequest.getEmail(), EMAIL_LENGTH, FIELD_EMAIL);
        validateFieldLength(customerRequest.getGstInAddress(), NAME_LENGTH, FIELD_GSTN_ADDRESS);
        validateFieldLength(customerRequest.getAddress2(), ADDRESS_LENGTH, FIELD_ADDRESS2);
        validateFieldLength(customerRequest.getCity(), NAME_LENGTH, FIELD_CITY);
        validateFieldLength(customerRequest.getState(), NAME_LENGTH, FIELD_STATE);
        throwIfErrors();
    }

    /**
     * Method name : validateCustomerRequest
     * Description : Validates mandatory fields of merchant customer creation request
     * @param customerRequest : Object of CustomerRequest
     */
    private void validateMandatoryFields(CustomerRequest customerRequest) {
        checkMandatoryField(customerRequest.getCustomerName(), FIELD_CUSTOMER_NAME);
        checkMandatoryField(customerRequest.getEmail(), FIELD_EMAIL);
        checkMandatoryField(customerRequest.getPhoneNumber(), FIELD_PHONE);
        checkMandatoryField(customerRequest.getAddress1(), FIELD_ADDRESS1);
        checkMandatoryField(customerRequest.getCountry(), FIELD_COUNTRY);
        checkMandatoryField(customerRequest.getPinCode(), FIELD_PINCODE);
        validateFieldLength(customerRequest.getCustomerName(), NAME_LENGTH, FIELD_CUSTOMER_NAME);
        validateFieldLength(customerRequest.getEmail(), EMAIL_LENGTH, FIELD_EMAIL);
        validateFieldLength(customerRequest.getAddress1(), ADDRESS_LENGTH, FIELD_ADDRESS1);
        validateFieldLength(customerRequest.getCountry(), COUNTRY_LENGTH, FIELD_COUNTRY);
        throwIfErrors();
    }

    /**
     * Method name : validateLeadingAndTraling
     * Description : Validates leading and Traling spaces from merchant customer creation request
     * @param customerRequest : Object of CustomerRequest
     */
    private void validateLeadingTrailingSpaces(CustomerRequest customerRequest) {
        checkForLeadingTrailingAndSingleSpace(customerRequest.getCustomerName(), FIELD_CUSTOMER_NAME);
        checkForLeadingTrailingAndSingleSpace(customerRequest.getAddress1(), FIELD_ADDRESS1);
        checkForLeadingTrailingAndSingleSpace(customerRequest.getEmail(), FIELD_EMAIL);
        checkForLeadingTrailingAndSingleSpace(customerRequest.getPhoneNumber(), FIELD_PHONE);
        checkForLeadingTrailingAndSingleSpace(customerRequest.getCountry(), FIELD_COUNTRY);
        checkForLeadingTrailingAndSingleSpace(customerRequest.getPinCode(), FIELD_PINCODE);
        checkForLeadingTrailingAndSingleSpace(customerRequest.getGstIn(), FIELD_GSTN);
        checkForLeadingTrailingAndSingleSpace(customerRequest.getGstInAddress(), FIELD_GSTN_ADDRESS);
        checkForLeadingTrailingAndSingleSpace(customerRequest.getAddress2(), FIELD_ADDRESS2);
        checkForLeadingTrailingAndSingleSpace(customerRequest.getCity(), FIELD_CITY);
        checkForLeadingTrailingAndSingleSpace(customerRequest.getState(), FIELD_STATE);

        throwIfErrors();
    }

    /**
     * Method name : validateFieldsValue
     * Description : Validates fields values of merchant customer creation request
     * @param customerRequest : Object of CustomerRequest
     */
    private void validateFieldsValue(CustomerRequest customerRequest) {
        validateFieldWithRegex(customerRequest.getCustomerName(), SPEC_CHARACTER_REGEX, FIELD_CUSTOMER,  INCORRECT_FORMAT);
        validateFieldWithRegex(customerRequest.getEmail(), EMAIL_REGEX, FIELD_EMAIL,  INCORRECT_FORMAT);
        validateFieldWithRegex(customerRequest.getPhoneNumber(), PHONE_REGEX, FIELD_PHONE,  INCORRECT_FORMAT);
        validateFieldWithRegex(customerRequest.getCountry(), SPEC_CHARACTER_REGEX, FIELD_COUNTRY,  INCORRECT_FORMAT);
        validateFieldWithRegex(customerRequest.getPinCode(), PIN_REGEX, FIELD_PINCODE,  INCORRECT_FORMAT);
        validateFieldWithRegex(customerRequest.getGstIn(), GSTIN_REGEX, FIELD_GST,  INCORRECT_FORMAT);
        validateFieldWithRegex(customerRequest.getGstInAddress(), SPEC_CHARACTER_REGEX, FIELD_GSTN_ADDRESS,  INCORRECT_FORMAT);

        validateFieldWithRegex(customerRequest.getCity(), SPEC_CHARACTER_REGEX, FIELD_CITY,  INCORRECT_FORMAT);
        validateFieldWithRegex(customerRequest.getState(), SPEC_CHARACTER_REGEX, FIELD_STATE,  INCORRECT_FORMAT);
        throwIfErrors();
    }

    /**
     * Method name : validateUniqueCustomer
     * Description : Validates uniqueness of merchant customer
     * @param customerRequestDto : Object of MerchantCustomerResponseDto
     */
    private void validateUniqueCustomer(CustomerRequest customerRequestDto) {
        Optional<CustomerDto> customerExists = customerDao.findCustomerByEmailAndPhoneNumber(EPayIdentityUtil.getUserPrincipal().getMId(), customerRequestDto.getEmail(), customerRequestDto.getPhoneNumber());
        customerExists.ifPresent(customerDto -> addError("Customer", ALREADY_EXIST_ERROR_CODE, ALREADY_EXIST_ERROR_MESSAGE));
        throwIfErrors();
    }

    /**
     * Method name : validatePostalCode
     * Description : Validates postal code creation request for customer
     *
     * @param customerRequestDto : an object of MerchantOrderDto
     */
    private void validatePostalCode(CustomerRequest customerRequestDto) {
        if (ObjectUtils.isNotEmpty(customerRequestDto.getPinCode())) {
            MerchantPostalCodeResponse response = adminDao.getPostalCodeDetails(customerRequestDto.getPinCode());
            // Validate postal code
            if (!StringUtils.equalsIgnoreCase(customerRequestDto.getPinCode(), response.getPostalCode())) {
                errorLogDao.logCustomerError(EPayIdentityUtil.getUserPrincipal().getMId(), EntityType.CUSTOMER,null,null,null,null, NOT_FOUND_ERROR_CODE, MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, VALID_PINCODE));
                throw new TransactionException(NOT_FOUND_ERROR_CODE, MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, VALID_PINCODE));
            }
            // Handle city: if blank populate from DB otherwisevalidate
            if (ObjectUtils.isEmpty(customerRequestDto.getCity())) {
                customerRequestDto.setCity(response.getCityName());
            }else if (ObjectUtils.isNotEmpty(customerRequestDto.getCity()) && !StringUtils.equalsIgnoreCase(customerRequestDto.getCity(), response.getCityName())) {
                errorLogDao.logCustomerError(EPayIdentityUtil.getUserPrincipal().getMId(), EntityType.CUSTOMER,null,null,null,null, NOT_FOUND_ERROR_CODE, MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, VALID_CITY));
                throw new TransactionException(NOT_FOUND_ERROR_CODE, MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, VALID_CITY));
            }
            // Handle state: if blank populate from DB otherwise, validate
            if (ObjectUtils.isEmpty(customerRequestDto.getState())) {
                customerRequestDto.setState(response.getStateName());
            } else if (ObjectUtils.isNotEmpty(customerRequestDto.getState()) && !StringUtils.equalsIgnoreCase(customerRequestDto.getState(), response.getStateName())) {
                errorLogDao.logCustomerError(EPayIdentityUtil.getUserPrincipal().getMId(), EntityType.CUSTOMER,null,null,null,null, NOT_FOUND_ERROR_CODE, MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, VALID_STATE));
                throw new TransactionException(NOT_FOUND_ERROR_CODE, MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, VALID_STATE));
            }
            // Validate country
            if (!StringUtils.equalsIgnoreCase(customerRequestDto.getCountry(),response.getCountryCode())) {
                errorLogDao.logCustomerError(EPayIdentityUtil.getUserPrincipal().getMId(), EntityType.CUSTOMER,null,null,null,null, NOT_FOUND_ERROR_CODE, MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, VALID_COUNTRY));
                throw new TransactionException(NOT_FOUND_ERROR_CODE, MessageFormat.format(NOT_FOUND_ERROR_MESSAGE, VALID_COUNTRY));
            }
            logger.debug("Validated Postal code details with admin response: {} ", response);
        }
    }

}