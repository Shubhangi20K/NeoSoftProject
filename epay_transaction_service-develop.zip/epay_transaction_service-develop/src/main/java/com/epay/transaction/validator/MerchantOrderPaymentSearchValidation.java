package com.epay.transaction.validator;

import com.epay.transaction.model.request.MerchantOrderPaymentSearchRequest;
import com.epay.transaction.util.TransactionConstant;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import org.springframework.stereotype.Component;
import java.util.ArrayList;

import static com.epay.transaction.util.TransactionConstant.*;
import static com.epay.transaction.util.TransactionErrorConstants.*;

/**
 * Class Name:MerchantOrderPaymentSearchValidation
 * *
 * Description: This class is used for validateDownloadTransaction,validateMandatoryFields
 * *
 * Author:V1014352
 * <p>
 * Copyright (c) 2024 [State Bank of india]
 * All right reserved
 * *
 * Version:1.0
 */
@Component
public class MerchantOrderPaymentSearchValidation extends BaseValidator {

    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());

    /**
     * Validates the download transaction request by ensuring that all mand atory fields
     * in the MerchantOrderPaymentSearchRequest object are present and valid.
     *
     * @param merchantOrderPaymentSearchRequest The request object containing payment search data to be validated.
     */
    public void validateDownloadTransaction(String mId, MerchantOrderPaymentSearchRequest merchantOrderPaymentSearchRequest) {
        logger.info("Starting validation for download transaction");
        errorDtoList = new ArrayList<>();
        validateMandatoryFields(mId, merchantOrderPaymentSearchRequest);
        checkForLeadingTrailingAndSingleSpaces(mId, merchantOrderPaymentSearchRequest);
        validateFieldsLength(mId ,merchantOrderPaymentSearchRequest);
        validateFieldsValue(mId, merchantOrderPaymentSearchRequest);
    }

    private void validateFieldsValue(String mId, MerchantOrderPaymentSearchRequest merchantOrderPaymentSearchRequest) {
        logger.info("validation started for fields values in the merchantOrderPaymentSearchRequest.");
        validateFieldWithRegex(merchantOrderPaymentSearchRequest.getAtrn(), ATRN_ARRN_REGEX, TransactionConstant.ATRN, INVALID_ATRN_REASON);
        validateFieldWithRegex(merchantOrderPaymentSearchRequest.getTransactionStatus(), GENERIC_ENUM_REGEX, TransactionConstant.TRANSACTION_STATUS, INCORRECT_FORMAT);
        validateFieldWithRegex(merchantOrderPaymentSearchRequest.getOrderStatus(), GENERIC_ENUM_REGEX, TransactionConstant.ORDER_STATUS, INCORRECT_FORMAT);
        validateFieldWithRegex(merchantOrderPaymentSearchRequest.getRefundStatus(), GENERIC_ENUM_REGEX, TransactionConstant.REFUND_STATUS, INCORRECT_FORMAT);
        validateFieldWithRegex(merchantOrderPaymentSearchRequest.getPaymentStatus(), GENERIC_ENUM_REGEX, TransactionConstant.PAYMENT_STATUS, INCORRECT_FORMAT);
        validateFieldWithRegex(merchantOrderPaymentSearchRequest.getOrderRefNumber(), ORDER_REFERENCE_NUMBER_REGEX, FIELD_ORDER_REF_NUMBER,  INCORRECT_FORMAT);
        validateFieldWithRegex(merchantOrderPaymentSearchRequest.getSbiOrderRefNumber(), ORDER_REFERENCE_NUMBER_REGEX, SBI_ORDER_REF_NUMBER_MESSAGE,  INCORRECT_FORMAT);
        validateFieldWithRegex(merchantOrderPaymentSearchRequest.getBankRefNumber(), ORDER_REFERENCE_NUMBER_REGEX, BANK_REF_NUMBER,  INCORRECT_FORMAT);
        validateFieldWithRegex(mId, ALLOWED_DIGIT_REGEX, MID,  INCORRECT_FORMAT);
        throwIfErrors();
    }

    private void validateFieldsLength(String mId, MerchantOrderPaymentSearchRequest merchantOrderPaymentSearchRequest) {
        logger.info("validation started for fields length in the merchantOrderPaymentSearchRequest.");
        validateFieldLength(merchantOrderPaymentSearchRequest.getOrderRefNumber(), ORDER_REF_LENGTH, FIELD_ORDER_REF_NUMBER);
        validateFieldLength(merchantOrderPaymentSearchRequest.getBankRefNumber(), BANK_REF_LENGTH, BANK_REF_NUMBER);
        validateFieldLength(merchantOrderPaymentSearchRequest.getSbiOrderRefNumber(), SBI_ORDER_REF_LENGTH, SBI_ORDER_REF_NUMBER);
        validateFieldLength(merchantOrderPaymentSearchRequest.getTransactionStatus(), STATUS_LENGTH, TransactionConstant.TRANSACTION_STATUS);
        validateFieldLength(merchantOrderPaymentSearchRequest.getOrderStatus(), STATUS_LENGTH, TransactionConstant.ORDER_STATUS);
        validateFieldLength(merchantOrderPaymentSearchRequest.getRefundStatus(), STATUS_LENGTH, TransactionConstant.REFUND_STATUS);
        validateFieldLength(merchantOrderPaymentSearchRequest.getPaymentStatus(), STATUS_LENGTH, TransactionConstant.PAYMENT_STATUS);
        validateFixedFieldLength(merchantOrderPaymentSearchRequest.getAtrn(), ATRN_ARRN_LENGTH, TransactionConstant.ATRN);
        validateFixedFieldLength(mId, TransactionConstant.MID_MAX_LENGTH, MID);
        throwIfErrors();
    }

    private void checkForLeadingTrailingAndSingleSpaces(String mId,MerchantOrderPaymentSearchRequest merchantOrderPaymentSearchRequest) {
        logger.info("validation started for leading and trailing spaces in the merchantOrderPaymentSearchRequest.");
        checkForLeadingTrailingAndSingleSpace(merchantOrderPaymentSearchRequest.getSbiOrderRefNumber(), SBI_ORDER_REF_NUMBER);
        checkForLeadingTrailingAndSingleSpace(merchantOrderPaymentSearchRequest.getOrderRefNumber(), TransactionConstant.ORDER_REF_NUMBER);
        checkForLeadingTrailingAndSingleSpace(merchantOrderPaymentSearchRequest.getAtrn(), TransactionConstant.ATRN);
        checkForLeadingTrailingAndSingleSpace(merchantOrderPaymentSearchRequest.getBankRefNumber(), BANK_REF_NUMBER);
        checkForLeadingTrailingAndSingleSpace(merchantOrderPaymentSearchRequest.getTransactionStatus(), TransactionConstant.TRANSACTION_STATUS);
        checkForLeadingTrailingAndSingleSpace(merchantOrderPaymentSearchRequest.getOrderStatus(), TransactionConstant.ORDER_STATUS);
        checkForLeadingTrailingAndSingleSpace(merchantOrderPaymentSearchRequest.getRefundStatus(), TransactionConstant.REFUND_STATUS);
        checkForLeadingTrailingAndSingleSpace(merchantOrderPaymentSearchRequest.getPaymentStatus(), TransactionConstant.PAYMENT_STATUS);
        checkForLeadingTrailingAndSingleSpace(mId, MID);
        throwIfErrors();
    }

    /**
     * Validates the mandatory fields in the MerchantOrderPaymentSearchRequest object.
     * This method checks if both "From Date" and "To Date" fields are provided and valid.
     *
     * @param merchantOrderPaymentSearchRequest The request object containing the payment search data to be validated.
     */
    private void validateMandatoryFields(String mId, MerchantOrderPaymentSearchRequest merchantOrderPaymentSearchRequest) {
        logger.info("Starting validation for mandatory fields in the MerchantOrderPaymentSearchRequest.");
        checkMandatoryField(merchantOrderPaymentSearchRequest.getFromDate(), "From Date");
        checkMandatoryField(merchantOrderPaymentSearchRequest.getToDate(), "To Date");
        checkMandatoryField(mId, MID);
        throwIfErrors();
    }
}

