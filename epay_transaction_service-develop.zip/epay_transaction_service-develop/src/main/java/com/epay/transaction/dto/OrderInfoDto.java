package com.epay.transaction.dto;

import com.epay.transaction.util.enums.OrderStatus;
import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * Class Name: OrderInfoDto
 * *
 * Description: This class contains details related to order details.
 * *
 * Author: Gireesh M
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Data
@AllArgsConstructor
public class OrderInfoDto {
    private String sbiOrderId;
    private String merchantOrderNumber;
    private OrderStatus orderStatus;
    private String currency;
    private String otherDetails;
}
