package com.epay.transaction.etl.producer;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * Class Name: public class PaymentPushVerificationProducer extends PaymentProducer.
 * *
 * Description: The implementation is for produce payment push verification.
 * *
 * Author: Gireesh M
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Component
@RequiredArgsConstructor
public class PaymentPushVerificationProducer extends TransactionProducer<Map<String, Object>> {
    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());

    private final ObjectMapper objectMapper;

    @Override
    public void publish(String requestType, String routingKey, Map<String, Object> message) {
        try {
            logger.debug("Payment push verification published for requestType : {}, routingKey : {} and value : {}", requestType, routingKey, message);
            kafkaMessagePublisher.publish(topics.getPaymentPushVerificationTopic(), getRoutingKey("paymentPushVerification", requestType, routingKey), objectMapper.writeValueAsString(message));
        } catch (Exception ex) {
            logger.error("Error in publish payment push verification message, TransactionEmailDto {}", message, ex.getMessage());
        }
    }
}
