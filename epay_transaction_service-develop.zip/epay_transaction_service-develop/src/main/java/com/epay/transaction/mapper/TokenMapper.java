package com.epay.transaction.mapper;

import com.epay.transaction.dto.DeviceDetailsDto;
import com.epay.transaction.dto.TokenDto;
import com.epay.transaction.entity.Token;
import com.epay.transaction.entity.TransactionDeviceInfo;
import com.epay.transaction.util.DateTimeUtils;
import org.mapstruct.Builder;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

/**
 * Class Name: TokenMapper
 * *
 * Description: Define alle pojo to pojo mapping here.
 * *
 * Author: VShilpa Kothre
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Mapper(builder = @Builder(disableBuilder = true), componentModel = "spring", imports = DateTimeUtils.class)
public interface TokenMapper {

    /**
     * Converts a TokenDto object to a Token entity.
     *
     * @param tokenDto the TokenDto object to be converted
     * @return the corresponding Token entity
     */
    Token dtoToEntity(TokenDto tokenDto);

    /**
     * Converts a Token entity to a TokenDto object.
     *
     * @param token the Token entity to be converted
     * @return the corresponding TokenDto object
     */
    TokenDto entityToDto(Token token);

    /**
     * Converts a DeviceDetailsDto object to a TransactionDeviceInfo entity.
     *
     * @param deviceDetailsDto the DeviceDetailsDto object to be converted
     * @return the corresponding TransactionDeviceInfo entity
     */
    @Mapping(target = "createdDate", expression = "java(DateTimeUtils.getCurrentTimeInMills())")
    TransactionDeviceInfo dtoToEntity(DeviceDetailsDto deviceDetailsDto);

}