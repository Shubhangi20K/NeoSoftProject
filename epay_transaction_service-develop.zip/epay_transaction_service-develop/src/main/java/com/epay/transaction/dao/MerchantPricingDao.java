package com.epay.transaction.dao;

import com.epay.transaction.dto.MerchantPricingDto;
import com.epay.transaction.entity.MerchantOrderHybridFee;
import com.epay.transaction.externalservice.response.admin.MerchantPricingResponse;
import com.epay.transaction.model.request.MerchantPricingRequest;
import com.epay.transaction.repository.MerchantOrderHybridFeeRepository;
import com.epay.transaction.util.TransactionConstant;
import com.sbi.epay.authentication.providers.EPayTokenProvider;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
/**
 * Class Name:MerchantPricingDao
 * *
 * Description: this class is used for getEncryptedAESKey,saveMerchantOrderPricing and getValidMerchantPricingStructure
 * *
 * Author:NIRMAL GURJAR
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
@Component
@RequiredArgsConstructor
public class MerchantPricingDao {

    private final MerchantOrderHybridFeeRepository merchantOrderHybridFeeRepository;
    private final AdminDao adminDao;
    private final EPayTokenProvider ePayTokenProvider;
    private final TokenDao tokenDao;
    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());


    /**
     * Method name:getEncryptedAESKey
     * Description:This method retrieves the encrypted AES key for encryption/decryption operations from the token DAO.
     *
     * @return String The encrypted AES key for the encryption/decryption process.
     */
    public String getEncryptedAESKey() {
        logger.info("Fetching the encrypted AES key using the token: {}", ePayTokenProvider.getToken());
        return tokenDao.getEncryptionAESKey(ePayTokenProvider.getToken());
    }

    /**
     * Method name:saveMerchantOrderPricing
     * Description:This method saves the merchant order pricing details to the database.
     * It processes the given merchant pricing request, pricing structure, and DTO to create a new `MerchantOrderHybridFee` object,
     * which contains the merchant's order pricing information, including bearable amounts, fees, and tax rates.
     * The created `MerchantOrderHybridFee` object is then persisted in the database.
     *
     * @param merchantPricingRequest The request containing the pricing information for the merchant's order.
     * @param merchantPricingDto The DTO containing the detailed pricing breakdown for the merchant's order.
     * @param pricingStructure The structure containing the pricing details, such as bearable amounts, tax rates, and limits.
     */
    public void saveMerchantOrderPricing(MerchantPricingRequest merchantPricingRequest, MerchantPricingDto merchantPricingDto, MerchantPricingResponse pricingStructure) {
        MerchantOrderHybridFee merchantOrderHybridFee = MerchantOrderHybridFee.builder().atrnNum(merchantPricingRequest.getAtrn()).mId(merchantPricingRequest.getMId()).bearableEntity(pricingStructure.getBearableEntity()).bearableComponent(pricingStructure.getBearableComponent()).bearableAmountCutoff(merchantPricingDto.getBearableCutOffAmt()).bearableRateType(pricingStructure.getBearableType()).bearablePercentageRate(pricingStructure.getBearablePercentageRate()).bearableFlatRate(pricingStructure.getBearableFlatRate()).merchantFeeBearableAbs(merchantPricingDto.getMerchantBearableAmt()).customerFeeBearableAbs(merchantPricingDto.getCustomerBearableAmt()).merchantGstBearableAbs(merchantPricingDto.getMerchantBearableServiceTax()).customerGstBearableAbs(merchantPricingDto.getCustomerBearableServiceTax()).gstRate(pricingStructure.getServiceTax()).bearableLimit(pricingStructure.getBearableLimit()).createdBySessionId(TransactionConstant.PRICING_SERVICE_IDENTIFIER).processFlag(pricingStructure.getProcessFlag()).build();
        merchantOrderHybridFeeRepository.save(merchantOrderHybridFee);
    }

    /**
     * Method name:getValidMerchantPricingStructure
     * Description:This method retrieves the valid merchant pricing structure based on the provided merchant pricing request.
     * It calls the DAO layer to fetch the pricing structure details for the given merchant request.
     *
     * @param merchantPricingRequest The request containing merchant-specific details to fetch the valid pricing structure.
     * @return MerchantPricingResponse The valid merchant pricing structure that corresponds to the given request.
     */
    public MerchantPricingResponse getValidMerchantPricingStructure(MerchantPricingRequest merchantPricingRequest) {
        logger.info("Fetching valid merchant pricing structure ");
        return adminDao.getValidMerchantPricingStructure(merchantPricingRequest);
    }
}
