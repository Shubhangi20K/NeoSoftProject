package com.epay.transaction.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.UUID;

/**
 * Class Name:TransactionDeviceInfo
 * *
 * Description:
 * *
 * Author:Shubhangi Kurelay
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */

@Data
@Entity
@Builder
@Table(name = "DEVICE_DETAILS")
@AllArgsConstructor
@NoArgsConstructor
public class TransactionDeviceInfo {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(nullable = false, updatable = false, unique = true)
    private UUID id;

    private String orderHash;

    private String clientIp;

    @Lob
    private byte[] deviceDetails;

    private Long createdDate;

}
