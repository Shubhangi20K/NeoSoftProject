package com.epay.transaction.service;

import com.epay.transaction.dao.PaymentCallbackForwardDao;
import com.epay.transaction.externalservice.request.payment.PaymentRequestResendCard;
import com.epay.transaction.externalservice.request.payment.PaymentRequestVerifyCard;
import com.epay.transaction.model.request.EncryptedRequest;
import com.epay.transaction.model.request.PaymentCallBackRequest;
import com.epay.transaction.model.response.EncryptedResponse;
import com.epay.transaction.model.response.TransactionResponse;
import com.epay.transaction.util.TransactionConstant;
import com.epay.transaction.util.TransactionUtil;
import com.epay.transaction.validator.PaymentCallbackValidator;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

import static com.epay.transaction.util.EncryptionDecryptionUtil.encryptValue;
import static com.epay.transaction.util.TransactionConstant.RESPONSE_SUCCESS;


/**
 * Class Name:PaymentCallbackForwardService
 * *
 * Description:
 * *
 * Author:V1014352(Ranjan Kumar)
 * <p>
 * Copyright (c) 2025 [State Bank of INdia]
 * All right reserved
 * *
 * Version:1.0
 */
@Service
@RequiredArgsConstructor
public class PaymentCallbackForwardService {
    private final PaymentCallbackForwardDao paymentCallbackForwardDao;
    private final PaymentCallbackValidator paymentCallbackValidator;
    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());

    /**
     * @param paymentCallBackRequest:
     * @return RedirectView
     */
    public String processCallbackResponse(PaymentCallBackRequest paymentCallBackRequest) {
        logger.info("Payment Initiation Start for INB callBack {} ", paymentCallBackRequest);
        // validate paymentCallBackRequest
        paymentCallbackValidator.validatePaymentRequest(paymentCallBackRequest);
        //get mek from Mid
        String mek = paymentCallbackForwardDao.getMerchantMekKey(paymentCallBackRequest.getMId());
        //encrypt paymentCallBackRequest by mek
        String encryptedFinalResponse = encryptValue(mek, TransactionUtil.toJson(paymentCallBackRequest));

        logger.info("Payment Initiation Start for  callBack {} ", encryptedFinalResponse);
        return paymentCallbackForwardDao.buildEncryptedResponse(paymentCallBackRequest, encryptedFinalResponse, TransactionConstant.MERCHANT_PUSH_RESPONSE_UI);
    }


    /**
     * @param encryptedRequest:String
     * @return EncryptedResponse
     */
    public TransactionResponse<EncryptedResponse> processCardRupayOtpResponsePayload(EncryptedRequest encryptedRequest) {
        String aesKey = paymentCallbackForwardDao.getEncryptedAESKey();
        PaymentRequestVerifyCard paymentRequestVerifyCard = TransactionUtil.buildRequestByEncryptRequest(encryptedRequest.getEncryptedRequest(), aesKey, PaymentRequestVerifyCard.class);
        EncryptedResponse encryptedResponse = paymentCallbackForwardDao.processRupayCardVerifyOtp(paymentRequestVerifyCard, aesKey);
        return TransactionResponse.<EncryptedResponse>builder().status(RESPONSE_SUCCESS).data(List.of(encryptedResponse)).count(1L).build();
    }

    /**
     * @param encryptedRequest:String
     * @return EncryptedResponse
     */
    public TransactionResponse<EncryptedResponse> getRupayCardCallBackResentOtpResponse(EncryptedRequest encryptedRequest) {
        String aesKey = paymentCallbackForwardDao.getEncryptedAESKey();
        PaymentRequestResendCard paymentRequestResendCard = TransactionUtil.buildRequestByEncryptRequest(encryptedRequest.getEncryptedRequest(), aesKey, PaymentRequestResendCard.class);
        EncryptedResponse encryptedResponse = paymentCallbackForwardDao.processRupayCardResendOtp(paymentRequestResendCard, aesKey);
        return TransactionResponse.<EncryptedResponse>builder().status(RESPONSE_SUCCESS).data(List.of(encryptedResponse)).count(1L).build();
    }


}