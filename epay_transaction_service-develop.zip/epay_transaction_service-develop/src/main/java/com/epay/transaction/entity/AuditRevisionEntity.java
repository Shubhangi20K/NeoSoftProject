package com.epay.transaction.entity;

import com.epay.transaction.config.listener.AuditRevisionListener;
import jakarta.persistence.*;
import lombok.Data;
import org.hibernate.envers.RevisionEntity;
import org.hibernate.envers.RevisionNumber;
import org.hibernate.envers.RevisionTimestamp;

@Entity
@RevisionEntity(AuditRevisionListener.class)
@Table(name = "audit_revision_info")
@Data
public class AuditRevisionEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "custom_rev_id_seq")
    @SequenceGenerator(name = "custom_rev_id_seq", sequenceName = "custom_rev_id_seq", allocationSize = 1)
    @RevisionNumber
    @Column(name = "audit_revision_id")
    private Long revisionId;

    @RevisionTimestamp
    @Column(name = "audit_revision_time")
    private Long revisionTime;

    private String entityClassName;

}
