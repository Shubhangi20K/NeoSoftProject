package com.epay.transaction.repository;

import com.epay.transaction.entity.BulkRefundBookingDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

/**
 * Class Name:BulkRefundDetailsRepository
 * *
 * Description:
 * *
 * Author:Nirmal
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */

@Repository
public interface BulkRefundDetailsRepository extends JpaRepository<BulkRefundBookingDetails, UUID> {
    List<BulkRefundBookingDetails> findByBulkIdAndRefundStatus(String bulkId, String refundStatus);

    List<BulkRefundBookingDetails> findByBulkId(String bulkId);

    @Query("""
        SELECT 
            COUNT(d) as totalProcessed, 
            SUM(CASE WHEN d.refundStatus = 'SUCCESS' THEN 1 ELSE 0 END) as passCount, 
            SUM(CASE WHEN d.refundStatus = 'FAILED' THEN 1 ELSE 0 END) as failCount 
        FROM BulkRefundBookingDetails d 
        WHERE d.bulkId = :bulkId 
        AND d.refundStatus IN ('SUCCESS', 'FAILED')
    """)
    Object[] getProcessedAndFailedCounts(@Param("bulkId") String bulkId);
}