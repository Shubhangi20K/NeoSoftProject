package com.epay.transaction.externalservice.request.payment;

import lombok.Data;

/**
 * Class Name:PaymentStatusRequest
 * *
 * Description:
 * *
 * Author:V1014352(Ranjan Kumar)
 * <p>
 * Copyright (c) 2025 [State Bank of INdia]
 * All right reserved
 * *
 * Version:1.0
 */
@Data
public class PaymentStatusRequest {
    private String atrn;
    private String status;
}
