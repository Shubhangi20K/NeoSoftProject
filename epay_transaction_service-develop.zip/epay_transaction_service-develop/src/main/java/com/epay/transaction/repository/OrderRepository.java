package com.epay.transaction.repository;

import com.epay.transaction.entity.Order;
import com.epay.transaction.util.enums.OrderStatus;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * Class Name: OrderRepository
 * *
 * Description: OrderRepository class for manage order data persistence and retrieval in a database.
 * *
 * Author: V1012904(Shital suryawanshi)
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */

@Repository
public interface OrderRepository extends JpaRepository<Order, String> {

    Optional<Order> findByOrderHashAndStatusAndExpiryGreaterThan(String orderHash, OrderStatus status, Long currentTimeStamp);

    @Query("SELECT t FROM Order t WHERE t.orderHash =:orderHash AND t.status IN :orderStatus AND (t.orderRetryCount is null OR t.orderRetryCount < 4)")
    Optional<Order> findOrderByHashAndStatus(@Param("orderHash") String orderHash, List<OrderStatus> orderStatus);

    @Query("SELECT t FROM Order t WHERE t.mId = :mId AND t.orderRefNumber =:orderRefNumber AND t.sbiOrderRefNumber IN :sbiOrderRefNumber")
    Optional<Order> findBymIdAndOrderRefNumberAndSbiOrderRefNumber(@Param("mId") String mId, @Param("orderRefNumber") String orderRefNumber, @Param("sbiOrderRefNumber") String sbiOrderRefNumber);

    Optional<Order> findBymIdAndSbiOrderRefNumber(String mId, String sbiOrderRefNumber);

    Optional<Order> findBySbiOrderRefNumber(String sbiOrderRefNumber);

    long countSbiOrderRefNumberBymIdAndOrderRefNumber(String mId, String orderRefNumber);

    boolean existsBymIdAndOrderRefNumberAndStatus(String mId, String orderRefNumber, OrderStatus status);

    List<Order> findAll(Specification<Order> specification);

}

