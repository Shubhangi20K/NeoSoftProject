package com.epay.transaction.util;

import lombok.experimental.UtilityClass;

/**
 * Class Name:TransactionConstant
 * *
 * Description:this class contain TransactionConstant
 * *
 * Author:V1014352(Ranjan Kumar)
 * <p>
 * Copyright (c) 2024 [State Bank of India]
 * All right reserved
 * *
 * Version:1.0
 */
@UtilityClass
public class TransactionConstant {

    public static final int RESPONSE_SUCCESS = 1;
    public static final int RESPONSE_FAILURE = 0;
    public static final String SBIEPAY = "SBIEPay";

    public static final String SBI_NAME = "State Bank of India";
    public static final String TRANSACTION_PUSH_RESPONSE = "P";
    public static final String PAY_PROC_ID_SELF = "SELF";
    public static final String PAY_PROC_ID_BHIMQR = "BHIMQR";
    public static final String VALID_CUSTOMER = "valid customer";

    public static final String EMAIL_REGEX = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$";
    public static final String PHONE_REGEX = "^[1-9]\\d{9}";
    public static final String CARD_NUMBER_REGEX="^\\d{16}$";
    public static final String PIN_REGEX = "^\\d{6}$";
    public static final String GSTIN_REGEX = "\\d{2}[A-Z]{5}\\d{4}[A-Z]{1}[A-Z\\d]{1}[Z]{1}[A-Z\\d]{1}";
    public static final String SPECIAL_CHAR_REGEX = "[-+^=!/]*";
    public static final String ALPHABET_CHARS_REGEX = "^[a-zA-Z .]*$";
    public static final String ALLOWED_ALPHABET_REGEX = "^(?! )[A-Za-z  .-]+(?<! )$";
    public static final String ALT_NUMBER = "^[0-9]{15,16}$";
    public static final String CVV_NUMBER = "^\\s*[0-9]{3,4}\\s*$";
    public static final String YEAR_REGEX = "^\\s*(20[2-9][0-9]|2[1-9][0-9]{2})\\s*$";
    public static final String MONTH_REGEX = "^\\s*(0[1-9]|1[0-2])\\s*$";
    public static final String SPEC_CHARACTER_REGEX = "[a-zA-z ]+";
    public static final String AMOUNT_LENGTH_REGEX = "^\\d{1,18}(\\.\\d{1,2})?$";
    public static final String COMMENT_REGEX = "^[a-zA-Z0-9_.@/ ,\\-:]*$";
    public static final String ATRN_ARRN_REGEX = "^[a-zA-Z0-9]{20}$";
    public static final String CUSTOMER_ID_REGEX = "^[a-zA-Z0-9]*$";
    public static final String BANK_TRACE_NO_REGEX = "^[a-zA-Z0-9]*$";
    public static final String GTW_MAPSID_REGEX = "^\\s*[0-9]{1,20}\\s*$";
    public static final String ORDER_REFERENCE_NUMBER_REGEX = "^[a-zA-Z0-9]+$";
    public static final String URL_REGEX= "^(https?:\\/\\/)[^\\s]+$";
    public static final String INVALID_SPECIAL_CHAR_REGEX="^[a-zA-Z]+$";
    public static final String ALLOW_SPECIAL_CHAR_REGEX="^[a-zA-Z0-9_.@/ ,\\-:]*$";
    public static final int NAME_LENGTH = 100;
    public static final int EMAIL_LENGTH = 100;
    public static final int PAY_PROC_ID_TYPE_LENGTH = 5;
    public static final int CHANNEL_BANK_LENGTH = 100;
    public static final int OTHER_DETAILS_LENGTH =4000;
    public static final int OPERATING_MODE=5;
    public static final int ADDRESS_LENGTH = 255;
    public static final int COUNTRY_LENGTH = 50;
    public static final int COMMENT_LENGTH = 500;
    public static final int ATRN_ARRN_LENGTH = 20;
    public static final int CIN_LENGTH = 20;
    public static final int BANK_CODE_LENGTH = 20;
    public static final int OTHERDETAILS_LENGTH = 20;
    public static final int ORDER_RETRY_LENGTH = 1;
    public static final int BANKTRACE_LENGTH = 20;
    public static final int CUSTOMER_ID_LENGTH = 20;
    public static final int ORDER_REF_LENGTH = 50;
    public static final int DEFAULT_MAX_PAGE_SIZE = 1000;
    public static final int STATUS_LENGTH = 50;
    public static final int ORDER_HASH_LENGTH = 2000;
    public static final int GATEWAY_MAP_ID_LENGTH=5;
    public static final int GSTIN_LENGTH=15;
    public static final int PINCODE_LENGTH=6;
    public static final int PHONE_NUMBER_LENGTH=10;
    public static final int SBI_ORDER_REF_LENGTH = 20;
    public static final int REASON_LENGTH = 2000;
    public static final String TOKEN_INVALIDATED = "Token invalidated successfully";
    public static final String ORDER_STATUS_UPDATED = "Order Status updated Successfully.";
    public static final String PAYMENT_TYPE_VPA = "VPA";
    public static final String PAYMENT_TYPE_VISA = "VISA";
    public static final String PAYMENT_TYPE_MASTER = "MASTER";
    public static final String BEARABLE_COMPONENT_AMOUNT = "AMOUNT";
    public static final String BEARABLE_COMPONENT_FEE = "FEE";
    public static final String BEARABLE_LIMIT_LOWER = "LOWER";
    public static final String BEARABLE_LIMIT_HIGHER = "HIGHER";
    public static final int PAY_MODE_CODE_LENGTH = 10;
    public static final int BANK_REF_LENGTH = 50;

    public static final char TRANSACTION_PROCESSING_FLAG_HYBRID = 'H';
    public static final char MERCHANT_FEE_TYPE_PERCENTAGE = 'P';
    public static final char MERCHANT_FEE_TYPE_FLAT = 'F';
    public static final char BEARABLE_TYPE_FLAT = 'F';
    public static final char BEARABLE_TYPE_BUSINESS = 'B';
    public static final char BEARABLE_TYPE_PERCENTAGE = 'P';
    public static final char BEARABLE_ENTITY_MERCHANT = 'M';
    public static final char BEARABLE_ENTITY_CUSTOMER = 'C';

    public static final String[] BULK_REFUND_FILE_TYPES = {"text/csv", "csv"};
    public static final String BULK_REFUND_FILE = "Bulk refund file";
    public static final String BULK_REFUND_HEADERS = "Refund Type,Merchant Order ID,ATRN,Refund Amount,Refund Currency,Comments";
    public static final String IFSC_REGEX = "^[A-Za-z]{4}0[A-Z0-9a-z]{6}$";
    public static final String ACCOUNT_REGEX= "^[0-9]{9,18}$";

    public static final String PRICING_SERVICE_IDENTIFIER = "Pricing Service";
    public static final String PUSH_RESPONSE_STATUS_PENDING = "P";
    public static final String PUSH_RESPONSE_STATUS_SUCCESS = "Y";
    public static final String PUSH_RESPONSE_STATUS_FAILURE = "F";
    public static final String MERCHANT_PUSH_RESPONSE_FLAG = "Y";
    public static final int PUSH_RESPONSE_INITIAL_COUNT = 0;
    public static final int MAX_PUSH_RESPONSE_COUNT = 3;
    public static final String EMAIL_SMS_CONSENT = "Y";

    public static final String REQUEST_TYPE_SUCCESS = "TRANSACTION_SUCCESS";
    public static final String REQUEST_TYPE_FAILURE = "TRANSACTION_FAILURE";
    public static final String CONTENT_TYPE_CSV = "text/csv";
    public static final String SMALL_LETTERS_NOT_ALLOWED = "Small letters not allowed";
    public static final String CAPS_REGEX = "[A-Z]+";
    public static final String PAY_PROC_ID = "payProcId";
    public static final String ALTNUMBER = "altnumber";
    public static final String EXPIRY_MONTH = "Expiry Month";
    public static final String EXPIRY_YEAR = "Expiry Year";
    public static final String CARD_HOLDER_NAME = "cardHolderName";
    public static final String CVV = "CVV";
    public static final int CARD_NUMBER_LENGTH = 16;
    public static final int CVV_LENGTH_THREE = 3;
    public static final int EXPIRY_MONTH_LENGTH = 2;
    public static final int EXPIRY_YEAR_LENGTH = 4;
    public static final int CARD_HOLDER_LENGTH = 200;
    public static final String MID = "MId";
    public static final int MID_LENGTH = 7;
    public static final String ALLOWED_DIGIT_REGEX = "^\\d+$";
    public static final String CURRENCY_CODE = "Currency Code";
    public static final String ORDER_REF_NUMBER = "Order Reference Number";
    public static final String RETURN_URL = "Return Url";
    public static final String ORDER_AMOUNT = "Order Amount";
    public static final String FIELD_ORDER_REF_NUMBER = "orderRefNumber";
    public static final String FIELD_EMAIL= "Email";
    public static final String FIELD_CUSTOMER_ID= "Customer Id";
    public static final String FIELD_PHONE= "Phone Number";
    public static final String FIELD_COUNTRY= "Country";
    public static final String FIELD_PINCODE= "PinCode";
    public static final String FIELD_GST= "GST Number";
    public static final String FIELD_CUSTOMER= "CustomerName";
    public static final String ORDER_REF_NUMBER_MESSAGE = "orderRefNumber";
    public static final String SBI_ORDER_REF_NUMBER_MESSAGE = "sbiOrderRefNumber";
    public static final String ATTEMPTS_APPLICABLE="Y";
    public static final String PAYMODE= "payMode";
    public static final String ACCOUNT_IDENTIFIER="Account Identifier";
    public static final String AMOUNT_DECIMAL_MESSAGE=" after decimal";
    public static final String AMOUNT_BEFORE_DECIMAL_MESSAGE=" before decimal";
    public static final String AMOUNT_GREATER_THAN_ZERO="Amount must be greater than 0";
    public static final String ORDER_EXPIRY_GREATER_THAN_ZERO="Order Expiry must be greater than 0";
    public static final String CLIENT_Id = "SBI";
    public static final String DESTINATION = "DCMS";
    public static final String TXT_TYPE = "LIMIT_FLAG";
    public static final String TXN_SUB_TYPE = "ENQUIRY";
    public static final String ACTION_TYPE = "INQUIRY";
    public static final String EIS_SOURCE_ID = "IN";
    public static final String SOURCE_ID_EY = "EY";
    public static final String SIGN_ALGO = "SHA256withRSA";
    public static final String CIPHER_RSA_ECB = "RSA/ECB/OAEPPADDING";
    public static final int AES_KEY_SIZE = 256;
    public static final String FLAG_Y = "Y" ;
    public static final String BULK_REFUND_SERVICE="Bulk Refund Service";
    public static final String BLOCK_ACTION = "BLOCK";
    public static final String FIELD_CUSTOMER_NAME= "customerName";
    public static final String FIELD_ADDRESS1= "address1";
    public static final String FIELD_GSTN= "gstIn";
    public static final String FIELD_GSTN_ADDRESS= "gstInAddress";
    public static final String FIELD_ADDRESS2= "address2";
    public static final String FIELD_CITY= "city";
    public static final String FIELD_STATE= "state";

    //pricing fields
    public static final String PAY_PROC_TYPE_FIELD = "payProcType";
    public static final String TRANSACTION_AMOUNT_FIELD = "transactionAmount";
    public static final String PAY_MODE_CODE_FIELD = "payModeCode";
    public static final String GATEWAY_MAPS_ID_FIELD = "gtwMapsId";

    //Order Fields
    public static final int RETURN_URL_LENGTH = 2000;
    public static final int PAYMODE_LENGTH = 50;
    public static final int CURRENCY_CODE_LENGTH=3;
    public static final int IFSC_CODE_LENGTH = 11;
    public static final int SBI_ACCOUNT_NUMBER_LENGTH = 13;
    public static final int OTHER_ACCOUNT_NUMBER_LENGTH = 16;
    public static final int ACCOUNT_IDENTIFIER_LENGTH=30;
    public static final int AMOUNT_LENGTH=18;
    public static final int AMOUNT_LENGTH_AFTER_DECIMAL=2;
    public static final int REFUND_TYPE_LENGTH = 50;

    //access token fields
    public static final String MERCHANT_API_KEY_ID = "Merchant-API-Key-Id";
    public static final String MERCHANT_API_KEY_SCRT = "Merchant-API-Key-Secret";

    public static final String ATRN = "atrn";

    public static final String STATUS = "status";

    public static final String CALBACK_RUPAY_VERIFY_OTP_ENDPOINT =  "/cards/sbi/rupay/verify-otp";
    public static final String CALBACK_RUPAY_RESENT_OTP_ENDPOINT=  "/cards/sbi/rupay/resend-otp";

    public static final String MERCHANT_PUSH_RESPONSE_UI=  "https://dev.epay.sbi/ui/channel/sbi";

    public static final String MERCHANT_ORDER_PAYMENT = "Merchant Order Payment";

    //vpa validation fields
    public static final String MID_CONST = "mId";
    public static final String UPI_VIRTUAL_ADDRESS = "upiAddress";
    public static final String UPI_PAY_GTW_ID = "payGtwMapId";
    public static final String UPI_INVALID_FORMAT = "Invalid format";
    public static final int MID_MAX_LENGTH = 7;
    public static final int VIRTUAL_ADDRESS_MAX_LENGTH = 321;
    public static final int PAY_GTW_LENGTH = 5;
    public static final String NUMBER_ONLY = "^[0-9]*$";
    public static final String BIGDECEMAL_ONLY = "^[0-9](.[0-9]*)?";
    public static final String VPA_REGEX = "^[0-9A-Za-z.-]{2,256}@[A-Za-z]{2,64}$";

    //EIS card validation fields
    public static final String CARD_NUMBER="cardNumber";
    public static final String  ENCRYPT_REQUEST="encryptedRequest";
    public static final String GSTIN_NUMBER="gstInNumber";

    public static final int UPI_STATUS_LENGTH = 1;
    public static final String GENERIC_ENUM_REGEX = "^[A-Z_]+$";

    public static final String TRANSACTION_STATUS = "transactionStatus";
    public static final String ORDER_STATUS = "orderStatus";
    public static final String BANK_REFERENCE_NUMBER_REGEX = "^[a-zA-Z0-9]+$";
    public static final int BANK_REFERENCE_LENGTH = 50;
    public static final String TRANSACTION_STATUS_REGEX = "^[a-zA-Z_]*$";
    public static final String ORDER_STATUS_REGEX = "^[a-zA-Z_]*$";
    public static final int ORDER_STATUS_LENGTH = 20;
    public static final String REFUND_STATUS_REGEX = "^[a-zA-Z_]*$";
    public static final String REFUND_STATUS = "refundStatus";
    public static final String PAYMENT_STATUS_REGEX = "^[a-zA-Z_]*$";
    public static final String PAYMENT_STATUS = "paymentStatus";
    public static final int BULK_REFUND_FILE_NAME_MAX_LENGTH = 100;
    public static final String BULK_REFUND_FILE_NAME_REGEX = "^[A-Za-z0-9]+(\\.[A-Za-z0-9]+)$";
    public static final int REFUND_STATUS_MAX_LENGTH = 50;
    public static final String BULK_ID= "bulkId";
    public static final int BULK_ID_MAX_LENGTH= 50;
    public static final int REFUND_STATUS_LENGTH = 50;
    public static final int PAYMENT_STATUS_LENGTH = 50;
    public static final String SBIORDER_REFERENCE_NUMBER_REGEX = "^[a-zA-Z0-9]+$";
    public static final String SBIORDER_REFERENCE_NUMBER_STATUS = "sbiOrderRefNumber";
    public static final int SBIORDER_REFERENCE_NUMBER_LENGTH = 50;
    public static final int MAX_PAGE_SIZE = 100;

    public static final int ALLOWED_FROM_TO_DATE_DIFF = 31;
    public static final int ALLOWED_FROM_DATE_DIFF = 365;

    public static final String EXTERNAL_SERVICE = "External service";
    public static final String TXN_FAILED_DVP = "TXN_FAILED_DVP";
    public static final String TXN_FAILED_NDVP = "TXN_FAILED_NDVP";
    public static final String TXN_SUCCESS = "TXN_SUCCESS";
    public static final String RECON_FAILED_RECORD_KEY = "FailedRfdId";
    public static final String RECON_FAIL = "RECON_FAIL" ;
    public static final String DVP = "DVP";

    public static final String RECON_REFUND_ADJUSTED_CONFIRMATION_KEY = "RefundAdjustedConfirmation";
    public static final String PAYOUT_ID = "PAYOUT_ID";

    public static final String CREATED_DATE = "createdDate";

}