package com.epay.transaction.service;

import com.epay.transaction.dao.MerchantDao;
import com.epay.transaction.dao.OrderDao;
import com.epay.transaction.dao.TokenDao;
import com.epay.transaction.dto.OrderDto;
import com.epay.transaction.externalservice.request.merchant.UserValidationRequest;
import com.sbi.epay.authentication.model.EPayPrincipal;
import com.sbi.epay.authentication.service.AuthenticationUserService;
import com.sbi.epay.authentication.util.enums.TokenType;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Optional;

/**
 * Class Name:SecurityService
 * *
 * Description:
 * *
 * Author:V1014352(Ranjan Kumar)
 * <p>
 * Copyright (c) 2024 [State Bank of INdia]
 * All right reserved
 * *
 * Version:1.0
 */

@Service
@RequiredArgsConstructor
public class SecurityService implements AuthenticationUserService {

    private final OrderDao orderDao;
    private final TokenDao tokenDao;
    private final MerchantDao merchantDao;

    @Override
    public Optional<EPayPrincipal> loadUserByUserName(String authKey) {
        String tokenType = authKey.substring(authKey.indexOf(":") + 1);
        return switch (TokenType.valueOf(tokenType)) {
            case ACCESS -> validateAccessTokenRequest(authKey);
            case TRANSACTION -> validateTransactionTokenRequest(authKey);
            case USER -> validateUserTokenRequest(authKey);
        };
    }

    @Override
    public boolean isTokenInValid(String token, String tokenType) {
        return switch (TokenType.valueOf(tokenType)) {
            case ACCESS, TRANSACTION -> !tokenDao.findByGeneratedTokenAndStatus(token, TokenType.valueOf(tokenType));
            case USER -> !merchantDao.validateMerchantToken(token);
        };
    }

    private Optional<EPayPrincipal> validateAccessTokenRequest(String authKey) {
        EPayPrincipal authenticateEntity = new EPayPrincipal();
        if (tokenDao.isMerchantExistByMid(authKey.substring(0, authKey.indexOf(":")))) {
            authenticateEntity.setMId(authKey.substring(0, authKey.indexOf(":")));
            authenticateEntity.setAuthenticationId(authKey.substring(0, authKey.indexOf(":")));
        }
        return Optional.of(authenticateEntity);
    }

    private Optional<EPayPrincipal> validateTransactionTokenRequest(String authKey) {
        EPayPrincipal authenticateEntity = new EPayPrincipal();
        OrderDto order = orderDao.getValidOrderBySBIOrderRefNumber(authKey.substring(0, authKey.indexOf(":")));
        authenticateEntity.setMId(order.getMId());
        authenticateEntity.setOrderRef(order.getOrderRefNumber());
        authenticateEntity.setAuthenticationId(authKey.substring(0, authKey.indexOf(":")));
        return Optional.of(authenticateEntity);
    }

    private Optional<EPayPrincipal> validateUserTokenRequest(String authKey) {
        EPayPrincipal authenticateEntity = new EPayPrincipal();
        UserValidationRequest userValidationRequest = UserValidationRequest.builder().userName(authKey.substring(0, authKey.indexOf(":"))).requestType("LOGIN").build();
        if (merchantDao.validateMerchantUser(userValidationRequest)) {
            authenticateEntity.setAuthenticationId(authKey.substring(0, authKey.indexOf(":")));
        }
        return Optional.of(authenticateEntity);
    }


}