package com.epay.transaction.controller;

import com.epay.transaction.model.request.EncryptedRequest;
import com.epay.transaction.model.response.EncryptedResponse;
import com.epay.transaction.model.response.TransactionResponse;
import com.epay.transaction.service.PaymentService;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Class Name: PaymentController
 * *
 * Description:This controller is used for transaction services
 * *
 * Author: V1018400 (Bhushan Wedekar)
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@RestController
@RequiredArgsConstructor
@Validated
@RequestMapping("/payment")
public class PaymentController {

    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private final PaymentService paymentService;

    /**
     * Method name:markTransactionStatusFail
     * Description:This method handles the request to update the status of a merchant's transaction to "fail." It receives an encrypted
     * request, processes the decryption, and calls the service to update the transaction status accordingly.
     *
     * @param encryptedRequest The encrypted request containing the necessary data to update the transaction status.
     * @return TransactionResponse containing the status of the transaction and an appropriate message.
     */
    @PostMapping("/update-fail")
    @Operation(summary = "Update MerchantOrderPayment status")
    @PreAuthorize("hasAnyRole('TRANSACTION')")
    public TransactionResponse<EncryptedResponse> updateTransactionFail(@Valid @RequestBody EncryptedRequest encryptedRequest) {
        logger.info("Start: Updating transaction status to 'fail'");
        return paymentService.updateTransactionFail(encryptedRequest);
    }

    /**
     * Method name:getTransactionDetails
     * Description:This method handles the request and get transaction details. It receives an encrypted
     * request, processes the decryption, and calls the service get transaction details against atrn.
     *
     * @param encryptedRequest The encrypted request containing the necessary data to get the transaction details.
     * @return TransactionResponse containing the transaction .
     */
    @PostMapping("/search")
    @Operation(summary = "get MerchantOrderPayment ")
    public TransactionResponse<EncryptedResponse> getTransactionDetails(@Valid @RequestBody EncryptedRequest encryptedRequest) {
        logger.info("Start: get merchantOrderPaymentDetails");
        return paymentService.getMerchantOrderPaymentDetails(encryptedRequest);
    }

}
