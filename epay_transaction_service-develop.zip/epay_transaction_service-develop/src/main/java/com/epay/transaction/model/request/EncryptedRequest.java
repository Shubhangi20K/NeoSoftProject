package com.epay.transaction.model.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

import java.io.Serializable;

import static com.epay.transaction.util.TransactionErrorConstants.ENCRYPTED_REQUEST_IS_REQUIRED;

/**
 * Class Name: EncryptedMerchantPricingRequest
 * *
 * Description:
 * *
 * Author: V1017903(bhushan wadekar)
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Data
public class EncryptedRequest implements Serializable {

    @NotBlank(message = ENCRYPTED_REQUEST_IS_REQUIRED)
    private String encryptedRequest;
}
