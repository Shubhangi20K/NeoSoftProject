package com.epay.transaction.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class EisApiHistoryDto {

    private UUID id;
    @JsonProperty("mId")
    private String mId;
    private String sbiOrderRefNumber;
    private String gstIn;
    private String email;
    private String requestType;
    private String requestJson;
    private String responseJson;
}
