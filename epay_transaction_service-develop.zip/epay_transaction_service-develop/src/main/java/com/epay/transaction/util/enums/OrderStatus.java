package com.epay.transaction.util.enums;

import com.epay.transaction.exceptions.TransactionException;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.text.MessageFormat;
import java.util.Arrays;

import static com.epay.transaction.util.TransactionErrorConstants.INVALID_ERROR_CODE_NO_REASON;
import static com.epay.transaction.util.TransactionErrorConstants.INVALID_ERROR_MESSAGE_NO_REASON;

/**
 * enum Name: OrderStatus
 * *
 * Description: OrderStatus enum for order status.
 * *
 * Author: V1012904(Shital suryawanshi)
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Getter
@AllArgsConstructor
public enum OrderStatus {
    CREATED("created"), ATTEMPTED("attempted"), FAILED("failed"),
        EXPIRED("expired"),  PAID("paid"), ATTEMPT_FAIL("attemptFail");//ATTEMPT("attempt"),

    private final String label;

    public static OrderStatus getOrderStatus(String label) {
        return Arrays.stream(values()).filter(p -> p.getLabel().equalsIgnoreCase(label)).findFirst().orElseThrow(() -> new TransactionException(INVALID_ERROR_CODE_NO_REASON, MessageFormat.format(INVALID_ERROR_MESSAGE_NO_REASON, "Order Status", label)));
    }
}
