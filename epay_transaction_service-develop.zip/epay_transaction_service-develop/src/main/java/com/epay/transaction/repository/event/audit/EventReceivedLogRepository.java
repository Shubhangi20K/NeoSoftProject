package com.epay.transaction.repository.event.audit;

import com.epay.transaction.entity.event.audit.EventReceivedLog;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

/**
 * Class Name: EventReceivedLogRepository
 * <p>
 * Description: interface for  event receive logs data persistence and retrieval in a database.
 * <p>
 * Copyright (c) [2024] [State Bank of India]
 * All rights reserved.
 * <p>
 * Author:@V0000001(Shilpa Kothre)
 * Version:1.0
 */
public interface EventReceivedLogRepository extends JpaRepository<EventReceivedLog, UUID> {
}
