package com.epay.transaction.model.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Class Name:PaymentUPIVpaRequest
 * *
 * Description:
 * *
 * Author:V1018841(Saurabh Mahto)
 * <p>
 * Copyright (c) 2025 [State Bank of INdia]
 * All right reserved
 * *
 * Version:1.0
 */

@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
public class SbiUPIVpaRequest {
    @JsonProperty(value = "mId")
    private String mId;
    private String virtualAddress;
    private String payGtwMapId;
}
