/**
 * Copyright (c) [2024] [State Bank of India]
 * All rights reserved.
 * <p>
 * Author:@V0000001(Shilpa Kothre)
 * <p>
 * Version:1.0
 * /
 */

package com.epay.transaction.entity;

import com.epay.transaction.config.listener.AuditRevisionListener;
import com.epay.transaction.util.enums.TokenStatus;
import com.sbi.epay.authentication.util.enums.TokenType;
import jakarta.persistence.*;
import lombok.*;
import lombok.experimental.SuperBuilder;
import org.hibernate.envers.AuditTable;
import org.hibernate.envers.Audited;

import java.util.UUID;

@EqualsAndHashCode(callSuper = true)
@Getter
@Setter
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Audited
@AuditTable(value = "TOKEN_AUDIT")
@Table(name = "TOKEN")
public class Token extends AuditEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;
    @Column(name = "MERCHANT_ID")
    private String mId;
    @Enumerated(EnumType.STRING)
    private TokenType tokenType;
    private String orderHash;
    private String generatedToken;
    private Long tokenExpiryTime;
    private boolean isTokenValid;
    private String failedReason;
    private String remarks;
    private Long expiredAt;
    @Enumerated(EnumType.STRING)
    private TokenStatus status;
    private String aesKey;

    @PrePersist
    @PreUpdate
    public void setEntityNameForRevision() {
        AuditRevisionListener.setEntityName(this.getClass().getSimpleName());
    }

}
