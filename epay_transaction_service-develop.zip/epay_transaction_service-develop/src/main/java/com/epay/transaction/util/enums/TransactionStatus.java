package com.epay.transaction.util.enums;

import java.util.Arrays;

public enum TransactionStatus {
    BOOKED, BOOKED_FAIL,
    PAYMENT_INITIATION_START, PAYMENT_INITIATED_FAIL,
    PAYMENT_IN_VERIFICATION, PAYMENT_VERIFIED, PAYMENT_VERIFICATION_FAIL,
    SUCCESS, SETTLED,FAILED,PENDING;

    public static boolean isValid(String status) {
        return Arrays.stream(TransactionStatus.values())
                .anyMatch(ps -> ps.name().equalsIgnoreCase(status));
    }
}
