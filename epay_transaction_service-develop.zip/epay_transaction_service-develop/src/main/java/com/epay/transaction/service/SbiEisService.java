package com.epay.transaction.service;

import com.epay.transaction.config.TransactionConfig;
import com.epay.transaction.dao.SbiEisDao;
import com.epay.transaction.dto.EisApiHistoryDto;
import com.epay.transaction.externalservice.request.eis.EISEncryptedRequest;
import com.epay.transaction.externalservice.request.eis.ecom.EISEComPayloadRequest;
import com.epay.transaction.externalservice.request.eis.ecom.EISEComRequest;
import com.epay.transaction.externalservice.request.eis.gst.EISGstRequest;
import com.epay.transaction.externalservice.response.eis.ecom.ChannelDetail;
import com.epay.transaction.externalservice.response.eis.ecom.EisEcomFinalResponse;
import com.epay.transaction.externalservice.response.eis.ecom.EisGstinResponse;
import com.epay.transaction.externalservice.response.eis.ecom.GSTResponse;
import com.epay.transaction.model.request.CardVerificationRequest;
import com.epay.transaction.model.request.EncryptedRequest;
import com.epay.transaction.model.request.GstInVerificationRequest;
import com.epay.transaction.model.response.EncryptedResponse;
import com.epay.transaction.model.response.TransactionResponse;
import com.epay.transaction.util.EPayIdentityUtil;
import com.epay.transaction.util.EncryptionDecryptionUtil;
import com.epay.transaction.util.TransactionConstant;
import com.epay.transaction.util.TransactionUtil;
import com.epay.transaction.util.dcms.eis.DCMSEISEncryptionDecryptionUtil;
import com.epay.transaction.util.enums.EisApiHistoryType;
import com.epay.transaction.validator.EisValidator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import lombok.AllArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.security.PublicKey;
import java.util.Collections;

import static com.epay.transaction.util.EncryptionDecryptionUtil.encryptValue;
import static com.epay.transaction.util.TransactionConstant.*;
import static com.epay.transaction.util.TransactionUtil.toJson;

/**
 * Class Name: SbiEisService
 * <p>
 * Description: Provide Eis Services
 * <p>
 * Copyright (c) [2024] [State Bank of India]
 * All rights reserved.
 * <p>
 * Author:@V0000001(Shilpa Kothre)
 * Version:1.0
 */
@Service
@AllArgsConstructor
public class SbiEisService {

    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());
    private final SbiEisDao sbiEisDao;
    private final TransactionConfig transactionConfig;
    private final ObjectMapper objectMapper;
    private final EisValidator eisValidator;


    /**
     * Method name :verifyGSTInNumber
     * Description :This method is being used to validate gstIn number from eis-service.
     *
     * @param request EncryptedRequest String of gstIn number
     * @return TransactionResponse with GstInNumberResponse
     */
    public TransactionResponse<EncryptedResponse> verifyGSTInNumber(EncryptedRequest request) {
        //Step 1 : validate encrypt request
        eisValidator.validateCardNumberRequest(request.getEncryptedRequest());
        //Step 2 : Get Merchant aesKey
        logger.info("GstIn number encrypt request {}", request);
        String aesKeyTxn = sbiEisDao.getEncryptedAESKey();
        logger.debug("Fetch aesKey for GstIn number  {}", aesKeyTxn);
        //Step 3 : Decrypt request
        GstInVerificationRequest gstInVerificationRequest = TransactionUtil.buildRequestByEncryptRequest(request.getEncryptedRequest(), aesKeyTxn, GstInVerificationRequest.class);
        //Step 4 : validate gstn Number
        eisValidator.validateGstInNumber(gstInVerificationRequest.getGstInNumber());
        //Step 5 : validate email request
        eisValidator.validateEmailId(gstInVerificationRequest.getEmail());


        String aesKey = TransactionUtil.generateRandomKey();
        String eisEncryptedRequest = buildEISGstEncryptedRequest(gstInVerificationRequest.getGstInNumber(), aesKey);
        GSTResponse gstnResponse = sbiEisDao.verifyGSTInNumber(aesKey, getEncryptedPublicKey(aesKey), eisEncryptedRequest, gstInVerificationRequest.getGstInNumber());
        // Step 5: Encrypt the response
        logger.debug("Fetch gstnResponse :{} ", gstnResponse);
        EisGstinResponse eisGstinResponse = EisGstinResponse.builder().status(gstnResponse.getGstinDetails().getDetailsofgst().getActiveStatus()).gstin(gstnResponse.getGstinDetails().getDetailsofgst().gstin).build();
        String encryptedResponseList = encryptValue(aesKeyTxn, toJson(eisGstinResponse));
        logger.debug("Encrypted Response of GsnInNumber :{}", encryptedResponseList);
        //step 6: save gstin request and response
        EisApiHistoryDto eisApiHistoryDto = buildEISApiRequest(gstInVerificationRequest, gstnResponse);
        sbiEisDao.saveEisHistory(eisApiHistoryDto);

        EncryptedResponse response = EncryptedResponse.builder().encryptedResponse(EncryptionDecryptionUtil.encryptValue(aesKeyTxn, TransactionUtil.toJson(eisGstinResponse))).build();
        return TransactionResponse.<EncryptedResponse>builder().data(Collections.singletonList(response)).status(TransactionConstant.RESPONSE_SUCCESS).build();

    }

    /**
     * Method name : buildEISGstEncryptedRequest
     * Description : Build encrypted gstnIn number request
     *
     * @param gstInNumber: gstInNumber for create Encrypted request
     * @param aesKey:      aseKey for Eis Service
     * @return String of buildEncryptedRequest
     */
    private String buildEISGstEncryptedRequest(String gstInNumber, String aesKey) {
        try {
            EISGstRequest gstRequest = buildEISGstRequest(gstInNumber);
            logger.info("gstRequest:" + gstRequest);

            String gstRequestString = objectMapper.writeValueAsString(gstRequest);
            logger.info("gstRequestString:" + gstRequestString);

            String encryptedGstRequest = DCMSEISEncryptionDecryptionUtil.encryptGst(gstRequestString, aesKey);


            String digitalSignData = DCMSEISEncryptionDecryptionUtil.signSHA256RSA(gstRequestString, transactionConfig.getEisPrivateKey());


            return buildEISGstEncryptedRequest(encryptedGstRequest, gstRequest.getRequestReferenceNumber(), digitalSignData);
        } catch (JsonProcessingException e) {
            logger.error("Error in creating EISGSTEncryptedRequest {} for gstInNumber {}", e.getMessage(), gstInNumber);
        }
        return StringUtils.EMPTY;
    }

    /**
     * Method name : buildEISGstRequest
     * Description : Build eis request for gstnIn number
     *
     * @param gstIn: gstInNumber for create EISGst request
     * @return EISGstRequest of gstIn number
     */
    private static EISGstRequest buildEISGstRequest(String gstIn) {
        String reqRefNumber = TransactionUtil.generateReqRefNo(SOURCE_ID_EY, CLIENT_Id);
        return EISGstRequest.builder().requestReferenceNumber(reqRefNumber).gstIn(gstIn).build();
    }

    /**
     * Method name : buildEISGstEncryptedRequest
     * Description : Build eis encrypt request for encrypted gstIn request
     *
     * @param encryptedGstRequest: gstInNumber for create eisEncrypted request
     * @param reqRefNumber:        gstInNumber for create eisEncrypted request
     * @param digitalSignData:     digitalSignData for create eisEncrypted request
     * @return string of build eis encrypt request
     */
    private String buildEISGstEncryptedRequest(String encryptedGstRequest, String reqRefNumber, String digitalSignData) {
        try {
            EISEncryptedRequest eisEncryptedRequest = EISEncryptedRequest.builder().request(encryptedGstRequest).requestReferenceNumber(reqRefNumber).digiSignData(digitalSignData).build();
            return objectMapper.writeValueAsString(eisEncryptedRequest);
        } catch (JsonProcessingException e) {
            logger.error("Error in creating EISEncryptedRequest {}", e.getMessage());
        }
        return StringUtils.EMPTY;
    }

    /**
     * Method name : getEncryptedPublicKey
     * Description : Build encrypted public key for aeskey of eis-service.
     *
     * @param aesKey: aesKey for create encrypted public key
     * @return string of encrypted public key
     */
    private String getEncryptedPublicKey(String aesKey) {
        PublicKey publicKey = DCMSEISEncryptionDecryptionUtil.getEISPublicKey(transactionConfig.getEisPublicKeyPath());
        return DCMSEISEncryptionDecryptionUtil.encryptPublicKey(aesKey, publicKey);
    }

    /**
     * Method name :verifyCardEComFlag
     * Description : This method is being used to validate ecom card number from eis-service
     *
     * @param request EncryptedRequest String of GstIn number
     * @return TransactionResponse with EcomCardNumberResponse
     */
    public TransactionResponse<EncryptedResponse> verifyCardEComFlag(EncryptedRequest request) {

        //Step 1 : validate encrypt request
        eisValidator.validateCardNumberRequest(request.getEncryptedRequest());
        //Step 2 : Get Merchant MEK
        logger.info("Card ecom encrypt request {}", request);
        String aesKeyTxn = sbiEisDao.getEncryptedAESKey();
        logger.debug("Fetch aesKey for card ecom  {}", aesKeyTxn);
        //Step 3 : Decrypt request
        CardVerificationRequest cardVerificationRequest = TransactionUtil.buildRequestByEncryptRequest(request.getEncryptedRequest(), aesKeyTxn, CardVerificationRequest.class);
        //Step 4 : validate request
        eisValidator.validateCardNumber(cardVerificationRequest.getCardNumber());
        String aesKey = TransactionUtil.generateRandomKey();

        String eisEComRequest = buildEISEComRequest(cardVerificationRequest.getCardNumber(), aesKey);
        TransactionResponse<ChannelDetail> channelDetail = sbiEisDao.getDCMSEISEComInfo(aesKey, generateEISEncryptionKey(aesKey), eisEComRequest);
        logger.debug("Fetch ecom card response :{} ", channelDetail);

        // Step 5: save ecom request and response
        EisApiHistoryDto eisApiHistoryDto = buildEisEComRequest(cardVerificationRequest, channelDetail);
        sbiEisDao.saveEisHistory(eisApiHistoryDto);

        EisEcomFinalResponse eisEcomFinalResponse = EisEcomFinalResponse.builder().ecomFlage(channelDetail.getData().getFirst().getFlag()).build();
        //step 7:encrypt response
        EncryptedResponse response = EncryptedResponse.builder().encryptedResponse(EncryptionDecryptionUtil.encryptValue(aesKeyTxn, TransactionUtil.toJson(eisEcomFinalResponse))).build();
        return TransactionResponse.<EncryptedResponse>builder().data(Collections.singletonList(response)).status(TransactionConstant.RESPONSE_SUCCESS).build();
    }

    /**
     * Method name : generateEISEncryptionKey
     * Description : Build encrypted key for aeskey of eis-service.
     *
     * @param aesKey: aesKey for create encrypted  key
     * @return string of encrypted key
     */
    private String generateEISEncryptionKey(String aesKey) {
        PublicKey publicKey = DCMSEISEncryptionDecryptionUtil.getEISPublicKey(transactionConfig.getEisPublicKeyPath());
        return DCMSEISEncryptionDecryptionUtil.encryptPublicKey(aesKey, publicKey);
    }

    /**
     * Method name : buildEISEComRequest
     * Description : Build eis ecom request for card number and aesk key of eis-service
     *
     * @param cardNumber: cardNumber for create eis ecom request
     * @param aesKey:     aesKey for build eis ecom request
     * @return string of eis ecom request
     */
    private String buildEISEComRequest(String cardNumber, String aesKey) {
        try {
            EISEComRequest eISEComRequest = buildDCMSRequest(cardNumber);
            logger.info("eISEComRequest:{}" + eISEComRequest);
            String plainObjString = objectMapper.writeValueAsString(eISEComRequest);
            logger.info("plainObjString:{}" + plainObjString);

            String encryptedGstRequest = DCMSEISEncryptionDecryptionUtil.encryptGst(plainObjString, aesKey);

            String digitalSignData = DCMSEISEncryptionDecryptionUtil.signSHA256RSA(plainObjString, transactionConfig.getEisPrivateKey());

            return buildEISGstEncryptedRequest(encryptedGstRequest, eISEComRequest.getRequestReferenceNumber(), digitalSignData);

        } catch (JsonProcessingException e) {
            logger.error("Error in creating EISEncryptedRequest   for cardNumber {} {} ", cardNumber, e.getMessage());
        }
        return StringUtils.EMPTY;
    }

    /**
     * Method name : buildDCMSRequest
     * Description : Build eis ecom request for card number
     *
     * @param cardNumber: cardNumber for create eis ecom request
     * @return EISEComRequest of eis ecom request
     */
    private static EISEComRequest buildDCMSRequest(String cardNumber) {
        String reqRefNumber = TransactionUtil.generateReqRefNo(TransactionConstant.SOURCE_ID_EY, TransactionConstant.CLIENT_Id);
        EISEComPayloadRequest eisEComPayloadRequest = EISEComPayloadRequest.builder().cardNumber(cardNumber).build();
        return EISEComRequest.builder().requestReferenceNumber(reqRefNumber).eisPayload(eisEComPayloadRequest).build();
    }

    private EisApiHistoryDto buildEISApiRequest(GstInVerificationRequest gstInVerificationRequest, GSTResponse gstResponse) {
        return EisApiHistoryDto.builder().gstIn(gstInVerificationRequest.getGstInNumber())
                .requestType(String.valueOf(EisApiHistoryType.GSTN))
                .email(gstInVerificationRequest.getEmail())
                .mId(EPayIdentityUtil.getUserPrincipal().getMId())
                .sbiOrderRefNumber(EPayIdentityUtil.getUserPrincipal().getOrderRef())
                .requestJson(toJson(gstInVerificationRequest))
                .responseJson(toJson(gstResponse.getGstinDetails()))
                .build();
    }

    private EisApiHistoryDto buildEisEComRequest(CardVerificationRequest cardVerificationRequest, TransactionResponse<ChannelDetail> channelDetail) {
        return EisApiHistoryDto.builder()
                .requestType(String.valueOf(EisApiHistoryType.ECOM))
                .mId(EPayIdentityUtil.getUserPrincipal().getMId())
                .sbiOrderRefNumber(EPayIdentityUtil.getUserPrincipal().getOrderRef())
                .requestJson(toJson(cardVerificationRequest))
                .responseJson(toJson(channelDetail.getData()))
                .build();
    }

}
