package com.epay.transaction.externalservice;

import com.epay.transaction.externalservice.request.payment.push.merchant.PaymentPushVerificationRequest;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import static com.sbi.epay.notification.client.ApiClient.prepareHttpHeaders;

/**
 * Class Name: PaymentPushVerificationClient
 * *
 * Description: This class is implemented to deal with merchant push verification client
 * *
 * Author: GIREESH M
 * <p>
 * Copyright (c) 2025 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Component
public class PaymentPushVerificationClient {

    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());

    /**
     * This method is used to send push request to return url.
     * @param encryptedPaymentPushData encrypted data
     * @param postUrl payment verification response.
     * @return boolean.
     */
    public boolean postPaymentPushVerification(String encryptedPaymentPushData, String postUrl){
        logger.info("Preparing URL for payment push verification response : {}, {}", encryptedPaymentPushData, postUrl);
        PaymentPushVerificationRequest paymentPushVerificationRequest = PaymentPushVerificationRequest.builder()
                .encryptedPushVerificationRequest(encryptedPaymentPushData)
                .build();

        return Boolean.TRUE.equals(WebClient.builder().build()
                .post()
                .uri(postUrl)
                .headers(httpHeaders -> httpHeaders.addAll(prepareHttpHeaders()))
                .bodyValue(paymentPushVerificationRequest)
                .exchangeToMono(this::handleResponse)
                .block());
    }

    private Mono<Boolean> handleResponse(ClientResponse clientResponse){
        return Mono.just(clientResponse.statusCode().is2xxSuccessful());
    }
}
