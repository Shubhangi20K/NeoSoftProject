package com.epay.transaction.externalservice.request.payment;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.gson.annotations.SerializedName;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * Class Name: PaymentRequestResendCard
 * *
 * Description: Card Payment Service
 * *
 * Author: V1014800 - Ranjan Kumar
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PaymentRequestResendCard  {

    private String atrn;
    private String pgtransactionid;
    private String apiType;
}
