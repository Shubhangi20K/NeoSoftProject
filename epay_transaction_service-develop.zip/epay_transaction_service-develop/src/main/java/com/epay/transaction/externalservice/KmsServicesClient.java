package com.epay.transaction.externalservice;


import com.epay.transaction.client.ApiClient;
import com.epay.transaction.externalservice.request.kms.KMSAPIKeyValidationRequest;
import com.epay.transaction.externalservice.response.kms.KMSEncryptionKeysResponse;
import com.epay.transaction.model.response.TransactionResponse;
import com.sbi.epay.logging.utility.LoggerFactoryUtility;
import com.sbi.epay.logging.utility.LoggerUtility;
import org.springframework.core.ParameterizedTypeReference;

/**
 * Class Name: KmsServicesClient
 * *
 * KmsServicesClient is responsible for validating API KeyId And Scrt with the Kms Service
 *  and retrieves the encryption key for a given merchant ID
 * Author: Shubhangi kurlay
 * Copyright (c) 2024 [State Bank of India]
 * All rights reserved
 * *
 * Version:1.0
 */
public class KmsServicesClient extends ApiClient {

    public static final String GET_ENCRYPTION_KEY = "/key/encryption/";
    public static final String API_KEY_VALIDATION = "/key/validate/api";
    private final LoggerUtility logger = LoggerFactoryUtility.getLogger(this.getClass());

    /**
     * Constructor to initialize KmsServicesClient with base URL.
     *
     * @param baseUrl    Base URL of the admin service.
     * @param corsOrigin
     */
    public KmsServicesClient(String baseUrl, String corsOrigin) {
        super(baseUrl, corsOrigin);
    }

    /**
     * Validates the merchant API key ID and scrt.
     *
     * @param merchantApiKeyId    The merchant's API key ID.
     * @param merchantApiKeySecret The merchant's API key scrt.
     * @return TransactionResponse<String> containing the validation result.
     */
    public TransactionResponse<String> validateAPIKeyIdAndSecret(String merchantApiKeyId, String merchantApiKeySecret) {
        logger.info("Validating API Key ID and Secret for Merchant API Key ID: {}", merchantApiKeyId);
        return post(API_KEY_VALIDATION, KMSAPIKeyValidationRequest.builder().apiKey(merchantApiKeyId).apiKeySecret(merchantApiKeySecret).build(), new ParameterizedTypeReference<>() {});
    }

    /**
     * Retrieves the encryption key for a given merchant ID.
     *
     * @param mId The merchant ID.
     * @return TransactionResponse<KMSEncryptionKeysResponse> containing the encryption key details.
     */
    public TransactionResponse<KMSEncryptionKeysResponse> getEncryptionKeys(String mId) {
        logger.info("Fetching encryption keys for Merchant ID: {}", mId);
        return get(GET_ENCRYPTION_KEY + mId, new ParameterizedTypeReference<>() {});
    }
}
